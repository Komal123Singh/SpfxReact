import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import styles from './savedata.module.scss';
import * as strings from 'HelloWorldWebPartStrings';
import HelloWorld from './components/HelloWorld';
import { IHelloWorldProps } from './components/IHelloWorldProps';

import {​​​SPHttpClient,SPHttpClientResponse}​​​ from'@microsoft/sp-http';


export interface IHelloWorldWebPartProps {
  description: string;
}

export default class HelloWorldWebPart extends BaseClientSideWebPart<IHelloWorldWebPartProps> {
  
   show=()=>{
    
      var Url=this.context.pageContext.web.absoluteUrl;
      console.log(Url);
  var restUrl=Url+"/_api/web/lists/getbytitle('Spfxlist')/items"
     this.context.spHttpClient.post(restUrl, SPHttpClient.configurations.v1,{  
      headers: {  
        'Accept': 'application/json;odata=nometadata',  
        'Content-type': 'application/json;odata=nometadata',  
        'odata-version': ''  
      },  
      body: JSON.stringify({  
        'UserRole': (this.domElement.querySelector('#text1') as HTMLInputElement).value,
         'ReasonForRequest': (this.domElement.querySelector('#text2') as HTMLSelectElement).value,
           'Title': (this.domElement.querySelector('#text3') as HTMLSelectElement).value,
         'EmployeeName': (this.domElement.querySelector('#text4') as HTMLInputElement).value,
         'EmployeeEmail': (this.domElement.querySelector('#text5') as HTMLInputElement).value,
          'User_x0020_ID': (this.domElement.querySelector('#text6') as HTMLInputElement).value,
         'SystemName': (this.domElement.querySelector('#text7') as HTMLInputElement).value,
         'SystemNumber': (this.domElement.querySelector('#text8') as HTMLInputElement).value,
        
        
      })  
    }).then((response)=>{return response.json()}).then((data)=>{console.log(data)});
    }
    
public BindAllMethods=()=>{
  this.domElement.querySelector('#btn').addEventListener('click',this.show);
   };

    
  public render(): void {
    this.domElement.innerHTML+=`<div>
    <h4 class="${styles.h}">Form For Submission</h4>
    <div class="${styles.parent}">
    <div class="${styles.child}">
    <div class="${styles.subchild}">
    <div>
    <label class="${styles.lbl1}">User Role:</label>
    </div>
    </div>
    <div class="${styles.subchild}">
    <div>
    <input type="text" class="${styles.txt}" id="text1">
    </div>
    </div>
    </div>
    </div>
    <div class="${styles.parent}">
    <div class="${styles.child}">
    <div class="${styles.subchild}">
    <div>
    <label class="${styles.lbl1}">Reason For Request:</label>
    </div>
    </div>
    <div class="${styles.subchild}">
    <div>
    <select class="${styles.sett}" id="text2">
    <option>Select</option>
<option>New Creation</option>
<option>Role Modification
</option>
<option>User Deactivation</option>
<option>User Remove</option>

  </select>
    </div>
    </div>
    </div>
    </div>
    <div class="${styles.parent}">
    <div class="${styles.child}">
    <div class="${styles.subchild}">
    <div>
    <label class="${styles.lbl1}">Location:</label>
    </div>
    </div>
    <div class="${styles.subchild}">
    <div>
    <select class="${styles.sett}" id="text3">
    <option>Select</option>
<option>Noida</option>
<option>Lucknow</option>
<option>Jaipur</option>
<option>Ahemdabad</option>

  </select>
    </div>
    </div>
    </div>
    </div>
    <div class="${styles.parent}">
    <div class="${styles.child}">
    <div class="${styles.subchild}">
    <div>
    <label class="${styles.lbl1}">Employee Name:</label>
    </div>
    </div>
    <div class="${styles.subchild}">
    <div>
    <input type="text" class="${styles.txt}" id="text4">
    </div>
    </div>
    </div>
    </div>
    <div class="${styles.parent}">
    <div class="${styles.child}">
    <div class="${styles.subchild}">
    <div>
    <label class="${styles.lbl1}">Employee Email:</label>
    </div>
    </div>
    <div class="${styles.subchild}">
    <div>
    <input type="text" class="${styles.txt}" id="text5">
    </div>
    </div>
    </div>
    </div>
    <div class="${styles.parent}">
    <div class="${styles.child}">
    <div class="${styles.subchild}">
    <div>
    <label class="${styles.lbl1}">User ID:</label>
    </div>
    </div>
    <div class="${styles.subchild}">
    <div>
    <input type="text" class="${styles.txt}" id="text6">
    </div>
    </div>
    </div>
    </div>
    <div class="${styles.parent}">
    <div class="${styles.child}">
    <div class="${styles.subchild}">
    <div>
    <label class="${styles.lbl1}">System Name:</label>
    </div>
    </div>
    <div class="${styles.subchild}">
    <div>
    <input type="text" class="${styles.txt}" id="text7">
    </div>
    </div>
    </div>
    </div>
    
    

    <div class="${styles.parent}">
    <div class="${styles.child}">
    <div class="${styles.subchild}">
    <div>
    <label class="${styles.lbl1}">System Number:</label>
    </div>
    </div>
    <div class="${styles.subchild}">
    <div>
    <input type="text" class="${styles.txt}" id="text8">
    </div>
    </div>
    </div>
    </div>
    <div class="${styles.parent}">
    <div class="${styles.child}">
    <div class="${styles.subchild}">
    <div>
    <button type="button"  id="btn" class="${styles.btn}">show</button>
    </div>
    </div> 
    </div>
 
   </div>

    </div>`;
    this.BindAllMethods();
  
  };
  // //   const element: React.ReactElement<IHelloWorldProps> = React.createElement(
  // //     HelloWorld,
  // //     {
  // //       description: this.properties.description
  // //     }
  // //   );

  // //   ReactDom.render(element, this.domElement);
  // // }

  // protected onDispose(): void {
  //   ReactDom.unmountComponentAtNode(this.domElement);
  // }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
