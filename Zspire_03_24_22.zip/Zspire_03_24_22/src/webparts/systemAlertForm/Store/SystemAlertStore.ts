import { EventEmitter } from 'events';
import { Dispatcher } from 'simplr-flux';

let savedResult;
let EditFormDetails=[];
let CategorylistitemDetails=[];
class SystemAlertStore extends EventEmitter {

    constructor() {
        super();
    }
    storeChange(action) {
        switch (action.action.type) {
            case 'getEditFormDetailsType':
                {
                    debugger;
                    EditFormDetails = action.action.response;
                    this.emit('getEditFormDetailschange');
                    break;
                }
                case 'insertResultType':
                    {
                        savedResult = action.action.response;
                        this.emit('insertResultchange');
                        break;
                    }
               
            }
        }
        getEditFormDetailsStoreValue() {
            return EditFormDetails;
        }
        getInserResultStoreValue() {
            return savedResult;
        }
       
}
let objSystemAlertStore = new SystemAlertStore();

Dispatcher.register(objSystemAlertStore.storeChange.bind(objSystemAlertStore));

export default objSystemAlertStore