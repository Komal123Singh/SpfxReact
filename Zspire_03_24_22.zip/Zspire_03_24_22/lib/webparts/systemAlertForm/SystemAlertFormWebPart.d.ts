import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface ISystemAlertFormWebPartProps {
    description: string;
    logo: string;
    exitLocation: string;
}
export default class SystemAlertFormWebPart extends BaseClientSideWebPart<ISystemAlertFormWebPartProps> {
    onInit(): Promise<void>;
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=SystemAlertFormWebPart.d.ts.map