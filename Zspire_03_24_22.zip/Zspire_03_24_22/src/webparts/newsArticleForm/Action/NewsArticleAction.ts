import { Dispatcher } from 'simplr-flux';
import { sp } from '@pnp/sp';
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/fields';
import '@pnp/sp/attachments';
import "@pnp/sp/sputilities";
import { IEmailProperties } from "@pnp/sp/sputilities";
import { Attachments } from '@pnp/sp/attachments';
let ListName = 'Z-SPIRE Home Page';


const getEditFormDetails = (Id) => {
   
    sp.web.lists.getByTitle(ListName).items.getById(Id).select('*','AttachmentFiles').expand('AttachmentFiles').get().then(res => {  
    Dispatcher.dispatch({ type: 'getEditFormDetailsType', response: res });
    }).catch(error => {
      console.log('getEditFormDetails ' + error);
    });
  }
  export { getEditFormDetails };

  const saveForm = (DocStatus, CreationDate,DocAuthor,ArticleTitle,Body,Attachments,DocType,Created,lncreated,lncreatedby,lnmodified,lnmodifiedby,year,Ehrev,editor,Ehdate,uploadedRichTextFiles) => {
     
    sp.web.lists.getByTitle(ListName).items.add({
  
      'DocStatus': DocStatus,
      'CreationDate':CreationDate,
      'DocAuthor':DocAuthor,
      'Title0':ArticleTitle,
      'Body':Body,
      'Title':DocType,
      'Created': Created,
      'LNCreated':lncreated,
      'LNCreatedBy':lncreatedby,
      'LNModified':lnmodified,
      'LNModifiedBy':lnmodifiedby,
      'Year':year,
      'EhRev':Ehrev,
      'EhEditor':editor,
      'EhDate':Ehdate,
      
    }).then(res => {

      if (res.data != undefined) {
        if (res != null && uploadedRichTextFiles.length > 0) {
            insertAttachRichTextFile(res, uploadedRichTextFiles, 0, Body,Attachments,res.data.Id );
        }
          debugger;
          if (Attachments.length != 0) {
              debugger;
              res.item.attachmentFiles.addMultiple(Attachments)
                  .then(resattach => {
                      if (res.data != undefined) {
                          Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
                      }
                  });
          }
          else {
              Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
          }
      }
  }).catch(error => {
      console.log('saveForm ' + error);
  });
}
  export { saveForm };
  
  // Update Existing Item
  //let addAttach=Attachments[];
  const updateForm = (uniqueId, DocStatus, CreationDate, DocAuthor, ArticleTitle, Body, Attachments,EditAttachments,delattach,lnmodified,lnmodifiedby,Ehrev,editor,Ehdate,uploadedRichTextFiles) => {
     
    sp.web.lists.getByTitle(ListName).items.getById(uniqueId).update({
  
      'DocStatus': DocStatus,
      'CreationDate':CreationDate,
      'DocAuthor':DocAuthor,
      'Title0':ArticleTitle,
      'Body':Body,
      'LNModified':lnmodified,
      'LNModifiedBy':lnmodifiedby,
      'EhRev':Ehrev,
      'EhEditor':editor,
      'EhDate':Ehdate,
      
      
    }).then(res => {
      debugger;
      if (res.data != undefined) {
        if (res != null && uploadedRichTextFiles.length > 0) {
            insertAttachRichTextFile(res, uploadedRichTextFiles, 0, Body,Attachments,uniqueId );
        }
        else {
            Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
        }
          debugger;
          if (Attachments.length != 0) {

              if (EditAttachments.length != 0) {
                  res.item.attachmentFiles.deleteMultiple(...delattach)
                      .then(resdel => {
                          if (res.data != undefined) {
                              res.item.attachmentFiles.addMultiple(Attachments)
                                  .then(resadd => {
                                      if (res.data != undefined) {
                                          Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
                                      }
                                  });
                          }
                      });
              }
              if (delattach.length != 0) {
                  res.item.attachmentFiles.deleteMultiple(...delattach)
                      .then(resdel => {
                          if (res.data != undefined) {
                              res.item.attachmentFiles.addMultiple(Attachments)
                                  .then(resadd => {
                                      if (res.data != undefined) {
                                          Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
                                      }
                                  });
                          }
                      });
              }
              else {
                  res.item.attachmentFiles.addMultiple(Attachments)
                      .then(resaddattach => {
                          if (res.data != undefined) {
                              Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
                          }
                      });
              }
          }

          else {
              if (delattach.length != 0) {
                 
                  res.item.attachmentFiles.deleteMultiple(...delattach)
                      .then(resdell => {
                          if (resdell != undefined) {
                              Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
                          }
                      });
              }
              else {
                  Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
              }
                Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
          }
      }
  }).catch(error => {
      console.log('updateForm ' + error);
  });
}
export { updateForm };
const insertAttachRichTextFile = (results, files, itemId, Attachments0Rich,Attachments,responseId) => {
    debugger;
    let domparser = new DOMParser();
    let fileInfos = [];
    if (files != null) {
        for (let f of files) {
            let fileRead = new FileReader();
            fileRead.onloadend = (e) => {
              fileInfos.push({
                name: f.name,
                content: fileRead.result,
              });
                results.item.attachmentFiles.addMultiple(fileInfos).then(() => {
                    debugger;
                    results.item
                        .select('ID,AttachmentFiles,Body')
                        .expand('AttachmentFiles').get().then(async (results: any) => {
                            let itemID = results.ID;
                            let fileData = results.AttachmentFiles;
                            
                            let Attachments0 = results.Body;
                            // let Attachments0 = Attachments0Rich;

                            let parsedAttachments0 = domparser.parseFromString(Attachments0, 'text/html');
                            await Promise.all([

                                await parsedAttachments0.querySelectorAll('img').forEach((img) => {
                                    fileData.forEach((fData) => {
                                        img.getAttribute('data-file-name') === fData['FileName'] ? img.setAttribute('src', fData['ServerRelativeUrl'])
                                            : null;
                                              
                                    });
                                }),
                            ]);
                            updateRichItem(itemID, parsedAttachments0,Attachments,responseId);
                        });
                });
            };
            fileRead.readAsArrayBuffer(f);
        }
    }
}
export { insertAttachRichTextFile };

const updateRichItem = (itemID, parsedAttachments0,Attachments,responseId) => {
    let s = new XMLSerializer();
    debugger;
    let serializeAttachments0 = s.serializeToString(parsedAttachments0);
    sp.web.lists.getByTitle(ListName).items.getById(itemID).update({

        'Body': serializeAttachments0,
    }).then(res => {
        if (res.data != undefined) {
            // Dispatcher.dispatch({ type: 'insertResultType', response: itemID });
            if (Attachments.length != 0) {
                debugger;
                res.item.attachmentFiles.addMultiple(Attachments)
                    .then(resattach => {
                        if (res.data != undefined) {
                            Dispatcher.dispatch({ type: 'insertResultType', response: responseId });
                        }
                    });
            }
            else {
                Dispatcher.dispatch({ type: 'insertResultType', response: responseId });
            }
        }
    }).catch(error => {
        console.log('updateRichItem ' + error);
    });
}
export { updateRichItem };

