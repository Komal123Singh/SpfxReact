import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPHttpClient,SPHttpClientConfiguration,SPHttpClientResponse } from "@microsoft/sp-http";
import { IDropdownOption } from "office-ui-fabric-react";
export class Operation{
    public getListTitles(context:WebPartContext):Promise<IDropdownOption[]>{
        let url:string=
        context.pageContext.web.absoluteUrl+"/_api/web/lists?$select=Title";
        var listTitles:IDropdownOption[]=[];
        return new Promise<IDropdownOption[]>(async(resolve,reject)=>{
            context.spHttpClient.get(url,SPHttpClient.configurations.v1)
            .then((response:SPHttpClientResponse)=>{
            response.json().then((results:any)=>{
                console.log(results);
                results.value.map((result:any)=>{
                    listTitles.push({key:result.Title,text:result.Title})
                })
            })
            resolve(listTitles);
            },(error:any):void=>{reject("error occurred")})
        })
       
    }
}








// import {sp} from '@pnp/sp/presets/all';
// import { reject, result } from 'lodash';
// import { IDropdown, IDropdownOption } from 'office-ui-fabric-react';
// export class Operation{
//   public getListTitles():Promise<IDropdownOption[]>{
//       let listTitles:IDropdownOption[]=[]
//     return new Promise<IDropdownOption[]>(async(resolve,reject)=>{
//         sp.web.lists.select("Title")().then((results:any)=>{
//             console.log(results);
//             results.map((result:any)=>{
//                 listTitles.push({key:result.Title , text:result.Title})
//             })
//             resolve(listTitles);

//         },(error:any)=>{reject("error")})
//     })
//   }
// }