import { Dispatcher } from 'simplr-flux';
import {sp} from "@pnp/sp";
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/fields';
import '@pnp/sp/attachments';
import { IItem } from "@pnp/sp/items/types";
import { IAttachmentFileInfo } from "@pnp/sp/attachments";
import { SPHttpClient} from '@microsoft/sp-http';
import { uniqueId } from 'lodash';
let AttachmentFiles;
let Attachmentblob;
let uploadedRichTextFiles;
// Get Admin List Details
let absoluteUrl;



const getPaymentTypeDetails = async (TypeListID) => {
    ////debugger;
    await sp.web.lists.getById(TypeListID).items.get().then(res =>{
        console.log(res);
        Dispatcher.dispatch({ type: 'getPaymentTypevalues', response: res});
    }).catch(error => {
        console.log('getPaymentTypevalues', +error);
    });
};
export {getPaymentTypeDetails};
// Get the edit click details
const getEditFormDetails = (Id,LettersListID) => {
sp.web.lists.getById(LettersListID).items.getById(Id).select('*',
'AttachmentFiles',

'SendTo/ID','SendTo','SendTo/Title',
'CopyTo/ID','CopyTo','CopyTo/Title',
'BlindCopyTo/ID','BlindCopyTo','BlindCopyTo/Title',
'From/ID','From','From/Title','TempAdj/ID','TempAdj','TempAdj/Title').expand('AttachmentFiles','SendTo','CopyTo','BlindCopyTo','From','TempAdj').get().then(res => {
Dispatcher.dispatch({ type: 'getEditFormDetailsType', response:res});
}).catch(error => {
console.log('getEditFormDetails ' + error);
});
  };
export {getEditFormDetails};
//save assigntoclaim

const closeDialog = (uniqueId,LettersListID,GAPAgreeN,InsuredLastN,InsuredFirstN,VSCAdj,TempAdjuster) =>{
  sp.web.lists.getById(LettersListID).items.getById(uniqueId).update({
    'GAPAgreeNum': GAPAgreeN,
    'InsuredLastName': InsuredLastN,
    'InsuredFirstName': InsuredFirstN,
    'VSCAdj': "Assigned To Claim",
    'Temp_x0020_Adjuster': VSCAdj==""?"Pending":"Assigned",
  });
  };
 export {closeDialog};
// Get Input Details
const saveForm =

(absoluteUrl,LettersListID, GAPAgreeNum,NotesType,VSCAdj,InsuredStreetAddress,
  InsuredCity,InsuredState,InsZip,mrk_delete,SendTo,TempAdj,CopyTo,BlindCopyTo,From,Date,Title,Body,
  uploadedRichTextFiles,AttachmentFiles,TempAdjuster)=>
  
  {
sp.web.lists.getById(LettersListID).items.add({

'GAPAgreeNum': GAPAgreeNum,
'VSCAdj': VSCAdj,
'Temp_x0020_Adjuster': VSCAdj==""?"Pending":"Assigned",
// 'InsuredLastName': InsuredLastName,
// 'InsuredFirstName': InsuredFirstName,
'InsuredStreetAddress': InsuredStreetAddress,
'InsuredCity': InsuredCity,
'InsuredState': InsuredState,
'InsZip': InsZip,
'NotesType':NotesType,
'mrk_delete': mrk_delete,
'SendToId': {results:SendTo},
'TempAdjId':  TempAdj.length > 0 ? TempAdj[0] : null,
'CopyToId': {results:CopyTo},
'BlindCopyToId': {results:BlindCopyTo},
'FromId': From.length > 0 ? From[0] : null,
'Date': Date,
'Title': Title,
// 'Body': Body,
'Body': Body,
}).then(res => {

  if(res != null && uploadedRichTextFiles.length > 0) {
    insertAttachRichTextFile(res,LettersListID, uploadedRichTextFiles, 0);
    }
if (res.data != undefined && res.data != null) {
  if(AttachmentFiles.length > 0)
  {
  insertFormAttachment(res.data.Id,LettersListID, AttachmentFiles);
  } else 
  {
  Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
  }
  }


  // if(res.data !=undefined &&  uploadedRichTextFiles.length>0)
  // {
  // insertAttachRichTextFile(res.data.ID,uploadedRichTextFiles,Body);

  // }


}).catch(error => {
console.log('saveForm ' + error);
});
};
export {saveForm};

// Update Existing Item
const updateForm = (uniqueId,LettersListID,NotesType,GAPAgreeNum,InsuredLastName,InsuredFirstName,InsuredStreetAddress,InsuredCity,InsuredState,InsZip,mrk_delete,
  SendTo,TempAdj,CopyTo,BlindCopyTo,From,Date,Title,Body,uploadedRichTextFiles,AttachmentFiles,deleteFiles,Status)=> {

 sp.web.lists.getById(LettersListID).items.getById(uniqueId).update({

'GAPAgreeNum': GAPAgreeNum,

'InsuredLastName': InsuredLastName,
'InsuredFirstName': InsuredFirstName,
'NotesType':NotesType,
'InsuredStreetAddress': InsuredStreetAddress,
'InsuredCity': InsuredCity,
'InsuredState': InsuredState,
'InsZip': InsZip,
'mrk_delete': mrk_delete,
'Status':mrk_delete=="Yes"?"Delete":null,
'SendToId': {results:SendTo},
'TempAdjId':  TempAdj.length > 0 ? TempAdj[0] : null,
'CopyToId': {results:CopyTo},
'BlindCopyToId': {results:BlindCopyTo},
'FromId': From.length > 0 ? From[0] : null,
'Date': Date,
'Title': Title,
'Body': Body,
}).then( async(res)=> {
  if (AttachmentFiles != null) {
    const item: IItem = sp.web.lists.getById(LettersListID).items.getById(uniqueId);
    if (item != null) {
      let fileInfos: IAttachmentFileInfo[] = [];
      let AllfileNames = null;
      if (AttachmentFiles != null && AttachmentFiles != undefined && AttachmentFiles.length > 0) {
        AttachmentFiles.forEach(element => {
          fileInfos.push({
            name: element.name,
            content: element
          });
  
          if (AllfileNames != null && AllfileNames != '') {
            AllfileNames += ";" + element.name;
          }
          else {
            AllfileNames = element.name;
          }
        });
      }
      item.attachmentFiles.addMultiple(fileInfos).then(v => {

        console.log("Added files Uploaded");
        item.update({
          AttachmentFiles: AllfileNames
        }).then(allNames => {
          console.log('File upload updated and modified');
        });
      });
    }
  
   
       await res.item.attachmentFiles.addMultiple(AttachmentFiles).then(() => {
       
        res.item
          .select("ID,AttachmentFiles")
          .expand("AttachmentFiles")
          .get()
          .then(async (results: any) => {
            // let itemID = results.uniqueID;
            let itemID = results.uniqueId;
            let fileData = results.AttachmentFiles;
            console.log("update results", results);
          })
          .catch((e) => {
            console.log("files not uploaded", e);
          });
      });
      Dispatcher.dispatch({ type: 'insertResultType', response: res.data });

    }
    
    if(res != null) {
      updateAttachRichTextFile(res,LettersListID, uploadedRichTextFiles, uniqueId);
      }
})
.catch(error => {
console.log('updateForm ' + error);
});
  };
export {updateForm};

const insertFormAttachment = (uniqueID,LettersListID, AttachmentFiles) => {
  ////debugger;
  sp.web.lists.getById(LettersListID).items.getById(uniqueID).attachmentFiles.addMultiple(AttachmentFiles).
  then(res => {
  Dispatcher.dispatch({ type: 'insertResultType', response: uniqueID });
  }).catch(error => {
  console.log('insertFormAttachment ' + error);
  });
  };
  export { insertFormAttachment };
  
  
  const DeleteFormAttachment = (uniqueID,LettersListID, deleteFiles, AttachmentFiles) => {
  let deleteFilesNames = deleteFiles.map(a => a);
  sp.web.lists.getById(LettersListID).items.getById(uniqueID).attachmentFiles.deleteMultiple(...deleteFilesNames).
  then(res => {
  if (AttachmentFiles.length > 0) {
  insertFormAttachment(uniqueID,LettersListID, AttachmentFiles);
  }else {
  Dispatcher.dispatch({ type: 'insertResultType', response: uniqueID });
  }
  }).catch(error => {
  console.log('insertFormAttachment ' + error);
  });
  };
  export { DeleteFormAttachment };
  
/********* */
/*Rich*/
  const insertAttachRichTextFile = (results,LettersListID, files, itemId) => {
    let domparser = new DOMParser();
    let fileInfos = [];
    if (files != null) {
    for (let f of files) {
    let fileRead = new FileReader();
    fileRead.onloadend = (e) => {
    fileInfos.push({
    name: f.name,
    content: fileRead.result,
    });
    results.item.attachmentFiles.addMultiple(fileInfos).then(() => {
    results.item
    .select('ID,AttachmentFiles,Body')
    .expand('AttachmentFiles').get().then(async (results: any) => {
    let itemID = results.ID;
    let fileData = results.AttachmentFiles;
    
    let Body = results.Body;
    let parsedBody = domparser.parseFromString(Body,'text/html');
    await Promise.all([    
    await parsedBody.querySelectorAll('img').forEach((img) => {fileData.forEach((fData) => {
    img.getAttribute('data-file-name') ===fData['FileName']? img.setAttribute('src',fData['ServerRelativeUrl'])
    : null;});}),
    ]);
    updateRichItem(itemID ,LettersListID, parsedBody);
    });
    });};
    fileRead.readAsArrayBuffer(f);
    }}};
    export { insertAttachRichTextFile };
    

  const updateRichItem = (itemID ,LettersListID,parsedBody) => {
  let s = new XMLSerializer();
  let serializeBody = s.serializeToString(parsedBody);
  sp.web.lists.getById(LettersListID).items.getById(itemID).update({
  'Body':serializeBody,
  }).then(res => {
  if (res.data != undefined) {
  Dispatcher.dispatch({ type: 'insertResultType', response: itemID });
  }
  }).catch(error => {
  console.log('updateRichItem ' + error);
  });
  };
  export { updateRichItem };
  

const updateAttachRichTextFile = (results,LettersListID, files, itemId) => {
let domparser = new DOMParser();
sp.web.lists.getById(LettersListID).items.getById(itemId).select('ID,AttachmentFiles,Body')
.expand('AttachmentFiles').get().then(async (fileResults: any) => {
let fileData = fileResults.AttachmentFiles;
let aFiles = [...fileData];
let Body = fileResults.Body;
aFiles.forEach(async (aFile) => {
let isExists = files.some((f) => f['name'] === aFile['FileName']);
if (isExists) {
parseUpdate(fileData,LettersListID, itemId,Body);
}
});
if (files.length > 0) {
let fileInfos = [];
for (let f of files) {
let fileRead = new FileReader();
fileRead.onloadend = (e) => {
fileInfos.push({
name: f.name,
content: fileRead.result,
});
results.item.attachmentFiles.add(fileInfos).then(() => {
results.item.select('ID,AttachmentFiles,Body')
.expand('AttachmentFiles').get().then(async (results: any) => {
let itemID = results.ID;
let fileData = results.AttachmentFiles;
let Body = results.Body;
parseUpdate(fileData,LettersListID, itemId,Body);
let parsedBody = domparser.parseFromString(Body,'text/html');
await Promise.all([
await parsedBody.querySelectorAll('img').forEach((img) => {fileData.forEach((fData) => {
img.getAttribute('data-file-name') ===fData['FileName']? img.setAttribute('src',fData['ServerRelativeUrl'])
: null;});}),
]);

updateRichItem(itemID ,LettersListID,parsedBody);
});
});
};
fileRead.readAsArrayBuffer(f);
}}
else if (files.length == 0) {
parseUpdate(fileData,LettersListID, itemId,Body);
}});
};
export { updateAttachRichTextFile };

const parseUpdate = async (fileData,LettersListID, itemId,Body) => {
let fileLevlInfos = [];
let domparser = new DOMParser();
let parsedBody = domparser.parseFromString(Body,'text/html');
parsedBody.querySelectorAll('img').forEach((img) => {
let iName = img.getAttribute('data-file-name');
fileData.forEach((fData) => {
img.getAttribute('data-file-name') === fData['FileName']
? img.setAttribute('src', fData['ServerRelativeUrl']): null;
});
fileLevlInfos.indexOf(iName)
? console.log('exisitng file')
: fileLevlInfos.push(iName);
});
let item = await sp.web.lists.getById(LettersListID).items.getById(itemId);
if (fileData.length !== fileLevlInfos.length) {
let fInfos = [];
fileData.forEach((aFile) => {
fInfos.push(aFile['FileName']);
});
let ainfos = fInfos.join('","');
let infos = ainfos.toString();
fileLevlInfos.length !== 0
? fileLevlInfos.forEach((rFile) => {
fileData.forEach(async (aFile) => {
rFile === aFile['FileName']? console.log(''): await item.attachmentFiles
.getByName(aFile['FileName']).delete();});})
: await item.attachmentFiles.deleteMultiple(infos);
}
};
export { parseUpdate };
const getmrk_deleteDetails = (Title,LettersListID) => {
sp.web.lists.getById(LettersListID).fields.getByInternalNameOrTitle("mrk_delete").get().then(res => {
Dispatcher.dispatch({ type: 'getmrk_deleteChoiceType', response:res});
}).catch(error => {
console.log('getDetails ' + error);
});
};
export {getmrk_deleteDetails};


