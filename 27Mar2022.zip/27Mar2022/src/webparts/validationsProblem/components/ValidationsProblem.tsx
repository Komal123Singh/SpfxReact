import * as React from 'react';
import { useEffect } from 'react';
import { IValidationsProblemProps } from './IValidationsProblemProps';
import { IValidationsProblemStates } from './IValidationsProblemStates';
import './ValidationsProblem.css';
import * as ValidationsProblemAction from '../Action/ValidationsProblemAction';
import ValidationsProblemStore from '../Store/ValidationsProblemStore';
import { PeoplePicker, PrincipalType } from '@pnp/spfx-controls-react/lib/PeoplePicker';
import { DateTimePicker, DateConvention, TimeConvention } from '@pnp/spfx-controls-react/lib/dateTimePicker';
import { TextField, Dropdown, Checkbox, Label, Link, ThemeProvider, createTheme, PrimaryButton, Toggle, ChoiceGroup, IconButton, IIconProps, ShimmerElementsDefaultHeights, DefaultButton } from '@fluentui/react';
import { ComboBox, IComboBox, IComboBoxOption, IComboBoxStyles, SelectableOptionMenuItemType, IButtonStyles, ProgressIndicator } from '@fluentui/react';
import { Stack } from 'office-ui-fabric-react/lib/Stack';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { SecurityTrimmedControl, PermissionLevel, } from '@pnp/spfx-controls-react/lib/SecurityTrimmedControl';
import { SPPermission } from '@microsoft/sp-page-context';
import ViewValidationsProblem from './ViewValidationsProblem';
import { Separator } from '@fluentui/react/lib/Separator';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { DropdownMenuItemType, IDropdownStyles, IDropdownOption, Icon } from '@fluentui/react';
//import './ValidationsProblemCss.css';
import moment from 'moment';
import { sp } from "@pnp/sp/presets/all";
import { Dialog, DialogType, DialogFooter } from '@fluentui/react/lib/Dialog';
import { RichText } from "@pnp/spfx-controls-react/lib/RichText";
import "@pnp/sp/webs";
import "@pnp/sp/site-users/web";
import { IStyleSet, ILabelStyles, Pivot, PivotItem } from '@fluentui/react';
import { DatePicker, defaultDatePickerStrings } from '@fluentui/react';
import SunEditor from 'suneditor-react';
import 'suneditor/dist/css/suneditor.min.css';
import * as _ from '@microsoft/sp-lodash-subset';

const labelStyles: Partial<IStyleSet<ILabelStyles>> = {

  root: { marginTop: 10 },

};


// Global Variable
let isProbdescContent=false;
let isProposedresContent=false;
let isSuggestContent=false;
let isResolutionContent=false;
let isCommentsContent=false;
let absoluteUrl;
let relativeURL;
let uploadedProbdescRichTextFiles = [];
let uploadedProposedresRichTextFiles = [];
let uploadedResolutionRichTextFiles = [];
let uploadedSuggestRichTextFiles = [];
let uploadedCommentsRichTextFiles = [];
let arrAllPrevAttachments: string[] = [];
let prevUploadedFilesObjProgram = { arrPrevSavedFiles: [], arrPrevSavedFilesHtml: [], arrPrevTobeRemovedFiles: [], newUploadedFileArray: [], uploadedRichTextFiles: [] };
let prevUploadedFilesObjProposedres = { arrPrevSavedFiles: [], arrPrevSavedFilesHtml: [], arrPrevTobeRemovedFiles: [], newUploadedFileArray: [], uploadedRichTextFiles: [] };
let prevUploadedFilesObjResolution = { arrPrevSavedFiles: [], arrPrevSavedFilesHtml: [], arrPrevTobeRemovedFiles: [], newUploadedFileArray: [], uploadedRichTextFiles: [] };
let prevUploadedFilesObjComments = { arrPrevSavedFiles: [], arrPrevSavedFilesHtml: [], arrPrevTobeRemovedFiles: [], newUploadedFileArray: [], uploadedRichTextFiles: [] };
let prevUploadedFilesObjSuggest = { arrPrevSavedFiles: [], arrPrevSavedFilesHtml: [], arrPrevTobeRemovedFiles: [], newUploadedFileArray: [], uploadedRichTextFiles: [] };

let itemListName = "";
let loadSpinner = false;
let deleteFiles = [];
let keywordsarr = [];
let envtypearr = [];
let vendorarr = [];
let rootcausearr = [];
let arr = [];
let delAttachList;
let isAdmin = false;
let isReader = false;
let isEditor = false;
let sendUpdate = false;
let isEmailError = false;

let user;
let updateHistory = ["DocNumber", "DocType", "Title", "TestCase", "Status", "Priority", "ProjectArea", "Severity", "Keywords", "EnvType", "ApplicationArea", "ActivePlayers", "ReportedBy", "ReptDt", "ProjectManagers", "AssignedTo", "AssignedDt", "ApprovedBy", "ApprovedDt", "DateResolved", "SendTo"];
let updateHistoryValue = '';
let HistoryStore = '';
let actionBtnClicked = '';
let uniqueId = 0;
let pagemode = '';

let localActivePlayersEmail = [];
let localActivePlayersID = [];
let localActivePlayersUser = [];
let localApprovedByEmail = [];
let localApprovedByID = [];
let localApprovedByUser = [];
let localAssignedToEmail = [];
let localAssignedToID = [];
let localAssignedToUser = [];
let localProjectManagersEmail = [];
let localProjectManagersID = [];
let localProjectManagersUser = [];
let localReportedByEmail = [];
let localReportedByID = [];
let localReportedByUser = [];
let localSendToEmail = [];
let localSendToID = [];
let localSendToUser = [];
let isEditMode = false;
let isViewMode = false;
let ActivePlayersHistory = [];
let ReportedByHistory = [];
let ProjectManagersHistory = [];
let AssignedToHistory = [];
let ApprovedByHistory = [];
let SendToHistory = [];
let SendTomail = [];
let EditFormDetails;
let CurrentloggedinUserID = [];
let CurrentloggedinUserName = [];
let createtimearray = [];

let DocConfiglistvalues;  //For DocConfig form values
let Adminlistvalues; // For Admin form values
let Problemlistvalues; //For Problem list Values
const stackTokens = { childrenGap: 3 };
const addIcon: IIconProps = { iconName: 'Add' };
const subIcon: IIconProps = { iconName: 'CalculatorMultiply' };
var XMLserialize = new XMLSerializer();
const stylesSep = {
  root: [{
    selectors: {
      '::before':
        { background: '#23366f', height: '7px' },
    }
  }]
};

const dropdownStyles: Partial<IDropdownStyles> = {
  dropdownItems: { maxHeight: '130px' },
};

const myTheme = createTheme({
  palette: {
    themePrimary: '#23366f',
    themeLighterAlt: '#f3f4f9',
    themeLighter: '#cfd5e8',
    themeLight: '#a9b4d4',
    themeTertiary: '#6476a9',
    themeSecondary: '#344781',
    themeDarkAlt: '#203165',
    themeDark: '#1b2a55',
    themeDarker: '#141f3f',
    neutralLighterAlt: '#faf9f8',
    neutralLighter: '#f3f2f1',
    neutralLight: '#edebe9',
    neutralQuaternaryAlt: '#e1dfdd',
    neutralQuaternary: '#d0d0d0',
    neutralTertiaryAlt: '#c8c6c4',
    neutralTertiary: '#a19f9d',
    neutralSecondary: '#605e5c',
    neutralPrimaryAlt: '#3b3a39',
    neutralPrimary: '#323130',
    neutralDark: '#201f1e',
    black: '#000000',
    white: '#ffffff',
  }
});

const onFormatDate = (date?: Date): string => {
  return !date ? '' : (date.getMonth() + 1) + '/' + date.getDate() + '/' + (date.getFullYear() % 100);
};

const dialogContentProps = {
  type: DialogType.largeHeader,
  title: 'Confirmation',
  subText: 'Are you sure want to save?',
  // isBlocking: false,
};
const dialogSavedProps = {
  type: DialogType.normal,
  title: 'SUCCESSFUL',
  closeButtonAriaLabel: 'Close',
  // isBlocking: false,
  // subText: "",
};
const iconStyle = {
  root: {
    color: '#107c10',
    fontSize: '50px',
  }
};
const dialogModelContentProps = {
  type: DialogType.normal,
  title: <div className="text-center"><div><Icon styles={iconStyle} iconName="SkypeCircleCheck"></Icon></div><div>Success</div></div>,
  closeButtonAriaLabel: 'Close',
  subText: '',
  // isBlocking: false,
};

//Business Objects Starts //
export interface MyState {

}
//Business Objects End //

export default class ValidationsProblem extends React.Component<IValidationsProblemProps, IValidationsProblemStates> {
  constructor(prop) {
    super(prop);
    this.state = {
      isDisabled: '',

      isOnlySave: false,
      oldsendUpdateBody: '',
      sendUpdateBody: '',
      showUpdateBody: false,
      DocTypeChoice: [],
      PriorityChoice: [],
      SeverityChoice: [],
      JurisdictionChoice: [],
      ProjectAreaChoice: [],
      EnvironmentTypeChoice: [],
      VendorChoice: [],
      RootCauseChoice: [],
      ResponseData: [],
      createdby: null,
      createdon: null,
      FormNoteID: '',
      Date: null,
      UpdateKeywords: [],
      UpdateEnvType: [],
      UpdateRootCause: [],
      UpdateVendors: [],
      isModalClose: true,
      ishide: false,
      ProjectAreaLabel: '',
      docnumber: null,
      TitleValidations: '',
      DocTypeValidations: '',
      SeverityValidations: '',
      KeywordsValidations: '',
      ProjectAreaValidations: '',
      EnvTypeValidations: '',
      TestCaseValidations: '',
      EstCompDateValidations: '',
      isModaldialogClose: true,
      isvalidRecord: false,
      isSavedHidden: true,
      isgroups: false,
      FormAttachment: [],
      FormAttachmentNames: [],
      oldAttachments: '',
      Attachments: '',
      FormID: '',
      ActivePlayers: [],
      ActivePlayersDefaultItems: [],
      ActivePlayersUserItems: [],
      ApplicationArea: '',
      ApprovedBy: [],
      ApprovedDt: null,
      ApprovedByDefaultItems: [],
      ApprovedByUserItems: [],
      AssignedTo: [],
      AssignedDt: null,
      AssignedToDefaultItems: [],
      AssignedToUserItems: [],
      Comments: '',
      CreateDt: null,
      CreateTime: '',
      DateResolved: null,
      AbsoluteUrl: '',
      DocNumber: null,
      DocType: 'Validations',
      EditHistoryFields: '',
      EnvType: '',
      EmailIdList: [],
      EmailSendTo: [],
      EstCompDt: null,
      IONum: '',
      Keywords: '',
      PhaseDetect: '',
      PhaseIntro: '',
      Priority: '',
      Probdesc: '',
      ProjectArea: '',
      ProjectManagers: [],
      ProjectManagersDefaultItems: [],
      ProjectManagersUserItems: [],
      Proposedres: '',
      ReportedBy: [],
      ReportedByDefaultItems: [],
      ReportedByUserItems: [],
      ReptArea: '',
      ReptDt: new Date(),
      ReptMgr: '',
      Resolution: '',
      RootCause: '',
      SendTo: [],
      SendToDefaultItems: [],
      SendToUserItems: [],
      Severity: '',
      Status: 'Open',
      Suggest: '',
      TestCase: null,
      Title: '',
      Vendors: '',
      WONum: null,
      programUploadedExFiles: [],
      proposedresUploadedExFiles: [],
      resolutionUploadedExFiles: [],
      suggestUploadedExFiles: [],
      commentsUploadedExFiles: [],
      toDeleteAttachments:'',
    };
    absoluteUrl = this.props.context.pageContext.site.absoluteUrl;
    relativeURL = this.props.context.pageContext.site.serverRelativeUrl;
    SPComponentLoader.loadCss('https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
    SPComponentLoader.loadCss('https://cdn.jsdelivr.net/npm/suneditor@latest/dist/css/suneditor.min.css');
    SPComponentLoader.loadScript('https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js');
    SPComponentLoader.loadScript('https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js');
    SPComponentLoader.loadScript('https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js');
  }

  componentDidMount() {

    try {
      const url = window.location.href;
      const urlObject = new URL(url);
      uniqueId = urlObject.searchParams.get('itemID') == '' || urlObject.searchParams.get('itemID') == null ? 0 : parseInt(urlObject.searchParams.get('itemID'));
      pagemode = urlObject.searchParams.get('pageMode') == '' || urlObject.searchParams.get('pageMode') == null ? '' : urlObject.searchParams.get('pageMode');
      this.getDocTypeDetails();
      this.getAdminListValues();
      this.CurrentloggedinUser();
      //this.getProblemListValues();
      this.getLoggedUsersGroup();
      this.getFormDefaultDetails();
      this.setState({
        AbsoluteUrl: this.props.context.pageContext.web.absoluteUrl
      });
      if (uniqueId != 0) {
        if(pagemode == 'Edit'){
          isEditMode = true;
          isViewMode = false;
        }else{
        isEditMode = false;
        isViewMode = true;
        }
        ValidationsProblemStore.on('getEditFormDetailschange', this.assignEditFormDetailsStore);
        this.getEditFormDetailsComp();
        this.showResponse();
      }
      // else {
      // this.getFormDefaultDetails();
      // }
    }
    catch (e) {
      console.log('componentDidMount: ' + e);
    }
  }

  getLoggedUsersGroup = async () => {

    try {
      debugger;
      let LoggedUsersGroup = await sp.web.currentUser.groups();
      //currentUserDetails = await sp.web.currentUser();
      LoggedUsersGroup.map((groupItem) => {
        if (groupItem.Title == "USU_APPS_Validations_Admins") {
          isAdmin = true;
        } if (groupItem.Title == "USU_APPS_Validations_Editors") {
          isEditor = true;
        } if (groupItem.Title == "USU_APPS_Validations_Readers") {
          isReader = true;
        }
        this.setState({ isgroups: true });
      });
    } catch (e) {
      console.log('getLoggedUsersGroup' + e);
    }
  }

  getFormDefaultDetails = () => {
    try {
      debugger;
      ValidationsProblemStore.on('insertResultchange', this.assignInsertResultStore);

    } catch (e) {
      console.log('getFormDefaultDetails' + e);
    }
  }

  getEditFormDetailsComp = () => {
    try {
      ValidationsProblemAction.getEditFormDetails(uniqueId);

    } catch (e) {
      console.log('getEditFormDetailsComp ' + e);
    }
  }

  public EditClickBtn = () => {
    try {
      isEditMode = true;
      isViewMode = false;
      this.getEditFormDetailsComp();
    } catch (e) {
      console.log('EditClickBtn' + e);
    }
  }

  public ViewClickBtn = () => {
    try {
      isEditMode = false;
      isViewMode = true;
      this.getEditFormDetailsComp();
    } catch (e) {
      console.log('ViewClickBtn' + e);
    }
  }

  getDocTypeDetails = () => {
    try {
      ValidationsProblemStore.on('getDocTypechange', this.getDocTypeStore);
      ValidationsProblemAction.getDocDetails();
    }
    catch (e) {
         console.log('getDocTypeDetails' + e);
    }
  }

  public getDocTypeStore = () => {
    DocConfiglistvalues = ValidationsProblemStore.getDocConfigDetails();
    let DocTypeDropDown = [];
    DocConfiglistvalues.map((item) => {
      DocTypeDropDown.push({ key: item.DocType, text: item.DocType, id: 'DocType' });
    });
    this.setState({
      DocTypeChoice: DocTypeDropDown.sort((a, b) => (a.key > b.key) ? 1 : -1)
    });
  }




  public getProblemListValues = () => {
    debugger;
    try {
      ValidationsProblemStore.on('Problemlist', this.getProblemListValuesStore);
      if (uniqueId == 0) {
        ValidationsProblemAction.getProblemlistDetails();
      } else {
        this.insertForm();
      }
    }
    catch (e) {
      console.log('getProblemListValues' + e);
    }
  }

  public getProblemListValuesStore = () => {
    debugger;
    Problemlistvalues = ValidationsProblemStore.getProblemDetails();
    // const lngt = Problemlistvalues.length;
    console.log(Problemlistvalues);
    const lngt = Problemlistvalues[0].DocNumber;
    this.setState({ docnumber: lngt + 1 });
    this.insertForm();
    debugger;

  }

  public getAdminListValues = () => {
    try {
      ValidationsProblemStore.on('Adminlist', this.getAdminListValuesStore);
      ValidationsProblemAction.getAdminlistDetails();
    }
    catch (e) {
      console.log('getAdminListValues' + e);
    }
  }

  public getAdminListValuesStore = () => {
    Adminlistvalues = ValidationsProblemStore.getAdminDetails();

    //Getting Priority Values from AdminList
    let PriorityDropDown = [];
    let VarPriority;
    let splitPriorityarr = [];
    VarPriority = Adminlistvalues[0].Priority;
    splitPriorityarr = VarPriority != undefined ? VarPriority.split(/[\n,;]+/) : [];
    splitPriorityarr.map((item) => {
      PriorityDropDown.push({ key: item, text: item });
    });
    
    //Getting Severity Values from AdminList
    let SeverityDropDown = [];
    let VarSeverity;
    let splitSeverityarr = [];
    VarSeverity = Adminlistvalues[0].Severity;
    splitSeverityarr = VarSeverity != undefined ? VarSeverity.split(/[\n,;]+/) : [];
    splitSeverityarr.map((item) => {
      SeverityDropDown.push({ key: item, text: item });
    });

    //Getting Jurisdiction Values from AdminList
    let JurisdictionDropDown = [];
    let VarJurisdiction;
    let splitJurisdictionarr = [];
    VarJurisdiction = Adminlistvalues[0].Jurisdiction;
    splitJurisdictionarr = VarJurisdiction != undefined ? VarJurisdiction.split(/[\n,;]+/) : [];
    splitJurisdictionarr.map((item) => {
      JurisdictionDropDown.push({ key: item, text: item });
    });

    //Getting ProjectArea Values from AdminList
    let ProjectAreaDropDown = [];
    let VarProjectArea;
    let splitProjectAreaarr = [];
    VarProjectArea = Adminlistvalues[0].ProjectArea;
    splitProjectAreaarr = VarProjectArea != undefined ? VarProjectArea.split(/[\n,;]+/) : [];
    splitProjectAreaarr.map((item) => {
      ProjectAreaDropDown.push({ key: item, text: item });
    });

    //Getting EnvType Values from AdminList
    let EnvironmentTypeDropDown = [];
    let VarEnvironmentType;
    let splitEnvironmentTypearr = [];
    VarEnvironmentType = Adminlistvalues[0].EnvironmentType;
    splitEnvironmentTypearr = VarEnvironmentType != undefined ? VarEnvironmentType.split(/[\n,;]+/) : [];
    splitEnvironmentTypearr.map((item) => {
      EnvironmentTypeDropDown.push({ key: item, text: item });
    });

    //Getting Vendor Values from AdminList
    let VendorDropDown = [];
    let VarVendor;
    let splitVendorarr = [];
    VarVendor = Adminlistvalues[0].Vendors;
    splitVendorarr = VarVendor != undefined ? VarVendor.split(/[\n,;]+/) : [];
    splitVendorarr.map((item) => {
      VendorDropDown.push({ key: item, text: item });
    });
    
    //Getting RootCause Values from AdminList
    let RootCauseDropDown = [];
    let VarRootCause;
    let splitRootCausearr = [];
    VarRootCause = Adminlistvalues[0].RootCauses;
    splitRootCausearr = VarRootCause != undefined ? VarRootCause.split(/[\n,;]+/) : [];
    splitRootCausearr.map((item) => {
      RootCauseDropDown.push({ key: item, text: item });
    });
  
    this.setState({
      PriorityChoice: PriorityDropDown,
      SeverityChoice: SeverityDropDown,
      JurisdictionChoice: JurisdictionDropDown,
      ProjectAreaChoice: ProjectAreaDropDown,
      EnvironmentTypeChoice: EnvironmentTypeDropDown,
      VendorChoice: VendorDropDown,
      RootCauseChoice: RootCauseDropDown
    });
  }

  public CurrentloggedinUser = () => {
    debugger;
    user = this.props.context.pageContext.user.displayName;

    var dateTime = moment().format('L h:mm A');
    createtimearray = dateTime.split(/ (.*)/);
    const username = this.props.context.pageContext.user.email;
    sp.web.ensureUser(username).then((res) => {
      debugger;
      let result = res;
      //let arrReptby=[];
      CurrentloggedinUserID.push(res.data.Id);
      CurrentloggedinUserName.push(res.data.Title);
      if (uniqueId == 0) {
        this.setState({
          createdby: user,
          createdon: dateTime,
          CreateTime: dateTime,
          ReportedBy: CurrentloggedinUserID,
          ReportedByDefaultItems: [username],
          // ApprovedBy: arrReptby,
          // ApprovedByDefaultItems: [username],
        });
      }
    });
  }
  CheckFormValidation = (actionClick) => {
    debugger;
    try {

      actionBtnClicked = actionClick;
      let vartitlevalidation = ((this.state.DocType == 'Validations' || this.state.DocType == 'Issues' || this.state.DocType == 'Instructions' || this.state.DocType == 'Discussion Item') && this.state.Title == '') ? this.setState({ TitleValidations: 'Please Enter Title' }) : '';
      let vardoctypevalidation = (this.state.DocType == '') ? this.setState({ DocTypeValidations: 'Please Select DocType Value' }) : '';
      let varseverityvalidation = (this.state.DocType == 'Validations' && this.state.Severity == '') ? this.setState({ SeverityValidations: 'Please Select Risk Level Value' }) : '';
      //  let varkeywordsvalidation = (this.state.DocType == 'Validations' &&  this.state.Keywords=='')?this.setState({KeywordsValidations: 'Please Select Jurisdiction Value'}):(this.state.DocType == 'Discussion Item' &&  this.state.Keywords=='')?this.setState({KeywordsValidations: 'Please Select Category Value'}):'';
      let varprojectareavalidation = ((this.state.DocType == 'Instructions' || this.state.DocType == 'Validations') && this.state.ProjectArea == '') ? this.setState({ ProjectAreaValidations: 'Please Select Compliance Action Value' }) : '';
      let varprojectareavalidation1 = (this.state.DocType == 'Discussion Item' && this.state.ProjectArea == '') ? this.setState({ ProjectAreaValidations: 'Please Select Product Line Value' }) : '';
      let varenvtypevalidation = (this.state.DocType == 'Validations' && this.state.EnvType == '') ? this.setState({ EnvTypeValidations: 'Please Select BU(s) Affected Value' }) : '';
      let vartestcasevalidation = (this.state.DocType == 'Validations' && (this.state.TestCase == '' || this.state.TestCase == null || this.state.TestCase == undefined)) ? this.setState({ TestCaseValidations: 'Please Provide Ready Date Value' }) : '';
      let varestcompdtvalidation = (this.state.DocType == 'Validations' && (this.state.EstCompDt == '' || this.state.EstCompDt == null || this.state.EstCompDt == undefined)) ? this.setState({ EstCompDateValidations: 'Please Provide Estimated Completion Date Value' }) : '';

      if (vartitlevalidation != '' || vardoctypevalidation != '' || varseverityvalidation != '' || varprojectareavalidation != '' || varprojectareavalidation1 != '' || varenvtypevalidation != '' || vartestcasevalidation != '' || varestcompdtvalidation != '') {
        this.setState({ isvalidRecord: false });
      }
      else {
        this.modalPopupOpen(actionBtnClicked);
        this.setState({ isvalidRecord: true });
      }
    }
    catch (e) {
      console.log('checkFormValidationChange: ' + e);
    }
  }

  modalPopupOpen = (actionCall) => {

    try {
      debugger;
      actionBtnClicked = actionCall;
      if (actionBtnClicked == 'close') {
        dialogContentProps.title = 'Exit Confirmation';

        dialogContentProps.subText = 'Are you sure you want to exit this Form?';
      } else if (actionBtnClicked == 'saveClose') {
        dialogContentProps.title = 'Save Confirmation';
        dialogContentProps.subText = 'Do you want to save this details?';
      } else if (actionBtnClicked == 'sendupdate') {
        this.setState({ showUpdateBody: true });
        dialogContentProps.title = 'Send Update';
        dialogContentProps.subText = 'Do you want to send the Update?';
      } else if (actionBtnClicked == 'statusreopen') {
        dialogContentProps.title = 'Status Open Confirmation';
        dialogContentProps.subText = 'Do you want to open the Status?';
      } else if (actionBtnClicked == 'statusclose') {
        dialogContentProps.title = 'Status Close Confirmation';
        dialogContentProps.subText = 'Do you want to close the Status?';
      } else if (actionBtnClicked == 'save') {
        dialogContentProps.title = 'Save Changes';
        dialogContentProps.subText = 'Do you want to save the changes?';
      }

      this.setState({ isModalClose: false });
    } catch (e) {
      console.log('modalPopup: ' + e);
    }
  }


  modalPopupOpenView = (actionCall) => {

    try {
      debugger;
      actionBtnClicked = actionCall;
      if (actionBtnClicked == 'close') {
        dialogContentProps.title = 'Exit Confirmation';
        dialogContentProps.subText = 'Would you like to exit this record?';
      }

      this.setState({ isModalClose: false });
    } catch (e) {
      console.log('modalPopup: ' + e);
    }
  }

  modalPopupClose = () => {
    try {
      debugger;
      this.setState({ isModalClose: true, showUpdateBody: false });
    } catch (e) {
      console.log('modalPopup: ' + e);
    }
  }




  modalSubmitClick = () => {
    try {
      loadSpinner = true;
      this.setState({ isDisabled: 'disabledbutton' });

      debugger;
      if (actionBtnClicked == 'close') {
        this.CloseForm();
      } else if (actionBtnClicked == 'saveClose') {
        if (uniqueId == 0) {
          this.getProblemListValues();
          this.setState({ isModalClose: true });
        } else {
          ApprovedByHistory = localApprovedByUser;
          this.checkUpdateHistory();
        }
      } else if (actionBtnClicked == 'sendupdate') {
        // alert('Update Send');
        ApprovedByHistory = localApprovedByUser;
        sendUpdate = true;
        this.checkUpdateHistory();

        this.setState({ isModalClose: true, showUpdateBody: false });
      } else if (actionBtnClicked == 'statusreopen') {
        this.SendReopenEmail();

        this.setState({ isModalClose: true });
      } else if (actionBtnClicked == 'statusclose') {
        this.SendClosedEmail();
        this.setState({ isModalClose: true });
      } else if (actionBtnClicked == 'save') {

        if (uniqueId == 0) {
          this.setState({ isModalClose: true, isOnlySave: true });
          //uniqueId = 0;
          this.getProblemListValues();

        } else {
          ApprovedByHistory = localApprovedByUser;
          this.checkUpdateHistory();
          this.setState({ isOnlySave: true });
        }
      }

    } catch (e) {
      console.log('modalSubmitClick: ' + e);
    }
  }

  CloseForm = () => {
    try {
      debugger;
      
      // exiturl = this.props.exiturl;
      if (this.state.isOnlySave == true) {
          const url = window.location.href;
          
        if (ValidationsProblemStore.getInserResultStoreValue() != undefined) {
          debugger;

          if (uniqueId == 0) {
            const id = ValidationsProblemStore.getInserResultStoreValue();
            uniqueId = id;
            window.location.href = url+'?itemID='+uniqueId+'&pageMode=Edit';
            // this.setState({ Attachments: '' });
            // ValidationsProblemStore.on('getEditFormDetailschange', this.assignEditFormDetailsStore);
            // this.getEditFormDetailsComp();
          } else {
            if(pagemode == ''){
                  window.location.href = url+'&pageMode=Edit';
               }else{
                  window.location.href = url
               } 
            // this.setState({ Attachments: '' });
            // this.getEditFormDetailsComp();
          }


          isEditMode = true;
          this.setState({ isSavedHidden: true, isOnlySave: false, });
          // window.location.href = this.props.siteurl + "?itemID=" + id;
        }

      } else {
        this.setState({ isSavedHidden: true });
        window.location.href = this.props.exiturl;
      }

    } catch (e) {
      console.log('CloseForm: ' + e);
    }
  }

  // Single Select DropDown Values Save in SP Starts

  public onDocTypeDropdownChange = (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): void => {
    this.setState({ DocType: item.key as string });
    if (item.key == "Discussion Item") {
      this.setState({ Status: "Discussion" });
    }
    else {
      this.setState({ Status: "Open" });
    }
    this.setState({ DocTypeValidations: '' });
  }
  public onPriorityDropDownChange = (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): void => {
    this.setState({ Priority: item.key as string });
  }
  public onSeverityDropDownChange = (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): void => {
    this.setState({
       Severity: item.key as string,
       SeverityValidations: '' 
      });
      //this.setState({ SeverityValidations: '' });
  }
  public onProjectAreaDropDownChange = (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): void => {
    this.setState({ 
      ProjectArea: item.key as string,
      ProjectAreaValidations: ''
    });
   // this.setState({ ProjectAreaValidations: '' });
  }

  // Single Select DropDown Values Save in SP Ends

  //Multi Select DropDown Values Save in SP Starts
  public onKeywordsDropdownChange = async (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): Promise<void> => {
    debugger;
    //  {this.state.UpdateKeywords!=''?this.setState({KeywordsValidations:''}):''}
    keywordsarr = this.state.UpdateKeywords;
    if (item.selected) {
      keywordsarr = [...keywordsarr, item.key as string];
      //keywordsarr.push(item.key as string);
    }
    else {
      // keywordsarr.indexOf(item.key) !== -1 && keywordsarr.splice(keywordsarr.indexOf(item.key), 1);
      keywordsarr = keywordsarr.filter(keyitem => keyitem !== item.key);
    }
    let text = keywordsarr.join(',');
    this.setState({ Keywords: text, UpdateKeywords: keywordsarr });

    //  this.setState({KeywordsValidations:''});
  }

  public onEnvTypeDropdownChange = async (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): Promise<void> => {
    debugger;
    envtypearr = this.state.UpdateEnvType;
    if (item.selected) {
      envtypearr = [...envtypearr, item.key as string];
      //envtypearr.push(item.key as string);
    }
    else {
      // envtypearr.indexOf(item.key) !== -1 && envtypearr.splice(envtypearr.indexOf(item.key), 1);
      envtypearr = envtypearr.filter(keyitem => keyitem !== item.key);
    }
    let text = envtypearr.join(',');
    this.setState({ EnvType: text, UpdateEnvType: envtypearr,
                   EnvTypeValidations: ''
                  });
    //this.setState({ EnvTypeValidations: '' });
  }

  public onVendorDropdownChange = async (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): Promise<void> => {
    vendorarr = this.state.UpdateVendors;
    if (item.selected) {
      vendorarr = [...vendorarr, item.key as string];
      //vendorarr.push(item.key as string);
    }
    else {
      //vendorarr.indexOf(item.key) !== -1 && vendorarr.splice(vendorarr.indexOf(item.key), 1);
      vendorarr = vendorarr.filter(keyitem => keyitem !== item.key);
    }
    let text = vendorarr.join(',');
    this.setState({ Vendors: text, UpdateVendors: vendorarr });
  }

  public onRootCauseDropdownChange = async (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): Promise<void> => {
    rootcausearr = this.state.UpdateRootCause;
    if (item.selected) {
      rootcausearr = [...rootcausearr, item.key as string];
      //rootcausearr.push(item.key as string);
    }
    else {
      // rootcausearr.indexOf(item.key) !== -1 && rootcausearr.splice(rootcausearr.indexOf(item.key), 1);
      rootcausearr = rootcausearr.filter(keyitem => keyitem !== item.key);
    }
    let text = rootcausearr.join(',');
    this.setState({ RootCause: text, UpdateRootCause: rootcausearr });
  }



  public assignEditFormDetailsStore = () => {
    debugger;
    EditFormDetails = ValidationsProblemStore.getEditClickStoreValue();
    let domparser = new DOMParser();
    let s = new XMLSerializer();
    
    if (EditFormDetails.length != 0) {

      localActivePlayersEmail = [];
      localActivePlayersID = [];
      localActivePlayersUser = [];
      if (EditFormDetails.ActivePlayers != undefined) {
        localActivePlayersEmail.push(EditFormDetails.ActivePlayers.EMail);
        localActivePlayersID.push(EditFormDetails.ActivePlayers.ID);
        localActivePlayersUser.push(EditFormDetails.ActivePlayers.Title);
      }
      localApprovedByEmail = [];
      localApprovedByID = [];
      localApprovedByUser = [];
      if (EditFormDetails.ApprovedBy != undefined) {
        localApprovedByEmail.push(EditFormDetails.ApprovedBy.EMail);
        localApprovedByID.push(EditFormDetails.ApprovedBy.ID);
        localApprovedByUser.push(EditFormDetails.ApprovedBy.Title);
      }

      localAssignedToEmail = [];
      localAssignedToID = [];
      localAssignedToUser = [];
      if (EditFormDetails.AssignedTo != undefined) {
        localAssignedToEmail.push(EditFormDetails.AssignedTo.EMail);
        localAssignedToID.push(EditFormDetails.AssignedTo.ID);
        localAssignedToUser.push(EditFormDetails.AssignedTo.Title);
      }
      localProjectManagersEmail = [];
      localProjectManagersID = [];
      localProjectManagersUser = [];
      if (EditFormDetails.ProjectManagers != undefined) {
        localProjectManagersEmail.push(EditFormDetails.ProjectManagers.EMail);
        localProjectManagersID.push(EditFormDetails.ProjectManagers.ID);
        localProjectManagersUser.push(EditFormDetails.ProjectManagers.Title);
      }
      localReportedByEmail = [];
      localReportedByID = [];
      localReportedByUser = [];
      if (EditFormDetails.ReportedBy != undefined) {
        localReportedByEmail.push(EditFormDetails.ReportedBy.EMail);
        localReportedByID.push(EditFormDetails.ReportedBy.ID);
        localReportedByUser.push(EditFormDetails.ReportedBy.Title);
      }
      localSendToEmail = [];
      localSendToID = [];
      localSendToUser = [];
      if (EditFormDetails.SendTo != undefined) {
        EditFormDetails.SendTo.map((item) => {
          localSendToEmail.push(item.EMail);
          localSendToID.push(item.ID);
          localSendToUser.push(item.Title);
        });

      }
      let localKeywords = [];
      let Varkeywords;
      if (EditFormDetails.Keywords != undefined) {
        Varkeywords = EditFormDetails.Keywords;
        localKeywords = Varkeywords != undefined ? Varkeywords.split(/[\n,;]+/) : [];
      }

      let localEnvType = [];
      let VarEnvType;
      if (EditFormDetails.EnvType != undefined) {
        VarEnvType = EditFormDetails.EnvType;
        localEnvType = VarEnvType != undefined ? VarEnvType.split(/[\n,;]+/) : [];
      }

      let localVendors = [];
      let VarVendors;
      if (EditFormDetails.Vendors != undefined) {
        VarVendors = EditFormDetails.Vendors;
        localVendors = VarVendors != undefined ? VarVendors.split(/[\n,;]+/) : [];
      }

      let localRootCause = [];
      let VarRootCause;
      if (EditFormDetails.RootCause != undefined) {
        VarRootCause = EditFormDetails.RootCause;
        localRootCause = VarRootCause != undefined ? VarRootCause.split(/[\n,;]+/) : [];
      }

      let TempWorkFlowHistoryArr = EditFormDetails.WorkFlowHistory != null && EditFormDetails.WorkFlowHistory != '' ? EditFormDetails.WorkFlowHistory.split('\n') : [];
      let TempWorkFlowJoin = TempWorkFlowHistoryArr.join('</br>');
      debugger;
      delAttachList = [...EditFormDetails.AttachmentFiles];

      let parsedInsured_Proposedres = domparser.parseFromString(EditFormDetails.Proposedres, 'text/html'); parsedInsured_Proposedres.querySelectorAll('[class*=se-component]').forEach((ext) => { ext.removeAttribute('class'); }); let serializeInsured_Proposedres = s.serializeToString(parsedInsured_Proposedres);
      let parsedInsured_profile = domparser.parseFromString(EditFormDetails.Probdesc, 'text/html'); parsedInsured_profile.querySelectorAll('[class*=se-component]').forEach((ext) => { ext.removeAttribute('class'); }); let serializeInsured_profile = s.serializeToString(parsedInsured_profile);
      let parsedInsured_Resolution = domparser.parseFromString(EditFormDetails.Resolution, 'text/html'); parsedInsured_Resolution.querySelectorAll('[class*=se-component]').forEach((ext) => { ext.removeAttribute('class'); }); let serializeInsured_Resolution = s.serializeToString(parsedInsured_Resolution);
      let parsedInsured_Suggest = domparser.parseFromString(EditFormDetails.Suggest, 'text/html'); parsedInsured_Suggest.querySelectorAll('[class*=se-component]').forEach((ext) => { ext.removeAttribute('class'); }); let serializeInsured_Suggest = s.serializeToString(parsedInsured_Suggest);
      let parsedInsured_Comments = domparser.parseFromString(EditFormDetails.Comments, 'text/html'); parsedInsured_Comments.querySelectorAll('[class*=se-component]').forEach((ext) => { ext.removeAttribute('class'); }); let serializeInsured_Comments = s.serializeToString(parsedInsured_Comments);

      prevUploadedFilesObjProgram = this.GetPrevSavedFiles(EditFormDetails.ProbdescFileUpload, "Probdesc");
      prevUploadedFilesObjProposedres = this.GetPrevSavedFiles(EditFormDetails.ProposedresFileUpload, "Proposedres");
      prevUploadedFilesObjResolution = this.GetPrevSavedFiles(EditFormDetails.ResolutionFileUpload, "Resolution");
      prevUploadedFilesObjSuggest = this.GetPrevSavedFiles(EditFormDetails.SuggestFileUpload, "Suggest");
      prevUploadedFilesObjComments = this.GetPrevSavedFiles(EditFormDetails.CommentsFileUpload, "Comments");

      arrAllPrevAttachments = this.getAllAttachments(EditFormDetails.AttachmentFiles);
      debugger;
      if(EditFormDetails.Probdesc!=null){
        isProbdescContent=true;
      }
      if(EditFormDetails.Proposedres!=null){
        isProposedresContent=true;
      }
      if(EditFormDetails.Resolution!=null){
        isResolutionContent=true;
      }
      if(EditFormDetails.Suggest!=null){
        isSuggestContent=true;
      }
      if(EditFormDetails.Comments!=null){
        isCommentsContent=true;
      }
      this.setState({
        createdby: EditFormDetails.ProblemCreatedBy,
        createdon: EditFormDetails.CreateDt,
        FormID: EditFormDetails.ID,
        FormNoteID: EditFormDetails.NoteID,
        oldAttachments: EditFormDetails.AttachmentFiles,
        ActivePlayersDefaultItems: localActivePlayersEmail,
        ActivePlayersUserItems: localActivePlayersUser,
        ActivePlayers: localActivePlayersID,
        ApplicationArea: EditFormDetails.ApplicationArea,
        ApprovedByDefaultItems: localApprovedByEmail,
        ApprovedByUserItems: localApprovedByUser,
        ApprovedBy: localApprovedByID,
        ApprovedDt: EditFormDetails.ApprovedDt != null ? new Date(EditFormDetails.ApprovedDt) : null,
        AssignedToDefaultItems: localAssignedToEmail,
        AssignedToUserItems: localAssignedToUser,
        AssignedTo: localAssignedToID,
        AssignedDt: EditFormDetails.AssignedDt != null ? new Date(EditFormDetails.AssignedDt) : null,
        // Comments: EditFormDetails.Comments,
        CreateDt: EditFormDetails.CreateDt != null ? new Date(EditFormDetails.CreateDt) : null,
        CreateTime: EditFormDetails.CreateTime,
        DateResolved: EditFormDetails.DateResolved != null ? new Date(EditFormDetails.DateResolved) : null,
        DocNumber: EditFormDetails.DocNumber,
        DocType: EditFormDetails.DocType,
        EditHistoryFields: TempWorkFlowJoin,
        EnvType: EditFormDetails.EnvType,
        UpdateEnvType: localEnvType,
        EstCompDt: EditFormDetails.EstCompDt != null ? new Date(EditFormDetails.EstCompDt) : null,
        IONum: EditFormDetails.IONum,
        Keywords: EditFormDetails.Keywords,
        UpdateKeywords: localKeywords,
        PhaseDetect: EditFormDetails.PhaseDetect,
        PhaseIntro: EditFormDetails.PhaseIntro,
        Priority: EditFormDetails.Priority,
        Probdesc: EditFormDetails.Probdesc != null ? (_.unescape(serializeInsured_profile) != null ? _.unescape(serializeInsured_profile) : '') : '',
        Proposedres: EditFormDetails.Proposedres != null ? (_.unescape(serializeInsured_Proposedres) != null ? _.unescape(serializeInsured_Proposedres) : '') : '',
        Resolution: EditFormDetails.Resolution != null ? (_.unescape(serializeInsured_Resolution) != null ? _.unescape(serializeInsured_Resolution) : '') : '',
        Suggest: EditFormDetails.Suggest != null ? (_.unescape(serializeInsured_Suggest) != null ? _.unescape(serializeInsured_Suggest) : '') : '',
        Comments: EditFormDetails.Comments != null ? (_.unescape(serializeInsured_Comments) != null ? _.unescape(serializeInsured_Comments) : '') : '',

        ProjectArea: EditFormDetails.ProjectArea,
        ProjectManagersDefaultItems: localProjectManagersEmail,
        ProjectManagersUserItems: localProjectManagersUser,
        ProjectManagers: localProjectManagersID,
        // Proposedres: EditFormDetails.Proposedres,

        oldsendUpdateBody: EditFormDetails.EmailBody,

        ReportedByDefaultItems: localReportedByEmail,
        ReportedByUserItems: localReportedByUser,
        ReportedBy: localReportedByID,
        ReptArea: EditFormDetails.ReptArea,
        ReptDt: EditFormDetails.ReptDt != null ? new Date(EditFormDetails.ReptDt) : null,
        ReptMgr: EditFormDetails.ReptMgr,
        // Resolution: EditFormDetails.Resolution,
        RootCause: EditFormDetails.RootCause,
        UpdateRootCause: localRootCause,
        SendToDefaultItems: localSendToEmail,
        SendToUserItems: localSendToUser,
        SendTo: localSendToID,
        EmailIdList: localSendToEmail,
        Severity: EditFormDetails.Severity,
        Status: EditFormDetails.Status,
        // Suggest: EditFormDetails.Suggest,
        TestCase: EditFormDetails.TestCase != null ? new Date(EditFormDetails.TestCase) : null,
        Title: EditFormDetails.Title,
        Vendors: EditFormDetails.Vendors,
        UpdateVendors: localVendors,
        WONum: EditFormDetails.WONum != null ? new Date(EditFormDetails.WONum) : null,
        toDeleteAttachments:'',
        programUploadedExFiles: prevUploadedFilesObjProgram.arrPrevSavedFilesHtml,
        proposedresUploadedExFiles: prevUploadedFilesObjProposedres.arrPrevSavedFilesHtml,
        resolutionUploadedExFiles: prevUploadedFilesObjResolution.arrPrevSavedFilesHtml,
        suggestUploadedExFiles: prevUploadedFilesObjSuggest.arrPrevSavedFilesHtml,
        commentsUploadedExFiles: prevUploadedFilesObjComments.arrPrevSavedFilesHtml,

      });
      debugger;
    }
  }

  private getAllAttachments(AllAttachments) {
    let AlAttachmentFiles = [];
    if (AllAttachments != null && AllAttachments.length > 0) {
      AllAttachments.forEach(element => {
        AlAttachmentFiles.push(element.FileName);
      });
    }
    return AlAttachmentFiles;
  }

  private GetPrevSavedFiles(arrPrevSavedFilesDetails: any, ctrlName) {
    let arrPrevSavedFiles = [];
    let arrPrevSavedFilesHtml = [];
    let arrPrevTobeRemovedFiles = [];
    let newUploadedFileArray = [];
    let uploadedRichTextFiles = [];
    if (arrPrevSavedFilesDetails != null && arrPrevSavedFilesDetails != '') {
      let arrAllPrevFiles = [];

      arrAllPrevFiles = arrPrevSavedFilesDetails.split(';');
      if (arrAllPrevFiles != null && arrAllPrevFiles != undefined && arrAllPrevFiles.length > 0) {

        arrAllPrevFiles.forEach((filElement) => {

          // NewFileDetails.push({FuileName:})
          if (filElement != null && filElement != undefined && filElement.length > 0) {
            // let splittedDetails = filElement;
            let fileUrl = absoluteUrl + "/Lists/" + itemListName + "/Attachments/" + uniqueId + "/" + filElement;
            arrPrevSavedFiles.push({ FileName: filElement, FileUrl: fileUrl });

            arrPrevSavedFilesHtml.push(<div id={filElement} style={{ display: "inline" }}><a href={fileUrl} download>{filElement}</a><IconButton iconProps={{ iconName: 'Delete' }} onClick={(event) => this.onRemoveExUploadedFile(filElement, ctrlName)}></IconButton></div>);
          }
        });
      }
      // this.setState({AttachedFiles:NewFileDetails});
    }
    let allPrevFiles = { arrPrevSavedFiles, arrPrevSavedFilesHtml, arrPrevTobeRemovedFiles, newUploadedFileArray, uploadedRichTextFiles };
    return allPrevFiles;
  }

  onRemoveExUploadedFile = (fileName, ctrlName) => {
    switch (ctrlName) {

      case "Probdesc":
        {
          let existingSpan = this.state.programUploadedExFiles;
          let allExFilesArrHtml = prevUploadedFilesObjProgram.arrPrevSavedFilesHtml;
          let allExFilesArr = prevUploadedFilesObjProgram.arrPrevSavedFiles;
          let alltobeRemovedArr = prevUploadedFilesObjProgram.arrPrevTobeRemovedFiles;
          let counter = 0;
          allExFilesArrHtml.forEach((element) => {

            if (element.props.id == fileName) {
              // newUploadedFileArray.splice(counter,1);
              allExFilesArrHtml.splice(counter, 1);
              allExFilesArr.splice(counter, 1);

              this.insertToArrayTobeRemoved(fileName, ctrlName);

            }
            counter = counter + 1;
          });


          prevUploadedFilesObjProgram.arrPrevSavedFilesHtml = allExFilesArrHtml;
          prevUploadedFilesObjProgram.arrPrevSavedFiles = allExFilesArr;
          // prevUploadedFilesObj.arrPrevTobeRemovedFiles=alltobeRemovedArr;
          this.setState({ programUploadedExFiles: allExFilesArrHtml });
        }

      case "Proposedres":
        {
          let existingSpan = this.state.proposedresUploadedExFiles;
          let allExFilesArrHtml = prevUploadedFilesObjProposedres.arrPrevSavedFilesHtml;
          let allExFilesArr = prevUploadedFilesObjProposedres.arrPrevSavedFiles;
          let alltobeRemovedArr = prevUploadedFilesObjProposedres.arrPrevTobeRemovedFiles;
          let counter = 0;
          allExFilesArrHtml.forEach((element) => {

            if (element.props.id == fileName) {
              // newUploadedFileArray.splice(counter,1);
              allExFilesArrHtml.splice(counter, 1);
              allExFilesArr.splice(counter, 1);

              this.insertToArrayTobeRemoved(fileName, ctrlName);

            }
            counter = counter + 1;
          });


          prevUploadedFilesObjProposedres.arrPrevSavedFilesHtml = allExFilesArrHtml;
          prevUploadedFilesObjProposedres.arrPrevSavedFiles = allExFilesArr;
          // prevUploadedFilesObj.arrPrevTobeRemovedFiles=alltobeRemovedArr;
          this.setState({ proposedresUploadedExFiles: allExFilesArrHtml });
        }

      case "Resolution":
        {
          let existingSpan = this.state.resolutionUploadedExFiles;
          let allExFilesArrHtml = prevUploadedFilesObjResolution.arrPrevSavedFilesHtml;
          let allExFilesArr = prevUploadedFilesObjResolution.arrPrevSavedFiles;
          let alltobeRemovedArr = prevUploadedFilesObjResolution.arrPrevTobeRemovedFiles;
          let counter = 0;
          allExFilesArrHtml.forEach((element) => {

            if (element.props.id == fileName) {
              // newUploadedFileArray.splice(counter,1);
              allExFilesArrHtml.splice(counter, 1);
              allExFilesArr.splice(counter, 1);

              this.insertToArrayTobeRemoved(fileName, ctrlName);

            }
            counter = counter + 1;
          });


          prevUploadedFilesObjResolution.arrPrevSavedFilesHtml = allExFilesArrHtml;
          prevUploadedFilesObjResolution.arrPrevSavedFiles = allExFilesArr;
          // prevUploadedFilesObj.arrPrevTobeRemovedFiles=alltobeRemovedArr;
          this.setState({ resolutionUploadedExFiles: allExFilesArrHtml });
        }

      case "Suggest":
        {
          let existingSpan = this.state.suggestUploadedExFiles;
          let allExFilesArrHtml = prevUploadedFilesObjSuggest.arrPrevSavedFilesHtml;
          let allExFilesArr = prevUploadedFilesObjSuggest.arrPrevSavedFiles;
          let alltobeRemovedArr = prevUploadedFilesObjSuggest.arrPrevTobeRemovedFiles;
          let counter = 0;
          allExFilesArrHtml.forEach((element) => {

            if (element.props.id == fileName) {
              // newUploadedFileArray.splice(counter,1);
              allExFilesArrHtml.splice(counter, 1);
              allExFilesArr.splice(counter, 1);

              this.insertToArrayTobeRemoved(fileName, ctrlName);

            }
            counter = counter + 1;
          });


          prevUploadedFilesObjSuggest.arrPrevSavedFilesHtml = allExFilesArrHtml;
          prevUploadedFilesObjSuggest.arrPrevSavedFiles = allExFilesArr;
          // prevUploadedFilesObj.arrPrevTobeRemovedFiles=alltobeRemovedArr;
          this.setState({ suggestUploadedExFiles: allExFilesArrHtml });
        }

      case "Comments":
        {
          let existingSpan = this.state.commentsUploadedExFiles;
          let allExFilesArrHtml = prevUploadedFilesObjComments.arrPrevSavedFilesHtml;
          let allExFilesArr = prevUploadedFilesObjComments.arrPrevSavedFiles;
          let alltobeRemovedArr = prevUploadedFilesObjComments.arrPrevTobeRemovedFiles;
          let counter = 0;
          allExFilesArrHtml.forEach((element) => {

            if (element.props.id == fileName) {
              // newUploadedFileArray.splice(counter,1);
              allExFilesArrHtml.splice(counter, 1);
              allExFilesArr.splice(counter, 1);

              this.insertToArrayTobeRemoved(fileName, ctrlName);

            }
            counter = counter + 1;
          });


          prevUploadedFilesObjComments.arrPrevSavedFilesHtml = allExFilesArrHtml;
          prevUploadedFilesObjComments.arrPrevSavedFiles = allExFilesArr;
          // prevUploadedFilesObj.arrPrevTobeRemovedFiles=alltobeRemovedArr;
          this.setState({ commentsUploadedExFiles: allExFilesArrHtml });
        }

    }
  }

  private insertToArrayTobeRemoved(fileName, ctrlName) {
    if ((arrAllPrevAttachments != null && arrAllPrevAttachments != undefined && arrAllPrevAttachments.length > 0 && arrAllPrevAttachments.indexOf(fileName) > -1)) {
      switch (ctrlName) {

        case 'Probdesc':
          {
            let alltobeRemovedArr = prevUploadedFilesObjProgram.arrPrevTobeRemovedFiles;
            if (alltobeRemovedArr != null && alltobeRemovedArr != undefined) {
              if (alltobeRemovedArr.length > 0 && alltobeRemovedArr.indexOf(fileName) < 0) {
                alltobeRemovedArr.push(fileName);
              }
              else {
                alltobeRemovedArr.push(fileName);
              }
            }
            else {
              alltobeRemovedArr.push(fileName);
            }
            prevUploadedFilesObjProgram.arrPrevTobeRemovedFiles = alltobeRemovedArr;
            break;
          }

        case 'Proposedres':
          {
            let alltobeRemovedArr = prevUploadedFilesObjProposedres.arrPrevTobeRemovedFiles;
            if (alltobeRemovedArr != null && alltobeRemovedArr != undefined) {
              if (alltobeRemovedArr.length > 0 && alltobeRemovedArr.indexOf(fileName) < 0) {
                alltobeRemovedArr.push(fileName);
              }
              else {
                alltobeRemovedArr.push(fileName);
              }
            }
            else {
              alltobeRemovedArr.push(fileName);
            }
            prevUploadedFilesObjProposedres.arrPrevTobeRemovedFiles = alltobeRemovedArr;
            break;
          }
        case 'Resolution':
          {
            let alltobeRemovedArr = prevUploadedFilesObjResolution.arrPrevTobeRemovedFiles;
            if (alltobeRemovedArr != null && alltobeRemovedArr != undefined) {
              if (alltobeRemovedArr.length > 0 && alltobeRemovedArr.indexOf(fileName) < 0) {
                alltobeRemovedArr.push(fileName);
              }
              else {
                alltobeRemovedArr.push(fileName);
              }
            }
            else {
              alltobeRemovedArr.push(fileName);
            }
            prevUploadedFilesObjResolution.arrPrevTobeRemovedFiles = alltobeRemovedArr;
            break;
          }
        case 'Suggest':
          {
            let alltobeRemovedArr = prevUploadedFilesObjSuggest.arrPrevTobeRemovedFiles;
            if (alltobeRemovedArr != null && alltobeRemovedArr != undefined) {
              if (alltobeRemovedArr.length > 0 && alltobeRemovedArr.indexOf(fileName) < 0) {
                alltobeRemovedArr.push(fileName);
              }
              else {
                alltobeRemovedArr.push(fileName);
              }
            }
            else {
              alltobeRemovedArr.push(fileName);
            }
            prevUploadedFilesObjSuggest.arrPrevTobeRemovedFiles = alltobeRemovedArr;
            break;
          }
        case 'Comments':
          {
            let alltobeRemovedArr = prevUploadedFilesObjComments.arrPrevTobeRemovedFiles;
            if (alltobeRemovedArr != null && alltobeRemovedArr != undefined) {
              if (alltobeRemovedArr.length > 0 && alltobeRemovedArr.indexOf(fileName) < 0) {
                alltobeRemovedArr.push(fileName);
              }
              else {
                alltobeRemovedArr.push(fileName);
              }
            }
            else {
              alltobeRemovedArr.push(fileName);
            }
            prevUploadedFilesObjComments.arrPrevTobeRemovedFiles = alltobeRemovedArr;
            break;
          }
      }
    }
  }

  // Call action save Result method
  public assignInsertResultStore = () => {
    try {
      debugger;
      if (ValidationsProblemStore.getInserResultStoreValue() != undefined) {
        debugger;
        const id = ValidationsProblemStore.getInserResultStoreValue();
        if (this.state.SendTo.length != 0 && uniqueId == 0 && this.state.isOnlySave == false) {

          debugger;
          this.SendEmail(id);
        } else if (this.state.SendTo.length != 0 && sendUpdate == true) {
          debugger;
          this.SendEmail(id);
        } else {
          loadSpinner = false;
          this.setState({ isSavedHidden: false, isDisabled: '' });

        }

      }
    } catch (e) {
      console.log('assignInsertResultStore: ' + e);
    }
  }
  // Call action save method


  public insertForm = () => {

    //this.getProblemListValues();
    try {
      this.setState({ isModalClose: true });

      let allNotesData = { notesProgram: this.state.Probdesc, notesProposedres: this.state.Proposedres, notesResolution: this.state.Resolution, notesSuggest: this.state.Suggest, notesComments: this.state.Comments };
      let arrprevUploadedFilesObjMaster = [prevUploadedFilesObjProgram, prevUploadedFilesObjProposedres, prevUploadedFilesObjResolution, prevUploadedFilesObjSuggest, prevUploadedFilesObjComments];

      // let allNotesProposedres = { }
      // let arrprevUploadedFilesObjProposedres = [prevUploadedFilesObjProposedres];

      if (uniqueId == 0) {
        debugger;
        var dateTimestamp = moment().format();
        var Rand = Math.random();
        var tempstamp = dateTimestamp + Rand;
        var stamp = tempstamp.replace('-', '').replace(':', '').replace('.', '').replace('-', '').replace(':', '').replace('-', '').replace(':', '');

        console.log(stamp);
        updateHistoryValue = '<br/>' + moment().format('L h:mm A ') + ': Document Created by ' + this.props.context.pageContext.user.displayName + '<br/>';
        ValidationsProblemAction.saveForm(stamp, uploadedCommentsRichTextFiles, uploadedSuggestRichTextFiles, uploadedResolutionRichTextFiles, uploadedProposedresRichTextFiles, uploadedProbdescRichTextFiles, this.state.createdby, this.state.createdon, this.state.ActivePlayers, this.state.ApplicationArea, this.state.ApprovedBy, this.state.ApprovedDt, this.state.AssignedTo, this.state.AssignedDt, this.state.Comments, this.state.CreateDt, this.state.CreateTime, this.state.DateResolved, this.state.docnumber, this.state.DocType, updateHistoryValue, this.state.EditHistoryFields, this.state.EnvType, this.state.EstCompDt, this.state.IONum, this.state.Keywords, this.state.PhaseDetect, this.state.PhaseIntro, this.state.Priority, this.state.Probdesc, this.state.ProjectArea, this.state.ProjectManagers, this.state.Proposedres, this.state.ReportedBy, this.state.ReptArea, this.state.ReptDt, this.state.ReptMgr, this.state.Resolution, this.state.RootCause, this.state.SendTo, this.state.Severity, this.state.Status, this.state.Suggest, this.state.TestCase, this.state.Title, this.state.Vendors, this.state.WONum, this.state.Attachments, allNotesData, arrprevUploadedFilesObjMaster, absoluteUrl);

      }
      else {

        // let toDelNames = [];
        // debugger;
        // if (this.state.oldAttachments.length != delAttachList.length) {
        //   const tokeep = [...this.state.oldAttachments];
        //   const final = [...delAttachList];
        //   debugger
        //   for (var i = 0; i < tokeep.length; i++) {

        //     for (var j = 0; j < delAttachList.length; j++) {
        //       if (tokeep[i] == delAttachList[j]) {
        //         debugger;
        //         final.splice(j, 1);
        //         console.log('match');
        //       }
        //     }

        //   }
        //   debugger;
        //   final.map((item) => {
        //     toDelNames.push(item.FileName);
        //   });
         // console.log(toDelNames);
        //}
        let toDelNames = [];

        if(this.state.toDeleteAttachments.length!=0){

          toDelNames = [...this.state.toDeleteAttachments];

        }else{

          toDelNames = [];

        }

       
        if (sendUpdate == true) {
          debugger;
          var finalUpdateBody = moment().format('L h:mm A ') + ': Update Sent from ' + this.props.context.pageContext.user.displayName + ' to ' + (SendToHistory.length > 0 ? SendToHistory.toString() : localSendToUser.toString()) + (this.state.sendUpdateBody != "" ? ' with Comments: ' + this.state.sendUpdateBody : '') + '<br></br>' + (this.state.oldsendUpdateBody != null ? this.state.oldsendUpdateBody : '');
        } else {
          finalUpdateBody = (this.state.oldsendUpdateBody != null ? this.state.oldsendUpdateBody : '')
        }
        ValidationsProblemAction.updateForm(finalUpdateBody, uploadedCommentsRichTextFiles, uploadedSuggestRichTextFiles, uploadedResolutionRichTextFiles, uploadedProposedresRichTextFiles, uploadedProbdescRichTextFiles, toDelNames, this.state.Attachments, uniqueId, this.state.ActivePlayers, this.state.ApplicationArea, this.state.ApprovedBy, this.state.ApprovedDt, this.state.AssignedTo, this.state.AssignedDt, this.state.Comments, this.state.CreateDt, this.state.CreateTime, this.state.DateResolved, this.state.DocNumber, this.state.DocType, updateHistoryValue, this.state.EditHistoryFields, this.state.EnvType, this.state.EstCompDt, this.state.IONum, this.state.Keywords, this.state.PhaseDetect, this.state.PhaseIntro, this.state.Priority, this.state.Probdesc, this.state.ProjectArea, this.state.ProjectManagers, this.state.Proposedres, this.state.ReportedBy, this.state.ReptArea, this.state.ReptDt, this.state.ReptMgr, this.state.Resolution, this.state.RootCause, this.state.SendTo, this.state.Severity, this.state.Status, this.state.Suggest, this.state.TestCase, this.state.Title, this.state.Vendors, this.state.WONum, allNotesData, arrprevUploadedFilesObjMaster, absoluteUrl);
      }
    }
    catch (e) {
      console.log('insertForm: ' + e);
    }
  }

  checkUpdateHistory = () => {
    try{
    if (EditFormDetails!=undefined && EditFormDetails!=null && EditFormDetails.length != 0) {

      updateHistoryValue = '<br/>' + moment().format('L h:mm A ') + ': Document changed by ' + this.props.context.pageContext.user.displayName;
      let isRun = false;
      updateHistory.map((fieldName, index) => {
        let fieldValue = EditFormDetails[fieldName];

        this.formUpdateHistory(fieldName, fieldValue, index);
      });

    }
  }catch(e){
    console.log('checkUpdateHistory'+e);
  }
  }

  formUpdateHistory = (fieldName, fieldValue, index) => {
        debugger;
    try {
      switch (fieldName) {
        case 'DocNumber':
          {
            updateHistoryValue = this.state.DocNumber != fieldValue ? updateHistoryValue + '<br/>' + '...............[DocNumber] from "' + ((fieldValue == '' || fieldValue == undefined || fieldValue == null) ? '' : fieldValue) + '" to "' + this.state.DocNumber + '"' : updateHistoryValue;
            break;
          }
        case 'DocType':
          {
            updateHistoryValue = this.state.DocType != fieldValue ? updateHistoryValue + '<br/>' + '...............[DocType] from "' + (fieldValue == '' || fieldValue == undefined || fieldValue == null ? '' : fieldValue) + '" to "' + this.state.DocType + '"' : updateHistoryValue;
            break;
          }
        case 'Title':
          {
            updateHistoryValue = this.state.Title != fieldValue ? updateHistoryValue + '<br/>' + '...............[Title] from "' + (fieldValue == '' || fieldValue == undefined || fieldValue == null ? '' : fieldValue) + '" to "' + this.state.Title + '"' : updateHistoryValue;

            break;
          }
        case 'TestCase':
          {
            updateHistoryValue = moment(this.state.TestCase).format('L') != moment(fieldValue).format('L') ? updateHistoryValue + '<br/>' + '...............[TestCase] from "' + (fieldValue == null || moment(fieldValue).format('L') == undefined || moment(fieldValue).format('L') == '' ? '' : moment(fieldValue).format('L')) + '" to "' + (this.state.TestCase != null ? moment(this.state.TestCase).format('L') : '') + '"' : updateHistoryValue;
            break;
          }
        case 'Status':
          {
            updateHistoryValue = this.state.Status != fieldValue ? updateHistoryValue + '<br/>' + '...............[Status] from "' + (fieldValue == '' || fieldValue == undefined || fieldValue == null ? '' : fieldValue) + '" to "' + this.state.Status + '"' : updateHistoryValue;
            break;
          }
        case 'Priority':
          {
            updateHistoryValue = this.state.Priority != fieldValue ? updateHistoryValue + '<br/>' + '...............[Priority] from "' + (fieldValue == '' || fieldValue == undefined || fieldValue == null ? '' : fieldValue) + '" to "' + this.state.Priority + '"' : updateHistoryValue;
            break;
          }
        case 'ProjectArea':
          {
            updateHistoryValue = this.state.ProjectArea != fieldValue ? updateHistoryValue + '<br/>' + '...............[ProjectArea] from "' + (fieldValue == '' || fieldValue == undefined || fieldValue == null ? '' : fieldValue) + '" to "' + this.state.ProjectArea + '"' : updateHistoryValue;
            break;
          }
        case 'Severity':
          {
            updateHistoryValue = this.state.Severity != fieldValue ? updateHistoryValue + '<br/>' + '...............[Severity] from "' + (fieldValue == '' || fieldValue == undefined || fieldValue == null ? '' : fieldValue) + '" to "' + this.state.Severity + '"' : updateHistoryValue;
            break;
          }
        case 'Keywords':
          {
            updateHistoryValue = this.state.Keywords != fieldValue ? updateHistoryValue + '<br/>' + '...............[Keywords] from "' + (fieldValue == '' || fieldValue == undefined || fieldValue == null ? '' : fieldValue) + '" to "' + this.state.Keywords + '"' : updateHistoryValue;
            break;
          }
        case 'EnvType':
          {
            updateHistoryValue = this.state.EnvType != fieldValue ? updateHistoryValue + '<br/>' + '...............[EnvType] from "' + (fieldValue == '' || fieldValue == undefined || fieldValue == null ? '' : fieldValue) + '" to "' + this.state.EnvType + '"' : updateHistoryValue;
            break;
          }
        case 'ApplicationArea':
          {
            updateHistoryValue = this.state.ApplicationArea != fieldValue ? updateHistoryValue + '<br/>' + '...............[ApplicationArea] from "' + (fieldValue == '' || fieldValue == undefined || fieldValue == null ? '' : fieldValue) + '" to "' + this.state.ApplicationArea + '"' : updateHistoryValue;
            break;
          }
        case 'ActivePlayers':
          {
            if (ActivePlayersHistory!=undefined && ActivePlayersHistory!=null && ActivePlayersHistory.length > 0) {
              updateHistoryValue = ActivePlayersHistory[0] != localActivePlayersUser[0] ? updateHistoryValue + '<br/>' + '...............[ActivePlayers] from "' + (localActivePlayersUser[0] == '' || localActivePlayersUser[0] == undefined || localActivePlayersUser[0] == null ? '' : localActivePlayersUser[0]) + '" to "' + ActivePlayersHistory[0] + '"' : updateHistoryValue;
            }
            break;

          }
        case 'ReportedBy':
          {
            if (ReportedByHistory!=undefined && ReportedByHistory!=null && ReportedByHistory.length > 0) {
              updateHistoryValue = ReportedByHistory[0] != localReportedByUser[0] ? updateHistoryValue + '<br/>' + '...............[ReportedBy] from "' + (localReportedByUser[0] == '' || localReportedByUser[0] == undefined || localReportedByUser[0] == null ? '' : localReportedByUser[0]) + '" to "' + ReportedByHistory[0] + '"' : updateHistoryValue;
            }
            break;
          }
        case 'ReptDt':
          {
            updateHistoryValue = moment(this.state.ReptDt).format('L') != moment(fieldValue).format('L') ? updateHistoryValue + '<br/>' + '...............[ReptDt] from "' + (fieldValue == null || moment(fieldValue).format('L') == undefined || moment(fieldValue).format('L') == '' ? '' : moment(fieldValue).format('L')) + '" to "' + (this.state.ReptDt != null ? moment(this.state.ReptDt).format('L') : '') + '"' : updateHistoryValue;
            break;
          }
        case 'ProjectManagers':
          {
            if (ProjectManagersHistory!=undefined && ProjectManagersHistory!=null && ProjectManagersHistory.length > 0) {
              updateHistoryValue = ProjectManagersHistory[0] != localProjectManagersUser[0] ? updateHistoryValue + '<br/>' + '...............[ProjectManagers] from "' + (localProjectManagersUser[0] == '' || localProjectManagersUser[0] == undefined || localProjectManagersUser[0] == null ? '' : localProjectManagersUser[0]) + '" to "' + ProjectManagersHistory[0] + '"' : updateHistoryValue;
            }
            break;
          }
        case 'AssignedTo':
          {
            if (AssignedToHistory!=undefined && AssignedToHistory!=null && AssignedToHistory.length > 0) {
              updateHistoryValue = AssignedToHistory[0] != localAssignedToUser[0] ? updateHistoryValue + '<br/>' + '...............[AssignedTo] from "' + (localAssignedToUser[0] == '' || localAssignedToUser[0] == undefined || localAssignedToUser[0] == null ? '' : localAssignedToUser[0]) + '" to "' + AssignedToHistory[0] + '"' : updateHistoryValue;
            }
            break;
          }
        case 'AssignedDt':
          {
            updateHistoryValue = moment(this.state.AssignedDt).format('L') != moment(fieldValue).format('L') ? updateHistoryValue + '<br/>' + '...............[AssignedDt] from "' + (fieldValue == null || moment(fieldValue).format('L') == undefined || moment(fieldValue).format('L') == '' ? '' : moment(fieldValue).format('L')) + '" to "' + (this.state.AssignedDt != null ? moment(this.state.AssignedDt).format('L') : '') + '"' : updateHistoryValue;
            break;
          }
        case 'EstCompDt':
          {
            updateHistoryValue = moment(this.state.EstCompDt).format('L') != moment(fieldValue).format('L') ? updateHistoryValue + '<br/>' + '...............[EstCompDt] from "' + (fieldValue == null || moment(fieldValue).format('L') == undefined || moment(fieldValue).format('L') == '' ? '' : moment(fieldValue).format('L')) + '" to "' + (this.state.EstCompDt != null ? moment(this.state.EstCompDt).format('L') : '') + '"' : updateHistoryValue;
            break;
          }
        case 'ApprovedBy':
          {

            updateHistoryValue = ApprovedByHistory[0] != localApprovedByUser[0] ? updateHistoryValue + '<br/>' + '...............[ApprovedBy] from "' + (localApprovedByUser[0] == '' || localApprovedByUser[0] == undefined || localApprovedByUser[0] == null ? '' : localApprovedByUser[0]) + '" to "' + (ApprovedByHistory[0] == '' || ApprovedByHistory[0] == undefined || ApprovedByHistory[0] == null ? '' : ApprovedByHistory[0]) + '"' : updateHistoryValue;
            break;
          }
        case 'ApprovedDt':
          {
            updateHistoryValue = moment(this.state.ApprovedDt).format('L') != moment(fieldValue).format('L') ? updateHistoryValue + '<br/>' + '...............[ApprovedDt] from "' + ((fieldValue == null || moment(fieldValue).format('L') == undefined || moment(fieldValue).format('L') == '') ? '' : moment(fieldValue).format('L')) + '" to "' + (this.state.ApprovedDt != null ? moment(this.state.ApprovedDt).format('L') : '') + '"' : updateHistoryValue;
            break;
          }
        case 'DateResolved':
          {
            updateHistoryValue = moment(this.state.DateResolved).format('L') != moment(fieldValue).format('L') ? updateHistoryValue + '<br/>' + '...............[DateResolved] from "' + (fieldValue == null || moment(fieldValue).format('L') == undefined || moment(fieldValue).format('L') == '' ? '' : moment(fieldValue).format('L')) + '" to "' + (this.state.DateResolved != null ? moment(this.state.DateResolved).format('L') : '') + '"' : updateHistoryValue;
            break;
          }
        case 'SendTo':
          {
            if (SendToHistory!=undefined && SendToHistory!=null && SendToHistory.length > 0) {
              updateHistoryValue = localSendToUser[localSendToUser.length - 1] != SendToHistory[SendToHistory.length - 1] ? updateHistoryValue + '<br/>' + '...............[SendTo] from "' + (localSendToUser[0] == '' || localSendToUser[0] == undefined || localSendToUser[0] == null ? '' : localSendToUser.toString()) + '" to "' + (SendToHistory.length > 0 ? SendToHistory.toString() : null) + '"' : updateHistoryValue;
            }
            break;
          }
      }

      if (updateHistory!=undefined && updateHistory!=null && updateHistory.length == index + 1) {

        updateHistoryValue = updateHistoryValue + this.state.EditHistoryFields;
        this.getProblemListValues();
        this.setState({ isModalClose: true });
      }
    }
    catch (e) {
      console.log('FormUpdateHistory'+e);
    }
  }
  // Get Input Details
  private inputFormChange = (inputValue) => {
    try {

      switch (inputValue.target.name) {

        case 'ApplicationArea':
          {
            this.setState({ ApplicationArea: inputValue.target.value });
            break;
          }
          //ApprovedBy
          //AssignedTo
          //Comments
          //CreateDt
          //CreateTime
          //DateResolved
        case 'DocNumber':
          {
            this.setState({ DocNumber: inputValue.target.value });
            break;
          }
          //DocType
          //EditHistoryFields
          //EnvType
          //EstCompDt
          //IONum
          //Keywords
          //PhaseDetect
          //PhaseIntro
          //Priority
          //Probdesc
          //ProjectArea
          //ProjectManagers
          //Proposedres
          //ReportedBy
          //ReptArea
          //ReptDt
          //ReptMgr
          //Resolution
          //RootCause
          //SendTo
          //Severity
          
        case 'Status':
          {
            this.setState({ Status: inputValue.target.value });
            break;
          }
          //Suggest
          //TestCase
        case 'Title':
          {
            this.setState({ Title: inputValue.target.value, 
                            TitleValidations: ''});
            break;
          }
          //Vendors
          //WONum
      }
    }
    catch (e) {
      console.log('inputFormChange: ' + e);
    }
  }



  // Get Input RichText Details
  // private handleRichTextChange = (fieldName, content) => {
  //  try {
  //  switch (fieldName) {

  //  }
  //   }
  //   catch (e) {
  //   console.log('handleRichTextChange: ' + e);
  //   }
  //   }







  // Get DropDownDetails
  


  private _getActivePlayersPeoplePickerItems = (items: any[]) => {
    let peoplePickArr = [];
    for (let item in items) {
      peoplePickArr.push(items[item].id);
      ActivePlayersHistory.push(items[item].text);
    } this.setState({ ActivePlayers: peoplePickArr });
  }
  private _getApprovedByPeoplePickerItems = (items: any[]) => {
    let peoplePickArr = [];
    for (let item in items) {
      peoplePickArr.push(items[item].id);
      ApprovedByHistory.push(items[item].text);
    } this.setState({ ApprovedBy: peoplePickArr });
  }
  private _getAssignedToPeoplePickerItems = (items: any[]) => {
    let peoplePickArr = [];
    for (let item in items) {
      peoplePickArr.push(items[item].id);
      AssignedToHistory.push(items[item].text);
    } this.setState({ AssignedTo: peoplePickArr, AssignedDt: new Date() });
    if (this.state.AssignedTo == []) {
      this.setState({ AssignedDt: null });
    }
  }
  private _getProjectManagersPeoplePickerItems = (items: any[]) => {
    let peoplePickArr = [];
    for (let item in items) {
      peoplePickArr.push(items[item].id);
      ProjectManagersHistory.push(items[item].text);
    } this.setState({ ProjectManagers: peoplePickArr });
  }
  private _getReportedByPeoplePickerItems = (items: any[]) => {
    let peoplePickArr = [];
    for (let item in items) {
      peoplePickArr.push(items[item].id);
      ReportedByHistory.push(items[item].text);
    } this.setState({ ReportedBy: peoplePickArr });
  }

  private _getSendToPeoplePickerItems = (items: any[]) => {
    debugger;
    let sendMailToArr = [];
    let emailListArr = [];
    SendToHistory = [];
    for (let item in items) {
      sendMailToArr.push(items[item].id);
      emailListArr.push(items[item].secondaryText);
      SendToHistory.push(items[item].text);
      SendTomail.push(items[item].text);
    }
    this.setState({ SendTo: sendMailToArr });
    this.setState({ EmailIdList: emailListArr });
    this.setState({ EmailSendTo: SendTomail });
    // console.log(emailList);
  }


  private _getCreateDtDatePickerItems = (items) => {
    this.setState({ CreateDt: items });
  }
  private _getDateResolvedDatePickerItems = (items) => {
    this.setState({ DateResolved: items });
  }
  private _getEstCompDtDatePickerItems = (items) => {
    this.setState({ EstCompDt: items });
    this.setState({ EstCompDateValidations: '' });
  }
  private _getReptDtDatePickerItems = (items) => {
    this.setState({ ReptDt: items });
  }
  private _getTestCaseDatePickerItems = (items) => {
    this.setState({ TestCase: items });
    this.setState({ TestCaseValidations: '' });
  }
  private _getWONumDatePickerItems = (items) => {
    this.setState({ WONum: items });
  }
  private _getAssignedDtDatePickerItems = (items) => {
    this.setState({ AssignedDt: items });
  }
  private _getApprovedDtDatePickerItems = (items) => {
    this.setState({ ApprovedDt: items });
  }
  private onProbdescChange = (newText: string) => {
    this.setState({ Probdesc: newText });
    return newText;
  }
  private onProposedresChange = (newText: string) => {
    this.setState({ Proposedres: newText });
    return newText;
  }
  private onResolutionChange = (newText: string) => {
    this.setState({ Resolution: newText });
    return newText;
  }
  private onSuggestChange = (newText: string) => {
    this.setState({ Suggest: newText });
    return newText;
  }
  private onCommentsChange = (newText: string) => {
    this.setState({ Comments: newText });
    return newText;
  }

  public Attachment = (event) => {
    debugger;
    let fileInfos = [];
    
    

    for (var index = 0; index < event.target.files.length; index++) {
      fileInfos.push({
        name: event.target.files[index].name,
        content: event.target.files[index]
      });
    }
    this.setState({ Attachments: fileInfos });
    console.log(this.state.Attachments);
  }

  // private handleDelete = (e) => {
  //   debugger;
  //   const list1 = [...this.state.oldAttachments];
  //   for (var i = 0; i < list1.length; i++) {
  //     if (list1[i].FileName == e.target.parentElement.id) {
  //       list1.splice(i, 1);
  //     }
  //   }
  //   console.log(list1);

  //   this.setState({
  //     oldAttachments: list1
  //   });

  // }

  private handleDelete = (e) => {

    debugger;
    if(this.state.oldAttachments.length!=0){

    const list1 = [...this.state.oldAttachments];

    let todelete=[...this.state.toDeleteAttachments];

    for (var i = 0; i < list1.length; i++) {

      if (list1[i].FileName == e.target.parentElement.id) {

       

        todelete.push(list1[i].FileName);

        list1.splice(i, 1);

      }

    }

    console.log(list1);



    this.setState({

      oldAttachments: list1,

      toDeleteAttachments:todelete

    });

  }

  }
  private selectedFiles = () => {
    if (this.state.Attachments != '' && this.state.Attachments.length > 1) {
      let file = this.state.Attachments;

      return file.map((item) => {
        return (
          <div id={item.name}><span>{item.name}</span></div>
        );
      });

    }

  }
  private showAttachment = () => {
    //  debugger;
    try {
      if (this.state.oldAttachments.length != 0) {
        console.log(this.state.oldAttachments);
        let AttachmentList = this.state.oldAttachments;
        // let AttachmentListArray=[];
       // let filtereditem = AttachmentList.filter(attachmentitems => !(attachmentitems.FileName.match(/=/g)));
        let filtereditem2 = AttachmentList.filter(attachmentitems2 => !(attachmentitems2.FileName.match(/.(jpg|jpeg|png|gif|jfif)$/i)));
        return filtereditem2.map((item) => {
          let downloadUrl = this.props.context.pageContext.web.absoluteUrl + "/_layouts/download.aspx?sourceurl=" + item.ServerRelativeUrl;
          return (
            <div id={item.FileName}><span><a href={downloadUrl}>{item.FileName}</a></span><Icon iconName="Delete" className='btn btn-light' onClick={(e) => this.handleDelete(e)} /></div>
          );
        });
      }
    } catch (e) {
      console.log('bindAttachment: ' + e);
    }
  }



  SendClosedEmail = async () => {
    //from, external
    try {
      isViewMode = false;
      isEditMode = true;

      this.setState({
        ApprovedBy: CurrentloggedinUserID,
        ApprovedByUserItems: [this.props.context.pageContext.user.displayName],
        ApprovedDt: new Date(),
        Status: "Closed",
      });
      ApprovedByHistory = CurrentloggedinUserName;
      if (this.state.DateResolved == null) {
        this.setState({ DateResolved: new Date() });
      }


      console.log(this.state.EmailIdList);
      const docUrl = this.props.siteurl + "?itemID=" + uniqueId;
      let addressString: string = await sp.utility.getCurrentUserEmailAddresses();
      const emailProps = {
        To: this.state.EmailIdList,
        From: addressString,
        CC: [],
        BCC: [],
        // Subject:  "Update for " + this.state.DocType+ " # " + this.state.DocNumber+ " - " + this.state.Title,
        Subject: this.state.DocType + " Has Been Closed for " + this.state.ProjectArea + " Document ID: " + this.state.DocNumber + " - " + this.state.Title,
        Body: "Click the link to open the document - <b><a href='" + docUrl + "'>Document</a></b>",
        AdditionalHeaders: {
          "content-type": "text/html"
        }
      };
      if (this.state.EmailIdList.length != 0) {
        await sp.utility.sendEmail(emailProps).then((res) => {
          this.checkUpdateHistory();
          // loadSpinner = false;
          // this.setState({ isSavedHidden: false, isDisabled: '' });
        }).catch(error => {

          isEmailError = true;
          // loadSpinner = false;
          // this.setState({ isDisabled: '' });
          this.checkUpdateHistory();

        });
      }else{
        // loadSpinner = false;
        this.checkUpdateHistory();
        // this.setState({ isSavedHidden: false, isDisabled: '' });
      }
    } catch (e) {
      console.log(e);
    }

  }
  SendReopenEmail = async () => {
    //from, external
    try {
      isViewMode = false;
      isEditMode = true;
      this.setState({
        ApprovedBy: [],
        ApprovedDt: null,
        Status: "Open"
      });
      ApprovedByHistory=[];
      console.log(this.state.EmailIdList);
      const docUrl = this.props.siteurl + "?itemID=" + uniqueId;
      let addressString: string = await sp.utility.getCurrentUserEmailAddresses();
      const emailProps = {
        To: this.state.EmailIdList,
        From: addressString,
        CC: [],
        BCC: [],
        //Subject:  "Update for " + this.state.DocType+ " # " + this.state.DocNumber+ " - " + this.state.Title,
        Subject: this.state.DocType + " Has Been Reopened for " + this.state.ProjectArea + " Document ID: " + this.state.DocNumber + " - " + this.state.Title,
        Body: "Click the link to open the document -<b><a href='" + docUrl + "'>Document</a></b>",
        AdditionalHeaders: {
          "content-type": "text/html"
        }
      };

      //  await sp.utility.sendEmail(emailProps).then((res)=>{
      //   if(res!=undefined){
      //     this.checkUpdateHistory();
      //   }
      // });
      if (this.state.EmailIdList.length != 0) {
        await sp.utility.sendEmail(emailProps).then((res) => {
          this.checkUpdateHistory();
          // loadSpinner = false;
          // this.setState({ isSavedHidden: false, isDisabled: '' });
        }).catch(error => {

          isEmailError = true;
          // loadSpinner = false;
          // this.setState({ isDisabled: '' });
          this.checkUpdateHistory();

        });
      }else{
        // loadSpinner = false;
        this.checkUpdateHistory();
        // this.setState({ isSavedHidden: false, isDisabled: '' });
      }
    } catch (e) {
      console.log(e);
    }

  }

  SendEmail = async (id) => {
    debugger;
    //from, external
    try {
      if (uniqueId == 0) {
        // const receipent=this.state.EmailIdList
        console.log(this.state.EmailIdList);
        // const docUrl = "https://zurichinsurancenam.sharepoint.com/sites/VALIDATIONS/SitePages/ProblemForm.aspx?itemID=" + id;
        const docUrl = this.props.siteurl + "?itemID=" + id;
        let addressString: string = await sp.utility.getCurrentUserEmailAddresses();
        const emailProps = {
          To: this.state.EmailIdList,
          From: addressString,
          CC: [],
          BCC: [],
          Subject: " New " + this.state.DocType + " for " + this.state.ProjectArea + " Document ID: " + this.state.docnumber + " - " + this.state.Title,
          Body: "Click the link to open the document -<b><a href='" + docUrl + "'>Document</a></b>",
          AdditionalHeaders: {
            "content-type": "text/html"
          }
        };

        const Email = await sp.utility.sendEmail(emailProps).then((res) => {
          loadSpinner = false;
          this.setState({ isSavedHidden: false, isDisabled: '' });
        }).catch(error => {
          isEmailError = true;
          loadSpinner = false;
          this.setState({ isSavedHidden: false, isDisabled: '' });

        });
      } else {
        // const receipent=this.state.SendTo
        // console.log(this.state.EmailIdList);
        const docUrl = this.props.siteurl + "?itemID=" + uniqueId;
        let addressString: string = await sp.utility.getCurrentUserEmailAddresses();
        debugger;
        const emailProps = {

          To: this.state.EmailIdList,
          From: addressString,
          CC: [],
          BCC: [],
          Subject: "Update for " + this.state.DocType + " # " + this.state.DocNumber + " - " + this.state.Title,
          Body: "Hi " + (SendToHistory.length > 0 ? SendToHistory.toString() : localSendToUser.toString()) + ", <br/>" + (this.state.sendUpdateBody != '' ? "<br/>" + this.state.sendUpdateBody + "<br/>" : '') + "<br/> Click the link to open the document -<b><a href='" + docUrl + "'>Document</a></b> <br/><br></br> Thank You <br/>" + this.props.context.pageContext.user.displayName,
          AdditionalHeaders: {
            "content-type": "text/html"
          }
        };

        const Email = await sp.utility.sendEmail(emailProps).then((res) => {
          loadSpinner = false;
          this.setState({ isSavedHidden: false, isDisabled: '' });
        }).catch(error => {
          isEmailError = true;
          loadSpinner = false;
          this.setState({ isSavedHidden: false, isDisabled: '' });

        });
      }
    } catch (e) {
      console.log(e);
    }
  }

  createNewResponse = () => {
    //https://zurichinsurancenam.sharepoint.com/sites/VALIDATIONS/SitePages/ResponseForm.aspx
    window.location.assign(this.props.responseurl + '?itemID=' + this.state.FormID);
  }

  showResponse = async () => {

    // let stamp=new Date();
    // var dateTime = moment().format('L h:mm');



    await sp.web.lists.getByTitle("Response").items.getAll().then(res => {
      debugger;
      // console.log(res);
      let matcharray = [];

      res.map((item) => {
        // const dig=(item.ParentUNID).localeCompare(this.state.FormNoteID);
        // if(dig==0){
        if (item.ParentUNID == this.state.FormNoteID) {
          debugger;
          matcharray.push({ 'Date': item.Date, 'ParentUNID': item.ParentUNID, 'SharePointID': item.ID, 'ResTitle': item.Title });
        }
      });


      console.log(matcharray);
      this.dataFormResponse(matcharray);
    }).catch(error => {
      console.log(error);
    });

  }
  dataFormResponse = (matcharray) => {
    if (matcharray.length != 0) {
      this.setState({
        ResponseData: matcharray
      });
    }
  }
  showResponseList = () => {

    return this.state.ResponseData.map((item) => {
      return (
        <div className='row border'>
          <div className='col-md-2 text-center'>

            <a href={this.props.responseurl + '?resID=' + item.SharePointID + '&itemID=' + uniqueId}><Icon iconName="View" className='btn btn-light' /></a>
          </div>
          <div className='col-md-2'>
            {moment(item.Date).format('L')}
          </div>
          <div className='col-md-8'>
            {item.ResTitle}
          </div>
        </div>
      );
    });

  }


  handleRichTextChange = (fieldName, content,test) => {
    
    try {
     
      switch (fieldName) {

        case 'Probdesc':
          
         if(!isProbdescContent){
          this.setState({ Probdesc: content });


        }else{
          isProbdescContent=false;
        }
          
          break;
        case 'Proposedres':
          if(!isProposedresContent){
            this.setState({ Proposedres: content });
  
  
          }else{
            isProposedresContent=false;
          }
          
          break;
        case 'Resolution':
          if(!isResolutionContent){
            this.setState({ Resolution: content });
  
  
          }else{
            isResolutionContent=false;
          }
          
          break;
        case 'Suggest':
          if(!isSuggestContent){
            this.setState({ Suggest: content });
  
  
          }else{
            isSuggestContent=false;
          }
          
          break;
        case 'Comments':
          if(!isCommentsContent){
            this.setState({ Comments: content });
  
  
          }else{
            isCommentsContent=false;
          }
          
          break;

      }
    }
    catch (e) {
      console.log('handleRichTextChange: ' + e);
    }
  }

  // handleCommentsImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {
  //   debugger;
  //   if (imageInfo != null) {
  //     let files = uploadedCommentsRichTextFiles;
  //     let dataURI = imageInfo.src;
  //     let fileName = imageInfo.name;
  //     if (dataURI.split(',')[0].indexOf('base64') >= 0) {
  //       var arr = dataURI.split(','),
  //         mime = arr[0].match(/:(.*?);/)[1],
  //         bstr = atob(arr[1]),
  //         n = bstr.length,
  //         u8arr = new Uint8Array(n);
  //       while (n--) {
  //         u8arr[n] = bstr.charCodeAt(n);
  //       }
  //       const file = new File([u8arr], fileName, { type: mime });
  //       let fExists = files.some((f) => f['name'] === file['name']);
  //       if (!fExists) {
  //         files.push(file);
  //       }
  //       uploadedCommentsRichTextFiles = files;
  //     }
  //   }
  // }

  // handleSuggestImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {
  //   debugger;
  //   if (imageInfo != null) {
  //     let files = uploadedSuggestRichTextFiles;
  //     let dataURI = imageInfo.src;
  //     let fileName = imageInfo.name;
  //     if (dataURI.split(',')[0].indexOf('base64') >= 0) {
  //       var arr = dataURI.split(','),
  //         mime = arr[0].match(/:(.*?);/)[1],
  //         bstr = atob(arr[1]),
  //         n = bstr.length,
  //         u8arr = new Uint8Array(n);
  //       while (n--) {
  //         u8arr[n] = bstr.charCodeAt(n);
  //       }
  //       const file = new File([u8arr], fileName, { type: mime });
  //       let fExists = files.some((f) => f['name'] === file['name']);
  //       if (!fExists) {
  //         files.push(file);
  //       }
  //       uploadedSuggestRichTextFiles = files;
  //     }
  //   }
  // }
  // handleResolutionImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {
  //   debugger;
  //   if (imageInfo != null) {
  //     let files = uploadedResolutionRichTextFiles;
  //     let dataURI = imageInfo.src;
  //     let fileName = imageInfo.name;
  //     if (dataURI.split(',')[0].indexOf('base64') >= 0) {
  //       var arr = dataURI.split(','),
  //         mime = arr[0].match(/:(.*?);/)[1],
  //         bstr = atob(arr[1]),
  //         n = bstr.length,
  //         u8arr = new Uint8Array(n);
  //       while (n--) {
  //         u8arr[n] = bstr.charCodeAt(n);
  //       }
  //       const file = new File([u8arr], fileName, { type: mime });
  //       let fExists = files.some((f) => f['name'] === file['name']);
  //       if (!fExists) {
  //         files.push(file);
  //       }
  //       uploadedResolutionRichTextFiles = files;
  //     }
  //   }
  // }

  // handleProposedresImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {
  //   debugger;
  //   if (imageInfo != null) {
  //     let files = uploadedProposedresRichTextFiles;
  //     let dataURI = imageInfo.src;
  //     let fileName = imageInfo.name;
  //     if (dataURI.split(',')[0].indexOf('base64') >= 0) {
  //       var arr = dataURI.split(','),
  //         mime = arr[0].match(/:(.*?);/)[1],
  //         bstr = atob(arr[1]),
  //         n = bstr.length,
  //         u8arr = new Uint8Array(n);
  //       while (n--) {
  //         u8arr[n] = bstr.charCodeAt(n);
  //       }
  //       const file = new File([u8arr], fileName, { type: mime });
  //       let fExists = files.some((f) => f['name'] === file['name']);
  //       if (!fExists) {
  //         files.push(file);
  //       }
  //       uploadedProposedresRichTextFiles = files;
  //     }
  //   }
  // }
  handleImageUploadBefore(files, info, uploadHandler) {
    debugger;
    let fileName = files[0].name;

    let memory = files[0].size;
    // this.CheckFileBeforeUpload(fileName).then((val)=>{return val});
    // return allowUploadImage;
    var allowUploadImage = true;
    if(memory/1024<1024){

    if ((arrAllPrevAttachments != null && arrAllPrevAttachments != undefined && arrAllPrevAttachments.length > 0 && arrAllPrevAttachments.indexOf(fileName) > -1)) {

      let AttachmentPresent = false;
      for (let data in arrAllPrevAttachments) {
        if (data != null && data != undefined && data.length > 0) {
          if (arrAllPrevAttachments[data].toUpperCase() === fileName.toUpperCase()) {

            AttachmentPresent = true;
            break;
          }
        }
      }

      let isFileNotinProgram = (prevUploadedFilesObjProgram.arrPrevTobeRemovedFiles != null && prevUploadedFilesObjProgram.arrPrevTobeRemovedFiles != undefined && prevUploadedFilesObjProgram.arrPrevTobeRemovedFiles.length > 0 && prevUploadedFilesObjProgram.arrPrevTobeRemovedFiles.indexOf(fileName) < 0);
      let isFileNotinProposedres = (prevUploadedFilesObjProposedres.arrPrevTobeRemovedFiles != null && prevUploadedFilesObjProposedres.arrPrevTobeRemovedFiles != undefined && prevUploadedFilesObjProposedres.arrPrevTobeRemovedFiles.length > 0 && prevUploadedFilesObjProposedres.arrPrevTobeRemovedFiles.indexOf(fileName) < 0);
      let isFileNotinResolution = (prevUploadedFilesObjResolution.arrPrevTobeRemovedFiles != null && prevUploadedFilesObjResolution.arrPrevTobeRemovedFiles != undefined && prevUploadedFilesObjResolution.arrPrevTobeRemovedFiles.length > 0 && prevUploadedFilesObjResolution.arrPrevTobeRemovedFiles.indexOf(fileName) < 0);
      let isFileNotinSuggest = (prevUploadedFilesObjSuggest.arrPrevTobeRemovedFiles != null && prevUploadedFilesObjSuggest.arrPrevTobeRemovedFiles != undefined && prevUploadedFilesObjSuggest.arrPrevTobeRemovedFiles.length > 0 && prevUploadedFilesObjSuggest.arrPrevTobeRemovedFiles.indexOf(fileName) < 0);
      let isFileNotinComments = (prevUploadedFilesObjComments.arrPrevTobeRemovedFiles != null && prevUploadedFilesObjComments.arrPrevTobeRemovedFiles != undefined && prevUploadedFilesObjComments.arrPrevTobeRemovedFiles.length > 0 && prevUploadedFilesObjComments.arrPrevTobeRemovedFiles.indexOf(fileName) < 0);

      if (AttachmentPresent && (isFileNotinProgram || isFileNotinProposedres || isFileNotinResolution || isFileNotinSuggest || isFileNotinComments)) {
        allowUploadImage = false;
        alert("The file is already present.Please remove or upload file with a different Name");
        //  dialogModalError.subText="The file is already present.Please remove or upload file with a diffrent Name";
        //  this.setState({isModalErrorClose:false});
      }
    }
      let isFileinNwProgram = prevUploadedFilesObjProgram.newUploadedFileArray != null && prevUploadedFilesObjProgram.newUploadedFileArray != undefined && prevUploadedFilesObjProgram.newUploadedFileArray.length > 0 && prevUploadedFilesObjProgram.newUploadedFileArray.some(el => el.name === fileName);
      let isFileinNwProposedres = prevUploadedFilesObjProposedres.newUploadedFileArray != null && prevUploadedFilesObjProposedres.newUploadedFileArray != undefined && prevUploadedFilesObjProposedres.newUploadedFileArray.length > 0 && prevUploadedFilesObjProposedres.newUploadedFileArray.some(el => el.name === fileName);
      let isFileinNwResolution = prevUploadedFilesObjResolution.newUploadedFileArray != null && prevUploadedFilesObjResolution.newUploadedFileArray != undefined && prevUploadedFilesObjResolution.newUploadedFileArray.length > 0 && prevUploadedFilesObjResolution.newUploadedFileArray.some(el => el.name === fileName);
      let isFileinNwSuggest = prevUploadedFilesObjSuggest.newUploadedFileArray != null && prevUploadedFilesObjSuggest.newUploadedFileArray != undefined && prevUploadedFilesObjSuggest.newUploadedFileArray.length > 0 && prevUploadedFilesObjSuggest.newUploadedFileArray.some(el => el.name === fileName);
      let isFileinNwComments = prevUploadedFilesObjComments.newUploadedFileArray != null && prevUploadedFilesObjComments.newUploadedFileArray != undefined && prevUploadedFilesObjComments.newUploadedFileArray.length > 0 && prevUploadedFilesObjComments.newUploadedFileArray.some(el => el.name === fileName);
      if (allowUploadImage && (isFileinNwProgram || isFileinNwProposedres || isFileinNwResolution || isFileinNwSuggest || isFileinNwComments)) {
        allowUploadImage = false;
        alert("The file is already present in the new selected files.Please remove or upload file with a different Name");
        // dialogModalError.subText="The file is already present in the new selected files.Please remove or upload file with a diffrent Name";
        // this.setState({isModalErrorClose:false});
      }
      let isFileinRichProgram = prevUploadedFilesObjProgram.uploadedRichTextFiles != null && prevUploadedFilesObjProgram.uploadedRichTextFiles != undefined && prevUploadedFilesObjProgram.uploadedRichTextFiles.some(el => el.imgFileName === fileName);
      let isFileinRichProposedres = prevUploadedFilesObjProposedres.uploadedRichTextFiles != null && prevUploadedFilesObjProposedres.uploadedRichTextFiles != undefined && prevUploadedFilesObjProposedres.uploadedRichTextFiles.some(el => el.imgFileName === fileName);
      let isFileinRichResolution = prevUploadedFilesObjResolution.uploadedRichTextFiles != null && prevUploadedFilesObjResolution.uploadedRichTextFiles != undefined && prevUploadedFilesObjResolution.uploadedRichTextFiles.some(el => el.imgFileName === fileName);
      let isFileinRichSuggest = prevUploadedFilesObjSuggest.uploadedRichTextFiles != null && prevUploadedFilesObjSuggest.uploadedRichTextFiles != undefined && prevUploadedFilesObjSuggest.uploadedRichTextFiles.some(el => el.imgFileName === fileName);
      let isFileinRichComments = prevUploadedFilesObjComments.uploadedRichTextFiles != null && prevUploadedFilesObjComments.uploadedRichTextFiles != undefined && prevUploadedFilesObjComments.uploadedRichTextFiles.some(el => el.imgFileName === fileName);
      
      if (allowUploadImage && (isFileinRichProgram || isFileinRichProposedres || isFileinRichResolution || isFileinRichSuggest || isFileinRichComments)) {
        allowUploadImage = false;
        alert("The file is already present in the notes as files.Please remove or upload file with a different Name");
        // dialogModalError.subText="The file is already present in the notes as  files.Please remove or upload file with a diffrent Name";
        // this.setState({isModalErrorClose:false});
      }

      if (allowUploadImage && files[0].type != "image/png" && files[0].type != "image/PNG" && files[0].type != "image/JPEG" && files[0].type != "image/jpeg" && files[0].type != "image/jpg" && files[0].type != "image/JPG") {
        allowUploadImage = false;
        alert("The image file should be in JPEG or PNG format.Please upload with specified format");
        //  dialogModalError.subText="The image file should be in JPEG or PNG format.Please upload with specified format";
        //  this.setState({isModalErrorClose:false});
      }
    
    //return allowUploadImage;
    }else{
      allowUploadImage = false;
      alert("Please Upload the image less than 1024 KB");
      
    }
    return allowUploadImage;
}

  handleProbdescImageUpload = (targetImgElement, index, state, imageInfo, remainingFilesCount) => {
  
    if (imageInfo != null) {
      let files = prevUploadedFilesObjProgram.uploadedRichTextFiles;
      let dataURI = imageInfo.src;
      let fileName = imageInfo.name;
      // let fileName=event.target.files[0].name;
      if (dataURI.split(',')[0].indexOf('base64') >= 0) {
        var arr = dataURI.split(','),
          mime = arr[0].match(/:(.*?);/)[1],
          bstr = atob(arr[1]),
          n = bstr.length,
          u8arr = new Uint8Array(n);
        while (n--) {
          u8arr[n] = bstr.charCodeAt(n);
        }
        const file = new File([u8arr], fileName, { type: mime });
        let fExists = files.some((f) => f.imgIndex === index);
        if (fExists) {
          //let fileTobeUpdated = files.findIndex((e)=> { return e.imgIndex === index });
          // files.push({imgIndex:index,imgFileName:fileName, imgFile: file});
          files.forEach(element => {
            if (element.imgIndex == index) {
              element.imgFileName = fileName;
              element.imgFile = file;
              element.IsBase64 = true;
            }
          });
        }


        else {
          files.push({ imgIndex: index, imgFileName: fileName, imgFile: file, IsBase64: true });
        }
        prevUploadedFilesObjProgram.uploadedRichTextFiles = files;

      }
      else if (state == "update" && event == undefined) {
        if (files != null && files != undefined && files.length > 0) {
          let fExists = files.some((f) => f.imgIndex === index);
          if (fExists) {
            // files.forEach(element => {
            //   if(element.imgIndex==index)
            //   {
            //     //files.push({imgIndex:index,imgFileName:fileName, imgFile: null,IsBase64:false});
            //     //as same data no need to update
            //   }

            // });
          }
          else {
            files.push({ imgIndex: index, imgFileName: fileName, imgFile: null, IsBase64: false });
          }
        }
        else {
          files.push({ imgIndex: index, imgFileName: fileName, imgFile: null, IsBase64: false });
        }
        prevUploadedFilesObjProgram.uploadedRichTextFiles = files;
      }
    }
            debugger;
    if (((document.activeElement.closest('.Probdesc') != null) && state == "delete" && (document.activeElement.className.indexOf('sun-editor-editable') !=-1 || document.activeElement.className.indexOf('se-btn se-tooltip')!= -1))) {
      // var isIndexPresent=  alluploadedfilesinRichText.some(el => el.ImgID === index);
      debugger;
      var counter = 0;
      if (prevUploadedFilesObjProgram.uploadedRichTextFiles != null && prevUploadedFilesObjProgram.uploadedRichTextFiles != undefined && prevUploadedFilesObjProgram.uploadedRichTextFiles.length > 0) {
        prevUploadedFilesObjProgram.uploadedRichTextFiles.forEach(element => {
          if (element.imgIndex === index) {
            prevUploadedFilesObjProgram.uploadedRichTextFiles.splice(counter, 1);
            if (arrAllPrevAttachments != null && arrAllPrevAttachments != undefined && arrAllPrevAttachments.length > 0 && arrAllPrevAttachments.indexOf(element.imgFileName) > -1) {
              let alltobeRemovedArr = prevUploadedFilesObjProgram.arrPrevTobeRemovedFiles;
              if (alltobeRemovedArr != null && alltobeRemovedArr != undefined) {
                if (alltobeRemovedArr.length > 0 && alltobeRemovedArr.indexOf(element.imgFileName) < 0) {

                  alltobeRemovedArr.push(element.imgFileName);
                }
                else {
                  alltobeRemovedArr.push(element.imgFileName);
                }
              }
              else {
                alltobeRemovedArr.push(element.imgFileName);
              }
              prevUploadedFilesObjProgram.arrPrevTobeRemovedFiles = alltobeRemovedArr;
            }
          }
          counter++;
        });
      }
    }
  }

  handleResolutionImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {
    debugger;
    if (imageInfo != null) {
      let files = prevUploadedFilesObjResolution.uploadedRichTextFiles;
      let dataURI = imageInfo.src;
      let fileName = imageInfo.name;
      // let fileName=event.target.files[0].name;
      if (dataURI.split(',')[0].indexOf('base64') >= 0) {
        var arr = dataURI.split(','),
          mime = arr[0].match(/:(.*?);/)[1],
          bstr = atob(arr[1]),
          n = bstr.length,
          u8arr = new Uint8Array(n);
        while (n--) {
          u8arr[n] = bstr.charCodeAt(n);
        }
        const file = new File([u8arr], fileName, { type: mime });
        let fExists = files.some((f) => f.imgIndex === index);
        if (fExists) {
          //let fileTobeUpdated = files.findIndex((e)=> { return e.imgIndex === index });
          // files.push({imgIndex:index,imgFileName:fileName, imgFile: file});
          files.forEach(element => {
            if (element.imgIndex == index) {
              element.imgFileName = fileName;
              element.imgFile = file;
              element.IsBase64 = true;
            }
          });
        }


        else {
          files.push({ imgIndex: index, imgFileName: fileName, imgFile: file, IsBase64: true });
        }
        prevUploadedFilesObjResolution.uploadedRichTextFiles = files;

      }
      else if (state == "update" && event == undefined) {
        if (files != null && files != undefined && files.length > 0) {
          let fExists = files.some((f) => f.imgIndex === index);
          if (fExists) {
            // files.forEach(element => {
            //   if(element.imgIndex==index)
            //   {
            //     //files.push({imgIndex:index,imgFileName:fileName, imgFile: null,IsBase64:false});
            //     //as same data no need to update
            //   }

            // });
          }
          else {
            files.push({ imgIndex: index, imgFileName: fileName, imgFile: null, IsBase64: false });
          }
        }
        else {
          files.push({ imgIndex: index, imgFileName: fileName, imgFile: null, IsBase64: false });
        }
        prevUploadedFilesObjResolution.uploadedRichTextFiles = files;
      }
    }
           debugger;
           let test = document.activeElement.className.indexOf('sun-editor-editable'); 
    if (((document.activeElement.closest('.Resolution') != null) && state == "delete" && (document.activeElement.className.indexOf('sun-editor-editable') !=-1 || document.activeElement.className.indexOf('se-btn se-tooltip')!= -1))) {
      // var isIndexPresent=  alluploadedfilesinRichText.some(el => el.ImgID === index);
      debugger;
      var counter = 0;
      if (prevUploadedFilesObjResolution.uploadedRichTextFiles != null && prevUploadedFilesObjResolution.uploadedRichTextFiles != undefined && prevUploadedFilesObjResolution.uploadedRichTextFiles.length > 0) {
        prevUploadedFilesObjResolution.uploadedRichTextFiles.forEach(element => {
          if (element.imgIndex === index) {
            prevUploadedFilesObjResolution.uploadedRichTextFiles.splice(counter, 1);
            if (arrAllPrevAttachments != null && arrAllPrevAttachments != undefined && arrAllPrevAttachments.length > 0 && arrAllPrevAttachments.indexOf(element.imgFileName) > -1) {
              let alltobeRemovedArr = prevUploadedFilesObjResolution.arrPrevTobeRemovedFiles;
              if (alltobeRemovedArr != null && alltobeRemovedArr != undefined) {
                if (alltobeRemovedArr.length > 0 && alltobeRemovedArr.indexOf(element.imgFileName) < 0) {

                  alltobeRemovedArr.push(element.imgFileName);
                }
                else {
                  alltobeRemovedArr.push(element.imgFileName);
                }
              }
              else {
                alltobeRemovedArr.push(element.imgFileName);
              }
              prevUploadedFilesObjResolution.arrPrevTobeRemovedFiles = alltobeRemovedArr;
            }
          }
          counter++;
        });
      }
    }
  }



  handleProposedresImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {
    debugger;
    if (imageInfo != null) {
      let files = prevUploadedFilesObjProposedres.uploadedRichTextFiles;
      let dataURI = imageInfo.src;
      let fileName = imageInfo.name;
      // let fileName=event.target.files[0].name;
      if (dataURI.split(',')[0].indexOf('base64') >= 0) {
        var arr = dataURI.split(','),
          mime = arr[0].match(/:(.*?);/)[1],
          bstr = atob(arr[1]),
          n = bstr.length,
          u8arr = new Uint8Array(n);
        while (n--) {
          u8arr[n] = bstr.charCodeAt(n);
        }
        const file = new File([u8arr], fileName, { type: mime });
        let fExists = files.some((f) => f.imgIndex === index);
        if (fExists) {
          //let fileTobeUpdated = files.findIndex((e)=> { return e.imgIndex === index });
          // files.push({imgIndex:index,imgFileName:fileName, imgFile: file});
          files.forEach(element => {
            if (element.imgIndex == index) {
              element.imgFileName = fileName;
              element.imgFile = file;
              element.IsBase64 = true;
            }
          });
        }


        else {
          files.push({ imgIndex: index, imgFileName: fileName, imgFile: file, IsBase64: true });
        }
        prevUploadedFilesObjProposedres.uploadedRichTextFiles = files;

      }
      else if (state == "update" && event == undefined) {
        if (files != null && files != undefined && files.length > 0) {
          let fExists = files.some((f) => f.imgIndex === index);
          if (fExists) {
            // files.forEach(element => {
            //   if(element.imgIndex==index)
            //   {
            //     //files.push({imgIndex:index,imgFileName:fileName, imgFile: null,IsBase64:false});
            //     //as same data no need to update
            //   }

            // });
          }
          else {
            files.push({ imgIndex: index, imgFileName: fileName, imgFile: null, IsBase64: false });
          }
        }
        else {
          files.push({ imgIndex: index, imgFileName: fileName, imgFile: null, IsBase64: false });
        }
        prevUploadedFilesObjProposedres.uploadedRichTextFiles = files;
      }
    }
      debugger;
    if (((document.activeElement.closest('.Proposedres') != null) && state == "delete" && (document.activeElement.className.indexOf('sun-editor-editable') !=-1 || document.activeElement.className.indexOf('se-btn se-tooltip')!= -1))) {
      // var isIndexPresent=  alluploadedfilesinRichText.some(el => el.ImgID === index);
      debugger;
      var counter = 0;
      if (prevUploadedFilesObjProposedres.uploadedRichTextFiles != null && prevUploadedFilesObjProposedres.uploadedRichTextFiles != undefined && prevUploadedFilesObjProposedres.uploadedRichTextFiles.length > 0) {
        prevUploadedFilesObjProposedres.uploadedRichTextFiles.forEach(element => {
          if (element.imgIndex === index) {
            prevUploadedFilesObjProposedres.uploadedRichTextFiles.splice(counter, 1);
            if (arrAllPrevAttachments != null && arrAllPrevAttachments != undefined && arrAllPrevAttachments.length > 0 && arrAllPrevAttachments.indexOf(element.imgFileName) > -1) {
              let alltobeRemovedArr = prevUploadedFilesObjProposedres.arrPrevTobeRemovedFiles;
              if (alltobeRemovedArr != null && alltobeRemovedArr != undefined) {
                if (alltobeRemovedArr.length > 0 && alltobeRemovedArr.indexOf(element.imgFileName) < 0) {

                  alltobeRemovedArr.push(element.imgFileName);
                }
                else {
                  alltobeRemovedArr.push(element.imgFileName);
                }
              }
              else {
                alltobeRemovedArr.push(element.imgFileName);
              }
              prevUploadedFilesObjProposedres.arrPrevTobeRemovedFiles = alltobeRemovedArr;
            }
          }
          counter++;
        });
      }
    }
  }


  handleSuggestImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {
    debugger;
    if (imageInfo != null) {
      let files = prevUploadedFilesObjSuggest.uploadedRichTextFiles;
      let dataURI = imageInfo.src;
      let fileName = imageInfo.name;
      // let fileName=event.target.files[0].name;
      if (dataURI.split(',')[0].indexOf('base64') >= 0) {
        var arr = dataURI.split(','),
          mime = arr[0].match(/:(.*?);/)[1],
          bstr = atob(arr[1]),
          n = bstr.length,
          u8arr = new Uint8Array(n);
        while (n--) {
          u8arr[n] = bstr.charCodeAt(n);
        }
        const file = new File([u8arr], fileName, { type: mime });
        let fExists = files.some((f) => f.imgIndex === index);
        if (fExists) {
          //let fileTobeUpdated = files.findIndex((e)=> { return e.imgIndex === index });
          // files.push({imgIndex:index,imgFileName:fileName, imgFile: file});
          files.forEach(element => {
            if (element.imgIndex == index) {
              element.imgFileName = fileName;
              element.imgFile = file;
              element.IsBase64 = true;
            }
          });
        }


        else {
          files.push({ imgIndex: index, imgFileName: fileName, imgFile: file, IsBase64: true });
        }
        prevUploadedFilesObjSuggest.uploadedRichTextFiles = files;

      }
      else if (state == "update" && event == undefined) {
        if (files != null && files != undefined && files.length > 0) {
          let fExists = files.some((f) => f.imgIndex === index);
          if (fExists) {
            // files.forEach(element => {
            //   if(element.imgIndex==index)
            //   {
            //     //files.push({imgIndex:index,imgFileName:fileName, imgFile: null,IsBase64:false});
            //     //as same data no need to update
            //   }

            // });
          }
          else {
            files.push({ imgIndex: index, imgFileName: fileName, imgFile: null, IsBase64: false });
          }
        }
        else {
          files.push({ imgIndex: index, imgFileName: fileName, imgFile: null, IsBase64: false });
        }
        prevUploadedFilesObjSuggest.uploadedRichTextFiles = files;
      }
    }
       let var1 = document.activeElement.closest('.Suggest');
       let var2 = document.activeElement.className.indexOf('se-btn se-tooltip');
       debugger;
    if (((document.activeElement.closest('.Suggest') != null) && state == "delete" && (document.activeElement.className.indexOf('sun-editor-editable') !=-1 || document.activeElement.className.indexOf('se-btn se-tooltip')!= -1) ) ) {
      // var isIndexPresent=  alluploadedfilesinRichText.some(el => el.ImgID === index);
      debugger;
      
      var counter = 0;
      if (prevUploadedFilesObjSuggest.uploadedRichTextFiles != null && prevUploadedFilesObjSuggest.uploadedRichTextFiles != undefined && prevUploadedFilesObjSuggest.uploadedRichTextFiles.length > 0) {
        prevUploadedFilesObjSuggest.uploadedRichTextFiles.forEach(element => {
          if (element.imgIndex === index) {
            prevUploadedFilesObjSuggest.uploadedRichTextFiles.splice(counter, 1);
            if (arrAllPrevAttachments != null && arrAllPrevAttachments != undefined && arrAllPrevAttachments.length > 0 && arrAllPrevAttachments.indexOf(element.imgFileName) > -1) {
              let alltobeRemovedArr = prevUploadedFilesObjSuggest.arrPrevTobeRemovedFiles;
              if (alltobeRemovedArr != null && alltobeRemovedArr != undefined) {
                if (alltobeRemovedArr.length > 0 && alltobeRemovedArr.indexOf(element.imgFileName) < 0) {

                  alltobeRemovedArr.push(element.imgFileName);
                }
                else {
                  alltobeRemovedArr.push(element.imgFileName);
                }
              }
              else {
                alltobeRemovedArr.push(element.imgFileName);
              }
              prevUploadedFilesObjSuggest.arrPrevTobeRemovedFiles = alltobeRemovedArr;
            }
          }
          counter++;
        });
      }
    }
  }


  handleCommentsImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {
    debugger;
    if (imageInfo != null) {
      let files = prevUploadedFilesObjComments.uploadedRichTextFiles;
      let dataURI = imageInfo.src;
      let fileName = imageInfo.name;
      // let fileName=event.target.files[0].name;
      if (dataURI.split(',')[0].indexOf('base64') >= 0) {
        var arr = dataURI.split(','),
          mime = arr[0].match(/:(.*?);/)[1],
          bstr = atob(arr[1]),
          n = bstr.length,
          u8arr = new Uint8Array(n);
        while (n--) {
          u8arr[n] = bstr.charCodeAt(n);
        }
        const file = new File([u8arr], fileName, { type: mime });
        let fExists = files.some((f) => f.imgIndex === index);
        if (fExists) {
          //let fileTobeUpdated = files.findIndex((e)=> { return e.imgIndex === index });
          // files.push({imgIndex:index,imgFileName:fileName, imgFile: file});
          files.forEach(element => {
            if (element.imgIndex == index) {
              element.imgFileName = fileName;
              element.imgFile = file;
              element.IsBase64 = true;
            }
          });
        }


        else {
          files.push({ imgIndex: index, imgFileName: fileName, imgFile: file, IsBase64: true });
        }
        prevUploadedFilesObjComments.uploadedRichTextFiles = files;

      }
      else if (state == "update" && event == undefined) {
        if (files != null && files != undefined && files.length > 0) {
          let fExists = files.some((f) => f.imgIndex === index);
          if (fExists) {
            // files.forEach(element => {
            //   if(element.imgIndex==index)
            //   {
            //     //files.push({imgIndex:index,imgFileName:fileName, imgFile: null,IsBase64:false});
            //     //as same data no need to update
            //   }

            // });
          }
          else {
            files.push({ imgIndex: index, imgFileName: fileName, imgFile: null, IsBase64: false });
          }
        }
        else {
          files.push({ imgIndex: index, imgFileName: fileName, imgFile: null, IsBase64: false });
        }
        prevUploadedFilesObjComments.uploadedRichTextFiles = files;
      }
    }

    if (((document.activeElement.closest('.Comments') != null) && state == "delete" && (document.activeElement.className.indexOf('sun-editor-editable') !=-1 || document.activeElement.className.indexOf('se-btn se-tooltip')!= -1))) {
      // var isIndexPresent=  alluploadedfilesinRichText.some(el => el.ImgID === index);
      var counter = 0;
      if (prevUploadedFilesObjComments.uploadedRichTextFiles != null && prevUploadedFilesObjComments.uploadedRichTextFiles != undefined && prevUploadedFilesObjComments.uploadedRichTextFiles.length > 0) {
        prevUploadedFilesObjComments.uploadedRichTextFiles.forEach(element => {
          if (element.imgIndex === index) {
            prevUploadedFilesObjComments.uploadedRichTextFiles.splice(counter, 1);
            if (arrAllPrevAttachments != null && arrAllPrevAttachments != undefined && arrAllPrevAttachments.length > 0 && arrAllPrevAttachments.indexOf(element.imgFileName) > -1) {
              let alltobeRemovedArr = prevUploadedFilesObjComments.arrPrevTobeRemovedFiles;
              if (alltobeRemovedArr != null && alltobeRemovedArr != undefined) {
                if (alltobeRemovedArr.length > 0 && alltobeRemovedArr.indexOf(element.imgFileName) < 0) {

                  alltobeRemovedArr.push(element.imgFileName);
                }
                else {
                  alltobeRemovedArr.push(element.imgFileName);
                }
              }
              else {
                alltobeRemovedArr.push(element.imgFileName);
              }
              prevUploadedFilesObjComments.arrPrevTobeRemovedFiles = alltobeRemovedArr;
            }
          }
          counter++;
        });
      }
    }
  }

  private sendUpdateBodyContent = (e) => {
    this.setState({
      sendUpdateBody: e.target.value
    })
  }

  //Render Method //
  public render(): React.ReactElement<IValidationsProblemProps> {
    try {
      return (
        <ThemeProvider theme={myTheme}>
          <div className={'container ' + this.state.isDisabled} >
            <div className='border p-3' style={{ backgroundColor: '#23366f' }}>
              <div className='row'>
                <div className='col-md-6'><h3 className="text-light ">{this.props.description} - {this.state.DocType} </h3></div>
                <div className='col-md-6 text-right'><img src={this.props.logourl} alt='Logo' width='50' height='50' /></div>
              </div>

            </div>



            {/* <PrimaryButton className='ml-1' text='Email' onClick={this.SendEmail} allowDisabledFocus/> */}

            {/* {isViewMode == true ?  */}
            <div>
              <div className='buttonCls container mt-2'>
                <div className='row'>
                  {isEditMode == true || uniqueId == 0 ? null : <DefaultButton className='ml-1' text='Exit' onClick={this.modalPopupOpen.bind(this, 'close')} allowDisabledFocus />}

                  {isEditMode == true || uniqueId == 0 ? null :

                    (isAdmin || isEditor || user == this.state.createdby) ? <PrimaryButton className='ml-1' text='Edit' onClick={this.EditClickBtn} allowDisabledFocus /> : null
                  }


                  {isAdmin && isViewMode == true ?
                    <PrimaryButton className='ml-1' text='Response' onClick={this.createNewResponse} allowDisabledFocus />
                    : null}

                </div>
              </div>
            </div>


            {isViewMode == true && isEditMode == false ?
              <div>

                <Separator styles={stylesSep}></Separator>
                <Pivot aria-label="Item">
                  <PivotItem
                    headerText="Item"

                    headerButtonProps={{
                      'data-order': 1,
                      'data-title': 'Problem',
                    }}
                  >
                    <Label styles={labelStyles} >
                      <ViewValidationsProblem {...this.state} />
                    </Label>

                  </PivotItem>

                  <PivotItem headerText="Response List">

                    <Label styles={labelStyles}><div className='table table-hover'>
                      <div className='row text-center'>
                        <th className='col-md-2'>
                          Action
                        </th>
                        <th className='col-md-2'>
                          Created on
                        </th>
                        <th className='col-md-8'>
                          Response Title
                        </th>
                      </div>
                      {this.showResponseList()}
                    </div></Label>
                  </PivotItem>
                  {this.state.DocType == 'Discussion Item' ? null :
                    <PivotItem
                      headerText="History"
                      headerButtonProps={{
                        'data-order': 1,
                        'data-title': 'Problem',
                      }}>
                      <Label styles={labelStyles} >
                        <div dangerouslySetInnerHTML={{ __html: this.state.EditHistoryFields }} />
                      </Label>
                    </PivotItem>
                  }
                  <PivotItem
                    headerText="Email Updates"
                    headerButtonProps={{
                      'data-order': 1,
                      'data-title': 'Problem',
                    }}>
                    <Label styles={labelStyles} >
                      <div dangerouslySetInnerHTML={{ __html: this.state.oldsendUpdateBody }} />
                    </Label>
                  </PivotItem>
                </Pivot>
              </div> :
              <div>

                <div className='buttonCls mt-1'>
                  <DefaultButton className='' text='Exit' onClick={this.modalPopupOpen.bind(this, 'close')} allowDisabledFocus />
                  <PrimaryButton className='ml-1' text='Save' onClick={this.CheckFormValidation.bind(this, 'save')} allowDisabledFocus />
                  {/* {isEditMode == true  ? <PrimaryButton className='ml-1' text='View' onClick={this.ViewClickBtn} allowDisabledFocus />: null} */}
                  <PrimaryButton className='ml-1' text='Save & Exit' onClick={this.CheckFormValidation.bind(this, 'saveClose')} allowDisabledFocus />

                  {/* {(this.state.Status == 'Closed' && isEditMode == true) ?
                  ((this.state.ApprovedBy == null || this.state.DocType == "Discussion Item" || uniqueId == 0 || isEditor == false)) ? null : <PrimaryButton className='ml-1' text='Reopen' onClick={this.modalPopupOpen.bind(this, 'statusreopen')} allowDisabledFocus />
                  : null} */}
                  {(this.state.Status == 'Closed' && isEditMode == true && (isAdmin == true || isEditor == true)) ?
                    (this.state.ApprovedBy.length != 0 && uniqueId !== 0) ? this.state.DocType == "Discussion Item" ? null : <PrimaryButton className='ml-1' text='Reopen' onClick={this.modalPopupOpen.bind(this, 'statusreopen')} allowDisabledFocus /> : null
                    : null}
                  {console.log(isAdmin, isEditor, this.state.ApprovedBy.length, this.state.DocType, isReader, uniqueId)}

                  {/* {(this.state.Status == 'Open' && isEditMode == true) ?
                  ((this.state.ApprovedBy! == null || this.state.DocType == "Discussion Item" || uniqueId == 0 || isEditor == false || isAdmin == false)) ? null : <PrimaryButton className='ml-1' text='Closed' onClick={this.modalPopupOpen.bind(this, 'statusclose')} allowDisabledFocus />
                  : null} */}
                  {(this.state.Status == 'Open' && isEditMode == true && (isAdmin == true || isEditor == true)) ?
                    (this.state.ApprovedBy.length == 0 && uniqueId !== 0) ? this.state.DocType == "Discussion Item" ? null : <PrimaryButton className='ml-1' text='Closed' onClick={this.modalPopupOpen.bind(this, 'statusclose')} allowDisabledFocus /> : null
                    : null}

                  {(this.state.SendTo == '' || uniqueId == 0) ? null : <PrimaryButton className='ml-1' text='Send Update' onClick={this.modalPopupOpen.bind(this, 'sendupdate')} allowDisabledFocus />}
                </div>
                {loadSpinner ? <ProgressIndicator className={'text-center'} label="Submiting Details" /> : null}


                <div className='border p-3 mt-2'>
                  <div className='row'>
                    <div className='col-md-12'>
                      <div className='w-100'>Created by {this.state.createdby} on {createtimearray[0]} at {createtimearray[1] + createtimearray[2]}</div>

                    </div>
                  </div>
                  <div className='row'>
                    <div className='col-md-6'>
                      <Dropdown
                        label='Document Type'
                        placeholder="Select an option"
                        errorMessage={this.state.DocTypeValidations}
                        selectedKey={this.state.DocType}
                        options={this.state.DocTypeChoice}
                        onChange={this.onDocTypeDropdownChange} />
                    </div>
                    {(this.state.ishide) ?
                      <div className='col-md-6'>
                        <TextField className='w-100' label='IO#' value={this.state.IONum} name='IONum' onChange={this.inputFormChange} />
                      </div>
                      : null}

                  </div>




                  <div className='row'>
                    <div className='col-md-6'>
                      <TextField className='w-100' label='Title' placeholder='Enter Title' value={this.state.Title} name='Title' errorMessage={this.state.TitleValidations} onChange={this.inputFormChange} />
                    </div>
                    <div className='col-md-6'>
                      <TextField className='w-100' disabled label='Document ID' value={this.state.DocNumber} name='DocNumber' onChange={this.inputFormChange} />
                    </div>
                  </div>
                  <div className='row'>
                    {(this.state.ishide) ?
                      <div className='col-md-6'>
                        <TextField className='w-100' label='Reporting Area' value={this.state.ReptArea} name='ReptArea' onChange={this.inputFormChange} />
                      </div>
                      : null}
                    {(this.state.ishide) ?
                      <div className='col-md-6'>
                        <TextField className='w-100' label='Reporting Manager' value={this.state.ReptMgr} name='ReptMgr' onChange={this.inputFormChange} />
                      </div>
                      : null}
                  </div>
                  <div className='row'>
                    <div className='col-md-6'>
                      <TextField className='w-100' label='Status' readOnly value={this.state.Status} name='Status' onChange={this.inputFormChange} />
                    </div>
                    {(this.state.DocType == 'Validations' || this.state.DocType == 'Issues') ?
                      <div className='col-md-6'>
                        <Dropdown
                          label={(this.state.DocType == 'Validations') ? "Result Ranking" : "Priority"}
                          placeholder="Select an option"
                          selectedKey={this.state.Priority}
                          options={this.state.PriorityChoice}
                          onChange={this.onPriorityDropDownChange} />
                      </div>
                      : null}
                  </div>
                  <div className='row'>
                    {(this.state.DocType == 'Validations' || this.state.DocType == 'Issues') ?
                      <div className='col-md-6'>
                        {/* {(this.state.DocType == 'Validations')?} 
                     */}
                        <Dropdown
                          label={(this.state.DocType == 'Validations') ? "Risk Level" : "Severity"}
                          placeholder="Select an option"
                          errorMessage={this.state.SeverityValidations}
                          selectedKey={this.state.Severity}
                          options={this.state.SeverityChoice}
                          onChange={this.onSeverityDropDownChange} />
                      </div>
                      : null}
                    {(this.state.DocType == 'Validations' || this.state.DocType == 'Issues' || this.state.DocType == 'Discussion Item') ?
                      <div className='col-md-6'>
                        <Dropdown
                          placeholder="Select options"
                          selectedKeys={this.state.UpdateKeywords}
                          //defaultSelectedKeys={this.state.UpdateKeywords}
                          // errorMessage={this.state.KeywordsValidations}
                          styles={dropdownStyles}
                          label={(this.state.DocType == 'Issues' || this.state.DocType == 'Discussion Item') ? "Category" : "Jurisdiction"}
                          multiSelect
                          options={this.state.JurisdictionChoice}
                          onChange={this.onKeywordsDropdownChange} />
                      </div>
                      : null}
                  </div>
                  <div className='row'>
                    <div className='col-md-6'>
                      <Dropdown
                        label={(this.state.DocType == 'Discussion Item') ? "Product Line" : (this.state.DocType == 'Issues') ? "Project Area" : "Compliance Action"}
                        placeholder="Select an option"
                        selectedKey={this.state.ProjectArea}
                        errorMessage={this.state.ProjectAreaValidations}
                        options={this.state.ProjectAreaChoice}
                        onChange={this.onProjectAreaDropDownChange} />
                    </div>
                    {this.state.DocType == 'Issues' ?
                      <div className='col-md-6'>
                        <TextField className='w-100' label='ApplicationArea' value={this.state.ApplicationArea} name='ApplicationArea' onChange={this.inputFormChange} />
                      </div>
                      : null}
                  </div>
                  <div className='row'>
                    {(this.state.DocType == 'Validations' || this.state.DocType == 'Issues') ?
                      <div className='col-md-6'>
                        <Dropdown
                          placeholder="Select options"
                          selectedKeys={this.state.UpdateEnvType} //defaultSelectedKeys={this.state.UpdateEnvType}
                          label={(this.state.DocType == 'Validations') ? "BU(s) Affected" : "Environment Type"}
                          errorMessage={this.state.EnvTypeValidations}
                          multiSelect
                          options={this.state.EnvironmentTypeChoice}
                          onChange={this.onEnvTypeDropdownChange}
                        />
                      </div>
                      : null}
                    {(this.state.DocType == 'Validations' || this.state.DocType == 'Issues') ?
                      <div className='col-md-6'>
                        <div className='w-100'>
                          <DatePicker
                            label={(this.state.DocType == 'Validations') ? "Ready date" : "Test Case #"}
                            placeholder="Select a date..."
                            ariaLabel="Select a date"
                            value={this.state.TestCase}
                            formatDate={onFormatDate}
                            textField={{ errorMessage: this.state.TestCaseValidations }}
                            onSelectDate={this._getTestCaseDatePickerItems} />
                        </div>
                      </div>
                      : null}
                  </div>
                  <div className='row'>
                    {(this.state.DocType == 'Issues') ?
                      <div className='col-md-6'>
                        <div className='w-100'><PeoplePicker context={this.props.context} titleText='Participants'
                          personSelectionLimit={1} showtooltip={true} disabled={false} ensureUser={true} onChange={this._getActivePlayersPeoplePickerItems}
                          showHiddenInUI={false} defaultSelectedUsers={this.state.ActivePlayersDefaultItems} principalTypes={[PrincipalType.User]} resolveDelay={1000} /></div>
                      </div>
                      : null}
                    {(this.state.DocType == 'Issues') ?
                      <div className='col-md-6'>
                        <div className='w-100'><PeoplePicker context={this.props.context} titleText='ProjectManagers'
                          personSelectionLimit={1} showtooltip={true} disabled={false} ensureUser={true} onChange={this._getProjectManagersPeoplePickerItems}
                          showHiddenInUI={false} defaultSelectedUsers={this.state.ProjectManagersDefaultItems} principalTypes={[PrincipalType.User]} resolveDelay={1000} /></div>
                      </div>
                      : null}
                  </div>
                  <div className='row'>
                    {(this.state.DocType == 'Validations' || this.state.DocType == 'Issues') ?
                      <div className='col-md-6'>
                        {/* <TextField className='w-100' label='ReportedBy' value={this.state.createdby} name='ReportedBy' onChange={this.inputFormChange} /> */}
                        <div className='w-100'><PeoplePicker context={this.props.context} titleText={this.state.DocType == 'Validations' ? 'Record Created By' : 'Reported By'}
                          personSelectionLimit={1} showtooltip={true} disabled={false} ensureUser={true} onChange={this._getReportedByPeoplePickerItems}
                          showHiddenInUI={false} defaultSelectedUsers={this.state.ReportedByDefaultItems} principalTypes={[PrincipalType.User]} resolveDelay={1000} /></div>
                      </div>
                      : null}
                    {(this.state.DocType == 'Validations' || this.state.DocType == 'Issues') ?
                      <div className='col-md-6'>
                        <div className='w-100'>
                          <DatePicker
                            label={(this.state.DocType == 'Validations') ? "Date Created" : "Date Reported"}
                            placeholder="Select a date..."
                            ariaLabel="Select a date"
                            value={this.state.ReptDt}
                            formatDate={onFormatDate}
                            onSelectDate={this._getReptDtDatePickerItems} />
                        </div>
                        {/* <TextField className='w-100' label={(this.state.DocType == 'Validations')?"Date Created":"Date Reported"} value={moment(this.state.ReptDt).format('L')}  onChange={this.inputFormChange} /> */}
                      </div>
                      : null}
                  </div>
                  <div className='row'>
                    {(this.state.ishide) ?
                      <div className='col-md-6'>
                        <TextField className='w-100' label='PhaseDetect' value={this.state.PhaseDetect} name='PhaseDetect' onChange={this.inputFormChange} />
                      </div>
                      : null}
                    {(this.state.ishide) ?
                      <div className='col-md-6'>
                        <TextField className='w-100' label='PhaseIntro' value={this.state.PhaseIntro} name='PhaseIntro' onChange={this.inputFormChange} />
                      </div>
                      : null}
                  </div>
                  <div className='row'>
                    {(this.state.DocType == 'Validations') ?
                      <div className='col-md-6'>

                        <Dropdown
                          placeholder="Select options"
                          selectedKeys={this.state.UpdateVendors} //defaultSelectedKeys={this.state.UpdateVendors}
                          label='LOB(s) Affected'   //label="Vendor"
                          multiSelect
                          options={this.state.VendorChoice}
                          onChange={this.onVendorDropdownChange}
                        />
                      </div>
                      : null}
                    {(this.state.DocType == 'Validations') ?
                      <div className='col-md-6'>
                        <div className='w-100'>
                          <DatePicker
                            label='Val Completion Date'
                            placeholder="Select a date..."
                            ariaLabel="Select a date"
                            value={this.state.WONum}
                            formatDate={onFormatDate}
                            onSelectDate={this._getWONumDatePickerItems} />
                        </div>
                      </div>
                      : null}
                  </div>
                  <div className='row'>
                    {(this.state.DocType == 'Validations') ?
                      <div className='col-md-6'>
                        <Dropdown
                          placeholder="Select options"
                          selectedKeys={this.state.UpdateRootCause} //defaultSelectedKeys={this.state.UpdateRootCause} 
                          label="Ins. Categories"  //label="RootCause"
                          multiSelect
                          options={this.state.RootCauseChoice}
                          onChange={this.onRootCauseDropdownChange}
                        />
                      </div>
                      : null}
                  </div>
                  <div className='row'>
                    {(this.state.DocType == 'Issues') ?
                      <div className='col-md-6'>
                        <div className='w-100'><PeoplePicker context={this.props.context} titleText='Assigned To'
                          personSelectionLimit={1} showtooltip={true} disabled={false} ensureUser={true} onChange={this._getAssignedToPeoplePickerItems}
                          showHiddenInUI={false} defaultSelectedUsers={this.state.AssignedToDefaultItems} principalTypes={[PrincipalType.User]} resolveDelay={1000} /></div>
                      </div>
                      : null}
                    {(this.state.DocType == 'Issues') ?
                      <div className='col-md-6'>
                        <div className='w-100'>
                          {/* <DatePicker
        label="Date Assigned"
        placeholder="Select a date..."
        ariaLabel="Select a date"
        value={this.state.AssignedDt}
        formatDate={onFormatDate}
        onSelectDate={this._getAssignedDtDatePickerItems}/> */}

                          <Label>Date Assigned</Label>
                          {this.state.AssignedTo != '' ?
                            <TextField className='w-100' value={moment(this.state.AssignedDt).format('L')} onChange={this.inputFormChange} />
                            : null}
                        </div>
                      </div>
                      : null}

                  </div>




                  <div className='row'>
                    {(this.state.DocType == 'Validations' || this.state.DocType == 'Issues') ?
                      <div className='col-md-6'>
                        <div className='w-100'>
                          <DatePicker
                            label={(this.state.DocType == 'Validations') ? "Estimated Completion Date" : "Est Comp Date"}
                            placeholder="Select a date..."
                            ariaLabel="Select a date"
                            value={this.state.EstCompDt}
                            formatDate={onFormatDate}
                            textField={{ errorMessage: this.state.EstCompDateValidations }}
                            onSelectDate={this._getEstCompDtDatePickerItems} />
                        </div>
                      </div>
                      : null}
                    {(this.state.DocType == 'Validations' || this.state.DocType == 'Issues') ?
                      <div className='col-md-6'>
                        <div className='w-100'>
                          <DatePicker
                            label={(this.state.DocType == 'Validations') ? "Re-Val/Final Completion Date" : "Date Resolved"}
                            placeholder="Select a date..."
                            ariaLabel="Select a date"
                            value={this.state.DateResolved}
                            formatDate={onFormatDate}
                            onSelectDate={this._getDateResolvedDatePickerItems} />
                        </div>
                      </div>
                      : null}
                  </div>
                  {(this.state.DocType == 'Validations' || this.state.DocType == 'Issues') ?
                    <div className='row'>
                      {this.state.Status == 'Closed' ?
                        <div className='col-md-6'>
                          <div className='w-100'>
                            {/* <PeoplePicker context ={ this.props.context} titleText = 'Closed By'
personSelectionLimit ={1} showtooltip ={ true}  disabled ={ false} ensureUser ={ true} onChange ={ this._getApprovedByPeoplePickerItems}
showHiddenInUI ={ false} defaultSelectedUsers ={ this.state.ApprovedByDefaultItems} principalTypes ={[PrincipalType.User]} resolveDelay ={ 1000}/> */}


                            <Label> Closed By </Label>
                            {this.state.ApprovedByUserItems.length > 0 ? this.state.ApprovedByUserItems.map((team, index) =>
                              <span>{team}</span>
                            ) : null}

                          </div>
                        </div>
                        : null}
                      {this.state.Status == 'Closed' ?
                        <div className='col-md-6'>
                          <div className='w-100'>
                            {/* <DatePicker
        label="Closed Date"
        placeholder="Select a date..."
        ariaLabel="Select a date"
        value={this.state.ApprovedDt}
        formatDate={onFormatDate}
        onSelectDate={this._getApprovedDtDatePickerItems}/> */}
                            {/* <TextField className='w-100' label='Closed Date' value={moment(this.state.ApprovedDt).format('L')}  onChange={this.inputFormChange} /> */}

                            <Label> Closed Date </Label>
                            {this.state.ApprovedDt != undefined && this.state.ApprovedDt != '' && this.state.ApprovedDt != null ? moment(this.state.ApprovedDt.toUTCString()).format('L') : null}
                          </div>
                        </div>
                        : null}
                    </div>
                    : null}
                  <div className='row'>
                    <div className='col-md-6'>
                      <div className='w-100'><PeoplePicker context={this.props.context} titleText='Send Email Notifications To'
                        showtooltip={true} required={false} disabled={false} ensureUser={true} onChange={this._getSendToPeoplePickerItems}
                        personSelectionLimit={100} showHiddenInUI={false} defaultSelectedUsers={this.state.SendToDefaultItems} principalTypes={[PrincipalType.User]} resolveDelay={1000} /></div>
                    </div>
                  </div>
                  <div className='row'>
                    <div className='col-md-12'>
                      <label className='font-weight-bold'>Description:</label>

                      <div className='col-md-12 Probdesc'> <SunEditor enableToolbar={true} lang='en' placeholder='Please type here...' setContents={this.state.Probdesc} setOptions={{
                        mode: 'classic', minHeight: '170px', buttonList: [
                          ['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
                          ['table', 'link', 'image'],],
                      }}
                        onChange={this.handleRichTextChange.bind(this, 'Probdesc')}
                        onImageUpload={this.handleProbdescImageUpload} onImageUploadBefore={this.handleImageUploadBefore} /></div>
                      {/* <RichText className='border' isEditMode={true} value={this.state.Probdesc} onChange={this.onProbdescChange} /> */}
                    </div>
                  </div>
                  <div className='row'>
                    {(this.state.DocType == 'Validations' || this.state.DocType == 'Issues') ?
                      <div className='col-md-12'>
                        {this.state.DocType == 'Validations' ? <label className='font-weight-bold'>Validation Results & Recommendations:</label> : <label className='font-weight-bold'>Proposed Resolution</label>}
                        <div className='col-md-12 Proposedres'> <SunEditor enableToolbar={true} lang='en' placeholder='Please type here...' setContents={this.state.Proposedres} setOptions={{
                          mode: 'classic', minHeight: '170px', buttonList: [
                            ['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
                            ['table', 'link', 'image'],],
                        }}
                          onChange={this.handleRichTextChange.bind(this, 'Proposedres')}
                          onImageUpload={this.handleProposedresImageUpload} onImageUploadBefore={this.handleImageUploadBefore} /></div>

                        {/* <SunEditor enableToolbar={true} placeholder='Please type here...' setContents={this.state.Proposedres} showToolbar={true} setOptions={{
                        minHeight: '170px', mode: 'classic', buttonList: [
                          ['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
                          ['table', 'link', 'image'],],
                      }} onChange={this.handleRichTextChange.bind(this, 'Proposedres')} onImageUpload={this.handleProposedresImageUpload} /> */}

                        {/* <RichText className='border' isEditMode={true} value={this.state.Proposedres} onChange={this.onProposedresChange} /> */}
                      </div>
                      : null}
                  </div>
                  <div className='row'>
                    {(this.state.DocType == 'Validations' || this.state.DocType == 'Issues') ?
                      <div className='col-md-12'>
                        {this.state.DocType == 'Validations' ? <label className='font-weight-bold'>Re-Validation Results & Recommendations</label> : <label className='font-weight-bold'>Final Resolution</label>}

                        <div className='col-md-12 Resolution'> <SunEditor enableToolbar={true} lang='en' placeholder='Please type here...' setContents={this.state.Resolution} setOptions={{
                          mode: 'classic', minHeight: '170px', buttonList: [
                            ['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
                            ['table', 'link', 'image'],],
                        }}
                          onChange={this.handleRichTextChange.bind(this, 'Resolution')}
                          onImageUpload={this.handleResolutionImageUpload} onImageUploadBefore={this.handleImageUploadBefore} /></div>


                        {/* <SunEditor enableToolbar={true} placeholder='Please type here...' setContents={this.state.Resolution} showToolbar={true} setOptions={{
                        minHeight: '170px', mode: 'classic', buttonList: [
                          ['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
                          ['table', 'link', 'image'],],
                      }} onChange={this.handleRichTextChange.bind(this, 'Resolution')} onImageUpload={this.handleResolutionImageUpload} /> */}

                        {/* <RichText className='border' isEditMode={true} value={this.state.Resolution} onChange={this.onResolutionChange} /> */}
                      </div>
                      : null}
                  </div>
                  <div className='row'>
                    {this.state.DocType == 'Validations' ?
                      <div className='col-md-12'>
                        <label className='font-weight-bold'>Follow Up Activities</label>
                        <div className='col-md-12 Suggest'> <SunEditor enableToolbar={true} lang='en' placeholder='Please type here...' setContents={this.state.Suggest} setOptions={{
                          mode: 'classic', minHeight: '170px', buttonList: [
                            ['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
                            ['table', 'link', 'image'],],
                        }}
                          onChange={this.handleRichTextChange.bind(this, 'Suggest')}
                          onImageUpload={this.handleSuggestImageUpload} onImageUploadBefore={this.handleImageUploadBefore} /></div>
                      </div>
                      : null}
                  </div>
                  
                  <div className='row'>
                    <div className='col-md-12'>
                      <label className='font-weight-bold'>Comments</label>
                      <div className='col-md-12 Comments'> <SunEditor enableToolbar={true} lang='en' placeholder='Please type here...' setContents={this.state.Comments} setOptions={{
                        mode: 'classic', minHeight: '170px', buttonList: [
                          ['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
                          ['table', 'link', 'image'],],
                      }}
                        onChange={this.handleRichTextChange.bind(this, 'Comments')}
                        onImageUpload={this.handleCommentsImageUpload} onImageUploadBefore={this.handleImageUploadBefore} /></div>


                      {/* <SunEditor enableToolbar={true} placeholder='Please type here...' setContents={this.state.Comments} showToolbar={true} setOptions={{
                      minHeight: '170px', mode: 'classic', buttonList: [
                        ['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
                        ['table', 'link', 'image'],],
                    }} onChange={this.handleRichTextChange.bind(this, 'Comments')} onImageUpload={this.handleCommentsImageUpload} /> */}

                      {/* <RichText className='border' isEditMode={true} value={this.state.Comments} onChange={this.onCommentsChange} /> */}
                    </div>
                  </div>
                  <div className='row'>
                    <div className='col-md-12'>
                      <label className='font-weight-bold'>Attachments</label>
                      <input className='ReactFieldEditor-Attachments-UploadInput mt-2' type="file" accept="application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document, .doc, .DOC, .docm, .DOCM, .docx, .DOCX, .dot, .DOT, .dotm, .DOTM, .dotx, .DOTX, .xml, .XML, .dot, .DOT, .pdf, .PDF, .xls, .XLS, .xlsx, .XLSX, .htm, .HTM, .html, .HTML, .mht, .MHT, .mhtml, MHTML, .odt, .ODT,.pdf, .PDF, .rtf, .RTF, .txt, .TXT, .wps, .WPS, .xps, .XPS, .pot, .POT, .potm, POTM, .potx, POTX, .ppa, .PPA, .ppam, .PPAM, .pps, .PPS, .ppsm, .PPSM, .ppsx, .PPSX, .ppt, .PPT, .pptm, .PPTM, .pptx, .PPTX, .thmx, .THMX, .msg, .zip  "  multiple title='Attach Files' aria-required='false' aria-label='Attach Files' onChange={this.Attachment} />
                      {this.selectedFiles()}
                      {this.showAttachment()}
                    </div>
                  </div>
                  <Dialog minWidth={'380px'} hidden={this.state.isModaldialogClose} dialogContentProps={dialogModelContentProps}>
                    <DialogFooter>
                      <PrimaryButton style={{ textAlign: 'center' }} onClick={this.CloseForm} text="OK" />
                    </DialogFooter>
                  </Dialog>
                </div>
              </div>
            }<Dialog minWidth={'460px'} maxWidth={'520px'} hidden={this.state.isModalClose} onDismiss={this.modalPopupClose} dialogContentProps={dialogContentProps}>

              {this.state.showUpdateBody ? <TextField label="Mail Body Comments" multiline autoAdjustHeight placeholder="Please enter text here" onChange={(e) => this.sendUpdateBodyContent(e)} /> : null}
              <DialogFooter>
                <DefaultButton onClick={this.modalPopupClose} text="No" />
                <PrimaryButton onClick={this.modalSubmitClick} text="Yes" />
              </DialogFooter>
            </Dialog>
            <Dialog hidden={this.state.isSavedHidden} dialogContentProps={dialogSavedProps}>
              <div className="text-center">
                <Icon iconName="CompletedSolid" className="btn-lg text-success" />
                <br></br>
                {isEmailError ?
                  <div>Data Saved Succesfully but Email Not Sent</div> : <div>Data Saved Succesfully!</div>}
              </div>
              <DialogFooter>
                <PrimaryButton onClick={this.CloseForm} text="OK" />
              </DialogFooter>
            </Dialog>

          </div>
        </ThemeProvider>
      );
    }
    catch (e) {
      console.log('render ' + e);
    }
  }
}