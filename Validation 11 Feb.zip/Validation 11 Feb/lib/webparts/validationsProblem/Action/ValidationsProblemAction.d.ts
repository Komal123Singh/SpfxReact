import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/fields';
import '@pnp/sp/attachments';
declare const getDocDetails: () => void;
export { getDocDetails };
declare const getAdminlistDetails: () => Promise<void>;
export { getAdminlistDetails };
declare const getProblemlistDetails: () => Promise<void>;
export { getProblemlistDetails };
declare const getEditFormDetails: (Id: any) => void;
export { getEditFormDetails };
declare const saveForm: (createdby: any, createdon: any, ActivePlayers: any, ApplicationArea: any, ApprovedBy: any, ApprovedDt: any, AssignedTo: any, AssignedDt: any, Comments: any, CreateDt: any, CreateTime: any, DateResolved: any, docnumber: any, DocType: any, EditHistoryFields: any, EnvType: any, EstCompDt: any, IONum: any, Keywords: any, PhaseDetect: any, PhaseIntro: any, Priority: any, Probdesc: any, ProjectArea: any, ProjectManagers: any, Proposedres: any, ReportedBy: any, ReptArea: any, ReptDt: any, ReptMgr: any, Resolution: any, RootCause: any, SendTo: any, Severity: any, Status: any, Suggest: any, TestCase: any, Title: any, Vendors: any, WONum: any, Attachments: any) => void;
export { saveForm };
declare const updateForm: (toDelNames: any, Attachments: any, uniqueId: any, ActivePlayers: any, ApplicationArea: any, ApprovedBy: any, AssignedTo: any, Comments: any, CreateDt: any, CreateTime: any, DateResolved: any, DocNumber: any, DocType: any, EditHistoryFields: any, EnvType: any, EstCompDt: any, IONum: any, Keywords: any, PhaseDetect: any, PhaseIntro: any, Priority: any, Probdesc: any, ProjectArea: any, ProjectManagers: any, Proposedres: any, ReportedBy: any, ReptArea: any, ReptDt: any, ReptMgr: any, Resolution: any, RootCause: any, SendTo: any, Severity: any, Status: any, Suggest: any, TestCase: any, Title: any, Vendors: any, WONum: any) => void;
export { updateForm };
//# sourceMappingURL=ValidationsProblemAction.d.ts.map