import { EventEmitter } from 'events';
declare class GapClaimsLettersStore extends EventEmitter {
    constructor();
    storeChange(action: any): void;
    getEditClickStoreValue(): any[];
    getInserResultStoreValue(): any;
    getPaymentTypeDetailsList(): any[];
    getmrk_deleteChoiceStoreValue(): any[];
}
declare let objGapClaimsLettersStore: GapClaimsLettersStore;
export default objGapClaimsLettersStore;
//# sourceMappingURL=GapClaimsLettersStore.d.ts.map