import * as React from 'react';
import { IGapClaimsLettersStates } from './IGapClaimsLettersStates';
import 'suneditor/dist/css/suneditor.min.css';
import 'suneditor/dist/css/suneditor.min.css';
import "@pnp/sp/site-users/web";
export default class ViewGapClaimsLetters extends React.Component<IGapClaimsLettersStates, {}> {
    private SplitAndEncodeURIComponent;
    getEditFormBodyDetails: (uniqueId: any) => void;
    addDeleteFiles: (fileName: any) => void;
    render(): JSX.Element;
}
//# sourceMappingURL=ViewGapClaimsLetters.d.ts.map