define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "LogoUrlFieldLabel": "Logo Url",
    "ExitUrlFieldLabel": "Exit Url",
  }
});