import { WebPartContext } from '@microsoft/sp-webpart-base';


export interface IReleaseDocumentFormProps {
  description: string;
  context: WebPartContext;
  logo : string;
  exitLocation:string; 

}
