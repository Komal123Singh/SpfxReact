export interface ISpfxCrudPnpProps {
  description: string;
}
