import * as React from 'react';
import { IGapClaimsLettersProps } from './IGapClaimsLettersProps';
import { IGapClaimsLettersStates } from './IGapClaimsLettersStates';
import * as GapClaimsLettersAction from '../Action/GapClaimsLettersAction';
import GapClaimsLettersStore from '../Store/GapClaimsLettersStore';
import { PeoplePicker, PrincipalType } from '@pnp/spfx-controls-react/lib/PeoplePicker';
import { DateTimePicker, DateConvention, TimeConvention } from '@pnp/spfx-controls-react/lib/dateTimePicker';
import { TextField, Dropdown, DatePicker, IDropdownOption, ProgressIndicator, Checkbox, DialogFooter, DialogType, Icon, IChoiceGroupOption, Label, Link, PrimaryButton, Toggle, ChoiceGroup, IconButton, IIconProps, Dialog, elementContainsAttribute } from '@fluentui/react';
import "@pnp/sp/site-users/web";
import { sp } from "@pnp/sp/presets/all";
import * as moment from "moment";
import { ThemeProvider } from '@fluentui/react';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { SecurityTrimmedControl, PermissionLevel, } from '@pnp/spfx-controls-react/lib/SecurityTrimmedControl';
import { SPPermission } from '@microsoft/sp-page-context';
import ViewGapClaimsLetters from './ViewGapClaimsLetters';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import './GapClaimsLettersCss.css';
import 'suneditor/dist/css/suneditor.min.css';
import SunEditor from 'suneditor-react';
import 'suneditor/dist/css/suneditor.min.css';
import * as _ from '@microsoft/sp-lodash-subset';
import { containsInvalidFileFolderChars } from '@pnp/sp';
import { saveAs } from "file-saver";
import { Attachments } from '@pnp/sp/attachments';
import { IAttachmentInfo } from "@pnp/sp/attachments";
import { IItem } from "@pnp/sp/items/types";
import { first, split } from 'lodash';
import { HttpClient, HttpClientResponse, IHttpClientOptions } from "@microsoft/sp-http";
import { Spinner, SpinnerSize } from '@fluentui/react/lib/Spinner';
import { IStackProps, Stack, IStackStyles } from '@fluentui/react/lib/Stack';

// Global Variable
let re;
let absoluteUrl;
let relativeURL;
let accessToken;
let tempfile = [];
let uploadedRichTextFiles = [];
let deleteFiles = [];
let toDelNames = [];
let toDeleteAttachments = [];
let actionclicked;
let filename;
let filebase64data;
let actionBtnClicked;
let fileonchangealert = false;
let delAttachList;
let includes = [];
let claimidentifier = '';
let localSendToEmail = [];
let localSendToID = [];
let localSendToUser = [];
let localTempAdjEmail = [];
let localTempAdjID = [];
// let claimObject;
let localTempAdjUser = [];
let localCopyToEmail = [];
let localCopyToID = [];
let localCopyToUser = [];
let localBlindCopyToEmail = [];
let localBlindCopyToID = [];
let localBlindCopyToUser = [];
let localFromEmail = [];
let localFromID = [];
let localFromUser = [];
let Typevalues = [];
let isProgress = false;
let Attachmentbase64data;
const url = window.location.href;
const urlObject = new URL(url);
let uniqueId = urlObject.searchParams.get('itemID') == '' || urlObject.searchParams.get('itemID') == null ? 0 : parseInt(urlObject.searchParams.get('itemID'));
let isEditMode = false;
let isAssignToClaim = false;
let AssignSave = false;
let isViewMode = false;
let EditFormDetails;
let openDailog2 = false;

// const stackTokens = { childrenGap: 3 };
const addIcon: IIconProps = { iconName: 'Add' };
const subIcon: IIconProps = { iconName: 'CalculatorMultiply' };
var XMLserialize = new XMLSerializer();
const stackTokens = { childrenGap: 50 };
const stackStyles: Partial<IStackStyles> = { root: { width: 650 } };
const columnProps: Partial<IStackProps> = {
  tokens: { childrenGap: 15 },
  styles: { root: { width: 300 } },
};
const dialogContentProps = {
  type: DialogType.largeHeader,
  title: 'Confirmation',
  subText: 'Are you sure want to save?',
};
const dialogSavedProps = {
  type: DialogType.normal,
  title: '',
  closeButtonAriaLabel: 'Close',
};
const onFormatDate = (date?: Date): string => {
  var ampm = date.getHours() >= 12 ? ' PM ' : ' AM ';
  return !date ? '' : (date.getMonth() + 1) + '/' + date.getDate() + '/' + (date.getFullYear() % 100) + " " + [date.getHours(),
  date.getMinutes()].join(':') + ampm;
};
export default class GapClaimsLetters extends React.Component<IGapClaimsLettersProps, IGapClaimsLettersStates, {}> {
  constructor(props) {
    super(props);
    this.state = {
      selectedFiles: [],
     // TempAdjText:[],
      UploadErrorMessage:'',
      isReader: false,
      Status: '',
      ValidClaimno: false,
      ValidResponse:false,
      Disable: false,
      isSpinner: false,
      isSpinner1: false,
      isExitHidden: true,
      webpartContxt: this.props.context,
      FormAttachment: [],//Attachment
      FormAttachmentNames: [],
      TextAttachmentNames: [],
      oldAttachments: '',
      Attachments: '',
      toDeleteAttachments: '',
      attachmentType: [],
      hideDialog: true,
      modalclose: true,
      hideDialog2: true,
      isLoading: false,
      isSuccess: false,
      id: 0,
      toDelNames: [],
      GAPAgreeNum: '',
      GAPAgreeNumA: '',
      VSCAdj: '',
      InsuredLastName: '',
      InsuredFirstName: '',
      InsuredLastNameA: '',
      TempAdjuster: '',
      InsuredFirstNameA: '',
      InsuredStreetAddress: '',
      InsuredCity: '',
      InsuredState: '',
      InsZip: '',
      NotesType: '',
      PaymentTypeOptions: [],
      mrk_delete: '',
      mrk_deleteChoiceArr: [{ key: 'Yes', text: 'Yes' }, { key: 'No', text: 'No' }],
      SendTo: [],
      TempAdj: [],
      SendToText: [],
      SendToDefaultItems: [],
      SendToUserItems: [],
      TempAdjDefaultItems: [],
      TempAdjUserItems: [],

      CopyTo: [],
      CopyToText: [],
      CopyToDefaultItems: [],
      filec: 1,
      CopyToUserItems: [],
      BlindCopyTo: [],
      BlindCopyToText: [],
      BlindCopyToDefaultItems: [],
      BlindCopyToUserItems: [],
      From: [],
      FromText: [],
      FromDefaultItems: [],
      FromUserItems: [],
      Date: null,
      Title: '',
      Body: '',
      LettersListID: this.props.LettersListID,
      TypeListID: this.props.TypeListID
    };
    absoluteUrl = this.props.context.pageContext.site.absoluteUrl;
    relativeURL = this.props.context.pageContext.site.serverRelativeUrl;
    SPComponentLoader.loadCss('https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
    SPComponentLoader.loadCss('https://cdn.jsdelivr.net/npm/suneditor@latest/dist/css/suneditor.min.css');
    SPComponentLoader.loadScript('https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js');
    SPComponentLoader.loadScript('https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js');
    SPComponentLoader.loadScript('https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js');
    SPComponentLoader.loadScript("https://cdnjs.cloudflare.com/ajax/libs/javascript-canvas-to-blob/3.4.0/js/canvas-to-blob.min.js");
  }
  public componentDidMount() {
    try {
      const url = window.location.href;
      const urlObject = new URL(url);
      uniqueId = urlObject.searchParams.get('itemID') == '' || urlObject.searchParams.get('itemID') == null ? 0 : parseInt(urlObject.searchParams.get('itemID'));
      // this.getEditFormBodyDetails(uniqueId);
      this.getLoggedUsersgroup();
      if (uniqueId != 0) {
        isViewMode = true;
        this.getEditFormDetailsComp();
        this.getPaymentValues();
        this.getEditFormBodyDetails(uniqueId, this.state.LettersListID);
      }
      else {
        this.getFormDefaultDetails();
        this.getPaymentValues();
      }
      this.getEditFormBodyDetails(uniqueId, this.state.LettersListID);
    }
    catch (e) {
      console.log('componentDidMount: ' + e);
    }
  }
  public getFormDefaultDetails = () => {
    try {
      GapClaimsLettersStore.on('insertResultchange', this.assignInsertResultStore);
      GapClaimsLettersAction.getmrk_deleteDetails('mrk_delete', this.state.LettersListID);
      GapClaimsLettersAction.getPaymentTypeDetails(this.state.TypeListID);
      GapClaimsLettersStore.on('mrk_deletechange', this.assignmrk_deleteStore);
    } catch (e) {
      console.log('getFormDefaultDetails' + e);
    }
  }

  public getLoggedUsersgroup = async () => {
    try {

      // debugger;

      let LoggedUsersGroup = await sp.web.currentUser.groups();


      LoggedUsersGroup.map((groupItem) => {
        if (groupItem.Title == "USU_GAPClaims_Readers") {

          this.setState({ isReader: true });

        }

      });

    } catch (e) {

      console.log('getLoggedUsersGroup' + e);

    }

  }
  private SplitAndEncodeURIComponent = (value: string = '') => {
    let modifiedValue: string = value;
    let splitBySlashValue = value.split("/");
    let lastSlashtSplitValue = splitBySlashValue.pop();
    let encodeFileName = encodeURIComponent(lastSlashtSplitValue);
    let restSlashValue = splitBySlashValue.join("/")
    modifiedValue = `${restSlashValue}/${encodeFileName}`;
    return modifiedValue;
  }

  //AssigntoClaim
  public getEditFormDetailsComp = () => {
    try {
      //debugger;
      this.getFormDefaultDetails();
      GapClaimsLettersAction.getEditFormDetails(uniqueId, this.state.LettersListID);
      GapClaimsLettersStore.on('getEditFormDetailschange', this.assignEditFormDetailsStore);
    } catch (e) {
      console.log('EditClickBtn' + e);
    }
  }
  public EditClickBtn = () => {
    try {
      isEditMode = true;
      isViewMode = false;
      this.getEditFormDetailsComp();
    } catch (e) {
      console.log('EditClickBtn' + e);
    }
  }

  public ViewClickBtn = () => {
    try {
      isEditMode = false;
      isViewMode = true;
      this.getEditFormDetailsComp();
    } catch (e) {
      console.log('ViewClickBtn' + e);
    }
  }

  //Getting PaymentType values
  public getPaymentValues = () => {
    try {
      GapClaimsLettersStore.on('PaymenTypeChange', this.getPaymentTypevaluesStore);
      GapClaimsLettersAction.getPaymentTypeDetails(this.state.TypeListID);
    }
    catch (e) {
      console.log('getAdminListValues' + e);
    }
  }
  public getEditFormBodyDetails = (uniqueId, LettersListID) => {
    sp.web.lists
      .getById(LettersListID)
      .items.getById(uniqueId)
      .select("Body", "AttachmentFiles")
      .expand("AttachmentFiles")
      .get()
      .then((res) => {
        let fileLevlInfos = [];
        let item = sp.web.lists.getById(LettersListID).items.getById(uniqueId);
        item.attachmentFiles.get().then((fileData) => {
          let Body = res.Body;
          let domparser = new DOMParser();
          let parsedBody = domparser.parseFromString(Body, "text/html");
          let allImgaes = parsedBody.querySelectorAll("img");
          if (allImgaes.length != 0) {
            allImgaes.forEach((img) => {
              let iName = img.getAttribute("src");
              let suB = img.getAttribute("src");
              if (suB != null) {
                let val = suB.indexOf("@");
                let sval = suB.indexOf(":");
                let fname = suB.substring(sval + 1, val);
                fileData.forEach((fData) => {
                  if (fname === fData["FileName"]) {
                    img.setAttribute("src", fData["ServerRelativeUrl"]);
                  }
                });
                fileLevlInfos.indexOf(iName)
                  ? console.log("exisitng file")
                  : fileLevlInfos.push(iName);
              }
            });
          }
          let s = new XMLSerializer();
          let serializeBody = s.serializeToString(parsedBody);
          //console.log("Parsed", parsedBody);
          sp.web.lists
            .getById(LettersListID)
            .items.getById(uniqueId)
            .update({
              Body: serializeBody,
            })
            .then((updatedres) => {
              if (updatedres.data != undefined) {
                console.log("updated body");
              }
            })
            .catch((error) => {
              console.log("updatebodyRichItem " + error);
            });
        });
      })
      .catch((error) => {
        console.log("getEditFormBodyDetails " + error);
      });
  }
  public getPaymentTypevaluesStore = () => {
    Typevalues = GapClaimsLettersStore.getPaymentTypeDetailsList();
    //Getting Type Values from PaymentTypeList
    let TypeDropDown = [];
    let VarType;
    let splitPaymentTypearr = [];
    VarType = Typevalues[0].NotesType;
    splitPaymentTypearr = VarType != undefined ? VarType.split(/[\n,;]+/) : [];

    splitPaymentTypearr.map((item) => {
      TypeDropDown.push({ key: item, text: item });
    });
    this.setState({
      PaymentTypeOptions: TypeDropDown
    });
    console.log(this.state.PaymentTypeOptions);
  }
  public onPaymentTypeChange = (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): void => {
    this.setState({ NotesType: item.key as string });
    console.log(this.state.NotesType);
  }
  public Assign_to_Claimm = async () => {
    /*if(!this.state.isSpinner && !this.state.isSpinner1){
      await this.setState({GAPAgreeNumA: '',InsuredFirstNameA:'',InsuredLastNameA:''});
    }*/
    if (fileonchangealert == false) {
      await this.open_dialog();
    }
    else if (fileonchangealert == true) {
      await this.insertForm();
      await this.open_dialog();
    }
  }
  public open_dialog = () => {
    isAssignToClaim = true;
    this.setState({ hideDialog: false });
  }
  public getuserEmail = async (Id) => {
    return await sp.web.siteUsers.getById(Id).get();
  }
  public assignEditFormDetailsStore = async () => {
    // localSendToEmail
    //debugger;
    EditFormDetails = GapClaimsLettersStore.getEditClickStoreValue();
    let domparser = new DOMParser();
    let s = new XMLSerializer();
    if (EditFormDetails.length != 0) {
      localSendToEmail = [];
      localSendToID = [];
      localSendToUser = [];
      let sarr = [];
      if (EditFormDetails.SendTo == undefined) {
        localSendToEmail = [""].concat(localSendToEmail);
      }
      else if (EditFormDetails.SendTo != undefined) {
        for (var i = 0; i < EditFormDetails.SendTo.length; i++) {
          // localSendToEmail.push(EditFormDetails.SendTo[i].EMail);
          localSendToID.push(EditFormDetails.SendTo[i].ID);
          await this.getuserEmail(EditFormDetails.SendTo[i].ID).then(async (usr) => {
            localSendToEmail.push(usr.Email);
            sarr = localSendToEmail.filter((val, id, array) => array.indexOf(val) == id);
            localSendToEmail = [...sarr];
          });
          localSendToUser.push(EditFormDetails.SendTo[i].Title);
          sarr = localSendToUser.filter((val, id, array) => array.indexOf(val) == id);
          localSendToUser = [...sarr];
        }
      }
      localCopyToEmail = [];
      localCopyToID = [];
      localCopyToUser = [];
      let cArr = [];
      if (EditFormDetails.CopyTo == undefined) {
        localCopyToEmail = [""].concat(localCopyToEmail);
      }
      else if (EditFormDetails.CopyTo != undefined) {
        for (var i = 0; i < EditFormDetails.CopyTo.length; i++) {
          // localCopyToEmail.push(EditFormDetails.CopyTo[i].EMail);
          localCopyToID.push(EditFormDetails.CopyTo[i].ID);
          await this.getuserEmail(EditFormDetails.CopyTo[i].ID).then(async (usr) => {
            localCopyToEmail.push(usr.Email);
            cArr = localCopyToEmail.filter((val, id, array) => array.indexOf(val) == id);
            localCopyToEmail = [...cArr];

          });
          localCopyToUser.push(EditFormDetails.CopyTo[i].Title);
          cArr = localCopyToUser.filter((val, id, array) => array.indexOf(val) == id);
          localCopyToUser = [...cArr];
        }
      }
      localBlindCopyToEmail = [];
      localBlindCopyToID = [];
      localBlindCopyToUser = [];
      let bccarr = [];
      if (EditFormDetails.BlindCopyTo == undefined) {
        localBlindCopyToEmail = [""].concat(localBlindCopyToEmail);
      }
      else if (EditFormDetails.BlindCopyTo != undefined) {
        for (var i = 0; i < EditFormDetails.BlindCopyTo.length; i++) {
          // localBlindCopyToEmail.push(EditFormDetails.BlindCopyTo[i].EMail);
          await this.getuserEmail(EditFormDetails.BlindCopyTo[i].ID).then(async (usr) => {
            localBlindCopyToEmail.push(usr.Email);
            bccarr = localBlindCopyToEmail.filter((val, id, array) => array.indexOf(val) == id);
            localBlindCopyToEmail = [...bccarr];
          });
          // localBlindCopyToID.push(EditFormDetails.BlindCopyTo[i].ID);
          localBlindCopyToUser.push(EditFormDetails.BlindCopyTo[i].Title);
          bccarr = localBlindCopyToUser.filter((val, id, array) => array.indexOf(val) == id);
          localBlindCopyToUser = [...bccarr];
        }
      }
      localFromEmail = [];
      localFromID = [];
      localFromUser = [];
      let farr = [];
      if (EditFormDetails.From == undefined) {
        localFromEmail = [""].concat(localFromEmail);
      }
      else if (EditFormDetails.From != undefined) {
        // localFromEmail.push(EditFormDetails.From.EMail);
        await this.getuserEmail(EditFormDetails.From.ID).then(async (usr) => {
          localFromEmail.push(usr.Email);
          farr = localFromEmail.filter((val, id, array) => array.indexOf(val) == id);
          localFromEmail = [...farr];
        });
        localFromID.push(EditFormDetails.From.ID);
        localFromUser.push(EditFormDetails.From.Title);
        farr = localFromUser.filter((val, id, array) => array.indexOf(val) == id);
        localFromUser = [...farr];
      }
      localTempAdjEmail = [];
      localTempAdjID = [];
      localTempAdjUser = [];
      let temparr = [];
      if (EditFormDetails.TempAdj == undefined) {
        localTempAdjEmail = [""].concat(localTempAdjEmail);
      }
      else if (EditFormDetails.TempAdj != undefined) {
        // localFromEmail.push(EditFormDetails.From.EMail);
        await this.getuserEmail(EditFormDetails.TempAdj.ID).then(async (usr) => {
          localTempAdjEmail.push(usr.Email);
          temparr = localTempAdjEmail.filter((val, id, array) => array.indexOf(val) == id);
          localTempAdjEmail = [...temparr];
        });
        localTempAdjID.push(EditFormDetails.TempAdj.ID);
        localTempAdjUser.push(EditFormDetails.TempAdj.Title);
        temparr = localTempAdjUser.filter((val, id, array) => array.indexOf(val) == id);
        localTempAdjUser = [...temparr];
      }
      let parsedBody = domparser.parseFromString(EditFormDetails.Body, 'text/html');
      parsedBody.querySelectorAll('[class*=se-component]').forEach((ext) => { ext.removeAttribute('class'); }); let serializeBody = s.serializeToString(parsedBody);
      if (serializeBody != undefined && serializeBody != null && serializeBody != '') {

        serializeBody = serializeBody.replace(/\n/g, "<br>");
      }
      delAttachList = [...EditFormDetails.AttachmentFiles];
      this.setState({
        FormAttachmentNames: EditFormDetails.AttachmentFiles,
        GAPAgreeNum: EditFormDetails.GAPAgreeNum,
        GAPAgreeNumA: EditFormDetails.GAPAgreeNum,
        VSCAdj: EditFormDetails.VSCAdj,
        InsuredLastName: EditFormDetails.InsuredLastName,
        InsuredFirstName: EditFormDetails.InsuredFirstName,
        InsuredFirstNameA: EditFormDetails.InsuredFirstName,
        InsuredLastNameA: EditFormDetails.InsuredLastName,
        InsuredStreetAddress: EditFormDetails.InsuredStreetAddress,
        InsuredCity: EditFormDetails.InsuredCity,
        InsuredState: EditFormDetails.InsuredState,
        InsZip: EditFormDetails.InsZip,
        NotesType: EditFormDetails.NotesType,
        mrk_delete: EditFormDetails.mrk_delete,
        SendToDefaultItems: localSendToEmail,
        SendToUserItems: localSendToUser,
        SendTo: localSendToID,
        TempAdjDefaultItems: localTempAdjEmail,
        TempAdjUserItems: localTempAdjUser,
        TempAdj: localTempAdjID,
        CopyToDefaultItems: localCopyToEmail,
        CopyToUserItems: localCopyToUser,
        CopyTo: localCopyToID,
        BlindCopyToDefaultItems: localBlindCopyToEmail,
        BlindCopyToUserItems: localBlindCopyToUser,
        BlindCopyTo: localBlindCopyToID,
        FromDefaultItems: localFromEmail,
        FromUserItems: localFromUser,
        From: localFromID,
        Date: EditFormDetails.Date != null ? new Date(EditFormDetails.Date) : null,
        Title: EditFormDetails.Title,
        Body: _.unescape(serializeBody),
        CopyToText: EditFormDetails.CopyToText,
        FromText: EditFormDetails.FromText,
        BlindCopyToText: EditFormDetails.BlindCopyToText,
        SendToText: EditFormDetails.SendToText,
       // TempAdjText:EditFormDetails.TempAdjText
      });
    }
  }
  static get mrk_deleteChoice() {
    const mrk_deleteOptions: IChoiceGroupOption[] = [
      { key: "Yes", text: "Yes" },
      { key: "No", text: "No" },
    ];
    return mrk_deleteOptions;
  }
  public assignmrk_deleteStore = () => {
    try {
      let mrk_deleteChoice = [];
      if (GapClaimsLettersStore.getmrk_deleteChoiceStoreValue() != undefined) {
        if (GapClaimsLettersStore.getmrk_deleteChoiceStoreValue().length != 0)
          GapClaimsLettersStore.getmrk_deleteChoiceStoreValue().map((item) => {
            mrk_deleteChoice.push([{ key: item, text: item, id: 'mrk_delete' },]);
          });
        this.setState({ mrk_deleteChoiceArr: mrk_deleteChoice });
      }
    } catch (e) {
      console.log('assignmrk_deleteStore: ' + e);
    }
  }
  // Call action save Result method
  public assignInsertResultStore = () => {
    try {
      if (GapClaimsLettersStore.getInserResultStoreValue() != undefined) {

      }
    } catch (e) {
      console.log('assignInsertResultStore: ' + e);
    }
  }
  public Dialog_close = () => {
    this.setState({ hideDialog: true });

  }
  public ValidClaim = () => {
    this.setState({ ValidClaimno: false });

    // window.location.href = url;
  }
  public ValidResponseApi=()=>{
    this.setState({ ValidResponse: false });
  }
  public Dialog_close2 = () => {
    this.setState({ hideDialog2: true });
    // isProgress = false;

  }
  //Assigntocalim
  public UploadFiless = async () => {
    if (uniqueId != 0) {
      isProgress = true;
      GapClaimsLettersAction.closeDialog(uniqueId, this.state.LettersListID, this.state.GAPAgreeNumA,
        this.state.InsuredLastNameA, this.state.InsuredFirstNameA, this.state.VSCAdj, this.state.TempAdjuster);
    }

  }
  public Dialog_save = async (actionCall) => {
    actionclicked = actionCall;
    try {
      if (actionclicked == 'Save') {
        isProgress = true;
        //  await(this.setState({Disable:true}));
        await this.setState({ isSpinner1: true });
        // await this.UploadFiless();
        await this.getDatafromApi(this.state.LettersListID);
        isAssignToClaim = true;
      }

      else {
        this.setState({ hideDialog2: true });
      }
    }
    catch (e) {
      console.log('Dialog_save ' + e);
    }
  }
  public _close = () => {
    this.setState({ hideDialog: true, hideDialog2: true });
    // this.setState({hideDialog:true}); 
    AssignSave = true;
    isProgress = false;
  }
  public ExitForm = () => {
    window.location.href = this.props.exiturl;
    try {
    } catch (e) {
      console.log('ExitForm' + e);
    }
  }
  // Call action save method
  public insertForm = () => {
    try {

      if (uniqueId == 0) {
        GapClaimsLettersAction.saveForm(absoluteUrl, this.state.LettersListID, this.state.GAPAgreeNum, this.state.NotesType, this.state.VSCAdj,
          this.state.InsuredStreetAddress,
          this.state.InsuredCity, this.state.InsuredState, this.state.InsZip, this.state.mrk_delete,
          this.state.SendTo, this.state.TempAdj, this.state.CopyTo, this.state.BlindCopyTo, this.state.From, this.state.Date,
          this.state.Title, this.state.Body, uploadedRichTextFiles, this.state.FormAttachment, this.state.TempAdjuster);
      }

      GapClaimsLettersAction.updateForm(uniqueId, this.state.LettersListID, this.state.NotesType,
        this.state.GAPAgreeNumA, this.state.InsuredLastNameA,
        this.state.InsuredFirstNameA, this.state.InsuredStreetAddress, this.state.InsuredCity,
        this.state.InsuredState, this.state.InsZip, this.state.mrk_delete, this.state.SendTo, this.state.TempAdj,
        this.state.CopyTo, this.state.BlindCopyTo, this.state.From, this.state.Date, this.state.Title,
        this.state.Body, uploadedRichTextFiles, this.state.FormAttachment, deleteFiles, this.state.Status);
    }
    // this.ExitForm(); 
    catch (e) {
      console.log('insertForm: ' + e);
    }
  }
  //get Assigndetails
  /***Modalclsoe */
  public modalPopupOpen = (actionCall) => {
    //debugger;
    try {
      actionBtnClicked = actionCall;
      if (actionBtnClicked == 'SaveExit') {
        dialogContentProps.title = 'Save Confirmation';
        dialogContentProps.subText = 'Do you want to save this details?';
      }
      this.setState({ modalclose: false });
    } catch (e) {
      console.log('modalPopupOpen' + e);
    }
  }
  public modalPopupClose = () => {
    try {
      //debugger;
      this.setState({ modalclose: true });
    } catch (e) {
      console.log('modalPopupClose' + e);
    }
  }
  public modalSubmitClick = async () => {
    try {
      // isProgress = true;
      //  this.setState({ isDisabled: 'disabledbutton' });
      if (actionBtnClicked == 'SaveExit') {
        await this.insertForm();
        await this.setState({ modalclose: true });
        // window.location.href = url;

        // this.ExitForm();
        this.setState({ modalclose: true, isExitHidden: false });
      } else if (actionBtnClicked == 'Exit') {
        this.ExitForm();
        this.setState({ modalclose: true });
      }
    } catch (e) {
      console.log('modalSubmitClick' + e);
    }
  }
  public ExitmodalPopupOpen = (actionCall) => {
    try {
      //debugger;
      actionBtnClicked = actionCall;
      if (actionBtnClicked == 'Exit') {
        dialogContentProps.title = 'Exit Confirmation';
        dialogContentProps.subText = 'Would you like to exit this record?';
      }
      this.setState({ modalclose: false });
    } catch (e) {
      console.log('modalPopup: ' + e);
    }
  }
  private inputFormChange1 = (e) => {
    try {
      switch (e.target.name) {
        case 'GAPAgreeNumA':
          {
            this.setState({ GAPAgreeNumA: e.target.value });
            break;
          }
        case 'InsuredLastNameA':
          {
            this.setState({ InsuredLastNameA: e.target.value });
            break;
          }
        case 'InsuredFirstNameA':
          {
            this.setState({ InsuredFirstNameA: e.target.value });
            break;
          }
      }
    }
    catch (e) {
      console.log('inputFormChange1: ' + e);
    }
  }
  // Get Input Details
  private inputFormChange = (inputValue) => {
    try {
      switch (inputValue.target.name) {
        case 'GAPAgreeNum':
          {
            this.setState({ GAPAgreeNum: inputValue.target.value });
            break;
          }
        case 'NotesType':
          {
            this.setState({ NotesType: inputValue.target.value });
            break;
          }
        case 'VSCAdj':
          {
            this.setState({ VSCAdj: inputValue.target.value });
            break;
          }
        case 'InsuredLastName':
          {
            this.setState({ InsuredLastName: inputValue.target.value });
            break;
          }
        case 'InsuredFirstName':
          {
            this.setState({ InsuredFirstName: inputValue.target.value });
            break;
          }
        case 'InsuredStreetAddress':
          {
            this.setState({ InsuredStreetAddress: inputValue.target.value });
            break;
          }
        case 'InsuredCity':
          {
            this.setState({ InsuredCity: inputValue.target.value });
            break;
          }
        case 'InsuredState':
          {
            this.setState({ InsuredState: inputValue.target.value });
            break;
          }
        case 'InsZip':
          {
            this.setState({ InsZip: inputValue.target.value });
            break;
          }
        case 'SendTo':
          {
            this.setState({ SendTo: inputValue.target.value });
            break;
          }
        case 'TempAdj':
          {
            this.setState({ TempAdj: inputValue.target.value });
            break;
          }
        case 'CopyTo':
          {
            this.setState({ CopyTo: inputValue.target.value });
            break;
          }
        case 'BlindCopyTo':
          {
            this.setState({ BlindCopyTo: inputValue.target.value });
            break;
          }
        case 'From':
          {
            this.setState({ From: inputValue.target.value });
            break;
          }
        case 'Date':
          {
            this.setState({ Date: inputValue.target.value });
            break;
          }
        case 'Title':
          {
            this.setState({ Title: inputValue.target.value });
            break;
          }
        case 'Body':
          {
            this.setState({ Body: inputValue.target.value });
            break;
          }
      }
    }
    catch (e) {
      console.log('inputFormChange: ' + e);
    }
  }
  // Get Input RichText Details
  private handleRichTextChange = (fieldName, content) => {
    try {
      switch (fieldName) {

        case 'Body':
          this.setState({ Body: content });
          break;
      }
    }
    catch (e) {
      console.log('handleRichTextChange: ' + e);
    }
  }
  /****RichTextMy */
  private handleImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {
    if (imageInfo != null) {
      let files = uploadedRichTextFiles;
      let dataURI = imageInfo.src;
      let fileName = imageInfo.name;
      if (dataURI.split(',')[0].indexOf('base64') >= 0) {
        var arr = dataURI.split(','),
          mime = arr[0].match(/:(.*?);/)[1],
          bstr = atob(arr[1]),
          n = bstr.length,
          u8arr = new Uint8Array(n);
        while (n--) {
          u8arr[n] = bstr.charCodeAt(n);
        }
        const file = new File([u8arr], fileName, { type: mime });
        let fExists = files.some((f) => f['name'] === file['name']);
        if (!fExists) {
          files.push(file);
        }
        uploadedRichTextFiles = files;
      }
    }
  }

  public handleAttachmentChange = async (chTarget) => {
    //debugger;
    try {
      if (isAssignToClaim == false) {
        fileonchangealert = true;

        let { FormAttachment, FormAttachmentNames } = this.state;
        // let fileInfos = [];
        let target = chTarget.target;
        if (FormAttachment.length !== 0 || target.files.length !== 0) {
          // let fileName = [];

          // let tempFName = [];
          let fileName = [];
          // let tempfile = [];
          let tempFName = [];
          FormAttachment.forEach((aFiles) => {
            if (aFiles.name === target.files.name) {
              alert("file already exisist with same name");
            }
            else if(target.files.size>9437184){
              alert("file size exceeded");
            }
          });
          const replacedate = "";
          const searchsub = /[!@#$%^&*()}+\=\[\];':"\\|,<>\/?]+/;
          tempfile = this.state.FormAttachment;
          tempFName = this.state.FormAttachmentNames;
          for (let fileItem of target.files) {
            tempFName.push({ FileName: (fileItem.name).split(searchsub).join(replacedate) });
            tempfile.push({ name: (fileItem.name).split(searchsub).join(replacedate), content: fileItem });
            this.setState({
              FormAttachment: tempfile,
              FormAttachmentNames: tempFName,
            });
          }
        }

      }
      else {
        fileonchangealert = false;
        isAssignToClaim = true;
      }
    } catch (e) {
      console.log("handleAttachmentChange: " + e);
    }
  }
  public addDeleteFiles = async (fileName) => {
    try {
      let tempAttachFileName = this.state.FormAttachmentNames;
      var index = tempAttachFileName.map((p) => p.FileName).indexOf(fileName);
      if (
        uniqueId != 0 &&
        deleteFiles != undefined &&
        deleteFiles.length != 0
      ) {
        var indexCheck = deleteFiles.map(
          (p) => p.FileName
        ).indexOf(fileName);
        indexCheck != -1 &&
          deleteFiles[indexCheck].ServerRelativePath !=
          undefined
          ? deleteFiles.push(fileName)
          : null;
        tempAttachFileName.splice(index, 1);
        await this.setState({ FormAttachmentNames: tempAttachFileName });
      }
      if (uniqueId != 0) {
        var indexCheck = deleteFiles.map((p) => p.FileName).indexOf(fileName);
        if(indexCheck === -1)
         deleteFiles.push(fileName);
        let filtered = tempAttachFileName.filter(file => file.FileName !== fileName);
        await this.setState({
          FormAttachmentNames: filtered,
        });
      }
    } catch (e) {
      console.log("addDeleteFiles " + e);
    }
  }

  // Get DropDownDetails
  private inputDropDownDetailsChange = (inputValue) => {
    try {
      switch (inputValue.id) {
      }
    }
    catch (e) {
      console.log('inputDropDownDetailsChange: ' + e);
    }
  }


  private _getSendToPeoplePickerItems = (items: any[]) => {
    let peoplePickArr = [];
    for (let item in items) {
      peoplePickArr.push(items[item].id);
    } this.setState({ SendTo: peoplePickArr });
  }


  private _getCopyToPeoplePickerItems = (items: any[]) => {
    let peoplePickArr = [];
    for (let item in items) {
      peoplePickArr.push(items[item].id);
    } this.setState({ CopyTo: peoplePickArr });
  }
  private _getBlindCopyToPeoplePickerItems = (items: any[]) => {
    let peoplePickArr = [];
    for (let item in items) {
      peoplePickArr.push(items[item].id);
    } this.setState({ BlindCopyTo: peoplePickArr });
  }
  private _getFromPeoplePickerItems = (items: any[]) => {
    let peoplePickArr = [];
    for (let item in items) {
      peoplePickArr.push(items[item].id);
    }
    this.setState({ From: peoplePickArr });
  }
  private _getTempAdjPeoplePickerItems = (items: any[]) => {
    let peoplePickArr = [];
    for (let item in items) {
      peoplePickArr.push(items[item].id);
    } this.setState({ TempAdj: peoplePickArr });
  }
  private _getDateDatePickerItems = (items) => {
    this.setState({ Date: items });
  }


  private mrk_deleteRadioBtnChange = (items) => {
    items.target.innerText != '' ? this.setState({ mrk_delete: items.target.innerText }) : null;
  }

  public PrintScreen = () => {
    try {
      window.print();

    } catch (e) {
      console.log('PrintScreen: ' + e);
    }
  }


  /***********8Cover Lettters */
  public txtfile = () => {
    // let filecount=1;
    isProgress = true;
    var d = new Date;
    var ampm = d.getHours() >= 12 ? ' PM ' : ' AM ';
    let dformat = [d.getMonth() + 1,
    d.getDate(),
    d.getFullYear()].join('-') + ' ' +
      [d.getHours(),
      d.getMinutes(),
      d.getSeconds()].join(':') + ampm;
    const txt = document.createElement('a');
    const htmlToFormattedText = require("html2plaintext");
    let domparser = new DOMParser();
    let s = new XMLSerializer();
    let parsedBody = domparser.parseFromString(this.state.Body, 'text/html');
    parsedBody.querySelectorAll('[class*=se-component]').
      forEach((ext) => { ext.removeAttribute('class'); });
    let serializeBody = s.serializeToString(parsedBody);
    const functionn = (htmlToFormattedText) => {
      return htmlToFormattedText(serializeBody);
    };
    const SendtoVal = () => {
      if (this.state.SendToDefaultItems.includes(null) == true || this.state.SendToDefaultItems.includes(undefined) == true || this.state.SendToDefaultItems.includes("") == true || this.state.SendToDefaultItems.length == 0) {
        let splisendtoval = split(this.state.SendToText, ",");
        return splisendtoval[0];
      }
      else {
        return localSendToEmail[0];
      }
    };
    const CopyToVal = () => {
      if (this.state.CopyToDefaultItems.includes(null) == true || this.state.CopyToDefaultItems.includes(undefined) == true || this.state.CopyToDefaultItems.includes("") == true) {
        let splicopyval = split(this.state.CopyToText, ", ");
        return splicopyval[0];
      }
      else {
        return localCopyToEmail.slice(0, 1);
      }
    };
    const FromVal = () => {
      if (this.state.FromDefaultItems.includes(null) == true || this.state.FromDefaultItems.includes(undefined) == true || this.state.FromDefaultItems.includes("") == true) {
        let splifromval = split(this.state.FromText, ",");
        return splifromval[0];
      }
      else {
        return localFromEmail;
      }
    };
    const search = '}';
    const replace = "";
    const searchdate = ":";
    const replacedate = "";
    var searchsub = /[!@#$%^&*()}+\=\[\];'"\\|<>\/?]+/;
    const SubjectVal = () => {
      if (this.state.Title == "" || this.state.Title == null || _.isEmpty(this.state.Title) == true) {
        return this.state.Title;
      }
      else {
        return (this.state.Title.split(search).join(replace)).slice(0, 91);
      }
    };
    const FileSubjectVal = () => {
      if (this.state.Title == "" || this.state.Title == null || _.isEmpty(this.state.Title) == true) {
        return this.state.Title;
      }
      else {
        //  if (searchsub.test(this.state.Title)){
        return (this.state.Title.split(searchsub).join(replacedate)).slice(0, 91);
      }
    };
    let filecount = 2;
    let filecount1 = 1;
    const filec = (filecount, padding) => {
      var zeroes = new Array(padding + 1).join("0");
      return (zeroes + filecount).slice(-padding);
    };

    const file = new Blob([("Sender: " + FromVal() + "\n"), ("Date: " + dformat + "\n"),
    ("Send To: " + SendtoVal() + "\n"), ("Copy To: " + CopyToVal() + "\n"), ("Subject: " + SubjectVal() + "\n")
      , ("DocumentID: " + uniqueId + "\n"), ("Content:" + functionn(htmlToFormattedText) + "\n"), ("Attachments: " + this.state.FormAttachmentNames.map((item) => (
        "CLAIM}U}" + this.state.GAPAgreeNumA + "}U}GAP10}I}" + dformat + "-" + filec(filecount++, 3) + "-" + "ATTACHMENT" + "-" + filec((filecount1++), 3) + "." + item.FileName)))
    ], {
      type: "text/plain"
      //"text/plain;charset=UTF-8"
    });
    filename = "CLAIM}U}" + this.state.GAPAgreeNumA + "_}U}GAP10}I}" + dformat.split(searchdate).join(replacedate) + "-001-" + FileSubjectVal() + ".TXT";
    txt.href = URL.createObjectURL(file);
    txt.download = filename;
    document.body.appendChild(txt);
    txt.click();
    var reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onloadend = async () => {
      let base64data = reader.result;
      filebase64data = (reader.result as string).substring((reader.result as string).indexOf(',') + 1);
    await this.UploadfilestoApi();
    };
  }
  /*****Azureapicall */
  private getAccessToken = async () => {
    // debugger;
    const requestHeaders: Headers = new Headers();
    requestHeaders.append('Content-Type', 'application/json');
    const httpClientOptionsForGlobal: IHttpClientOptions = {
      headers: requestHeaders
    };
    accessToken = await this.props.context.httpClient
   //   .get(`https://gapclaims-logicappdo1.azurewebsites.net:443/api/Gap_Claims_OKTA_Token_Generation/triggers/manualPost/invoke?api-version=2022-05-01&sp=%2Ftriggers%2FmanualPost%2Frun&sv=1.0&sig=g8qrcy2YOAEVKIa1H1fEGMYARWepwnDW9CRHVRN5yvs`, HttpClient.configurations.v1, httpClientOptionsForGlobal)//dev and qa logic apps(qa)
      .get(`https://gapclaims-logicappdo1.azurewebsites.net:443/api/Gap_Claims_Dev_OKTA_Token_Generation/triggers/manual/invoke?api-version=2022-05-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=c7WqafJcLdvqOXK_aDLbhH-p07MTwFjXsk29Jevi_9U`, HttpClient.configurations.v1, httpClientOptionsForGlobal)//dev and qa logic apps(dev)

    //.get(`https://gapclaims-logicapp-qa.azurewebsites.net:443/api/Test/triggers/manual/invoke?api-version=2022-05-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=bsAyTtukYgqqoNsJPaGNT4PA2vyIOt7DukoImSZDaQ8`, HttpClient.configurations.v1, httpClientOptionsForGlobal)//dev and qa logic apps

      // .then((response: HttpClientResponse) => response.json())
      // .then((token) => {
      //    console.log(token);
      //    return token;
      // });
      .then(async(response: HttpClientResponse) => {
        return await response.json();
      })
      .catch((error) => {
         console.log(error);
         return null;
      });
    //  console.log(accessToken);
  }
  public getDatafromApi = async (LettersListID) => {
    // debugger; 
    isProgress = true;
    let claimno = this.state.GAPAgreeNumA;
    try{
      await this.getAccessToken();
    }
     catch(e){
      console.log(e);
     }
    const requestHeaders: Headers = new Headers();
    requestHeaders.append('Ocp-Apim-Subscription-Key', '72d1df75381e488fb5a6dafc07b19562');//dev
   //requestHeaders.append('Ocp-Apim-Subscription-Key', 'cec1c33eb72e4f09848849408b10585a');//qa
   //requestHeaders.append('Ocp-Apim-Subscription-Key', '1661a67e27e84d7987be93ca4323013b');//prod

    requestHeaders.append('Content-Type', 'application/json');

   //const getClaimNumberURL = `https://azureapi-qa.zurichna.com/purefi/api/claim/v2/UUG/claims/${claimno}/documents`;
     const getClaimNumberURL = `https://azureapi-dev.zurichna.com/purefi/api/claim/v2/UUG/claims/${claimno}/documents`;
  //  const getClaimNumberURL = `https://zna-api.zurichna.com/purefi/api/claim/v2/UUG/claims/${claimno}/documents`;

   let token = accessToken["token_type"] + " " + accessToken["access_token"];
    // let token = "Bearer" + " " +"eyJraWQiOiJHYi1ZZDgxeG9CZ3U1YUdQRGVDSGN1UU0tWG1ZMHJzZlNUTVYzUDktLUdrIiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULjlzaXR2T1JPdXN0Y1FCS1k3aTBSWjlMRE1pN3JUT09Mc2FSY3A5TUNyZFEiLCJpc3MiOiJodHRwczovL3FhbG9naW4uenVyaWNobmEuY29tL29hdXRoMi9hdXN4dWZta3cwbFlKUVY4UTBoNyIsImF1ZCI6IkF6dXJlIEFQSSIsImlhdCI6MTY2Nzk3NjUxNCwiZXhwIjoxNjY3OTgwMTE0LCJjaWQiOiIwb2ExOTZ2cDg1ZWY2RHpSbTBoOCIsInNjcCI6WyJBUElfQWNjZXNzdG9rZW4iXSwic3ViIjoiMG9hMTk2dnA4NWVmNkR6Um0waDgifQ.We_qpI7hGd95lMHAOtnlc4WnZKhS--kRDDsiMOplPVuGVDqFPUEXrw9fALuHRF7uIlNt8zEQiE2YBXdYmga1HZNjj-Jc2b1FaUpkT67zsPdWaCLCBAoRPF7Nt9TG-YqXKAT3VHg0Pw5i5RWaHxieoEGpKcC716SCiM2VxbLCiFfFzgQTc0DfzTqU_6CJuti6EXASA95plVn4YciMQuJYzJyNL9DQhgS7CcErPM3-iSSR3fS1MKR6j2lMQ-d5pTEDLOkOVEZ8yVepVH5zSOydnM0OKdbKgr8ONuaOK746IyZgOEwIip6iauokaw2Ziw3B37c2rHDsTJYQNK-YVuzFOQ";
    requestHeaders.append("Authorization", `${token}`);
    const httpClientOptionsForGlobal: IHttpClientOptions = {
      headers: requestHeaders
    };
    let claimObject: any = await this.props.context.httpClient
      .get(getClaimNumberURL, HttpClient.configurations.v1, httpClientOptionsForGlobal)
      .then(async (response: HttpClientResponse) => {
        // console.log(response.json());
        if (typeof response.statusText!="undefined" && response.statusText != null&&  response.statusText.toLowerCase() != "ok") {
          await this.setState({ ValidClaimno: true, isSpinner1: false });
          await this.setState({ isSpinner1: false });
        }
      
        return response.json();
      })
      //let responseclaimobject= await response.json();
      // console.log(responseclaimobject);
      
        .catch(async (e) => {
          await this.setState({ ValidClaimno: true, isSpinner1: false });
          // await(this.setState({Disable:true}));
          await this.setState({ isSpinner1: false });
          console.log("Error", e);
        });

   
    /******Post data */
    let existclaimidentifier: boolean = false;
    if (claimObject && claimObject.length > 0) {
      claimObject.filter((obj: any) => {
        if (obj.direction && obj.direction.toLowerCase() == 'incoming' && !existclaimidentifier) {
          claimidentifier = obj.identifier;
          existclaimidentifier = true;
          return true;
        }
        return false;
      });
      console.log(claimidentifier);
      if (claimidentifier) {
        await this.setState({ isSpinner1: false });
        await this.setState({ isSpinner: true });

   // await this.txtfile();     //(commentes for not to upload)
        
      }

    } console.log(claimidentifier);
  }

  public IsNullOrUndefined<T>(obj: T | null | undefined): obj is null | undefined {
    return typeof obj === "undefined" || obj === null;
  }

  private UploadfilestoApi = async () => {
    let claimno = this.state.GAPAgreeNumA;
    const requestHeaders: Headers = new Headers();
    requestHeaders.append('Content-Type', 'application/json');
 requestHeaders.append('Ocp-Apim-Subscription-Key', '72d1df75381e488fb5a6dafc07b19562'); //dev
//     requestHeaders.append('Ocp-Apim-Subscription-Key', 'cec1c33eb72e4f09848849408b10585a'); // qa
    //  requestHeaders.append('Ocp-Apim-Subscription-Key', '1661a67e27e84d7987be93ca4323013b');//prod

    let token = accessToken["token_type"] + " " + accessToken["access_token"];
    requestHeaders.append("Authorization", `${token}`);
    const body: string = JSON.stringify({
      'fileName': `${filename}`,
      'fileContent': `${filebase64data}`,
      'userId': `${this.props.context.pageContext.user.displayName.slice(0, 29)}`,
      'notest': `${this.state.Title}`
    });
    const httpClientOptions: IHttpClientOptions = {
      body: body,
      headers: requestHeaders
    };
    
    let filecount = 2;
    let filecount1 = 1;
    const searchdate = ":";
    const replacedate = "";
    const filec = (filecount, padding) => {
      var zeroes = new Array(padding + 1).join("0");
      return (zeroes + filecount).slice(-padding);
    };
    re = await this.props.context.httpClient.post(
  //   `https://azureapi-qa.zurichna.com/purefi/api/claim/v2/UUG/claims/${claimno}/document/incoming/${claimidentifier}`, HttpClient.configurations.v1, httpClientOptions)
      `https://azureapi-dev.zurichna.com/purefi/api/claim/v2/UUG/claims/${claimno}/document/incoming/${claimidentifier}`, HttpClient.configurations.v1, httpClientOptions)
      .then(async (response: HttpClientResponse) => {

        if(response.statusText == "OK" || response.statusText == "ok" || response.statusText == "Ok"){
          
          if (this.state.FormAttachmentNames.length > 0) {
            const item: IItem = await sp.web.lists.getById(this.props.LettersListID).items.getById(uniqueId);
            var d = new Date;
            var ampm = d.getHours() >= 12 ? ' PM ' : ' AM ';
            let dformat = [d.getMonth() + 1,
            d.getDate(),
            d.getFullYear()].join('-') + ' ' +
              [d.getHours(),
              d.getMinutes(),
              d.getSeconds()].join(':') + ampm;
            const replacedate = "";
            const searchsub = /[!@#$%^&*()}+\=\[\];':"\\|,<>\/?]+/;
            this.state.FormAttachmentNames.forEach(name => {
              item.attachmentFiles.getByName(name['FileName']).getBlob().then((res: Blob) => {
                var reader:any = new FileReader();

                reader.readAsDataURL(res);
                
              //   if(res.size>7864320){
              //     this.state.FormAttachmentNames.forEach(name => {
              //       item.attachmentFiles.getByName(name['FileName']).getBlob().then((res: Blob) => {
              //         // if (res.size>7864320){
              //         //   alert(name['FileName']+" File size Exceeded!");
              //         //   console.log(['FileName']+" File size Exceeded!");
              //         //   this.setState({isSpinner:false});
              //         // }
                
              //       })
              //   })
              // }
       //         else{
                reader.onloadend = () => {
                  
                  let base64data = reader.result;
               
                  Attachmentbase64data = (base64data as string).substring((base64data as string).indexOf(',') + 1);
                  const body1: string = JSON.stringify({
                    'fileName': `${"CLAIM}U}" + this.state.GAPAgreeNumA + "}U}GAP10}I}" + dformat.split(":").join(replacedate) + "-" + filec(filecount++, 3) + "-" + "ATTACHMENT" + "-" + filec((filecount1++), 3) + "." + name['FileName'].split(searchsub).join(replacedate)} `,
                    'fileContent': `${Attachmentbase64data}`,
                    'userId': `${this.props.context.pageContext.user.displayName.slice(0,29)}`,
                    'notest': `${this.state.Title}`
                  });
                  const httpClientOptions: IHttpClientOptions = {
                    body: body1,
                    headers: requestHeaders
                  };
                  let postResponse = this.props.context.httpClient.post(
                 //   `https://azureapi-qa.zurichna.com/purefi/api/claim/v2/UUG/claims/${claimno}/document/incoming/${claimidentifier}`, HttpClient.configurations.v1, httpClientOptions)
              `https://azureapi-dev.zurichna.com/purefi/api/claim/v2/UUG/claims/${claimno}/document/incoming/${claimidentifier}`, HttpClient.configurations.v1,httpClientOptions)
                    .then(async (response: HttpClientResponse) => {
                
                      if (response.statusText == "OK" || response.statusText == "ok" || response.statusText == "Ok") {
                        
                        await this.setState({ isSpinner: false });
                        openDailog2 = true;
                        await this.setState({ hideDialog: true, hideDialog2: false });
                      }
                      else {
                        await this.setState({ ValidResponse: true,isSpinner: false });
                      }
                   })
                  //  .then((data) => {
                  //     console.log("Post Request recieved");
                  //     return data;
                  //   })
                    .catch(async(e) => {
                    await this.setState({ ValidResponse: true, isSpinner: false });
                      console.log("post error", e);
                    });
                };
          //    }
              });
            });
            //  console.log(re);
          }
          else{
            await this.setState({ isSpinner: false });
                        openDailog2 = true;
                        await this.setState({ hideDialog: true, hideDialog2: false });
          }
          await this.UploadFiless();//saving data in sharepoint
        }
        else {
          //let uploadErrorResponse: any = await response.json();
         // await this.setState({ ValidResponse: true, UploadErrorMessage: uploadErrorResponse.Errors[0].Message});    
          let uploadErrorResponse: any = await response.json();
        
          if (!this.IsNullOrUndefined(uploadErrorResponse) && uploadErrorResponse != ''    
          && !this.IsNullOrUndefined(uploadErrorResponse.Errors) && uploadErrorResponse.Errors.length > 0) {    
           await this.setState({ ValidResponse: true, UploadErrorMessage: uploadErrorResponse.Errors[0].Message});    
         
         
          }
        }
        await this.setState({ isSpinner: false });
       
        return response.json();
      })
      // .then((data) => {
      //   console.log("Post Request recieved");
      //   return data;
      // })
      .catch(async(e) => {
        await this.setState({ ValidResponse: true, isSpinner: false });
        console.log("post error", e);
      });
    console.log(re);
  }
  /***************** */
  //Render Method //
  public render(): React.ReactElement<IGapClaimsLettersProps> {
    return (
      <ThemeProvider>
        <div className='container'>
          <div className='border p-3' style={{ backgroundColor: "#23366f" }}>
            <div className='row'>
              <div className='col-md-6 '><h3 className='text-light'>{this.props.description}</h3></div>
              <div className='col-md-6 text-right'>
                {this.props.logourl && <img src={this.props.logourl} alt='Logo' width='50' height='50' />}
              </div>
            </div>
          </div>
          <Dialog minWidth={'460px'} maxWidth={'520px'} hidden={this.state.modalclose} dialogContentProps={dialogContentProps}>
            <DialogFooter>
              <PrimaryButton style={{ backgroundColor: "#23366f" }} onClick={this.modalSubmitClick} text="Yes" />
              <PrimaryButton style={{ backgroundColor: "#23366f" }} onClick={this.modalPopupClose} text="No" />
            </DialogFooter>
          </Dialog>
          <Dialog hidden={this.state.isExitHidden} dialogContentProps={dialogSavedProps}>
            <div className="text-center">
              <Icon iconName="CompletedSolid" className="btn-lg text-success" />
              <br></br>
              <div>Data Saved Succesfully!</div>
            </div>
            <DialogFooter>
              <PrimaryButton style={{ backgroundColor: "#23366f" }} onClick={this.ExitForm} text="OK" />
            </DialogFooter>
          </Dialog>

          {isViewMode == true && isEditMode == false ?

            <div>
              <div className='buttonCls text-right'>
                {/* <PrimaryButton className='' text='Exit' allowDisabledFocus onClick={this.ExitForm}/>
               */}
                <PrimaryButton className='' style={{ backgroundColor: "#23366f" }} text='Exit' allowDisabledFocus onClick={this.ExitmodalPopupOpen.bind(this, 'Exit')} />

                {this.state.isReader == false ? <PrimaryButton className='ml-1' style={{ backgroundColor: "#23366f" }} text='Edit' onClick={this.EditClickBtn} allowDisabledFocus />
                  : null}
                {/* <PrimaryButton className='ml-1' style={{ backgroundColor: "#23366f" }} text='Print' onClick={this.PrintScreen} allowDisabledFocus />
             */}
              </div>
              <div style={{ backgroundColor: this.props.bodyBackground }}><ViewGapClaimsLetters {...this.state} />
              </div>
              </div> :

            <div>
              <div className='buttonCls mt-2 text-right'>
                <PrimaryButton className='' style={{ backgroundColor: "#23366f" }} text='Exit' allowDisabledFocus onClick={this.ExitmodalPopupOpen.bind(this, 'Exit')} />

                <PrimaryButton className='ml-1' style={{ backgroundColor: "#23366f" }} text='Save and Exit' onClick={this.modalPopupOpen.bind(this, 'SaveExit')} allowDisabledFocus />
                {isEditMode == true ?
                  <>
                    {/* <PrimaryButton className='ml-1' style={{ backgroundColor: "#23366f" }} text='View' onClick={this.ViewClickBtn} allowDisabledFocus />
                   */}
                    <PrimaryButton className='assign' style={{ backgroundColor: "#23366f" }} text="Assign To Claim" onClick={this.Assign_to_Claimm} allowDisabledFocus></PrimaryButton>
                  </> : null}
              </div>
              <div className='border p-3 mt-2'>
                <div className='row'>
                  <div className='col-md-6'>
                    <Label>GAP Agreement #</Label>
                    <TextField className='w-100' value={this.state.GAPAgreeNum} disabled={true} name='GAPAgreeNum' onChange={this.inputFormChange} />
                  </div>
                  <div className='col-md-6'>
                    {actionclicked == 'Save' ? <TextField className='w-100' label='Gap Adjuster' disabled={true} value={this.state.VSCAdj} name='VSCAdj' onChange={this.inputFormChange} /> :
                      <> <Label>Gap Adjuster</Label>
                        <TextField className='w-100' value={this.state.VSCAdj} name='VSCAdj' disabled={true} onChange={this.inputFormChange} /></>}
                  </div>
                </div>
                <div className='row'>
                  <div className='col-md-6'>
                    <Label>Claimant Last Name</Label>
                    <TextField className='w-100' disabled={true} value={this.state.InsuredLastName} name='InsuredLastName' onChange={this.inputFormChange} />
                  </div>
                  <div className='col-md-6'>
                    <Label>First Name</Label>
                    <TextField className='w-100' disabled={true} value={this.state.InsuredFirstName} name='InsuredFirstName' onChange={this.inputFormChange} />
                  </div>
                </div>
                {/* <div className='row'>
                  <div className='col-md-6'>
                    <Label>Claimant Address</Label>
                    <TextField className='w-100'  value={this.state.InsuredStreetAddress} name='InsuredStreetAddress' onChange={this.inputFormChange} />
                  </div>
                  <div className='col-md-6'>
                    <Label>Claimant City</Label>
                    <TextField className='w-100'  value={this.state.InsuredCity} name='InsuredCity' onChange={this.inputFormChange} />
                  </div>
                </div>
                <div className='row'>
                  <div className='col-md-6'>
                    <Label>Claimant State</Label>
                    <TextField className='w-100'  value={this.state.InsuredState} name='InsuredState' onChange={this.inputFormChange} />
                  </div>
                  <div className='col-md-6'>
                    <Label>Claimant Zip</Label>
                    <TextField className='w-100'  value={this.state.InsZip} name='InsZip' onChange={this.inputFormChange} />
                  </div>
                </div> */}
 <div className='row'>
                  <div className='col-md-6'>
                    <PeoplePicker context={this.props.context} titleText='Reassign To'
                      personSelectionLimit={1} showtooltip={true} disabled={false} ensureUser={true} onChange={this._getTempAdjPeoplePickerItems}
                      showHiddenInUI={false} defaultSelectedUsers={this.state.TempAdjDefaultItems} principalTypes={[PrincipalType.User]} resolveDelay={1000} />
                  </div>
                  <div className='col-md-6 inlineflex'>
                    <ChoiceGroup label='Mark Delete'
                      selectedKey={this.state.mrk_delete}
                      defaultSelectedKey="No"
                      options={this.state.mrk_deleteChoiceArr} onClick={this.mrk_deleteRadioBtnChange} />
                  </div>
                </div>

                {/* <div className='row'>
                  <div className='col-md-6'>
                  {this.state.TempAdjDefaultItems.includes(null) == true || this.state.TempAdjDefaultItems.includes(undefined) == true || this.state.TempAdjDefaultItems.includes("") == true ?
                        <div className='w-100'> <Label>Reassign To</Label>{this.state.TempAdjText} </div> :
                        <div className='w-100'>
                          <PeoplePicker context={this.props.context} titleText='Reassign To'
                      personSelectionLimit={1} showtooltip={true} disabled={false} ensureUser={true} onChange={this._getTempAdjPeoplePickerItems}
                      showHiddenInUI={false} defaultSelectedUsers={this.state.TempAdjDefaultItems} principalTypes={[PrincipalType.User]} resolveDelay={1000} />
</div>

                      }
                  
                  </div>
                  <div className='col-md-6 inlineflex'>
                    <ChoiceGroup label='Mark Delete'
                      selectedKey={this.state.mrk_delete}
                      defaultSelectedKey="No"
                      options={this.state.mrk_deleteChoiceArr} onClick={this.mrk_deleteRadioBtnChange} />
                  </div>
                </div> */}
              </div>
              <div className='border p-3 mt-2'>
                {this.state.SendToDefaultItems.includes(null) == true || this.state.SendToDefaultItems.includes(undefined) == true || this.state.SendToDefaultItems.includes("") == true || ((this.state.SendToText != null || this.state.SendToText != undefined || this.state.SendToText != "") && this.state.SendToDefaultItems.includes("") != true) ?
                  <div className='row'>
                    <div className='col-md-6'><Label>To:</Label></div>
                    <div className='col-md-6'><Label>{this.state.SendToText}</Label></div>
                  </div> :
                  <div className='row'>
                    <div className='col-md-6'><Label>To:</Label></div>
                    <div className='col-md-6'><Label>
                      {this.state.SendToDefaultItems.length > 0 ? this.state.SendToDefaultItems.map((team, index) =>
                        <span>{team}{index != this.state.SendToDefaultItems.length - 1 ? ' , ' : null}</span>) : null}</Label>
                      {/* <Label>{this.state.SendToDefaultItems}</Label> */}
                      {/* <div className='w-25'>
<PeoplePicker context ={ this.props.context} titleText = 'To'
personSelectionLimit ={ 3} showtooltip ={ true} required ={ true} disabled ={ false} ensureUser ={ true}
 onChange ={ this._getSendToPeoplePickerItems}
showHiddenInUI ={ false}
 defaultSelectedUsers ={ this.state.SendToDefaultItems}
  principalTypes ={[PrincipalType.User]} resolveDelay ={ 1000}/></div> */}
                    </div>
                  </div>
                }
                <div>
                  {this.state.CopyToDefaultItems.includes(null) == true || this.state.CopyToDefaultItems.includes(undefined) == true || this.state.CopyToDefaultItems.includes("") == true || ((this.state.CopyToText != null || this.state.CopyToText != undefined || this.state.CopyToText != "") && this.state.CopyToDefaultItems.includes("") != true) ?
                    <div className='row'>
                      <div className='col-md-6'><Label>Copy To:</Label></div>
                      <div className='col-md-6'><Label>{this.state.CopyToText}</Label></div>
                    </div>
                    :
                    <div className='row'>
                      <div className='col-md-6'><Label>Copy To:</Label></div>
                      <div className='col-md-6'><Label>
                        {this.state.CopyToDefaultItems.length > 0 ? this.state.CopyToDefaultItems.map((team, index) =>
                          <span>{team}{index != this.state.CopyToDefaultItems.length - 1 ? ' , ' : null}</span>) : null}</Label></div>
                    </div>}
                </div>
                <div>
                  {this.state.BlindCopyToDefaultItems.includes(null) == true || this.state.BlindCopyToDefaultItems.includes(undefined) == true || this.state.BlindCopyToDefaultItems.includes("") == true || ((this.state.BlindCopyToText != null || this.state.BlindCopyToText != undefined || this.state.BlindCopyToText != "") && this.state.BlindCopyToDefaultItems.includes("") != true) ?
                    <div className='row'>
                      <div className='col-md-6'><Label>Blind Copy To:</Label></div>
                      <div className='col-md-6'><Label>{this.state.BlindCopyToText}</Label></div>
                    </div>
                    :
                    <div className='row'>
                      <div className='col-md-6'><Label>Blind Copy To</Label></div>
                      <div className='col-md-6'><Label>{this.state.BlindCopyToDefaultItems.length > 0 ? this.state.BlindCopyToDefaultItems.map((team, index) =>
                        <span>{team}{index != this.state.BlindCopyToDefaultItems.length - 1 ? ' , ' : null}</span>) : null}</Label></div>
                    </div>}
                </div>
                {this.state.FromDefaultItems.includes(null) == true || this.state.FromDefaultItems.includes(undefined) == true || this.state.FromDefaultItems.includes("") == true ?
                  <div className='row'>
                    <div className='col-md-6'><Label>From:</Label></div>
                    <div className='col-md-6'><Label>{this.state.FromText}</Label></div></div> :
                  <div className='row'>
                    <div className='col-md-6'><Label>From:</Label></div>
                    <div className='col-md-6'><Label>{this.state.FromDefaultItems}</Label></div>
                  </div>
                }
                <div className='row'>
                  <div className='col-md-6'><Label>Date</Label></div>
                  <div className='col-md-6'>
                    <Label>{this.state.Date != undefined && this.state.Date != '' && this.state.Date != null ? moment(this.state.Date).format('L hh:mm A') : null}</Label>
                    {/* <DateTimePicker showLabels={false}
formatDate={onFormatDate}
dateConvention={DateConvention.Date}
 disabled={true}
value={this.state.Date} onChange={this._getDateDatePickerItems} /> */}
                  </div>
                </div>
                <div className='row'>
                  <div className='col-md-6'><Label>Subject</Label></div>
                  <div className='col-md-6'><Label>{this.state.Title}</Label></div>
                </div>
              </div>
              <div className='border p-3 mt-2'>
                <div className='row'>
                  <div className='col-md-12'>
                    <Label className='font-weight-bold w-25'>Message</Label>
                    <div className='col-md-12' style={{minHeight:'180px',maxHeight:'200px', overflowY:'auto'}}>

                     <div dangerouslySetInnerHTML={{ __html: this.state.Body }} />

                          </div>
                    {/* <SunEditor enableToolbar={false} lang='en' placeholder='Please type here...'
                      autoFocus={true} disable={true} setContents={this.state.Body} setOptions={{
                        minHeight: '180px'
                      }}
                      onChange={this.handleRichTextChange.bind(this, 'Body')}
                      onImageUpload={this.handleImageUpload} /> */}
                  </div>
                </div>
              </div>
              <div className='border p-3 mt-2'>
                <div className='row'>
                  <div className='col-md-12'>
                    <Label className='font-weight-bold'> Attachments </Label>
                    <input className='ReactFieldEditor - Attachments - UploadInput'
                      type='file' name='attachmentFiles' title='Attach Files'
                      aria-required='false' aria-label='Attach Files' multiple onChange={this.handleAttachmentChange.bind(this)} />
                    <div>
                      <div className="row">
                        <div className="col-md-12">
                          {this.state.FormAttachmentNames !== undefined &&
                            this.state.FormAttachmentNames !== null
                            ?
                            this.state.FormAttachmentNames.map((item) => (
                              <div><span>
                                <Link
                                  key={item.FileName}
                                  onClick={() =>
                                    window.open(
                                      this.SplitAndEncodeURIComponent(item.ServerRelativeUrl),
                                      "_blank"
                                    )
                                  }
                                >
                                  {item.FileName}
                                </Link>
                                {uniqueId == 0 ? null : (
                                  <IconButton
                                    className="mt-1" style={{ verticalAlign: "bottom" }}
                                    iconProps={{ iconName: "Download" }}
                                    title="Download"
                                    ariaLabel="Download"
                                    onClick={() =>
                                    (window.location.href =
                                      this.props.context.pageContext.web
                                        .absoluteUrl +
                                      "/_layouts/download.aspx?sourceurl=" +
                                      this.SplitAndEncodeURIComponent(item.ServerRelativeUrl))
                                    }
                                  />
                                )}
                                {/* <IconButton
                            className="mt-1"
                            iconProps={{ iconName: "Delete" }}
                            title="Delete"
                            ariaLabel="Delete"
                            onClick={() => this.addDeleteFiles(item.FileName)}
                          /> */}
                              </span></div>
                            ))
                            : null}
                        </div>
                      </div>
                    </div>
                    <Dropdown
                      label="Type"
                      placeholder="Select an option"
                      selectedKey={this.state.NotesType}
                      options={this.state.PaymentTypeOptions}
                      onChange={this.onPaymentTypeChange} />
                  </div>
                  {isAssignToClaim == true ?
                    <Dialog
                      hidden={this.state.hideDialog}
                      onDismiss={this.Dialog_close}
                      dialogContentProps={{
                        type: DialogType.close,
                        title: <div className='border p-3' style={{ backgroundColor: "#23366f" }}>
                          <div className='row'>
                            <div className='col-md-12 '><Label><h6 className='text-light'>SCS Claims Correspondence</h6></Label></div>
                          </div>
                        </div>
                      }}
                      modalProps={{
                        isBlocking: false,
                        styles: { main: { maxWidth: 9000 } },
                      }} >
                      {this.state.isSpinner == true ?
                        <Spinner label="Uploading Files" labelPosition='top' size={SpinnerSize.large}>
                        </Spinner> : null}
                      {this.state.isSpinner1 == true ?
                        <Spinner label="Loading..." labelPosition='top' size={SpinnerSize.large}>
                        </Spinner> : null}
                      <div className='row'>
                        <div className='col-md-9'>
                          <TextField className='w-100' label='Claim Number'
                            value={this.state.GAPAgreeNumA} name='GAPAgreeNumA' onChange={this.inputFormChange1} />
                        </div>
                        <div className='col-md-9'>
                          <TextField className='w-100' label='Claimant Last Name' value={this.state.InsuredLastNameA} name='InsuredLastNameA' onChange={this.inputFormChange1} />
                        </div>
                        <div className='col-md-9'>
                          <TextField className='w-100' label='First Name' value={this.state.InsuredFirstNameA} name='InsuredFirstNameA' onChange={this.inputFormChange1} />
                        </div>
                      </div>
                      <DialogFooter>
                        <PrimaryButton id="btn-submit" disabled={this.state.Disable} style={{ backgroundColor: "#23366f" }} onClick={this.Dialog_save.bind(this, "Save")} text="Save and Exit" />
                      </DialogFooter>
                    </Dialog>
                    : null
                  }
                  {openDailog2 == true ? <Dialog
                    hidden={this.state.hideDialog2}
                    onDismiss={this.Dialog_close2}
                    dialogContentProps={{
                      type: DialogType.close,
                      title: ' ',
                      subText: "This document content has been saved to shared folder.Click Ok!"
                    }}
                    modalProps={{
                      isBlocking: false,
                      styles: { main: { maxWidth: 450 } },
                    }}
                  >
                    <DialogFooter>
                      <PrimaryButton onClick={this._close} text="Ok" allowDisabledFocus />
                    </DialogFooter>
                  </Dialog> : null}

                  {this.state.ValidClaimno ? <Dialog hidden={!this.state.ValidClaimno} dialogContentProps={dialogSavedProps}>
                    <div className="text-center">
                      <Icon iconName="CompletedSolid" className="btn-lg text-danger" />
                      <br></br>
                      <div>Please enter the Valid claim number.</div>
                    </div>
                    <DialogFooter>
                      <PrimaryButton onClick={this.ValidClaim} text="OK" />
                    </DialogFooter>
                  </Dialog> : null}
                  {/* responseerror */}
                  {this.state.ValidResponse ? <Dialog hidden={!this.state.ValidResponse} dialogContentProps={dialogSavedProps}>
                    <div className="text-center">
                      <Icon iconName="CompletedSolid" className="btn-lg text-danger" />
                      <br></br>
                      <div>{this.state.UploadErrorMessage}</div>
                    </div>
                    <DialogFooter>
                      <PrimaryButton onClick={this.ValidResponseApi} text="OK" />
                    </DialogFooter>
                  </Dialog> : null}
                  {/* {
                  // actionclicked == 'Save' && isProgress == true ?        
                 openDailog3==true && actionclicked == 'Save' && isAssignToClaim==true?
                  <Dialog
                    hidden={this.state.hideDialog}
                    onDismiss={this.Dialog_close}
                    dialogContentProps={{
                      type: DialogType.close,
                      title: 'Uploading Files'
                    }}
                    modalProps={{
                      isBlocking: false,
                      styles: { main: { maxWidth: 900 } },
                    }} >
                   <DialogContent>
                   <div className='row'>
                   <div className='col-md-9'>
                   {isProgress == true  ?<Spinner  label ="Uploading Files" labelPosition='top' size={SpinnerSize.large}></Spinner>:null}
      </div>
                  </div>
                   </DialogContent>
                  {/* </Dialog>
                  :
                  null
                } */}
                </div>
              </div>
            </div>
          }
        </div>
      </ThemeProvider>
    );
  }
}