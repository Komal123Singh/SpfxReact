import { EventEmitter } from 'events';
import { Dispatcher } from 'simplr-flux';
let CategorylistitemDetails = [];
let savedResult;
let EditFormDetails=[];
let Userroleslistdetails=[];
class UserGuideStore extends EventEmitter {

    constructor() {
        super();
    }
    storeChange(action) {
        switch (action.action.type) {
            case 'getEditFormDetailsType':
                {
                    debugger;
                    EditFormDetails = action.action.response;
                    this.emit('getEditFormDetailschange');
                    break;
                }
            case 'getcategorieslistitemDetailsType':
                {
                  
                    CategorylistitemDetails = action.action.response;
                    this.emit('getcategorieslistitemDetailschange');
                    break;
                }
                case 'getUserRoleslistitemDetailsType':
                {
               
                    Userroleslistdetails = action.action.response;
                    this.emit('getUserRoleslistitemDetailschange');
                    break;
                }
                
            case 'insertResultType':
                {
                    savedResult = action.action.response;
                    this.emit('insertResultchange');
                    break;
                }
        }
    }
    getEditFormDetailsStoreValue() {
        return EditFormDetails;
    }
    getcategorieslistitemStoreValue() {
        return CategorylistitemDetails;
    }
    getUserRoleslistitemStoreValue() {
        return Userroleslistdetails;
    }

    getInserResultStoreValue() {
        return savedResult;
    }
}

let objUserGuideStore = new UserGuideStore();

Dispatcher.register(objUserGuideStore.storeChange.bind(objUserGuideStore));

export default objUserGuideStore;

