/* tslint:disable */
require("./FirstJs.module.css");
const styles = {
  firstJs: 'firstJs_8355fcf1',
  container: 'container_8355fcf1',
  row: 'row_8355fcf1',
  column: 'column_8355fcf1',
  'ms-Grid': 'ms-Grid_8355fcf1',
  title: 'title_8355fcf1',
  subTitle: 'subTitle_8355fcf1',
  description: 'description_8355fcf1',
  button: 'button_8355fcf1',
  label: 'label_8355fcf1'
};

export default styles;
/* tslint:enable */