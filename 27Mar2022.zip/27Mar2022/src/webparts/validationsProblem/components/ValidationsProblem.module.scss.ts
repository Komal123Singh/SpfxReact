/* tslint:disable */
require("./ValidationsProblem.module.css");
const styles = {
  validationsProblem: 'validationsProblem_f4241edd',
  container: 'container_f4241edd',
  row: 'row_f4241edd',
  column: 'column_f4241edd',
  'ms-Grid': 'ms-Grid_f4241edd',
  title: 'title_f4241edd',
  subTitle: 'subTitle_f4241edd',
  description: 'description_f4241edd',
  button: 'button_f4241edd',
  label: 'label_f4241edd'
};

export default styles;
/* tslint:enable */