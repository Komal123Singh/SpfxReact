import { WebPartContext } from "@microsoft/sp-webpart-base";

//Business Objects Starts //
export interface IGapClaimsLettersStates
{
webpartContxt:WebPartContext;
FormAttachment: any;
selectedFiles:any;
toDelNames:any;
FormAttachmentNames:any;
oldAttachments:any;
toDeleteAttachments:any;
Attachments:any;
NotesType:string;
attachmentType:any;
GAPAgreeNum : string;
dataURLtoBlob?:any;
GAPAgreeNumA:string;
id:number;
InsuredLastNameA : string,
InsuredFirstNameA : string,
VSCAdj : string;
hideDialog:boolean;
hideDialog2:boolean;
PaymentTypeOptions:any;
InsuredLastName : string;
InsuredFirstName : string;
InsuredStreetAddress : string;
InsuredCity : string;
InsuredState : string;
InsZip : string;
mrk_delete : string;
mrk_deleteChoiceArr : any;
SendTo : any;
SendToText:any;
SendToDefaultItems:string[];
SendToUserItems:string[];
CopyTo : any;
CopyToText:any;
CopyToDefaultItems:string[];
CopyToUserItems:string[];
BlindCopyTo : any;
BlindCopyToText:any;
BlindCopyToDefaultItems:string[];
BlindCopyToUserItems:string[];
From : any;
filec:number;
FromText:any;
FromDefaultItems:string[];
FromUserItems:string[];
Date : any;
Title : string;
Body : string;
}
//Business Objects End //
