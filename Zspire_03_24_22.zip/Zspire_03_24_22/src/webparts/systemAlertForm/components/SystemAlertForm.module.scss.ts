/* tslint:disable */
require("./SystemAlertForm.module.css");
const styles = {
  systemAlertForm: 'systemAlertForm_9777d7d9',
  container: 'container_9777d7d9',
  row: 'row_9777d7d9',
  column: 'column_9777d7d9',
  'ms-Grid': 'ms-Grid_9777d7d9',
  title: 'title_9777d7d9',
  subTitle: 'subTitle_9777d7d9',
  description: 'description_9777d7d9',
  button: 'button_9777d7d9',
  label: 'label_9777d7d9'
};

export default styles;
/* tslint:enable */