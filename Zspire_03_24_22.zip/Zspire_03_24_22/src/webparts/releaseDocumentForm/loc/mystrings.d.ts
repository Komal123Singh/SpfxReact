declare interface IReleaseDocumentFormWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ReleaseDocumentFormWebPartStrings' {
  const strings: IReleaseDocumentFormWebPartStrings;
  export = strings;
}
