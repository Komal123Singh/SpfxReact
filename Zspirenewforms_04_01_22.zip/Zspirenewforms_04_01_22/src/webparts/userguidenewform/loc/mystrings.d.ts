declare interface IUserguidenewformWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'UserguidenewformWebPartStrings' {
  const strings: IUserguidenewformWebPartStrings;
  export = strings;
}
