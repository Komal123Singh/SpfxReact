import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/fields';
import '@pnp/sp/attachments';
import "@pnp/sp/files";
import "@pnp/sp/folders";
declare const getEditFormDetails: (Id: any) => void;
export { getEditFormDetails };
declare const getcategorieslistitemDetails: () => void;
export { getcategorieslistitemDetails };
declare const getUserRoleslistitemDetails: () => void;
export { getUserRoleslistitemDetails };
declare const SaveForm: (subcategories: any, SearchTerms: any, AspireUserRoles: any, category: any, Section: any, Status: any, DocTitle: any, Synopsys: any, Attachments: any, Created: any, lncreated: any, lncreatedby: any, lnmodified: any, lnmodifiedby: any, Ehrev: any, EhEditor: any, Ehdate: any, year: any) => void;
export { SaveForm };
declare const updateForm: (uniqueId: any, subcategories: any, SearchTerms: any, AspireUserRoles: any, category: any, Section: any, Status: any, DocTitle: any, Synopsys: any, Attachments: any, EditAttachments: any, delattach: any, lnmodified: any, lnmodifiedby: any, Ehrev: any, EhEditor: any, Ehdate: any) => void;
export { updateForm };
//# sourceMappingURL=UserGuideAction.d.ts.map