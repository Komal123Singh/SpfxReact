import * as React from 'react';
import {PrimaryButton,createTheme,ThemeProvider} from '@fluentui/react';
import { IUserguidenewformProps } from './IUserguidenewformProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { sp } from "@pnp/sp";
import "@pnp/sp/webs"; 
import "@pnp/sp/site-users/web";
let exitLocation;
let absoluteUrl;
let uniqueId=0;
const myTheme = createTheme({
  palette: {
    themePrimary: '#23366f',
    themeLighterAlt: '#f3f4f9',
    themeLighter: '#cfd5e8',
    themeLight: '#a9b4d4',
    themeTertiary: '#6476a9',
    themeSecondary: '#344781',
    themeDarkAlt: '#203165',
    themeDark: '#1b2a55',
    themeDarker: '#141f3f',
    neutralLighterAlt: '#faf9f8',
    neutralLighter: '#f3f2f1',
    neutralLight: '#edebe9',
    neutralQuaternaryAlt: '#e1dfdd',
    neutralQuaternary: '#d0d0d0',
    neutralTertiaryAlt: '#c8c6c4',
    neutralTertiary: '#a19f9d',
    neutralSecondary: '#605e5c',
    neutralPrimaryAlt: '#3b3a39',
    neutralPrimary: '#323130',
    neutralDark: '#201f1e',
    black: '#000000',
    white: '#ffffff',
  }
});
export interface MyState {
  webpartContxt: WebPartContext;
  isEditor:boolean;
}
export default class Userguidenewform extends React.Component<IUserguidenewformProps,MyState> {
  constructor(prop) {
    super(prop);
    this.state = {
      webpartContxt: this.props.context,
      isEditor:false,
    };
    absoluteUrl= this.props.context.pageContext.site.absoluteUrl;
SPComponentLoader.loadCss(absoluteUrl+'/SiteAssets/StyleSheet/bootstrap.min.css');
SPComponentLoader.loadCss(absoluteUrl+'/SiteAssets/StyleSheet/suneditor.min.css');
SPComponentLoader.loadScript(absoluteUrl+'/SiteAssets/JS/jquery.min.js');
SPComponentLoader.loadScript(absoluteUrl+'/SiteAssets/JS/popper.min.js');
SPComponentLoader.loadScript(absoluteUrl+'/SiteAssets/JS/bootstrap.min.js');
  }
  componentDidMount() {
    try {

      const url = window.location.href;
      const urlObject = new URL(url);
      uniqueId = urlObject.searchParams.get('itemID') == '' || urlObject.searchParams.get('itemID') == null ? 0 : parseInt(urlObject.searchParams.get('itemID'));
      this.getLoggedUsersGroup();
    }
    catch (e) {
  
      console.log('componentDidMount: ' + e);
    } 
  }

  public userguidenewform = () => {
   
    try {
      exitLocation=this.props.exitLocation;
      window.open(exitLocation);
  
    } catch (e) {
  
      console.log('Exitform: ' + e);
    } 
  }
  getLoggedUsersGroup = async () => {
    try { 
    let LoggedUsersGroup = await sp.web.currentUser.groups();
    let permissionupdated=false;
    LoggedUsersGroup.map((groupItem) => {
     if(permissionupdated==false) {
      if (groupItem.Title == "USZ_ZSPIREHomePage_Access_Admins"||groupItem.Title == "USZ_ZSPIREHomePage_Admins"||groupItem.Title == "USZ_ZSPIREHomePage_Editors"
    ||groupItem.Title == "Z-SPIRE Homepage & User guide Owners"||groupItem.Title == "Z-SPIRE Homepage & User guide Members")
     {
      permissionupdated=true;
      this.setState({isEditor:true});
    } 
     }
    
    }) 
    
    } catch (e) {
    console.log('getLoggedUsersGroup' + e);
    }
    }
  public render(): React.ReactElement<IUserguidenewformProps> {
    return (
      <ThemeProvider theme={myTheme}>
        {this.state.isEditor==true?
      <div className='buttonCls mt-0'>
      <PrimaryButton className='ml-3 ' text='Create Document' onClick={this.userguidenewform}> </PrimaryButton>
      </div>:null}
      </ThemeProvider>
    );
  }
}
