import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface INewFormsProps {
  description: string;
  context: WebPartContext;
  ReleaseDocLocation:string;
  NewsArcticleLocation:string;
  FaqLocation:string;
  SystemAlertLocation:string;
  isUserguideform:boolean;
  exitLocation:string;
  isHomepageforms:boolean

}
