import { EventEmitter } from 'events';
import { Dispatcher } from 'simplr-flux';

let savedResult;
let EditFormDetails=[];
let CategorylistitemDetails=[];
class faqDocumentStore extends EventEmitter {

    constructor() {
        super();
    }
    storeChange(action) {
        switch (action.action.type) {
            case 'getEditFormDetailsType':
                {
                    debugger;
                    EditFormDetails = action.action.response;
                    this.emit('getEditFormDetailschange');
                    break;
                }
                case 'insertResultType':
                    {
                        savedResult = action.action.response;
                        this.emit('insertResultchange');
                        break;
                    }
                    case 'getcategorieslistitemDetailsType':
                {
                  
                    CategorylistitemDetails = action.action.response;
                    this.emit('getcategorieslistitemDetailschange');
                    break;
                }
            }
        }
        getEditFormDetailsStoreValue() {
            return EditFormDetails;
        }
        getInserResultStoreValue() {
            return savedResult;
        }
        getcategorieslistitemStoreValue() {
            return CategorylistitemDetails;
        }
}
let objFaqdocumentStore = new faqDocumentStore();

Dispatcher.register(objFaqdocumentStore.storeChange.bind(objFaqdocumentStore));

export default objFaqdocumentStore