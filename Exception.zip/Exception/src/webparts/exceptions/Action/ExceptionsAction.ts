import { Dispatcher } from 'simplr-flux';
import { sp } from '@pnp/sp';
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/fields';
import '@pnp/sp/attachments';
import '@pnp/sp/views';
import "@pnp/sp/site-users/web";
import { SPHttpClient } from '@microsoft/sp-http';
import "@pnp/sp/sputilities";
import { IEmailProperties } from "@pnp/sp/sputilities";
import { Attachments } from '@pnp/sp/attachments';
import { Item } from '@pnp/sp/items';

import { IItem } from "@pnp/sp/items";
import { IAttachmentInfo } from "@pnp/sp/attachments";
import { IAttachmentFileInfo } from "@pnp/sp/attachments";
//for Prod
// const exceptionList = "Exceptions";


//const exceptionLogList = "ExceptionLogList3";
const DefinitionsList = "Definitions";
const AdminList = "Admin";
const MakeModelList = "MakeModel";

//forLocal
//const exceptionList="exception7Exception";


// const exceptionList="Exception2021";
// const exceptionLogList="ExceptionLogList3";
// const DefinitionsList="exceptionDefinitions";
// const AdminList="exceptionAdmin";
// const MakeModelList="exceptionMakeModel";




// Get the edit click details
const getEditFormDetails = (Id,exceptionListName) => {
  sp.web.lists.getByTitle(exceptionListName).items.getById(Id).select('*', 'ApprovedBy/Title', 'CancelledBy/Title', 'DeniedBy/Title','ReqBy/EMail','UnderwriterAssgnd/EMail','AttachmentFiles/FileName').expand('ApprovedBy', 'CancelledBy', 'DeniedBy','ReqBy','UnderwriterAssgnd','AttachmentFiles').get().then(res => {
    Dispatcher.dispatch({ type: 'getEditFormDetailsType', response: res });
  }).catch(error => {
    console.log('getEditFormDetails ' + error);
  });
}
export { getEditFormDetails };

// Get Input Details

const saveForm = (exceptionlistName,ExceptType, ProdLine,  Customer, ContractDate, States,  DlrGroupNm, AcctNo, AcctNm,   DOB, CLITerm, Age, LifeCovg, AHCovg, InitCvg, MoBenefit, NewOrUsed, DedType, Contract, ModelYr, Make, IsMakeNew, Model, IsmodelNew,  Odometer, VSCTerm, VSCCovg,  UnderwriterComments, Criteria, UnderwriterAssgnd, ApprovedBy, ApprovedDate, ExpDate, Notes, uploadedRichTextFiles, RecordStatus, Processed, CancelledBy, CancelledDate, DeniedBy, DeniedDate, ReviewDate, AAOK, ReqBy, ReqDate,StatesScope,uploadedFileArray,tobeRemovedArray,arrPrevSavedFiles,Certificate,underWriterAssigndtext,requestedByText,approvedByText,deniedByText,cancelledByText, absoluteUrl) => {
  debugger;

  sp.web.lists.getByTitle(exceptionlistName).items.add({
    'ExceptType': ExceptType,
    'ProdLine': ProdLine,
    //commented for CR1
    // 'ExceptCatg': ExceptCatg,
    // 'ExceptSubCatg': ExceptSubCatg,
    'Customer': Customer,
    'ContractDate': ContractDate,
    'States': States,
    //commented for Scope
    // 'Scope': Scope,
    
    'DlrGroupNm': DlrGroupNm,
    'AcctNo': AcctNo,
    'AcctNm': AcctNm,
    //commented for CR1
    // 'Div': Div,
    // 'Rgn': Rgn,
    // 'Terr': Terr,
    // 'PgmYr': PgmYr,
    'DOB': DOB,
    'CLITerm': CLITerm,
    'Age': Age,
    'LifeCovg': LifeCovg,
    'AHCovg': AHCovg,
    'InitCvg': InitCvg,
    'MoBenefit': MoBenefit,
    'NewOrUsed': NewOrUsed,
    'DedType': DedType,
    'Contract': Contract,
    'ModelYr': ModelYr,
    'Make': Make,
    'Model': Model,
    //commented for CR1
    // 'Symbol': Symbol,
    'Odometer': Odometer,
    'VSCTerm': VSCTerm,
    'VSCCovg': VSCCovg,

    /* commented for CR1
    'CovgLevel': CovgLevel,
    'CalcRate': CalcRate,
    'RatingFactor': RatingFactor,
    'TermFactor': TermFactor,
    'CoverageFactor': CoverageFactor,
    'BaseRate': BaseRate,
    'OdometerFactor': OdometerFactor,
    'DedSurcharge': DedSurcharge,
    'AdminFee': AdminFee,
    'OtherFees': OtherFees,
    'OverRemit': OverRemit,
    */

    'UnderwriterComments': UnderwriterComments,
    'Criteria': Criteria,
    'UnderwriterAssgndId':  UnderwriterAssgnd ,
    'ApprovedById': ApprovedBy ,
    'ApprovedDate': ApprovedDate,
    'ExpDate': ExpDate,
    'Notes': uploadedRichTextFiles.length > 0 ? '' : Notes,
    'Status': RecordStatus,
    'Processed': Processed,
    'DeniedById':  DeniedBy ,
    'DeniedDate': DeniedDate,
    'CancelledById':  CancelledBy ,
    'CancelledDate': CancelledDate,
    'ReviewDate': ReviewDate,
    'AAOK': AAOK,
    'ReqById':  ReqBy ,
    'ReqDate': ReqDate,
    //commented for CR1
    // 'CommentInd':CommentInd,
    'StatesScope':StatesScope,
    'Certificate':Certificate,
    'UnderwriterAssgndText':underWriterAssigndtext,
    'ReqByText':requestedByText,
    'ApprovedByText':approvedByText,
    'DeniedByText':deniedByText,
    'CancelledByText':cancelledByText
   
  }).then(res => {
    if (IsMakeNew == true || IsmodelNew == true) {
      saveMakeModelNew(Make, Model);
    }
    // if(tobeRemovedArray.length>0)
    // {
    //   removeDeletedAttachments(res.data.ID,tobeRemovedArray,tobeRemovedArray)
    // }
    if(res !=null && uploadedFileArray.length>0|| tobeRemovedArray.length>0 || uploadedRichTextFiles.length>0)
    {
    addNewAttachments(exceptionlistName,res.data.ID,tobeRemovedArray,uploadedFileArray,uploadedRichTextFiles,arrPrevSavedFiles,Notes,absoluteUrl);

    }
    else
    {
      Dispatcher.dispatch({ type: 'insertResultType', response: res.data.ID });
    }
  //  debugger;
    // if (res != null && uploadedRichTextFiles.length > 0) {
    //  // insertAttachRichTextFile(res, uploadedRichTextFiles, 0, Notes);
    // }
    // else {
    //   if (res.data != undefined) {
    //     debugger;
    //     Dispatcher.dispatch({ type: 'insertResultType', response: res });
    //   }
    // }
  }).catch(error => {
    console.log('saveForm ' + error);
  });
}
export { saveForm };

// Update Existing Item
const updateForm = (exceptionlistName,uniqueId, ExceptType, ProdLine,  Customer, ContractDate, States,  DlrGroupNm, AcctNo, AcctNm,   DOB, CLITerm, Age, LifeCovg, AHCovg, InitCvg, MoBenefit, NewOrUsed, DedType, Contract, ModelYr, Make, IsMakeNew, Model, IsModelNew,  Odometer, VSCTerm, VSCCovg,  UnderwriterComments, Criteria, UnderwriterAssgnd, ApprovedBy, ApprovedDate, ExpDate, Notes, uploadedRichTextFiles, RecordStatus, Processed, CancelledBy, CancelledDate, DeniedBy, DeniedDate, ReviewDate, AAOK, ReqBy, ReqDate,StatesScope,uploadedFileArray,tobeRemovedFileArray,arrPrevSavedFiles,Certificate,underWriterAssigndtext, requestedByText,approvedByText,deniedByText,cancelledByText, absoluteUrl) => {

  //let isUploadAction=false;

  sp.web.lists.getByTitle(exceptionlistName).items.getById(uniqueId).update({
    'ExceptType': ExceptType,
    'ProdLine': ProdLine,
    //commented for CR1
    // 'ExceptCatg': ExceptCatg,
    // 'ExceptSubCatg': ExceptSubCatg,
    'Customer': Customer,
    'ContractDate': ContractDate,

    'States': States,
    //commented for CR1
    // 'Scope': Scope,
    'DlrGroupNm': DlrGroupNm,
    'AcctNo': AcctNo,
    'AcctNm': AcctNm,
    //commented for CR1
    // 'Div': Div,
    // 'Rgn': Rgn,
    // 'Terr': Terr,
    // 'PgmYr': PgmYr,
    'DOB': DOB,
    'CLITerm': CLITerm,
    'Age': Age,
    'LifeCovg': LifeCovg,
    'AHCovg': AHCovg,
    'InitCvg': InitCvg,
    'MoBenefit': MoBenefit,
    'NewOrUsed': NewOrUsed,
    'DedType': DedType,
    'Contract': Contract,
    'ModelYr': ModelYr,
    'Make': Make,
    'Model': Model,
    //commented for CR1
    // 'Symbol': Symbol,
    'Odometer': Odometer,
    'VSCTerm': VSCTerm,
    'VSCCovg': VSCCovg,
    /*commented for CR1
    'CovgLevel': CovgLevel,
    'CalcRate': CalcRate,
    'RatingFactor': RatingFactor,
    'TermFactor': TermFactor,
    'CoverageFactor': CoverageFactor,
    'BaseRate': BaseRate,
    'OdometerFactor': OdometerFactor,
    'DedSurcharge': DedSurcharge,
    'AdminFee': AdminFee,
    'OtherFees': OtherFees,
    'OverRemit': OverRemit,
    */
    'UnderwriterComments': UnderwriterComments,
    'Criteria': Criteria,
    'UnderwriterAssgndId':  UnderwriterAssgnd ,

    'ApprovedDate': ApprovedDate,
    'ExpDate': ExpDate,
    'Notes': uploadedRichTextFiles.length > 0 ? '' : Notes,
    'Status': RecordStatus,
    'Processed': Processed,
    'ApprovedById': ApprovedBy ,
    'DeniedById':  DeniedBy ,
    'DeniedDate': DeniedDate,
    'CancelledById':  CancelledBy ,
    'CancelledDate': CancelledDate,
    'ReviewDate': ReviewDate,
    'AAOK': AAOK,
    'ReqById':  ReqBy ,
    'ReqDate': ReqDate,
    //commented for CR1
    // 'CommentInd':CommentInd,
    'StatesScope':StatesScope,
    'Certificate':Certificate,
    'UnderwriterAssgndText':underWriterAssigndtext,
    'ReqByText':requestedByText,
    'ApprovedByText':approvedByText,
    'DeniedByText':deniedByText,
    'CancelledByText':cancelledByText
   
  }).then(res => {
    if (IsMakeNew == true || IsModelNew == true) {
      saveMakeModelNew(Make, Model);
    }
    if(tobeRemovedFileArray.length>0 || uploadedFileArray.length>0 || uploadedRichTextFiles.length>0)
    {
    addNewAttachments(exceptionlistName, uniqueId,tobeRemovedFileArray, uploadedFileArray,uploadedRichTextFiles,arrPrevSavedFiles,Notes,absoluteUrl);

    }
    else
    {
      Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
    }
    
  }).catch(error => {
    console.log('updateForm ' + error);
  });
}
export { updateForm };
 const deleteForm=(exceptionListName,uniqueId)=>{
  sp.web.lists.getByTitle(exceptionListName).items.getById(uniqueId).delete().then((res)=>{
    Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
  })
 }
 export {deleteForm}

const updateExceptionLog = (exceptionlogListName,CreatedBy,CreatedByText, CreatedDate, ExceptType, ProdLine,  StatesScope, AcctNo, AcctNm) => {
  debugger;
  sp.web.lists.getByTitle(exceptionlogListName).items.add({

    'CreatedById':  CreatedBy ,
    'CreatedByText':CreatedByText,
    'CreatedDate': CreatedDate,
    'ExceptType': ExceptType,
    'ProdLine': ProdLine,
    //commented for CR1
    // 'ExceptCatg': ExceptCatg,
    // 'ExceptSubCatg': ExceptSubCatg,
    'StatesScope': StatesScope,
    'AcctNo': AcctNo,
    'AcctNm': AcctNm
    //commented for CR1
    // 'Div': Div,
    // 'Rgn': Rgn,
    // 'Terr': Terr,
  }).then(res => {

    if (res.data != undefined) {
      Dispatcher.dispatch({ type: 'insertExceptionType', response: res.data.Id });
    }


  }).catch(error => {
    console.log('saveForm ' + error);
  });
}
export { updateExceptionLog };


const addNewAttachments=async (exceptionListName,res,tobeRemovedArray, uploadedFileArray,uploadedRichTextFiles,arrPrevSavedFiles,unSavedNotes,absoluteUrl)=>
{
  debugger;
  const item: IItem = sp.web.lists.getByTitle(exceptionListName).items.getById(res);
  
  //const info2: IAttachmentInfo = await item.attachmentFiles.getByName(uploadedFileArray[0])();
if(item!=null)
{
  let fileInfos: IAttachmentFileInfo[] = []; 
  let AllfileNames=null;
  if(uploadedFileArray!=null && uploadedFileArray!=undefined && uploadedFileArray.length>0)
  {
  uploadedFileArray.forEach(element => {
    fileInfos.push({
      name: element.name,
      content: element
  });
 
  if(AllfileNames!=null && AllfileNames!='')
  {
  AllfileNames+=";"+element.name;
  }
  else{
    AllfileNames=element.name;
  }
  });
}
if(arrPrevSavedFiles!=null && arrPrevSavedFiles!=undefined && arrPrevSavedFiles.length>0)
{
  arrPrevSavedFiles.forEach(element => {
    if(AllfileNames!=null && AllfileNames!='')
  {
  AllfileNames+=";"+element.FileName;
  }
  else{
   AllfileNames=element.FileName;
  }
  });
}

  let allRichFiles=[];
  if(uploadedRichTextFiles!=null && uploadedRichTextFiles!=undefined && uploadedRichTextFiles.length>0)
  {
    allRichFiles = uploadedRichTextFiles.map(a => a.imgFile);
  }
  let fileInfosRich: IAttachmentFileInfo[] = []; 
  let serializeNotes=null;
  if(allRichFiles!=null && allRichFiles!=undefined && allRichFiles.length>0)
  {
   
  for (let f of allRichFiles) {
    
    // fileRead.onloadend = (e) => {
      fileInfosRich.push({
        name: f.name,
        content: f,
      });
   // }
  }
  let Notes =unSavedNotes;
  let domparser = new DOMParser();
  let  parsedNotes = domparser.parseFromString(Notes,'text/html');;
  
   

    if(parsedNotes!=null && parsedNotes!=undefined)
    {
     
     parsedNotes.querySelectorAll('img').forEach((img) => {allRichFiles.forEach((fData) => {
   
      if(img.getAttribute('data-file-name') ===fData['name'])
      {
       let newImageUrl=absoluteUrl+"/Lists/"+exceptionListName+"/Attachments/"+res+"/"+fData['name'];
       img.setAttribute('src',newImageUrl) 
     }
     else
     {
   
     }
   })
   })

  }
     let s = new XMLSerializer();

      serializeNotes = s.serializeToString(parsedNotes);
}
  //if(tobeRemovedArray.length>0)
  {
    if(tobeRemovedArray.length>0)
    {

    }
    else{
      tobeRemovedArray=[];
    }
  await item.attachmentFiles.deleteMultiple(...tobeRemovedArray).then((el)=>{
  console.log("deleteting complete Proceeding for addition");
   item.attachmentFiles.addMultiple(fileInfos).then(v => {
    //updateListColumns(res,uploadedFileArray);
    console.log("Added files Uploaded");
    item.update({
      UploadedFiles:AllfileNames
    }).then(allNames=>{
      console.log('File upload updated and modified')
     
      item.attachmentFiles.addMultiple(fileInfosRich).then(()=>{
        console.log("Rich text upoloaded")
        if(serializeNotes!=null)
        {

          item.update({
            Notes:serializeNotes
          }).then(()=>{ 
          console.log("Notes filed upldated")
          Dispatcher.dispatch({ type: 'insertResultType', response: res }
          )
        })
        }
        else{
          console.log("No note updation required")
          Dispatcher.dispatch({ type: 'insertResultType', response: res })
        }
       
     
      })
    //}
      
    });
  });
})
}

}
} 



const updateListColumns=(res,uploadedFileArray)=>{
  // sp.web.lists.getByTitle(exceptionList).items.getById(res.ID).update({

  //   'Notes': serializeNotes,
  // })
}
export {updateListColumns}


const saveMakeModelNew = async (make, model) => {

  const list = await sp.web.lists.getByTitle(MakeModelList);
  // cons result2 = await list.views.getByTitle("StateDef").select("ViewQuery")();
  //console.log(result2.ViewQuery);
  let xml = `<View><Query><Where><Eq><FieldRef Name="Make"/><Value Type="Text">${make}</Value></Eq></Where></Query></View>`
 
  let items = await list.getItemsByCAMLQuery({ 'ViewXml': xml });
  if (items != null && items.length > 0  ) {
    if(items[0].Model!=null)
    {
    
    let allModel= items[0].Model;
    let  allModelArray = allModel.split(';');
    if(allModelArray!=null && allModelArray.length>0)
    {
  
    let isModelPresent:boolean=false;
    allModelArray.forEach(element => {
        if(element==model)
        {
          isModelPresent=true;
        }
       });
       if(isModelPresent)
       {
         console.log("Log action true");
          //model present
       }
       else{
         if(allModel!=null && allModel.trim()!='')
         {
          UpdateMakeModel(make, allModel +';'+model,items[0].ID); 
        }
        else{
          UpdateMakeModel(make, model,items[0].ID);
        }
       }
   
      }
    else{
      UpdateMakeModel(make, model,items[0].ID);
    }
  }
  else{
    UpdateMakeModel(make, model,items[0].ID);
  }
  }
  else {
    createMakeModel(make, model);
    console.log("MakeModel Log" + "Item already present");
  }
}
export { saveMakeModelNew };


const getAllAdminDetails = () => {

  sp.web.lists.getByTitle(AdminList).items.select('*',
    'Underwriters/ID', 'Underwriters/Title','Underwriters/EMail', 'AcctEmail/EMail', 'Dlremail/EMail', 'UndEmail/EMail').
    expand('Underwriters', 'AcctEmail', 'Dlremail', 'UndEmail').get().then(res => {


      Dispatcher.dispatch({ type: 'getAdminDetailsType', response: res });
    }).catch(error => {
      console.log('getDetails  error ' + error);
    });
}
export { getAllAdminDetails };

const getDefSubCatgDetails = async () => {
  try {
    const list = sp.web.lists.getByTitle(DefinitionsList);
    const result2 = await list.views.getByTitle("SubCatgDef").select("ViewQuery")();
    console.log("Logging ViewQuery" + result2.ViewQuery);
    let xml = '<View><Query>' + result2.ViewQuery + '</Query></View>';
    let items = await list.getItemsByCAMLQuery({ 'ViewXml': xml });
    console.log(items);
    Dispatcher.dispatch({ type: 'getDefSubCatgDetailsType', response: items });
  }
  catch (ex) {
    console.log("getDefSubCatgDetails error " + ex);
  }
}
export { getDefSubCatgDetails };
const getListMakeDetails = async () => {

  sp.web.lists.getByTitle(MakeModelList).items.select('*',).getAll().then(res => {
    Dispatcher.dispatch({ type: 'getListMakeDetailsType', response: res });
  }).catch(error => {
    console.log('getListMakeDetails error ' + error);
  });
}

export { getListMakeDetails };
const getDefScopeDetails = async () => {

  try {
    const list = await sp.web.lists.getByTitle(DefinitionsList);
    const result2 = await list.views.getByTitle("StateDef").select("ViewQuery")();
    console.log(result2.ViewQuery);
    let xml = '<View><Query>' + result2.ViewQuery + '</Query></View>';
    let items = await list.getItemsByCAMLQuery({ 'ViewXml': xml });
    //console.log(items);
    Dispatcher.dispatch({ type: 'getDefScopeDetailsType', response: items });
  }
  catch (ex) {
    console.log("getDefScopeDetails error " + ex);
  }
}
export { getDefScopeDetails };
const getUserGroupDetails = async () => {

  try {
    const groups = await sp.web.currentUser.groups();;


    Dispatcher.dispatch({ type: 'getUserGroupDetailsType', response: groups });
  }
  catch (ex) {
    console.log("getUserGroupDetails error " + ex);
  }
}
export { getUserGroupDetails };
const getUserInfoDetails = async () => {

  try {
    const groups = await sp.web.currentUser();;


    Dispatcher.dispatch({ type: 'getUserInfoDetailsType', response: groups });
  }
  catch (ex) {
    console.log("getUserInfoDetails error " + ex);
  }
}
export { getUserInfoDetails };


const getAccountNumberDetails = (AccountNumber,AllListNames) => {
 
  let AccountNmberArr=[];
  let ExceptionListsToQuery=AllListNames;
  //let ExceptionListsToQuery:string[]=["ExceptionList1","ExceptionList2","ExceptionList3","ExceptionList4","ExceptionList5"];
  
  const batch=sp.web.createBatch();
  
  ExceptionListsToQuery.forEach((element)=>{
    if(element!=null && element!=undefined && element!='')
    {
    sp.web.lists.getByTitle(element.key).items.inBatch(batch).filter(`AcctNo eq '${AccountNumber}'`).get().then((res)=>{console.log(res);
      if(res!= null && res !=undefined && res.length>0)
      {
        
       AccountNmberArr.push(res);
      }
       
     })
    }
  }
  ) 
 
   
  
 batch.execute().then((data)=>{console.log(data);
  Dispatcher.dispatch({ type: 'getAccountNumberDetailsType', response: AccountNmberArr });
});
}

export { getAccountNumberDetails };




const SendEmail = async (ToEMail, CCEmail, BCCEmail, Subject, Body) => {
  debugger;
 
  const emailProps: IEmailProperties = {
   
   From:'F&I Exception',
    
    To:ToEMail,
    CC: CCEmail,
    BCC: BCCEmail,
    Subject: Subject,
    //Body: "<a href='"+Body+"'>Click here</a>"+"<div>"+strToEmail+"</div>",
    Body: "<a href='"+Body+"'>Click to view the record</a>",
    AdditionalHeaders: {
      "content-type": "text/html"
    }

  };

  await sp.utility.sendEmail(emailProps).then(
    (results) => {
      console.log(results);
      Dispatcher.dispatch({ type: 'sendEmailType', response: results });
    }
  ).catch(error => {
    console.log('sendEmailAction error ' + error);
  });
}
export { SendEmail };

function createMakeModel(make: any, model: any) {
  sp.web.lists.getByTitle(MakeModelList).items.add({
    "Make": make,
    "Model": model
  }).then(res => {
    console.log("MAke Model created");
  }
  ).catch(err => {
    console.log("NewMakeModel " + err);
  });
}
function UpdateMakeModel(make: any, model: any,listItemID:any) {
  sp.web.lists.getByTitle(MakeModelList).items.getById(listItemID).update({
    "Make": make,
    "Model": model
  }).then(res => {
    console.log("Make Model created");
  }
  ).catch(err => {
    console.log("NewMakeModel " + err);
  });
}