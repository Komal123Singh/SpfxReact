import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IExceptionsWebPartProps {
    description: string;
    logo: string;
    bannerBackground: string;
    bodyBackground: string;
    exitLink: string;
}
export default class ExceptionsWebPart extends BaseClientSideWebPart<IExceptionsWebPartProps> {
    onInit(): Promise<void>;
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=ExceptionsWebPart.d.ts.map