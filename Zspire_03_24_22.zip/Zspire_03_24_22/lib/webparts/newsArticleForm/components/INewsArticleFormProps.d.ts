import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface INewsArticleFormProps {
    description: string;
    context: WebPartContext;
    logo: string;
    exitLocation: string;
    Label: string;
}
//# sourceMappingURL=INewsArticleFormProps.d.ts.map