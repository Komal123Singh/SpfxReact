export interface IFirstJsProps {
  description: string;
}
