import * as React from 'react';
import { MyState } from './SystemAlertForm';
export default class ViewSystemAlert extends React.Component<MyState> {
    bindAttachmentFileNames(): any;
    render(): JSX.Element;
}
//# sourceMappingURL=ViewSystemAlert.d.ts.map