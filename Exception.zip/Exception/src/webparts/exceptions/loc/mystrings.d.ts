declare interface IExceptionsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ExceptionsWebPartStrings' {
  const strings: IExceptionsWebPartStrings;
  export = strings;
}
