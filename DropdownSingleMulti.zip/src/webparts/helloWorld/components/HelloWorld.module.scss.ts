/* tslint:disable */
require("./HelloWorld.module.css");
const styles = {
  helloWorld: 'helloWorld_6e6e1386',
  container: 'container_6e6e1386',
  row: 'row_6e6e1386',
  column: 'column_6e6e1386',
  'ms-Grid': 'ms-Grid_6e6e1386',
  title: 'title_6e6e1386',
  subTitle: 'subTitle_6e6e1386',
  description: 'description_6e6e1386',
  button: 'button_6e6e1386',
  label: 'label_6e6e1386'
};

export default styles;
/* tslint:enable */