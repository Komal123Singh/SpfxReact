import { EventEmitter } from 'events';
declare class NewsArticleStore extends EventEmitter {
    constructor();
    storeChange(action: any): void;
    getEditClickStoreValue(): any[];
    getInserResultStoreValue(): any;
}
declare let objNewsArticleStore: NewsArticleStore;
export default objNewsArticleStore;
//# sourceMappingURL=NewsArticleStore.d.ts.map