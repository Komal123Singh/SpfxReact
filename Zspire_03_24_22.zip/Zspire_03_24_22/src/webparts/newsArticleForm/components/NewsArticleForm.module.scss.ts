/* tslint:disable */
require("./NewsArticleForm.module.css");
const styles = {
  userGuideForm: 'userGuideForm_54522013',
  container: 'container_54522013',
  row: 'row_54522013',
  column: 'column_54522013',
  'ms-Grid': 'ms-Grid_54522013',
  title: 'title_54522013',
  subTitle: 'subTitle_54522013',
  description: 'description_54522013',
  button: 'button_54522013',
  label: 'label_54522013'
};

export default styles;
/* tslint:enable */