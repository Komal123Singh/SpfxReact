declare interface ICrudWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'CrudWebPartStrings' {
  const strings: ICrudWebPartStrings;
  export = strings;
}
