import { WebPartContext } from '@microsoft/sp-webpart-base';
import { MessageBarType } from 'office-ui-fabric-react';

export interface INewsArticleFormProps {
  description: string;
  context: WebPartContext;
  logo : string;
  exitLocation:string; 
  Label:string;
  
  
}
