declare interface IFirstJsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'FirstJsWebPartStrings' {
  const strings: IFirstJsWebPartStrings;
  export = strings;
}
