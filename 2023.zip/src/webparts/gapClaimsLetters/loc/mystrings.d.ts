declare interface IGapClaimsLettersWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  AppLocalEnvironmentSharePoint: string;
  AppLocalEnvironmentTeams: string;
  AppSharePointEnvironment: string;
  AppTeamsTabEnvironment: string;
  LogoUrlFieldLabel:string;

  ExitUrlFieldLabel: string;
}

declare module 'GapClaimsLettersWebPartStrings' {
  const strings: IGapClaimsLettersWebPartStrings;
  export = strings;
}
