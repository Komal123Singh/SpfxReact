import * as React from 'react';
import { MyState } from './FaqDocumentForm';
export default class ViewfaqDocumentForm extends React.Component<MyState> {
    bindAttachmentFileNames(): any;
    render(): JSX.Element;
}
//# sourceMappingURL=ViewfaqDocumentForm.d.ts.map