import * as React from 'react';
import {Label,Link,IconButton} from '@fluentui/react';
import { SecurityTrimmedControl, PermissionLevel, } from '@pnp/spfx-controls-react/lib/SecurityTrimmedControl';
import { SPPermission } from '@microsoft/sp-page-context';
import { IGapClaimsLettersStates } from './IGapClaimsLettersStates'; 
import * as  moment from "moment";
import 'suneditor/dist/css/suneditor.min.css';
import SunEditor from 'suneditor-react';
import 'suneditor/dist/css/suneditor.min.css';
import { sp } from "@pnp/sp";
import "@pnp/sp/site-users/web";

// const htmlToFormattedText = require("html-to-formatted-text");
let deleteFiles = [];


export default class ViewGapClaimsLetters extends React.Component<IGapClaimsLettersStates,{}> {

// bindAttachmentFileNames() {
// try {
//    var d = new Date;
// var ampm = d.getHours() >= 12 ? ' PM ' : ' AM ';
// let dformat = [d.getMonth()+1,
// d.getDate(),
// d.getFullYear()].join('-')+' '+
// [d.getHours(),
// d.getMinutes(),
// d.getSeconds()].join(' ')+ampm;
// return this.props.FormAttachmentNames.map((item) => {
//   let filecount=1;
//   let  attachmentfile_name:any="CLAIM}U}" +this.props.GAPAgreeNumA + "}U}GAP10}I}" +dformat+"-" +((filecount+1)+"000")+"-"+"ATTACHMENT"+(filecount+"000")+"."

//  if (item.FileName.indexOf(attachmentfile_name) != -1) {
//  let fileName = item.FileName.replace(attachmentfile_name, '');
// return (
// <div><span><Link target='_blank' href={item.ServerRelativePath.DecodedUrl}>{attachmentfile_name+fileName}</Link><IconButton className='mt-1' iconProps={{ iconName: 'CalculatorMultiply' }} title='Delete' ariaLabel='Delete' onClick={this.addDeleteFiles.bind(this,attachmentfile_name+ fileName)} /></span></div>
// )
// }});
// }
// catch (e) {
// console.log('bindAttachmentFileNames ' + e);
// }
// }

//#region Added code for encodeURI Componet

private SplitAndEncodeURIComponent = (value: string = '') => {
  let modifiedValue: string = value;
  let splitBySlashValue = value.split("/");
  let lastSlashtSplitValue = splitBySlashValue.pop();
  let encodeFileName = encodeURIComponent(lastSlashtSplitValue);
  let restSlashValue = splitBySlashValue.join("/")
  modifiedValue = `${restSlashValue}/${encodeFileName}`;
  return modifiedValue;
}

//#endregion Added code for encodeURI Componet

public getEditFormBodyDetails = (uniqueId) => {
  sp.web.lists
    .getByTitle('Letters')
    .items.getById(uniqueId)
    .select("Body",  "AttachmentFiles")
    .expand("AttachmentFiles")
    .get()
    .then((res) => {
      let fileLevlInfos = [];
      let item = sp.web.lists.getByTitle('Letters').items.getById(uniqueId);
      item.attachmentFiles.get().then((fileData) => {
        let Body = res.Body;
        
        let domparser = new DOMParser();
        let parsedBody = domparser.parseFromString(Body, "text/html");
       
        let allImgaes = parsedBody.querySelectorAll("img");
       
        if (allImgaes.length != 0) {
          allImgaes.forEach((img) => {
            let iName = img.getAttribute("src");
            let suB = img.getAttribute("src");
            if (suB != null) {
              let val = suB.indexOf("@");
              let sval = suB.indexOf(":");
              let fname = suB.substring(sval + 1, val);

              fileData.forEach((fData) => {
                if (fname === fData["FileName"]) {
                  img.setAttribute("src", fData["ServerRelativeUrl"]);
                }
              });
              fileLevlInfos.indexOf(iName)
                ? console.log("exisitng file")
                : fileLevlInfos.push(iName);
            }
          });
        }
       

        let s = new XMLSerializer();
        let serializeBody = s.serializeToString(parsedBody);
        //console.log("Parsed", parsedBody);

        sp.web.lists
          .getByTitle('Letters')
          .items.getById(uniqueId)
          .update({
            Body: serializeBody,
            
          })
          .then((updatedres) => {
            if (updatedres.data != undefined) {
              console.log("updated body");
            }
          })
          .catch((error) => {
            console.log("updatebodyRichItem " + error);
          });
      });
     
    })
    .catch((error) => {
      console.log("getEditFormBodyDetails " + error);
    });
}
public addDeleteFiles = (fileName) => {
try {
  /***comented for deleting files */
  
// let tempAttachFileName = this.props.FormAttachmentNames;
// var index = tempAttachFileName.map(p => p.FileName).indexOf('FormAtach_' + fileName);
// tempAttachFileName.splice(index, 1);
// deleteFiles.push('FormAtach_' + fileName);
// this.setState({ FormAttachmentNames: tempAttachFileName });
}
catch (e) {
console.log('addDeleteFiles ' + e);
}
}

// functionname =(htmlToFormattedText)=> {
  
// let domparser = new DOMParser();
// let s = new XMLSerializer();
// let parsedBody= domparser.parseFromString(this.props.Body,'text/html');
// parsedBody.querySelectorAll('[class*=se-component]').
// forEach((ext) => {ext.removeAttribute('class');});
// let serializeBody= s.serializeToString(parsedBody);

//     return htmlToFormattedText(serializeBody);
//     // return htmlToFormattedText(serializeBody.replace(regex,''));
//  };


public render() {
return (
<div>


<div className='border p-3 mt-1'>
<div className='row'>
<div className='col-md-6'>
{this.props.modalclose}
 <Label className='font-weight-bold w-100'> GAP Agreement #</Label><span>{this.props.GAPAgreeNum}</span>
</div>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Gap Adjuster</Label><span>{this.props.VSCAdj}</span>
</div>
</div>
<div className='row'>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Claimant Last Name</Label><span>{this.props.InsuredLastName}</span>
</div>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> First Name</Label><span>{this.props.InsuredFirstName}</span>
</div>
</div>
{/*<div className='row'>
 <div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Claimant Address</Label><span>{this.props.InsuredStreetAddress}</span>
</div>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Claimant City</Label><span>{this.props.InsuredCity}</span>
</div>
</div>
<div className='row'>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Claimant State</Label><span>{this.props.InsuredState}</span>
</div>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Claimant Zip</Label><span>{this.props.InsZip}</span>
</div>
</div> */}
<div className='row'>
<div className='col-md-6'>
<Label className='font-weight-bold w-25'>Reassign To </Label>
{this.props.TempAdjUserItems.length > 0 ? this.props.TempAdjUserItems.map((team) =>
<span>{team}</span>
):null}
</div>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Mark Delete</Label><span>{this.props.mrk_delete}</span>
</div>

</div>
</div>

<div className='border p-3 mt-1'>
<div>

{this.props.SendToDefaultItems.includes(null) == true || this.props.SendToDefaultItems.includes(undefined) == true || this.props.SendToDefaultItems.includes("")==true ||((this.props.SendToText!=null || this.props.SendToText!=undefined || this.props.SendToText!="") && this.props.SendToDefaultItems.includes("") != true)?
<div className='row'>
<div className='col-md-6'><Label>To</Label></div>
  <div className='w-50'><Label>{this.props.SendToText}</Label></div>

</div>
:
<div className='row'>
<div className='col-md-6'><Label>To</Label></div>
<div className='w-50'><Label>{this.props.SendToDefaultItems.length > 0 ?
 this.props.SendToDefaultItems.map((team, index) =>
<span>{team}{index!=this.props.SendToDefaultItems.length-1?',':null}</span>):null}</Label></div>

</div>}

</div>








{/* <div className='row'>
<div className='col-md-6'><Label className='font-weight-bold w-25'> To </Label></div>
<div className='w-50'>

{this.props.SendToUserItems.length > 0 ? this.props.SendToUserItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
</div> */}
<div>

{this.props.CopyToDefaultItems.includes(null) == true || this.props.CopyToDefaultItems.includes(undefined) == true || this.props.CopyToDefaultItems.includes("")==true ||((this.props.CopyToText!=null || this.props.CopyToText!=undefined || this.props.CopyToText!="") && this.props.CopyToDefaultItems.includes("") != true)?
<div className='row'>
<div className='col-md-6'><Label>Copy To:</Label></div>
  <div className='w-50'><Label>{this.props.CopyToText}</Label></div>
</div>
:
<div className='row'>
<div className='col-md-6'><Label> Copy To:</Label></div>
<div className='w-50'><Label>{this.props.CopyToDefaultItems.length > 0 ? this.props.CopyToDefaultItems.map((team, index) =>
<span>{team}{index!=this.props.CopyToDefaultItems.length-1?',':null}</span>):null}</Label></div>

</div>}

</div>
{/* <div className='row'>
<div className='col-md-6'><Label className='font-weight-bold w-25'> Copy To </Label></div>
<div className='w-50'>
{this.props.CopyToUserItems.length > 0 ? this.props.CopyToUserItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
</div> */}



<div>

{this.props.BlindCopyToDefaultItems.includes(null) == true || this.props.BlindCopyToDefaultItems.includes(undefined) == true || this.props.BlindCopyToDefaultItems.includes("")==true ||((this.props.BlindCopyToText!=null || this.props.BlindCopyToText!=undefined || this.props.BlindCopyToText!="") && this.props.BlindCopyToDefaultItems.includes("") != true)?
<div className='row'>
<div className='col-md-6'><Label>Blind Copy To:</Label></div>
  <div className='w-50'><Label>{this.props.BlindCopyToText}</Label></div>

</div>
:
<div className='row'>
<div className='col-md-6'><Label>Blind Copy To:</Label></div>
<div className='w-50'><Label>{this.props.BlindCopyToDefaultItems.length > 0 ? this.props.BlindCopyToDefaultItems.map((team, index) =>
<span>{team}{index!=this.props.BlindCopyToDefaultItems.length-1?', ':null}</span>):null}</Label></div>

</div>}

</div>
{/* <div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold w-25'> Blind Copy To </Label>
{this.props.BlindCopyToUserItems.length > 0 ? this.props.BlindCopyToUserItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
</div> */}

<div>

{this.props.FromDefaultItems.includes(null) == true || this.props.FromDefaultItems.includes(undefined) == true || this.props.FromDefaultItems.includes("")==true?
<div className='row'>
<div className='col-md-6'><Label>From:</Label></div>
  <div className='w-50'>{this.props.FromText}</div>
</div>
:
<div className='row'>
<div className='col-md-6'><Label>From:</Label></div>
<div className='w-50'><Label>{this.props.FromDefaultItems.length > 0 ? this.props.FromDefaultItems.map((team, index) =>
<span>{team}{index!=this.props.FromDefaultItems.length-1?' , ':null}</span>):null}</Label></div>

</div>}

</div>
{/* <div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold w-25'> From </Label>
{this.props.FromUserItems.length > 0 ? this.props.FromUserItems.map((team, index) =>
<span>{team}</span>
):null}

</div>
</div> */}
<div className='row'>
<div className='col-md-6'><Label className='font-weight w-25'> Date</Label></div>
   {/* <Label className='font-weight-bold w-25'> Date</Label><span>{this.props.Date!=undefined&&this.props.Date!=''&&this.props.Date!=null?this.props.Date.toUTCString():null}</span> */}
<div className='w-50'><Label><span>{this.props.Date!=undefined&&this.props.Date!=''&&this.props.Date!=null?moment(this.props.Date).format('L hh:mm A'):null}</span>
</Label>

</div>
</div>
<div className='row'>
<div className='col-md-6'> <Label className='font-weight w-25'> Subject </Label></div>
<div className='w-50'><span>{this.props.Title}</span></div>
</div>
</div>

<div className='border p-3 mt-1'>
<div className='row'>
<div className='col-md-12'>
{/* <SunEditor enableToolbar={false} showToolbar={false}  lang='en'
setContents={this.props.Body} autoFocus={false} disable={true} setOptions={{mode:"classic",minHeight: '170px'}}

/> */}
 {/* <Label className='font-weight-bold w-25'>Message</Label><div>this.functionname(htmlToFormattedText)</div> */}
 {/* <Label className='font-weight-bold w-25'>Message</Label><span><div dangerouslySetInnerHTML={{ __html: this.props.Body }}></div></span>*/}
 
 {/* <SunEditor enableToolbar={false} lang='en' placeholder='Please type here...'
                     autoFocus={true} disable={true} setOptions={{
                      minHeight: '180px'
                    }}setContents={this.props.Body}
                     /> */}
 <Label className='font-weight-bold w-25'>Message</Label><span><div dangerouslySetInnerHTML={{ __html: this.props.Body }}></div></span> 

</div>
</div>
</div>

<div className='border p-3 mt-2'>
<div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold'> Attachments </Label>
<div>
{/* {this.bindAttachmentFileNames()} */}
<div className="row">
                  <div className="col-md-12">
                    {this.props.FormAttachmentNames !== undefined &&
                    this.props.FormAttachmentNames !== null
                      ? this.props.FormAttachmentNames.map((item) => (
                         
                         <div><span>
                            <Link
                              key={item.FileName}
                              onClick={() =>
                                window.open(
                                  // item.ServerRelativePath.DecodedUrl,
                                  this.SplitAndEncodeURIComponent(item.ServerRelativeUrl),
                                  "_blank"
                                )
                              }
                            >
                            {item.FileName}
                            </Link>
                            {/* {uniqueId == 0 ? null : (
                              <IconButton
                                className="mt-1"
                                iconProps={{ iconName: "Download" }}
                                title="Download"
                                ariaLabel="Download"
                                onClick={() =>
                                  (window.location.href =
                                    this.props.context.pageContext.web
                                      .absoluteUrl +
                                    "/_layouts/download.aspx?sourceurl=" +
                                    item.ServerRelativePath.DecodedUrl)
                                }
                              />
                            )} */}

                            {/* <IconButton
                              className="mt-1"
                             iconProps={{ iconName: "Delete" }}
                              title="Delete"
                              ariaLabel="Delete"
                              onClick={() => this.addDeleteFiles(item.FileName)}
                            /> */}
                            <IconButton
                              className="mt-1" style={{verticalAlign:"bottom"}}
                             iconProps={{ iconName: "Download" }}
                              title="Download"
                              ariaLabel="Download"
                              onClick={() =>
                                (window.location.href =
                                  this.props.webpartContxt.pageContext.web
                                    .absoluteUrl +
                                  "/_layouts/download.aspx?sourceurl=" +
                                 this.SplitAndEncodeURIComponent(item.ServerRelativeUrl))
                              }
                            />
                          </span></div>
                        ))
                      : null}
                  </div>
                </div>

</div>
</div>
</div>
</div>
<div className='border p-3 mt-1'>
<div className='row'>
<div className='col-md-6'> <Label className='font-weight w-25'>Type:</Label></div>
<div className='w-50'><span>{this.props.NotesType}</span></div>
</div>
</div>
</div>

);
}
}