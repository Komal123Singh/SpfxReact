import * as React from 'react';
import styles from './HelloWorld.module.scss';
import { IHelloWorldProps } from './IHelloWorldProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { Button,autobind} from 'office-ui-fabric-react';
import { PeoplePicker ,PrincipalType} from "@pnp/spfx-controls-react/lib/PeoplePicker"; 
import { sp } from '@pnp/sp/presets/all';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";

export interface IHelloWorldState{
  
  // message:string;
  // messageType:boolean;
  // showMessageBar:any;
  // title:string;
  User:any[];
  
}

export default class HelloWorld extends React.Component<IHelloWorldProps,IHelloWorldState, {}> {
  constructor(props:IHelloWorldProps){
    super(props);
    this.Fetch=this.Fetch.bind(this);
    this.getPeoplePicker=this.getPeoplePicker.bind(this);
    this.state={User:[]}
      
  }
  private getPeoplePicker(items: any[]) {  
    console.log('Items:', items);  
    this.setState({ User: items });  
  } 
  private Fetch(): void{  
     var peoplepicarray = [];  
     for (let i = 0; i < this.state.User.length; i++) {  
       peoplepicarray.push(this.state.User[i]["id"]);  
     }  
     var Clientdata ={  
       "User1Id": { "results": peoplepicarray }  
     }; 
     console.log(peoplepicarray); 
     sp.web.lists.getByTitle("Spfxlist").items.add(Clientdata).then(i => {  
       alert("sucess");  
     });  
   }  
  
  
  public render(): React.ReactElement<IHelloWorldProps> {
    return (
      <div className={ styles.helloWorld }>
      <div>
       <PeoplePicker context={this.props.context}
        titleText={"User1"}
        placeholder="Enter Your Name"
        personSelectionLimit={1}
        onChange={this.getPeoplePicker}
        ensureUser={true}
        showtooltip={true} 
          disabled={false}  
          showHiddenInUI={false}  
        principalTypes={[PrincipalType.User]}  
        >
        </PeoplePicker>
        <Button text={"Submitt"} onClick={this.Fetch}></Button>
        {/* <input type="file"></input> */}
        
      </div>
      </div>
    );
  }
}

