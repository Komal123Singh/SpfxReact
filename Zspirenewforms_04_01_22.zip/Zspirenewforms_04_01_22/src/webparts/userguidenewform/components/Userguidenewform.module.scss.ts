/* tslint:disable */
require("./Userguidenewform.module.css");
const styles = {
  userguidenewform: 'userguidenewform_e2057ed5',
  container: 'container_e2057ed5',
  row: 'row_e2057ed5',
  column: 'column_e2057ed5',
  'ms-Grid': 'ms-Grid_e2057ed5',
  title: 'title_e2057ed5',
  subTitle: 'subTitle_e2057ed5',
  description: 'description_e2057ed5',
  button: 'button_e2057ed5',
  label: 'label_e2057ed5'
};

export default styles;
/* tslint:enable */