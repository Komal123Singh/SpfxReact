export interface IValidationsProblemStates {
    // DocConfigValues: any;
    DocTypeChoice: any;
    PriorityChoice: any;
    SeverityChoice: any;
    JurisdictionChoice: any;
    ProjectAreaChoice: any;
    EnvironmentTypeChoice: any;
    createdby:any;
    createdon:any
    VendorChoice:any;
    RootCauseChoice:any;
    Date: any;
    FormNoteID:string;
    FormID:string;
    AbsoluteUrl:string,
    ResponseData:any,
    ProjectAreaLabel: string;
    UpdateKeywords:any;
    UpdateEnvType:any;
    UpdateRootCause:any;
    UpdateVendors:any;
    ishide:boolean;
    isModalClose:boolean;
    docnumber:number;
    TitleValidations:string;
    DocTypeValidations:string;
    SeverityValidations:string;
    KeywordsValidations:string;
    ProjectAreaValidations:string;
    EnvTypeValidations:string;
    TestCaseValidations:string;
    EstCompDateValidations:string;
    isModaldialogClose:boolean;
    isvalidRecord:boolean;
    isSavedHidden:boolean;
    //Business Objects Starts //
FormAttachment: any;
FormAttachmentNames: any;

ActivePlayers : any;
ActivePlayersDefaultItems:string[];
ActivePlayersUserItems:string[];
ApplicationArea : string;
ApprovedBy : any;
ApprovedByDefaultItems:string[];
ApprovedByUserItems:string[];
ApprovedDt:any;
AssignedTo : any;
AssignedToDefaultItems:string[];
AssignedToUserItems:string[];
AssignedDt:any,
Comments : string;
CreateDt : any;
CreateTime : string;
DateResolved : any;
DocNumber : string;
DocType :string;
EditHistoryFields : string;
EnvType : string;
EmailIdList:string[];
EstCompDt : any;
IONum : string;
Keywords : string;     
PhaseDetect : string;
PhaseIntro : string;
Priority : string;
Probdesc : string;
ProjectArea : string;
ProjectManagers : any;
ProjectManagersDefaultItems:string[];
ProjectManagersUserItems:string[];
Proposedres : string;
ReportedBy : any;
ReportedByDefaultItems:string[];
ReportedByUserItems:string[];
ReptArea : string;
ReptDt : any;
ReptMgr : string;
Resolution : string;
RootCause : string;
SendTo : any;
SendToDefaultItems:string[];
SendToUserItems:string[];
Severity : string;
Status : string;
Suggest : string;
TestCase : any;
Title:string;
Vendors : string;
WONum : any;
oldAttachments:any;
Attachments:any;
//Business Objects End //
}