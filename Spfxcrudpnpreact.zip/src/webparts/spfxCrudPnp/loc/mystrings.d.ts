declare interface ISpfxCrudPnpWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SpfxCrudPnpWebPartStrings' {
  const strings: ISpfxCrudPnpWebPartStrings;
  export = strings;
}
