import { Dispatcher } from 'simplr-flux';
import { sp } from '@pnp/sp';
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/fields';
import '@pnp/sp/attachments';
import "@pnp/sp/files";
import "@pnp/sp/folders";
let ListName='ZspireUserGuide';


// Get the edit click details
const getEditFormDetails = (Id) => {
  sp.web.lists.getByTitle(ListName).items.getById(Id).select('*','AttachmentFiles').expand('AttachmentFiles').get().then(res => {
    Dispatcher.dispatch({ type: 'getEditFormDetailsType', response: res });
  }).catch(error => {
    console.log('getEditFormDetails ' + error);
  });
}
export { getEditFormDetails };


const getcategorieslistitemDetails = () => {

    sp.web.lists.getByTitle('Categories').items.get().then(res => {
      Dispatcher.dispatch({ type: 'getcategorieslistitemDetailsType', response: res });
    }).catch(error => {
      console.log('getcategorieslistitemDetails ' + error);
    });
  }
  export { getcategorieslistitemDetails };

  const getUserRoleslistitemDetails = () => {
  
      sp.web.lists.getByTitle('UserRoles').items.get().then(res => {
        Dispatcher.dispatch({ type: 'getUserRoleslistitemDetailsType', response: res });
      }).catch(error => {
        console.log('getUserRoleslistitemDetails ' + error);
      });
    }
    export { getUserRoleslistitemDetails };
  

  
  const SaveForm = (subcategories,SearchTerms,AspireUserRoles,category,Section,Status,DocTitle,Synopsys,Attachments,Created,lncreated,lncreatedby,lnmodified,lnmodifiedby,Ehrev,EhEditor,Ehdate,year) => {
    
    debugger;
    sp.web.lists.getByTitle('ZspireUserGuide').items.add({
      'Subcategory':subcategories,
          'SearchTerms':SearchTerms,  
          'AspireUserRoles': AspireUserRoles,
          'Category':category,
          'Section':Section,
          'Status':Status,
          'Title':DocTitle,
          'Synopsys':Synopsys,
          'Created':Created,
          'LNCreated':lncreated,
          'LNCreatedBy':lncreatedby,
          'LNModified':lnmodified,
          'LNModifiedBy':lnmodifiedby,
          'EhRev':Ehrev,
          'EhEditor':EhEditor,
          'EhDate':Ehdate,
          'Year':year,
        

   
        }).then(res => {

          if (res.data != undefined) {
              debugger;
              if (Attachments.length != 0) {
                  debugger;
                  res.item.attachmentFiles.addMultiple(Attachments)
                      .then(resattach => {
                          if (res.data != undefined) {
                              Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
                          }
                      });
              }
              else {
                  Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
              }
          }
      }).catch(error => {
          console.log('saveForm ' + error);
      });
    }
        
  export { SaveForm };
  
  // Update Existing Item
  const updateForm = (uniqueId,subcategories,SearchTerms,AspireUserRoles,category,Section,Status,DocTitle,Synopsys,Attachments,EditAttachments,delattach,lnmodified,lnmodifiedby,Ehrev,EhEditor,Ehdate) => {
    sp.web.lists.getByTitle('ZspireUserGuide').items.getById(uniqueId).update({
  
       'Subcategory':subcategories,
       
          'SearchTerms':SearchTerms,  
          'AspireUserRoles': AspireUserRoles,
         'Category':category,
          'Section':Section,
          'Status':Status,
          'Title':DocTitle,
          'Synopsys':Synopsys,
          'LNModified':lnmodified,
          'LNModifiedBy':lnmodifiedby,
          'EhRev':Ehrev,
           'EhEditor':EhEditor,
           'EhDate':Ehdate,
           
      
          }).then(res => {
            debugger;
            if (res.data != undefined) {
                debugger;
                if (Attachments.length != 0) {
      
                    if (EditAttachments.length != 0) {
                        res.item.attachmentFiles.deleteMultiple(...delattach)
                            .then(resdel => {
                                if (res.data != undefined) {
                                    res.item.attachmentFiles.addMultiple(Attachments)
                                        .then(resadd => {
                                            if (res.data != undefined) {
                                                Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
                                            }
                                        });
                                }
                            });
                    }
                    if (delattach.length != 0) {
                        res.item.attachmentFiles.deleteMultiple(...delattach)
                            .then(resdel => {
                                if (res.data != undefined) {
                                    res.item.attachmentFiles.addMultiple(Attachments)
                                        .then(resadd => {
                                            if (res.data != undefined) {
                                                Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
                                            }
                                        });
                                }
                            });
                    }
                    else {
                        res.item.attachmentFiles.addMultiple(Attachments)
                            .then(resaddattach => {
                                if (res.data != undefined) {
                                    Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
                                }
                            });
                    }
                }
      
                else {
                    if (delattach.length != 0) {
                       
                        res.item.attachmentFiles.deleteMultiple(...delattach)
                            .then(resdell => {
                                if (resdell != undefined) {
                                    Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
                                }
                            });
                    }
                    else {
                        Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
                    }
                      Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
                }
            }
        }).catch(error => {
            console.log('updateForm ' + error);
        });
      }
      export { updateForm };