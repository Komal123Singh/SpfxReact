/* tslint:disable */
require("./SpfxCrudPnp.module.css");
const styles = {
  spfxCrudPnp: 'spfxCrudPnp_65e2a7a4',
  container: 'container_65e2a7a4',
  row: 'row_65e2a7a4',
  column: 'column_65e2a7a4',
  'ms-Grid': 'ms-Grid_65e2a7a4',
  title: 'title_65e2a7a4',
  subTitle: 'subTitle_65e2a7a4',
  description: 'description_65e2a7a4',
  button: 'button_65e2a7a4',
  label: 'label_65e2a7a4'
};

export default styles;
/* tslint:enable */