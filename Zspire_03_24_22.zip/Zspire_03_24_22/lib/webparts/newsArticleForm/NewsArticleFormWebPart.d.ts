import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface INewsArticleFormWebPartProps {
    description: string;
    exitLocation: string;
    logo: string;
}
export default class NewsArticleFormWebPart extends BaseClientSideWebPart<INewsArticleFormWebPartProps> {
    onInit(): Promise<void>;
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=NewsArticleFormWebPart.d.ts.map