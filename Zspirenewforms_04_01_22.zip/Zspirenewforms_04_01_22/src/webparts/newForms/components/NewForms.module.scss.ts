/* tslint:disable */
require("./NewForms.module.css");
const styles = {
  newForms: 'newForms_493e7eb6',
  container: 'container_493e7eb6',
  row: 'row_493e7eb6',
  column: 'column_493e7eb6',
  'ms-Grid': 'ms-Grid_493e7eb6',
  title: 'title_493e7eb6',
  subTitle: 'subTitle_493e7eb6',
  description: 'description_493e7eb6',
  button: 'button_493e7eb6',
  label: 'label_493e7eb6'
};

export default styles;
/* tslint:enable */