/* tslint:disable */
require("./GapClaimsLetters.module.css");
const styles = {
  gapClaimsLetters: 'gapClaimsLetters_4a2cf087',
  container: 'container_4a2cf087',
  teams: 'teams_4a2cf087',
  welcome: 'welcome_4a2cf087',
  welcomeImage: 'welcomeImage_4a2cf087',
  links: 'links_4a2cf087'
};

export default styles;
/* tslint:enable */