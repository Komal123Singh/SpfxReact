import { Dispatcher } from 'simplr-flux';
import { sp } from '@pnp/sp';
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/fields';
import '@pnp/sp/attachments';
import { SPHttpClient} from '@microsoft/sp-http';

//Get Docconfig List details
const getDocDetails = () => {
    debugger;
    sp.web.lists.getByTitle("DocConfig").items.get().then(res =>{
        console.log(res);
        Dispatcher.dispatch({ type: 'getDocTypeType', response: res});
    }).catch(error => {
      //  console.log('getDocTypeType', +error)
    })
}
export {getDocDetails}  

//Get Admin List Details
const getAdminlistDetails = async () => {
    debugger;
    await sp.web.lists.getByTitle("Admin").items.get().then(res =>{
        console.log(res);
        Dispatcher.dispatch({ type: 'getAdminvalues', response: res});
    }).catch(error => {
        console.log('getAdminvalues', +error)
    })
}
export {getAdminlistDetails}  

const getProblemlistDetails = async () => {
    debugger;
    await sp.web.lists.getByTitle("Problem").items.getAll().then(res =>{
        console.log(res);
        Dispatcher.dispatch({ type: 'getProbelmvalues', response: res});
    }).catch(error => {
        console.log('getProblemlistDetails', +error)
    })
}
export {getProblemlistDetails}  

// Get the edit click details
const getEditFormDetails = (Id) => {
    debugger;
sp.web.lists.getByTitle('Problem').items.getById(Id).select('*','AttachmentFiles',
'ActivePlayers/ID','ActivePlayers/EMail','ActivePlayers/Title',
'ApprovedBy/ID','ApprovedBy/EMail','ApprovedBy/Title',
'AssignedTo/ID','AssignedTo/EMail','AssignedTo/Title',
'ProjectManagers/ID','ProjectManagers/EMail','ProjectManagers/Title',
'ReportedBy/ID','ReportedBy/EMail','ReportedBy/Title',
'SendTo/ID','SendTo/EMail','SendTo/Title',).expand('AttachmentFiles','ActivePlayers','ApprovedBy','AssignedTo','ProjectManagers','ReportedBy','SendTo',).get().then(res => {
debugger;
console.log("Success");
    Dispatcher.dispatch({ type: 'getEditFormDetailsType', response:res});
}).catch(error => {
console.log('getEditFormDetails ' + error);
});
  }
export {getEditFormDetails};

// Get Input Details
const saveForm = (stamp,uploadedCommentsRichTextFiles,uploadedSuggestRichTextFiles,uploadedResolutionRichTextFiles,uploadedProposedresRichTextFiles,uploadedProbdescRichTextFiles, createdby, createdon, ActivePlayers,ApplicationArea,ApprovedBy,ApprovedDt,AssignedTo,AssignedDt,Comments,CreateDt,CreateTime,DateResolved,docnumber,DocType,updateHistoryValue,EditHistoryFields,EnvType,EstCompDt,IONum,Keywords,PhaseDetect,PhaseIntro,Priority,Probdesc,ProjectArea,ProjectManagers,Proposedres,ReportedBy,ReptArea,ReptDt,ReptMgr,Resolution,RootCause,SendTo,Severity,Status,Suggest,TestCase,Title,Vendors,WONum,Attachments,)=> {
debugger;
sp.web.lists.getByTitle('Problem').items.add({
  'NoteID':stamp,
 'ProblemCreatedBy':createdby,
 'ActivePlayersId': ActivePlayers.length > 0 ? ActivePlayers[0] : null,
 'ApplicationArea': ApplicationArea,
 'ApprovedById': ApprovedBy.length > 0 ? ApprovedBy[0] : null,
 'ApprovedDt':ApprovedDt,
 'AssignedToId': AssignedTo.length > 0 ? AssignedTo[0] : null,
 'AssignedDt':AssignedDt,
 'Comments': Comments,
 'CreateDt': createdon,
 'CreateTime': CreateTime,
 'DateResolved': DateResolved,
'DocNumber': docnumber,
 'DocType': DocType,
 'WorkFlowHistory': updateHistoryValue,
 //'EditHistoryFields': EditHistoryFields,
  'EnvType': EnvType,
 'EstCompDt': EstCompDt,
 //'IONum': IONum,
 'Keywords': Keywords,
 //'PhaseDetect': PhaseDetect,
   //'PhaseIntro': PhaseIntro,
 'Priority': Priority,
 'Probdesc': Probdesc,
 'ProjectArea': ProjectArea,
 'ProjectManagersId': ProjectManagers.length > 0 ? ProjectManagers[0] : null,
 'Proposedres': Proposedres,
 'ReportedById': ReportedBy.length>0? ReportedBy[0]:null,
 //'ReptArea': ReptArea,
 'ReptDt': ReptDt,
 //'ReptMgr': ReptMgr,
 'Resolution': Resolution,
 'RootCause': RootCause,
'SendToId': SendTo.length > 0 ? SendTo[0] : null,
 'Severity': Severity,
 'Status': Status,
 'Suggest': Suggest,
 'TestCase': TestCase,
 'Title': Title,
 'Vendors': Vendors,
 'WONum': WONum,
 
}).then(res => {

    if (res.data != undefined) {
        debugger;
        
        // if (res != null && uploadedCommentsRichTextFiles.length > 0) {
        //     let type='Comments';
        //     updateAttachRichTextFile(res, uploadedCommentsRichTextFiles, 0, Comments,Attachments,type);
        //     // insertAttachRichTextFile(res, uploadedCommentsRichTextFiles, 0, Comments,Attachments, res.data.Id,type);
        //     // Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
        // }
        // if (res != null && uploadedSuggestRichTextFiles.length > 0) {
        //     let type='Suggest';
        //     updateAttachRichTextFile(res, uploadedSuggestRichTextFiles, 0, Suggest,Attachments,type);
        //     // insertAttachRichTextFile(res, uploadedSuggestRichTextFiles, 0, Suggest,Attachments, res.data.Id,type);
        //     // Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
        // }
        
        // if (res != null && uploadedResolutionRichTextFiles.length > 0) {
        //     let type='Resolution';
        //     updateAttachRichTextFile(res, uploadedResolutionRichTextFiles, 0, Resolution,Attachments,type);
        //     // insertAttachRichTextFile(res, uploadedResolutionRichTextFiles, 0, Resolution,Attachments, res.data.Id,type);
        //     // Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
        // }
        // if (res != null && uploadedProposedresRichTextFiles.length > 0) {
        //     let type='Proposedres';
        //     updateAttachRichTextFile(res, uploadedProposedresRichTextFiles, 0, Proposedres,Attachments,type);
        //     // insertAttachRichTextFile(res, uploadedProposedresRichTextFiles, 0, Proposedres,Attachments, res.data.Id,type);
        //     // Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
        // }
        // if (res != null && uploadedProbdescRichTextFiles.length > 0) {
        //     let type='Probdesc';
        //     updateAttachRichTextFile(res, uploadedProbdescRichTextFiles, 0, Probdesc,Attachments,type);
        //     // insertAttachRichTextFile(res, uploadedProbdescRichTextFiles, 0, Probdesc,Attachments, res.data.Id,type);
        //     // Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
        // }
        
        if(Attachments!=""){
            res.item.attachmentFiles.addMultiple(Attachments).then(result => {
            
                if (res.data != undefined) {
                    Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
                    }
            });}
        else{
           Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
        }
             
    
    }  
    }).catch(error => {
console.log('saveForm ' + error);
});
};
export {saveForm};

// Update Existing Item
const updateForm = (uploadedCommentsRichTextFiles,uploadedSuggestRichTextFiles,uploadedResolutionRichTextFiles,uploadedProposedresRichTextFiles,uploadedProbdescRichTextFiles,toDelNames,Attachments,uniqueId,ActivePlayers,ApplicationArea,ApprovedBy,ApprovedDt,AssignedTo,AssignedDt,Comments,CreateDt,CreateTime,DateResolved,DocNumber,DocType,updateHistoryValue,EditHistoryFields,EnvType,EstCompDt,IONum,Keywords,PhaseDetect,PhaseIntro,Priority,Probdesc,ProjectArea,ProjectManagers,Proposedres,ReportedBy,ReptArea,ReptDt,ReptMgr,Resolution,RootCause,SendTo,Severity,Status,Suggest,TestCase,Title,Vendors,WONum,)=> {
sp.web.lists.getByTitle('Problem').items.getById(uniqueId).update({

'ActivePlayersId': ActivePlayers.length > 0 ? ActivePlayers[0] : null,
'ApplicationArea': ApplicationArea,
'ApprovedById': ApprovedBy.length > 0 ? ApprovedBy[0] : null,
'ApprovedDt':ApprovedDt,
'AssignedToId': AssignedTo.length > 0 ? AssignedTo[0] : null,
'AssignedDt':AssignedDt,
'Comments': Comments,
//'CreateDt': CreateDt,
//'CreateTime': CreateTime,
'DateResolved': DateResolved,
'DocNumber': DocNumber,
'DocType': DocType,
'WorkFlowHistory': updateHistoryValue,
//'EditHistoryFields': EditHistoryFields,
'EnvType': EnvType,
'EstCompDt': EstCompDt,
//'IONum': IONum,
'Keywords': Keywords,
//'PhaseDetect': PhaseDetect,
//'PhaseIntro': PhaseIntro,
'Priority': Priority,
'Probdesc': Probdesc,
'ProjectArea': ProjectArea,
'ProjectManagersId': ProjectManagers.length > 0 ? ProjectManagers[0] : null,
'Proposedres': Proposedres,
'ReportedById': ReportedBy.length>0? ReportedBy[0]:null,
//'ReptArea': ReptArea,
'ReptDt': ReptDt,
//'ReptMgr': ReptMgr,
'Resolution': Resolution,
 'RootCause': RootCause,
'SendToId': SendTo.length > 0 ? SendTo[0] : null,
'Severity': Severity,
'Status': Status,
'Suggest': Suggest,
'TestCase': TestCase,
'Title':Title,
'Vendors': Vendors,
 'WONum': WONum,
}).then(res => {
    if (res.data != undefined) {
        // if (res != null && uploadedCommentsRichTextFiles.length > 0) {
        //     let type='Comments';
        //     updateAttachRichTextFile(res, uploadedCommentsRichTextFiles, 0, Probdesc,Attachments,type);
        //     // insertAttachRichTextFile(res, uploadedCommentsRichTextFiles, 0, Comments,Attachments, res.data,type);
        //     // Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
        // }
        // if (res != null && uploadedSuggestRichTextFiles.length > 0) {
        //     let type='Suggest';
        //     updateAttachRichTextFile(res, uploadedSuggestRichTextFiles, 0, Probdesc,Attachments,type);
        //     // insertAttachRichTextFile(res, uploadedSuggestRichTextFiles, 0, Suggest,Attachments, res.data,type);
        //     // Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
        // }
        // if (res != null && uploadedResolutionRichTextFiles.length > 0) {
        //     let type='Resolution';
        //     updateAttachRichTextFile(res, uploadedResolutionRichTextFiles, 0, Probdesc,Attachments,type);
        //     // insertAttachRichTextFile(res, uploadedResolutionRichTextFiles, 0, Resolution,Attachments, res.data,type);
        //     // Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
        // }
        
        // if (res != null && uploadedProposedresRichTextFiles.length > 0) {
        //     let type='Proposedres';
        //     // insertAttachRichTextFile(res, uploadedProposedresRichTextFiles, 0, Proposedres,Attachments, res.data,type);
        //     updateAttachRichTextFile(res, uploadedProposedresRichTextFiles, 0, Probdesc,Attachments,type);
        //     // Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
        // }
        // if (res != null && uploadedProbdescRichTextFiles.length > 0) {
        //     let type='Probdesc';
        //     updateAttachRichTextFile(res, uploadedProbdescRichTextFiles, 0, Probdesc,Attachments,type);
        //     // insertAttachRichTextFile(res, uploadedProbdescRichTextFiles, 0, Probdesc,Attachments, res.data,type);
        //     // Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
        // }
        debugger;
        if(toDelNames!=""){
            res.item.attachmentFiles.deleteMultiple(...toDelNames).then(resp => {
                debugger;
            if(Attachments!=""){
                res.item.attachmentFiles.addMultiple(Attachments).then(result => {
                    Dispatcher.dispatch({ type: 'insertResultType', response: res.data });
                    
                })}
            else{
                Dispatcher.dispatch({ type: 'insertResultType', response: res.data });
            }

         })}
         else if(Attachments!=""){
             debugger;
            res.item.attachmentFiles.addMultiple(Attachments).then(result => {
                Dispatcher.dispatch({ type: 'insertResultType', response: res.data });
                
            })}
         else{
            Dispatcher.dispatch({ type: 'insertResultType', response: res.data });
         }
        // if(Attachments!=""){
        }}).catch(error => {
console.log('updateForm ' + error);
});
  };
export {updateForm};





const insertAttachRichTextFile = (results, files, itemId, Attachments0Rich, Attachments, responseId,type) => {
    let domparser = new DOMParser();
    let fileInfos = [];
    if (files != null) {
      for (let f of files) {
        let fileRead = new FileReader();
        fileRead.onloadend = (e) => {
          fileInfos.push({
            name: f.name,
            content: fileRead.result,
          });
          results.item.attachmentFiles.addMultiple(fileInfos).then(() => {
            results.item
              .select('ID,AttachmentFiles',type)
              .expand('AttachmentFiles').get().then(async (results: any) => {
                let itemID = results.ID;
                let fileData = results.AttachmentFiles;
    
                //  let Attachments0 = results.Attachments0;
                let Attachments0 = results[type];
    
                let parsedAttachments0 = domparser.parseFromString(Attachments0, 'text/html');
                await Promise.all([
    
                  await parsedAttachments0.querySelectorAll('img').forEach((img) => {
                    fileData.forEach((fData) => {
                      img.getAttribute('data-file-name') === fData['FileName'] ? img.setAttribute('src', fData['ServerRelativeUrl'])
                        : null;
                    });
                  }),
                ]);
                updateRichItem(itemID, parsedAttachments0,Attachments,type);
              });
          });
        };
        fileRead.readAsArrayBuffer(f);
      }
    }
    }
    export { insertAttachRichTextFile };
    
    const updateRichItem = (itemID, parsedAttachments0,Attachments,type) => {
    let s = new XMLSerializer();
    
    let serializeAttachments0 = s.serializeToString(parsedAttachments0);
    sp.web.lists.getByTitle('Problem').items.getById(itemID).update({
    
      type: serializeAttachments0,
    }).then(res => {
    
        if (res.data != undefined) {
    
            
    
            if (Attachments.length != 0) {
    
                debugger;
    
                res.item.attachmentFiles.addMultiple(Attachments)
    
                    .then(resattach => {
    
                        if (res.data != undefined) {
    
                            Dispatcher.dispatch({ type: 'insertResultType', response: itemID });
    
                        }
    
                    });
    
            }
    
            else {
    
                Dispatcher.dispatch({ type: 'insertResultType', response: itemID });
    
            }
    
        }
    
    }).catch(error => {
    
        console.log('updateRichItem ' + error);
    
    });
    
    }
    
    export { updateRichItem };
    
    const updateAttachRichTextFile = (results, files, itemId, Attachments0Rich,Attachments,type) => {
        let domparser = new DOMParser();
        debugger;
        sp.web.lists.getByTitle('Problem').items.getById(itemId).select('ID,AttachmentFiles',type)
          .expand('AttachmentFiles').get().then(async (fileResults: any) => {
            let fileData = fileResults.AttachmentFiles;
            let aFiles = [...fileData];
      
              let Attachments0 = fileResults[type];
            // let Attachments0 = Attachments0Rich;
            aFiles.forEach(async (aFile) => {
              let isExists = files.some((f) => f['name'] === aFile['FileName']);
              if (isExists) {
                  debugger;
                parseUpdate(fileData, itemId, Attachments0)
              }
            });
            if (files.length > 0) {
              let fileInfos = [];
              for (let f of files) {
                let fileRead = new FileReader();
                fileRead.onloadend = (e) => {
                  fileInfos.push({
                    name: f.name,
                    content: fileRead.result,
                  });
                  results.item.attachmentFiles.addMultiple(fileInfos).then(() => {
                    results.item.select('ID,AttachmentFiles',type)
                      .expand('AttachmentFiles').get().then(async (results: any) => {
                        let itemID = results.ID;
                        let fileData = results.AttachmentFiles;
      
                        let Attachments0 = results[type];
                        parseUpdate(fileData, itemId, Attachments0);
      
      
                        let parsedAttachments0 = domparser.parseFromString(Attachments0, 'text/html');
                        await Promise.all([
      
      
                          await parsedAttachments0.querySelectorAll('img').forEach((img) => {
                            fileData.forEach((fData) => {
                              img.getAttribute('data-file-name') === fData['FileName'] ? img.setAttribute('src', fData['ServerRelativeUrl'])
                                : null;
                            });
                          }),
      
                        ]);
      
                        updateRichItem(itemID, parsedAttachments0,Attachments,type);
                      });
                  });
                };
                fileRead.readAsArrayBuffer(f);
              }
            }
            else if (files.length == 0) {
                debugger;
              parseUpdate(fileData, itemId, Attachments0)
            }
          });
      }
      export { updateAttachRichTextFile };
      
      const parseUpdate = async (fileData, itemId, Attachments0) => {
          debugger;
        let fileLevlInfos = [];
        let domparser = new DOMParser();
      
      
        let parsedAttachments0 = domparser.parseFromString(Attachments0, 'text/html');
      
        parsedAttachments0.querySelectorAll('img').forEach((img) => {
          let iName = img.getAttribute('data-file-name');
          fileData.forEach((fData) => {
            img.getAttribute('data-file-name') === fData['FileName']
              ? img.setAttribute('src', fData['ServerRelativeUrl']) : null;
          });
          fileLevlInfos.indexOf(iName)
            ? console.log('exisitng file')
            : fileLevlInfos.push(iName);
        });
        let item = await sp.web.lists.getByTitle('Problem').items.getById(itemId);
        if (fileData.length !== fileLevlInfos.length) {
          let fInfos = [];
          fileData.forEach((aFile) => {
            fInfos.push(aFile['FileName']);
          });
          let ainfos = fInfos.join('","');
          let infos = ainfos.toString();
          fileLevlInfos.length !== 0
            ? fileLevlInfos.forEach((rFile) => {
              fileData.forEach(async (aFile) => {
                rFile === aFile['FileName'] ? console.log('') : await item.attachmentFiles
                  .getByName(aFile['FileName']).delete();
              });
            })
            : await item.attachmentFiles.deleteMultiple(infos);
        }
      }
      export { parseUpdate };







