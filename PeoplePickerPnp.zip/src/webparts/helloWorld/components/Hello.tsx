import * as React from "react";
import styles from './HelloWorld.module.scss';
import { IHelloWorldProps } from './IHelloWorldProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { Button,autobind} from 'office-ui-fabric-react';
import { PeoplePicker ,PrincipalType} from "@pnp/spfx-controls-react/lib/PeoplePicker"; 
import { sp } from '@pnp/sp/presets/all';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
export default class HelloWorld extends React.Component<IHelloWorldProps, {}> {
    
    public render(): React.ReactElement<IHelloWorldProps> {
        return (
          <div className={ styles.helloWorld }>
              <h1>Hello</h1>
              </div>
              )
              }
}