import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IValidationsProblemWebPartProps {
    description: string;
    logourl: string;
    exiturl: string;
}
export default class ValidationsProblemWebPart extends BaseClientSideWebPart<IValidationsProblemWebPartProps> {
    onInit(): Promise<void>;
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=ValidationsProblemWebPart.d.ts.map