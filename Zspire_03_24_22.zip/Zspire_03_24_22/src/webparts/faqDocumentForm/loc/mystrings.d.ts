declare interface IFaqDocumentFormWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'FaqDocumentFormWebPartStrings' {
  const strings: IFaqDocumentFormWebPartStrings;
  export = strings;
}
