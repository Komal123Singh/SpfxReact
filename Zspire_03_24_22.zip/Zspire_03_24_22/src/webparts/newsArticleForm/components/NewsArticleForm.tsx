import * as React from 'react';
import { INewsArticleFormProps } from './INewsArticleFormProps';
import "@pnp/sp/webs";
import "@pnp/sp/site-users/web";
import * as _ from '@microsoft/sp-lodash-subset';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { ThemeProvider, createTheme, ProgressIndicator,ChoiceGroup, TextField, Label, PrimaryButton, Text, Link, Icon, IconButton, DialogType, Dialog, DialogFooter } from '@fluentui/react';
import { DefaultButton } from '@microsoft/office-ui-fabric-react-bundle';
import * as moment from 'moment';
import './NewsArticleForm.module.scss';
import './NewsArticleFormCss.css';
import ViewNewsArticle from './ViewNewsArticle';
import  NewsArticleStore from '../Store/NewsArticleStore';
import * as NewsArticleAction from '../Action/NewsArticleAction';
import { DateTimePicker, DateConvention } from '@pnp/spfx-controls-react/lib/dateTimePicker';
import { RichText } from '@pnp/spfx-controls-react/lib/RichText'
import { remove } from 'lodash';
import { Pivot, PivotItem,  } from '@fluentui/react';
import SunEditor from 'suneditor-react';
import 'suneditor/dist/css/suneditor.min.css';
import { sp } from "@pnp/sp";

let uniqueId = 0;
let isEditMode = false;
let isViewMode = false;
let EditFormDetails;
let exitLocation;
let documentStatusValidation='';
let dateValidation='';
let titleValidation='';
let bodyValidation='';
let actionBtnClicked='';
let  absoluteUrl;
let uploadedRichTextFiles=[];
let loadSpinner=false;


const myTheme = createTheme({
  palette: {
    themePrimary: '#23366f',
    themeLighterAlt: '#f3f4f9',
    themeLighter: '#cfd5e8',
    themeLight: '#a9b4d4',
    themeTertiary: '#6476a9',
    themeSecondary: '#344781',
    themeDarkAlt: '#203165',
    themeDark: '#1b2a55',
    themeDarker: '#141f3f',
    neutralLighterAlt: '#faf9f8',
    neutralLighter: '#f3f2f1',
    neutralLight: '#edebe9',
    neutralQuaternaryAlt: '#e1dfdd',
    neutralQuaternary: '#d0d0d0',
    neutralTertiaryAlt: '#c8c6c4',
    neutralTertiary: '#a19f9d',
    neutralSecondary: '#605e5c',
    neutralPrimaryAlt: '#3b3a39',
    neutralPrimary: '#323130',
    neutralDark: '#201f1e',
    black: '#000000',
    white: '#ffffff',
  }
});

const iconStyle = {
  root: {
    color: '#107c10',
    fontSize: '50px',
  }
};

let dialogContentProps = {
  type: DialogType.normal,
  title: 'Confirmation',
  closeButtonAriaLabel: 'Close',
  subText: '',
};

let dialogModelContentProps = {
  type: DialogType.normal,
  title: <div className="text-center"><div><Icon styles={iconStyle} iconName="SkypeCircleCheck"></Icon></div><div>Success</div></div>,
  closeButtonAriaLabel: 'Close',
  subText: '',
};

export interface MyState {
  webpartContxt: WebPartContext;
  DocStatus:string;
  CreationDate: any;
  DocAuthor: any;
  ArticleTitle:string;
  Body:string;
  Attachments:any;
  DocStatusChoiceArr:any;
  //InProgressradiobtn:any;
  //Publishedradiobtn:any;
  EditAttachments:any;
  Message:any;
  DocType:string;
  Created:any;
  delAttach:any;
  isvalidRecord: boolean;
  isModalClose: boolean;
  isModaldialogClose: boolean;
  LNCreated:any;
  LNCreatedBy:any;
  LNModified:any;
  LNModifiedBy:any;
  EhEditor:any;
  EhRev:any;
  EhDate:any;
  Year:any;
  isEditor:boolean;
  buttoncheck:any;

}

export default class NewsArticleForm extends React.Component<INewsArticleFormProps, MyState> {
  constructor(prop) {
    super(prop);
    this.state = {
      webpartContxt: this.props.context,
      DocStatus:'In-Progress',
      DocStatusChoiceArr:[{ key: 'In-Progress', text: 'In-Progress' },{key:'Publish',text:'Publish'}],
      CreationDate:new Date(),
      DocAuthor:this.props.context.pageContext.user.displayName,
      ArticleTitle:'',
      Body:'',
      Attachments:[],
      EditAttachments:[],
      Message:' ',
      DocType:'News Release',
      Created:null,
      delAttach:[],
      isvalidRecord: false,
      isModalClose: true,
      isModaldialogClose: true,
      LNCreated:null,
      LNCreatedBy:null,
      LNModified:null,
      LNModifiedBy:null,
      EhEditor:null,
      EhRev:null,
      EhDate:null,
      Year:null,
      isEditor:false,
      buttoncheck:''

    }
    absoluteUrl= this.props.context.pageContext.site.absoluteUrl;
    SPComponentLoader.loadCss(absoluteUrl+'/SiteAssets/StyleSheet/bootstrap.min.css');
    SPComponentLoader.loadCss(absoluteUrl+'/SiteAssets/StyleSheet/suneditor.min.css');
    SPComponentLoader.loadCss('https://cdn.jsdelivr.net/npm/suneditor@latest/dist/css/suneditor.min.css');
    SPComponentLoader.loadScript(absoluteUrl+'/SiteAssets/JS/jquery.min.js');
    SPComponentLoader.loadScript(absoluteUrl+'/SiteAssets/JS/popper.min.js');
    SPComponentLoader.loadScript(absoluteUrl+'/SiteAssets/JS/bootstrap.min.js');
  }
  componentDidMount() {
    try {
      
      const url = window.location.href;
      const urlObject = new URL(url);
      uniqueId = urlObject.searchParams.get('itemID') == '' || urlObject.searchParams.get('itemID') == null ? 0 : parseInt(urlObject.searchParams.get('itemID'));
      
      // Call default form details
      this.getFormDefaultDetails();
      this.getLoggedUsersGroup();

      if (uniqueId != 0) {
        isViewMode = true;
        isEditMode = false;
        this.getEditFormDetailsComp();
      }
      else {
        isViewMode = false;
        isEditMode = true;
      }
    }
    catch (e) {
      console.log('componentDidMount: ' + e);
    }
  }

  getFormDefaultDetails = () => {
    try {
      
      NewsArticleStore.on('insertResultchange', this.assignInsertResultStore);
    } catch (e) {
      console.log('getFormDefaultDetails' + e);
    }
  }

  getEditFormDetailsComp = () => {
    try {
      
      NewsArticleAction.getEditFormDetails(uniqueId);
      NewsArticleStore.on('getEditFormDetailschange', this.assignEditFormDetailsStore);
    } catch (e) {
      console.log('getEditFormDetailsComp' + e);
    }
  }

  private tabledetails = () => {
    
    
    try {
    let splitEheditor=this.state.EhEditor!=undefined?this.state.EhEditor.split('\n'):[];
    let splitEhrev=this.state.EhRev!=undefined?this.state.EhRev.split('\n'):[];
    let splitEhdate=this.state.EhDate!=undefined?this.state.EhDate.split('\n'):[];
    
    return(
      <table className="table table-bordered border-spacing:2px text-center">
                      <thead>
                        <tr>
                          <th scope="col">Rev.</th>
                          <th scope="col">Editor</th>
                          <th scope="col">Edit Date</th>                      
                        </tr>
                      </thead>
                      <tbody>

                        {splitEhrev.filter((item, index) => index < 10).map((items,index)=>{
                          
                          return(
                        <tr>
                          <td className='text-center'>{items}</td>
                          <td className='text-center'>{splitEheditor[index]}</td>
                          <td className='text-center'>{splitEhdate[index]}</td>
                        </tr>
                        //)}}}}
                        )})}
                      </tbody>
                    </table>
    ) 
    } catch (e) {
      console.log('tabledetails: ' + e);
    }
  }

  public EditClickBtn = () => {
    try {
      isEditMode = true;
      isViewMode = false;
      this.getEditFormDetailsComp();
    } catch (e) {
      console.log('EditClickBtn' + e);
    }
  }

  public ViewClickBtn = () => {
    try {
      isEditMode = false;
      isViewMode = true;
      this.getEditFormDetailsComp();
    } catch (e) {
      console.log('ViewClickBtn' + e);
    }
  }
  
getLoggedUsersGroup = async () => {
  try { 
  let LoggedUsersGroup = await sp.web.currentUser.groups();
  let permissionupdated=false;
  LoggedUsersGroup.map((groupItem) => {
   if(permissionupdated==false) {
    if (groupItem.Title == "USZ_ZSPIREHomePage_Access_Admins"||groupItem.Title == "USZ_ZSPIREHomePage_Admins"||groupItem.Title == "USZ_ZSPIREHomePage_Editors"
  ||groupItem.Title == "Z-SPIRE Homepage & User guide Owners"||groupItem.Title == "Z-SPIRE Homepage & User guide Members")
   {
    permissionupdated=true;
    this.setState({isEditor:true});
  } 
   }
  
  }) 
  
  } catch (e) {
  console.log('getLoggedUsersGroup' + e);
  }
  }

  public assignInsertResultStore = () => {
    try {
      if (NewsArticleStore.getInserResultStoreValue() != undefined) {
        let test=NewsArticleStore.getInserResultStoreValue();
        if (actionBtnClicked == "saveClose") {
          dialogModelContentProps.subText = 'This Form has been submitted sucessfully. Click Ok to exit';
          loadSpinner=false;
          this.setState({ isModaldialogClose: false });
        } 
        
      }
    } catch (e) {
      console.log('assignInsertResultStore: ' + e);
    }
  }
  

  public assignEditFormDetailsStore = () => {
    
    EditFormDetails = NewsArticleStore.getEditClickStoreValue();
    
    
    if (EditFormDetails != undefined) {
      let domparser = new DOMParser();
      let s = new XMLSerializer();

      let parsedAttachments0 = domparser.parseFromString(EditFormDetails.Body, 'text/html');
      parsedAttachments0.querySelectorAll('[class*=se-component]').forEach((ext) => { ext.removeAttribute('class'); }); let serializeAttachments0 = s.serializeToString(parsedAttachments0);
      this.setState({
        DocStatus: EditFormDetails.DocStatus,
        CreationDate:EditFormDetails.CreationDate!=null?new Date(EditFormDetails.CreationDate):null,
        DocAuthor:EditFormDetails.DocAuthor,
        ArticleTitle:EditFormDetails.Title0,
        Body: serializeAttachments0 != '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>null</body></html>' ? _.unescape(serializeAttachments0) : '',
        EditAttachments:EditFormDetails.AttachmentFiles,
        //Attachment:EditFormDetails.attachmentFiles,
        Created:EditFormDetails.Created,
        LNCreated:EditFormDetails.LNCreated!=null? new Date(EditFormDetails.LNCreated) : null,
        LNModified:EditFormDetails.LNModified!=null? new Date(EditFormDetails.LNModified) : null,
        LNCreatedBy:EditFormDetails.LNCreatedBy,
        LNModifiedBy:EditFormDetails.LNModifiedBy,
        EhDate:EditFormDetails.EhDate,
        EhEditor:EditFormDetails.EhEditor,
        EhRev:EditFormDetails.EhRev,

      });
      
      
    }
  }
  


  public insertForm = () => {
 
    try {
      loadSpinner=true;
      this.setState({ isModalClose: true,buttoncheck:'disabledbutton' });
      let username=this.props.context.pageContext.user.displayName;
      let date=moment(new Date()).format("MM/DD/YYYY LTS");
      let year=moment(new Date()).format("YYYY");
      let editor=this.props.context.pageContext.user.displayName;
      let ehDate=moment(new Date()).format("MM/DD/YYYY LTS");
      let Ehrev='0';
      let count=parseInt(this.state.EhRev);
      let neweditor=this.props.context.pageContext.user.displayName+"\n"+this.state.EhEditor;
      let rev=count+1;
      let newrev=rev.toString()+"\n"+this.state.EhRev;
      let newdate=moment(new Date()).format("MM/DD/YYYY LTS")+"\n"+this.state.EhDate;
      if(uniqueId==0){
      
        NewsArticleAction.saveForm(this.state.DocStatus, this.state.CreationDate, this.state.DocAuthor, this.state.ArticleTitle, this.state.Body, this.state.Attachments, this.state.DocType, this.state.Created, date, username, date, username, year, Ehrev, editor, ehDate,uploadedRichTextFiles)
      }
        else {
         NewsArticleAction.updateForm(uniqueId,this.state.DocStatus, this.state.CreationDate, this.state.DocAuthor, this.state.ArticleTitle, this.state.Body, this.state.Attachments, this.state.EditAttachments, this.state.delAttach, date, username, newrev, neweditor, newdate,uploadedRichTextFiles)
       }
      }
    catch (e) {
      console.log('insertForm: ' + e);
    }
  }

  // Get Input Details
  private inputFormChange = (inputValue) => {
 
    try {
      
      //let test=inputValue;
      switch (inputValue.target.name) {

        case 'ArticleTitle':
          {
            this.setState({ ArticleTitle: inputValue.target.value });
            break;
          }
          case 'CreationDate':
            {
              this.setState({ CreationDate: inputValue.target.value });
              break;
            }
            case 'DocAuthor':
          {
            this.setState({ DocAuthor: inputValue.target.value });
            break;
          }
          case 'Body':
          {
            this.setState({ Body: inputValue.target.value });
            break;
          }
          case 'Attachment':
          {
            this.setState({ Attachments: inputValue.target.value });
            break;
          }
      }
    }
    catch (e) {
      console.log('inputFormChange: ' + e);
    }
  }
  private InProgressRadioBtnChange = (ev: React.FormEvent<HTMLInputElement>, option: any) => {
    
    this.setState({ DocStatus:option.key});
  
  }

  private _getDateDatePickerItems = (items) => {

    this.setState({ CreationDate: items });
  }

  // private _onTextChange = (newText:string) => {
    
  //   this.setState({ Body: newText });
  //   return newText;
  // }
  handleRichTextChange = (fieldName, content) => {

    try {
      switch (fieldName) {

        case 'Body':
          this.setState({ Body: content });
          break;
      }
    }
    catch (e) {
      console.log('handleRichTextChange: ' + e);
    }
  }
  handleImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {
   
    if (imageInfo != null) {
      let files = uploadedRichTextFiles;
      let dataURI = imageInfo.src;
      let fileName = imageInfo.name;
      if (dataURI.split(',')[0].indexOf('base64') >= 0) {
        var arr = dataURI.split(','),
          mime = arr[0].match(/:(.*?);/)[1],
          bstr = atob(arr[1]),
          n = bstr.length,
          u8arr = new Uint8Array(n);
        while (n--) {
          u8arr[n] = bstr.charCodeAt(n);
        }
        const file = new File([u8arr], fileName, { type: mime });
        let fExists = files.some((f) => f['name'] === file['name']);
        if (!fExists) {
          files.push(file);
        }
        uploadedRichTextFiles = files;
      }
    }
  }


 private attach=(newattach) =>{
   
  let fileInfos = [];
     
    for(var i=0;i<newattach.target.files.length;i++){
      debugger;
            fileInfos.push({
                name:newattach.target.files[i].name,
                content:newattach.target.files[i]
            }); 
          }
    this.setState({ Attachments:fileInfos});
 }
 private showattach= ()=>{
  try{
    debugger;
    let showitem=this.state.Attachments;
    return showitem.map((item, idx) => {
    
      return(
            <div><span><a href=''>{showitem[idx].name}</a>
            </span>
            </div>
      )
  })
  }
  catch(e){
    console.log('showattach: ' + e);

}
}

 bindAttachmentFileNames() {
  try {
    let editattchments=this.state.EditAttachments;
     
        // let fileExtension = fileName.split('.').pop();
        let filtereditem = editattchments.filter(attachmentitems =>!attachmentitems.FileName.match(/.(jpg|jpeg|png|gif)$/i))
      return filtereditem.map((item, idx) => {
          //let fileName = item.FileName;
               let downloadUrl = this.props.context.pageContext.web.absoluteUrl + "/_layouts/download.aspx?sourceurl=" + filtereditem[idx].ServerRelativeUrl;  
          return (
              <div><span><a data-interception="off" target='_blank' href={filtereditem[idx].ServerRelativePath.DecodedUrl}>{filtereditem[idx].FileName}</a>
                  <IconButton className='mt-1' iconProps={{ iconName: 'Delete' }} title='Delete' ariaLabel='Delete' onClick={this.deleteAttachment.bind(this, filtereditem[idx].FileName)} />
                  </span></div>
              )

      });
  }
  catch (e) {
      console.log('bindAttachmentFileNames ' + e);
  }
}
private deleteAttachment = (DeleteFileName) => {
debugger;
  try{
 //remove(this.state.EditAttachments);
 let tempEditAttachment=this.state.EditAttachments;
 let tempDeleteAttachment=this.state.delAttach;
 let result;
  
  // let index=tempEditAttachment.indexOf(DeleteFileName);
  var index = tempEditAttachment.findIndex(function(DeleteItem) {
    return DeleteItem.FileName == DeleteFileName
   
  });
  tempEditAttachment.splice(index,1);
  this.setState({EditAttachments:tempEditAttachment});

  tempDeleteAttachment.push(DeleteFileName);

  this.setState({delAttach:tempDeleteAttachment})


  console.log(this.state.delAttach);

}
catch (e) {
  console.log('deleteAttachment: ' + e);
}
}


checkFormValidation = (actionClick) => {
  
  try {
    documentStatusValidation='';
    dateValidation='';
    titleValidation='';
    bodyValidation='';
    // Assign action value
    actionBtnClicked = actionClick;

    // Validation Check
    documentStatusValidation = this.state.DocStatus == '' ? 'Please enter the document status' : '';
    dateValidation = this.state.CreationDate == '' ? 'Please enter the date' : '';
    titleValidation = this.state.ArticleTitle == '' ? 'Please enter the title' : '';
    bodyValidation = this.state.Body == '' || this.state.Body == "<p><br></p>" ? 'Please enter the body' : '';
    if (documentStatusValidation != '' || dateValidation != '' || titleValidation != '' || bodyValidation !='') {
      this.setState({ isvalidRecord: false });
    } else {
      this.modalPopupOpen(actionBtnClicked);
      this.setState({ isvalidRecord: true });
    }
  }
  catch (e) {
    console.log('checkFormValidationChange: ' + e);
  }
}

modalPopupOpen = (actionCall) => {
  
  try {
    actionBtnClicked = actionCall;
    if (actionBtnClicked == 'close') {
      dialogContentProps.title = 'Close Confirmation';
      dialogContentProps.subText = 'Are you sure you want to close this Form?';
    } else if (actionBtnClicked == 'saveClose') {
      dialogContentProps.title = 'Save Confirmation';
      dialogContentProps.subText = 'Do you want to save this details?';
    }
    
    this.setState({ isModalClose: false });
  } catch (e) {
    console.log('modalPopup: ' + e);
  }
}

modalPopupOpenView = (actionCall) => {
  
  try {
    actionBtnClicked = actionCall;
    if (actionBtnClicked == 'close') {
      dialogContentProps.title = 'Close Confirmation';
      dialogContentProps.subText = 'Are you sure you want to close the form?';
    } 
    
    this.setState({ isModalClose: false });
  } catch (e) {
    console.log('modalPopup: ' + e);
  }
}

modalPopupClose = () => {
  try {
    this.setState({ isModalClose: true });
  } catch (e) {
    console.log('modalPopup: ' + e);
  }
}

modalSubmitClick = () => {
  try {

    if (actionBtnClicked == 'close') {
      this.CloseForm();
    } else if (actionBtnClicked == 'saveClose') {
      //actionBtnClicked = this.state.ProcessStatus == 'Complete' ? 'Complete' : actionBtnClicked;
      this.insertForm();
    }
  } catch (e) {
    console.log('modalSubmitClick: ' + e);
  }
}

CloseForm = () => {
    
  try {
    window.open('','_parent','');
    window.close();
  } catch (e) {

    console.log('CloseForm: ' + e);
  } 
}
Exit = () => {

  try {
    window.open('','_parent','');
    window.close();

  } catch (e) {

    console.log('CloseForm: ' + e);
  }
}

  
  public render(): React.ReactElement<INewsArticleFormProps> {
   
    return (
      <ThemeProvider theme={myTheme}>
        <div className={this.state.buttoncheck+' container'}>
          <div className='border p-3' style={{ backgroundColor: '#23366f' }}>
            <div className='row'>
              <div className='col-md-6'><h3 className="text-light ">{this.props.description}</h3></div>
              <div className='col-md-6 text-right'><img src={this.props.logo} alt='Logo' width='50' height='50' /></div>
            </div>
          </div>
          {isViewMode == true && isEditMode == false ?
          <div>
            <div className='buttonCls mt-0'>
              <DefaultButton className='mt-2' text='Close' onClick={this.modalPopupOpenView.bind(this, 'close')} allowDisabledFocus />
              {this.state.isEditor==true?<PrimaryButton className='ml-1 mt-2' text='Edit' onClick={this.EditClickBtn} allowDisabledFocus />:null}
              <div className='mt-0'>
              <Pivot aria-label="Basic Pivot Example">
      <PivotItem className='mt-3' headerText="News Release">
        <div style={{ backgroundColor: '' }}><ViewNewsArticle {...this.state} /></div>
      </PivotItem>
      <PivotItem className='mt-3' headerText="Edit History">
      <div>{this.tabledetails()}</div>
      </PivotItem>
      </Pivot>
      </div>
            </div>
            </div> :
          <div>
              <div className='buttonCls mt-2'>
                <DefaultButton className='' text='Close' onClick={this.modalPopupOpen.bind(this, 'close')} allowDisabledFocus />
                <PrimaryButton className='ml-1' text='Save & Close' onClick={this.checkFormValidation.bind(this, 'saveClose')} allowDisabledFocus />
              </div>
              {loadSpinner==true?<ProgressIndicator label="Submitting Details" />:null}
          <div className='row p-6 mt-2'>
            <div className='col-md-6'><p>Created on {(this.state.Created!=null)?(moment(this.state.Created).format('MM/DD/YYYY')):moment().format('MM/DD/YYYY')}</p></div>
            <div className='col-md-6 text-right style required'><b className='control'></b> Signifies a Required Field </div>
              </div>
           
          {/* <PrimaryButton className='ml-1' text='Retrieve' onClick={this.getEditFormDetailsComp}/> */}
          <div className='border p-3 mt-1'>
                <div className='row mt-2 '>
                <div className='col-md-3 form-group required'><b className='control-label'>Document Status:</b></div>
                <div className='col-md-9'> 
                    <ChoiceGroup className='w-100 inlineflex' selectedKey={this.state.DocStatus} options={this.state.DocStatusChoiceArr} onChange={this.InProgressRadioBtnChange} />
                 </div>
                </div>
                <div className='row mt-2'>
                <div className='col-md-3 form-group required'><b className='control-label'>Date:</b></div>
                <div className='col-md-4'>
                <DateTimePicker dateConvention={DateConvention.Date} showLabels={false}  value={this.state.CreationDate} formatDate={(date: Date) => date.toLocaleDateString('en-US',{month:"2-digit", day:"2-digit", year:"numeric"})}   onChange={this._getDateDatePickerItems}/> 
                </div>
               </div>
               <div className='row mt-2'>
               <div className='col-md-3 form-group required'><b className='control-label'>Author:</b></div>
                 <div className='col-md-4'>
                 <Label className='w-4 normal'> {this.state.DocAuthor}</Label>
                 </div>
               </div>
               <div className='row mt-2'>
               <div className='col-md-3 form-group required'><b className='control-label'>Title:</b></div>
                 <div className='col-md-6'>
                 <TextField   value={this.state.ArticleTitle} placeholder={'Enter the Title'} name='ArticleTitle' errorMessage={titleValidation} onChange={this.inputFormChange}/>
                 </div>
               </div>                           
               <div className='row mt-2'>
               <div className='col-md-3 form-group required'><b className='control-label' >Body:</b></div>
               
               {bodyValidation!=''?
                 <div className='col-md-9'>
                 {/* <TextField className='w-4' multiline  value={this.state.Body} name='Body' onChange={this.inputFormChange}/> */}
                 <div className='cell'>
                 {/* <div className='border p-3 mt-2'> */}
                 <SunEditor enableToolbar={true} placeholder='Please type here...' setContents={this.state.Body} showToolbar={true} setOptions={{
                        minHeight: '170px', mode: 'classic', buttonList: [
                          ['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
                          ['table', 'link', 'image'],],
                      }} onChange={this.handleRichTextChange.bind(this, 'Body')} onImageUpload={this.handleImageUpload} />
                 {/* </div>  */}
                 </div>                
                 <span className="text"> {bodyValidation} </span>                
                 </div>:
                 <div className='col-md-9'>
                 {/* <TextField className='w-4' multiline  value={this.state.Body} name='Body' onChange={this.inputFormChange}/> */}
                 {/* <div className='cell'> */}
                 <div className='border p-3 mt-2'>
                 <SunEditor enableToolbar={true} placeholder='Please type here...' setContents={this.state.Body} showToolbar={true} setOptions={{
                        minHeight: '170px', mode: 'classic', buttonList: [
                          ['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
                          ['table', 'link', 'image'],],
                      }} onChange={this.handleRichTextChange.bind(this, 'Body')} onImageUpload={this.handleImageUpload} />
                 </div>                 
                 {/* <span className="text-danger"> {bodyValidation} </span>                 */}
                 </div>}
                 </div>

               <div className='row mt-2'>
                 <div className='col-md-3'><b>Attachment:</b></div>
                 <div className='col-md-8'>
                 {/* <input type="file" id="attach" name="attach" onChange={this.attach.bind(this)} /> */}
                 <input className='ReactFieldEditor-Attachments-UploadInput mt-2' type='file' name='attachmentFiles' title='Attach Files' aria-required='false' aria-label='Attach Files' multiple onChange={this.attach}/>
                 <div>{this.showattach()}</div>
                 <div>{this.bindAttachmentFileNames()}                                                                       
                {/* <IconButton className='mt-1' iconProps={{ iconName: 'Delete' }} title='Delete' ariaLabel='Delete' onClick={this.deleteAttachment} /> */}
                </div>
                 </div>
               </div>
               </div>        
        </div>}
        <Dialog minWidth={'460px'} maxWidth={'520px'} hidden={this.state.isModalClose} onDismiss={this.modalPopupClose} dialogContentProps={dialogContentProps}>
            <DialogFooter>
              <DefaultButton onClick={this.modalPopupClose} text="No" />
              <PrimaryButton onClick={this.modalSubmitClick} text="Yes" />
            </DialogFooter>
          </Dialog>
          <Dialog minWidth={'380px'} hidden={this.state.isModaldialogClose} dialogContentProps={dialogModelContentProps}>
            <DialogFooter>
              <PrimaryButton style={{ textAlign: 'center' }} onClick={this.Exit} text="OK" />
            </DialogFooter>
          </Dialog>
        </div>
        
        </ThemeProvider>
    );
  }
}

  
  

  
  