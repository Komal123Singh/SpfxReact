import { Dispatcher } from 'simplr-flux';
import {sp} from "@pnp/sp";
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/fields';
import '@pnp/sp/attachments';
import { SPHttpClient} from '@microsoft/sp-http';
let AttachmentFiles;
let uploadedRichTextFiles;
// Get Admin List Details
let absoluteUrl;

const getPaymentTypeDetails = async () => {

    debugger;

    await sp.web.lists.getByTitle("Type").items.get().then(res =>{

        console.log(res);

        Dispatcher.dispatch({ type: 'getPaymentTypevalues', response: res});

    }).catch(error => {

        console.log('getPaymentTypevalues', +error);

    });

}

export {getPaymentTypeDetails}  
// Get the edit click details
const getEditFormDetails = (Id) => {
sp.web.lists.getByTitle('Letters').items.getById(Id).select('*',
'AttachmentFiles',

'SendTo/ID','SendTo','SendTo/Title',
'CopyTo/ID','CopyTo','CopyTo/Title',
'BlindCopyTo/ID','BlindCopyTo','BlindCopyTo/Title',
'From/ID','From','From/Title',).expand('AttachmentFiles','SendTo','CopyTo','BlindCopyTo','From',).get().then(res => {
Dispatcher.dispatch({ type: 'getEditFormDetailsType', response:res});
}).catch(error => {
console.log('getEditFormDetails ' + error);
});
  }
export {getEditFormDetails};
//save assigntoclaim
const closeDialog = (uniqueId,GAPAgreeN,InsuredLastN,InsuredFirstN) =>{
  sp.web.lists.getByTitle('Letters').items.getById(uniqueId).update({
    'GAPAgreeNum': GAPAgreeN,
    'InsuredLastName': InsuredLastN,
    'InsuredFirstName': InsuredFirstN,
  })
  }
 export {closeDialog}

// Get Input Details
const saveForm = (absoluteUrl,GAPAgreeNum,NotesType,VSCAdj,InsuredLastName,InsuredFirstName,InsuredStreetAddress,
  InsuredCity,InsuredState,InsZip,mrk_delete,SendTo,CopyTo,BlindCopyTo,From,Date,Title,Body,
  uploadedRichTextFiles,AttachmentFiles)=> {
sp.web.lists.getByTitle('Letters').items.add({

'GAPAgreeNum': GAPAgreeNum,
'VSCAdj': VSCAdj,
'InsuredLastName': InsuredLastName,
'InsuredFirstName': InsuredFirstName,
'InsuredStreetAddress': InsuredStreetAddress,
'InsuredCity': InsuredCity,
'InsuredState': InsuredState,
'InsZip': InsZip,
'NotesType':NotesType,
'mrk_delete': mrk_delete,
'SendToId': {results:SendTo},
'CopyToId': {results:CopyTo},
'BlindCopyToId': {results:BlindCopyTo},
'FromId': From.length > 0 ? From[0] : null,
'Date': Date,
'Title': Title,
// 'Body': Body,
'Body': Body,
}).then(res => {

  if(res != null && uploadedRichTextFiles.length > 0) {
    insertAttachRichTextFile(res, uploadedRichTextFiles, 0);
    }
if (res.data != undefined && res.data != null) {
  if(AttachmentFiles.length > 0)
  {
  insertFormAttachment(res.data.Id, AttachmentFiles);
  } else 
  {
  Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
  }
  }


  // if(res.data !=undefined &&  uploadedRichTextFiles.length>0)
  // {
  // insertAttachRichTextFile(res.data.ID,uploadedRichTextFiles,Body);

  // }


}).catch(error => {
console.log('saveForm ' + error);
});
}
export {saveForm};

// Update Existing Item
const updateForm = (uniqueId,NotesType,GAPAgreeNum,VSCAdj,InsuredLastName,
  InsuredFirstName,InsuredStreetAddress,InsuredCity,InsuredState,InsZip,mrk_delete,
  SendTo,CopyTo,BlindCopyTo,From,Date,Title,Body,uploadedRichTextFiles,AttachmentFiles,deleteFiles)=> {

 sp.web.lists.getByTitle('Letters').items.getById(uniqueId).update({

'GAPAgreeNum': GAPAgreeNum,
'VSCAdj': VSCAdj,
'InsuredLastName': InsuredLastName,
'InsuredFirstName': InsuredFirstName,
'NotesType':NotesType,
'InsuredStreetAddress': InsuredStreetAddress,
'InsuredCity': InsuredCity,
'InsuredState': InsuredState,
'InsZip': InsZip,
'mrk_delete': mrk_delete,
'SendToId': {results:SendTo},
'CopyToId': {results:CopyTo},
'BlindCopyToId': {results:BlindCopyTo},
'FromId': From.length > 0 ? From[0] : null,
'Date': Date,
'Title': Title,
'Body': Body,
}).then( async(res)=> {
  
    if (AttachmentFiles != null) {
      await res.item.attachmentFiles.addMultiple(AttachmentFiles).then(() => {
        res.item
          .select("ID,AttachmentFiles")
          .expand("AttachmentFiles")
          .get()
          .then(async (results: any) => {
            let itemID = results.ID;
            let fileData = results.AttachmentFiles;
            console.log("update results", results);
          })
          .catch((e) => {
            console.log("files not uploaded", e);
          });
      });
    }
    
    if(res != null) {
      updateAttachRichTextFile(res, uploadedRichTextFiles, uniqueId);
      }
    if (res.data != undefined && res.data != null) {
      if (deleteFiles.length !== 0) {
        await res.item.attachmentFiles
          .deleteMultiple(deleteFiles)
          .then(() => {
            console.log("deleted");
          });
      }  

Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });

}
}).catch(error => {
console.log('updateForm ' + error);
});
  }

export {updateForm};

const insertFormAttachment = (uniqueID, AttachmentFiles) => {
  debugger;
  sp.web.lists.getByTitle('Letters').items.getById(uniqueID).attachmentFiles.addMultiple(AttachmentFiles).
  then(res => {
  Dispatcher.dispatch({ type: 'insertResultType', response: uniqueID });
  }).catch(error => {
  console.log('insertFormAttachment ' + error);
  });
  }
  export { insertFormAttachment };
  
  
  const DeleteFormAttachment = (uniqueID, deleteFiles, AttachmentFiles) => {
  let deleteFilesNames = deleteFiles.map(a => a);
  sp.web.lists.getByTitle('Letters').items.getById(uniqueID).attachmentFiles.deleteMultiple(...deleteFilesNames).
  then(res => {
  if (AttachmentFiles.length > 0) {
  insertFormAttachment(uniqueID, AttachmentFiles);
  }else {
  Dispatcher.dispatch({ type: 'insertResultType', response: uniqueID });
  }
  }).catch(error => {
  console.log('insertFormAttachment ' + error);
  });
  };
  export { DeleteFormAttachment };
  
  

/********* */
/*Rich*/
const insertAttachRichTextFile = (results, files, itemId) => {
  let domparser = new DOMParser();
  let fileInfos = [];
  if (files != null) {
  for (let f of files) {
  let fileRead = new FileReader();
  fileRead.onloadend = (e) => {
  fileInfos.push({
  name: f.name,
  content: fileRead.result,
  });
  results.item.attachmentFiles.addMultiple(fileInfos).then(() => {
  results.item
  .select('ID,AttachmentFiles,Body')
  .expand('AttachmentFiles').get().then(async (results: any) => {
  let itemID = results.ID;
  let fileData = results.AttachmentFiles;
  
  let Body = results.Body;
  
  let parsedBody = domparser.parseFromString(Body,'text/html');
  await Promise.all([
  
  await parsedBody.querySelectorAll('img').forEach((img) => {fileData.forEach((fData) => {
  img.getAttribute('data-file-name') ===fData['FileName']? img.setAttribute('src',fData['ServerRelativeUrl'])
  : null;});}),
  ]);
  updateRichItem(itemID ,parsedBody);
  });
  });};
  fileRead.readAsArrayBuffer(f);
  }}};
  export { insertAttachRichTextFile };
  
  
  const updateRichItem = (itemID ,parsedBody) => {
  let s = new XMLSerializer();
  
  let serializeBody = s.serializeToString(parsedBody);
  sp.web.lists.getByTitle('Document').items.getById(itemID).update({
  
  'Body':serializeBody,
  }).then(res => {
  if (res.data != undefined) {
  Dispatcher.dispatch({ type: 'insertResultType', response: itemID });
  }
  }).catch(error => {
  console.log('updateRichItem ' + error);
  });
  };
  export { updateRichItem };
  
// const insertAttachRichTextFile = (results, files, itemId) => {
// let domparser = new DOMParser();
// let fileInfos = [];
// if (files != null) {
// for (let f of files) {
// let fileRead = new FileReader();
// fileRead.onloadend = (e) => {
// fileInfos.push({
// name: f.name,
// content: fileRead.result,
// });
// results.item.attachmentFiles.add(fileInfos).then(() => {
// results.item
// .select('ID,AttachmentFiles,Body')
// .expand('AttachmentFiles').get().then(async (results: any) => {
// let itemID = results.ID;
// let fileData = results.AttachmentFiles;

// let Body = results.Body;

// let parsedBody = domparser.parseFromString(Body,'text/html');
// await Promise.all([

// await parsedBody.querySelectorAll('img').forEach((img) => {fileData.forEach((fData) => {
// img.getAttribute('data-file-name') ===fData['FileName']? img.setAttribute('src',fData['ServerRelativeUrl'])
// : null;});}),
// ]);
// updateRichItem(itemID ,parsedBody);
// });
// });};
// fileRead.readAsArrayBuffer(f);
// }}}
// export { insertAttachRichTextFile };


const updateAttachRichTextFile = (results, files, itemId) => {
let domparser = new DOMParser();
sp.web.lists.getByTitle('Letters').items.getById(itemId).select('ID,AttachmentFiles,Body')
.expand('AttachmentFiles').get().then(async (fileResults: any) => {
let fileData = fileResults.AttachmentFiles;
let aFiles = [...fileData];

let Body = fileResults.Body;
aFiles.forEach(async (aFile) => {
let isExists = files.some((f) => f['name'] === aFile['FileName']);
if (isExists) {
parseUpdate(fileData, itemId,Body);
}
});
if (files.length > 0) {
let fileInfos = [];
for (let f of files) {
let fileRead = new FileReader();
fileRead.onloadend = (e) => {
fileInfos.push({
name: f.name,
content: fileRead.result,
});
results.item.attachmentFiles.add(fileInfos).then(() => {
results.item.select('ID,AttachmentFiles,Body')
.expand('AttachmentFiles').get().then(async (results: any) => {
let itemID = results.ID;
let fileData = results.AttachmentFiles;

let Body = results.Body;
parseUpdate(fileData, itemId,Body);


let parsedBody = domparser.parseFromString(Body,'text/html');
await Promise.all([


await parsedBody.querySelectorAll('img').forEach((img) => {fileData.forEach((fData) => {
img.getAttribute('data-file-name') ===fData['FileName']? img.setAttribute('src',fData['ServerRelativeUrl'])
: null;});}),

]);

updateRichItem(itemID ,parsedBody);
});
});
};
fileRead.readAsArrayBuffer(f);
}}
else if (files.length == 0) {
parseUpdate(fileData, itemId,Body);
}});}
export { updateAttachRichTextFile };




const parseUpdate = async (fileData,itemId,Body) => {
let fileLevlInfos = [];
let domparser = new DOMParser();


let parsedBody = domparser.parseFromString(Body,'text/html');

parsedBody.querySelectorAll('img').forEach((img) => {
let iName = img.getAttribute('data-file-name');
fileData.forEach((fData) => {
img.getAttribute('data-file-name') === fData['FileName']
? img.setAttribute('src', fData['ServerRelativeUrl']): null;
});
fileLevlInfos.indexOf(iName)
? console.log('exisitng file')
: fileLevlInfos.push(iName);
});
let item = await sp.web.lists.getByTitle('Letters').items.getById(itemId);
if (fileData.length !== fileLevlInfos.length) {
let fInfos = [];
fileData.forEach((aFile) => {
fInfos.push(aFile['FileName']);
});
let ainfos = fInfos.join('","');
let infos = ainfos.toString();
fileLevlInfos.length !== 0
? fileLevlInfos.forEach((rFile) => {
fileData.forEach(async (aFile) => {
rFile === aFile['FileName']? console.log(''): await item.attachmentFiles
.getByName(aFile['FileName']).delete();});})
: await item.attachmentFiles.deleteMultiple(infos);
};
};
export { parseUpdate };


const getmrk_deleteDetails = (Title) => {
sp.web.lists.getByTitle('Letters').fields.getByTitle(Title).get().then(res => {
Dispatcher.dispatch({ type: 'getmrk_deleteChoiceType', response:res});
}).catch(error => {
console.log('getDetails ' + error);
});
};
export {getmrk_deleteDetails};


