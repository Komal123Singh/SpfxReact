/* tslint:disable */
require("./FaqDocumentForm.module.css");
const styles = {
  faqDocumentForm: 'faqDocumentForm_4a1dee1f',
  container: 'container_4a1dee1f',
  row: 'row_4a1dee1f',
  column: 'column_4a1dee1f',
  'ms-Grid': 'ms-Grid_4a1dee1f',
  title: 'title_4a1dee1f',
  subTitle: 'subTitle_4a1dee1f',
  description: 'description_4a1dee1f',
  button: 'button_4a1dee1f',
  label: 'label_4a1dee1f'
};

export default styles;
/* tslint:enable */