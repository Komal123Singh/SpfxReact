import * as React from 'react';

import { IUserGuideFormProps } from './IUserGuideFormProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { sp } from "@pnp/sp"; 
import "@pnp/sp/webs"; 
import "@pnp/sp/site-users/web";
import { SPComponentLoader } from '@microsoft/sp-loader';
import { WebPartContext } from '@microsoft/sp-webpart-base';
// import {  } from '@pnp/spfx-controls-react/lib/dateTimePicker';
import { IconButton, ThemeProvider,ProgressIndicator, createTheme,ChoiceGroup,PrimaryButton,Checkbox,Dropdown,IDropdownStyles, DialogType, Dialog, DialogFooter,Icon,Label,Pivot,PivotItem,ILabelStyles,IStyleSet} from '@fluentui/react';
// import {  } from '@microsoft/office-ui-fabric-react-bundle';
import * as moment from 'moment';
import './UserGuideForm.module.scss';
import ViewUserGuide from './ViewUserGuide';
import  UserGuideStore from '../Store/UserGuideStore';
import * as UserGuideAction from '../Action/UserGuideAction';
import { TextField } from 'office-ui-fabric-react/lib/components/TextField/TextField';
import { remove, split } from 'lodash';
// import { List } from '@pnp/sp/lists';
import './UserGuideFormCss.css';
import { DefaultButton } from 'office-ui-fabric-react';
import { resultItem } from 'office-ui-fabric-react/lib/components/ExtendedPicker/PeoplePicker/ExtendedPeoplePicker.scss';



//Global variables
let uniqueId = 0;
let isEditMode = false;
let isViewMode = false;
let draftradiobtn=null;
let CategoryError='';
let EditFormDetails;
let categorylistarr;
let Userroleslistarr;
let Doctitlevalidation='';
let searchtermsvalidation='';
let statusvalidation='';
let userrolesvalidation='';
let attachmentvalidation='';
let actionBtnClicked='';
let updateAttachmentvalidation='';
let exitLocation;
let loadSpinner=false;
let test;
let selecteduserrole=false;
let result;
let absoluteUrl;


const myTheme = createTheme({
  palette: {
    themePrimary: '#23366f',
    themeLighterAlt: '#f3f4f9',
    themeLighter: '#cfd5e8',
    themeLight: '#a9b4d4',
    themeTertiary: '#6476a9',
    themeSecondary: '#344781',
    themeDarkAlt: '#203165',
    themeDark: '#1b2a55',
    themeDarker: '#141f3f',
    neutralLighterAlt: '#faf9f8',
    neutralLighter: '#f3f2f1',
    neutralLight: '#edebe9',
    neutralQuaternaryAlt: '#e1dfdd',
    neutralQuaternary: '#d0d0d0',
    neutralTertiaryAlt: '#c8c6c4',
    neutralTertiary: '#a19f9d',
    neutralSecondary: '#605e5c',
    neutralPrimaryAlt: '#3b3a39',
    neutralPrimary: '#323130',
    neutralDark: '#201f1e',
    black: '#000000',
    white: '#ffffff',
  }
});
const iconStyle = {
  root: {
    color: '#107c10',
    fontSize: '50px',
  }
};

let dialogContentProps = {
  type: DialogType.normal,
  title: 'Confirmation',
  closeButtonAriaLabel: 'Close',
  subText: '',
};

let dialogModelContentProps = {
  type: DialogType.normal,
  title: <div className="text-center"><div><Icon styles={iconStyle} iconName="SkypeCircleCheck"></Icon></div><div>Success</div></div>,
  closeButtonAriaLabel: 'Close',
  subText: '',
};
const dropdownStyles: Partial<IDropdownStyles> = {
  dropdownItems: { maxHeight: '250px' },
  dropdownItemsWrapper: { maxHeight: '250px' }
};
const labelStyles: Partial<IStyleSet<ILabelStyles>> = {
  root: { marginTop: 10 },
};

export interface MyState {
  webpartContxt: WebPartContext;
  
  FormAttachment: any;
  FormAttachmentNames: any;
  
  DocTitle:any;
  SearchTerms:any;
  Section:any;
  Status:any;
  
  Synopsys:any;
  StatusChoiceArr:any;
  Fileupload:any;
  subcategories:any;
  category:any;
  UserRole:any;
  categorieschoice:any;
  subCategrieschoicearr:any;
  SelectedCategoryitems:any;
  SelectedSubcategoryitems:any;
  Attachments:any;
  Userrolesdetailsarr:any;
  Date:any;
  UpdateAttachments:any;
  testloaditem:any;
  Lncreated:any;
  Lncreatedby:any;
  Lnmodified:any;
  Lnmodifiedby:any;
  isvalidRecord: boolean;
  isModalClose: boolean;
  isModaldialogClose: boolean;
  EhDate:any;
  EhRev:any;
  EhEditor:any;
  viewcategory:any;
  viewsubcategory:any
  viewUserroles:any;
  delAttach:any;
  sortedcategoryarr:any;
  isEditor:boolean;
  buttoncheck:any;
 
  
 
 
}

export default class UserGuideForm extends React.Component<IUserGuideFormProps, MyState> {
  constructor(prop) {
    super(prop);
    this.state = {
      webpartContxt: this.props.context,
      
      StatusChoiceArr:[{ key: 'Draft', text: 'Draft' },{key:'Published',text:'Published'}],
     
      DocTitle:'',
      FormAttachment: [],
      FormAttachmentNames: [],
      SearchTerms:'',
      Section:'',
      Status:'Draft',   
      Synopsys:'', 
      Fileupload:null,
      subcategories:[],
      category:[],
      UserRole:[],
      categorieschoice:[],
      subCategrieschoicearr:[],
      SelectedCategoryitems:null,
      SelectedSubcategoryitems:null,
      Attachments:[],
      Userrolesdetailsarr:[],
      Date:null,
      UpdateAttachments:[],
      testloaditem:[],
      Lncreated:null,
      Lncreatedby:null,
      Lnmodified:null,
      Lnmodifiedby:null,isvalidRecord: false,
      isModalClose: true,
      isModaldialogClose: true,
      EhDate:null,
      EhEditor:null,
      EhRev:null,
      viewcategory:[],
      viewsubcategory:[],
      viewUserroles:[],
      delAttach:[],
      sortedcategoryarr:[],
      isEditor:false,
      buttoncheck:'',
    };
    absoluteUrl= this.props.context.pageContext.site.absoluteUrl;
    SPComponentLoader.loadCss(absoluteUrl+'/SiteAssets/StyleSheet/bootstrap.min.css');
    SPComponentLoader.loadCss(absoluteUrl+'/SiteAssets/StyleSheet/suneditor.min.css');
    SPComponentLoader.loadScript(absoluteUrl+'/SiteAssets/JS/jquery.min.js');
    SPComponentLoader.loadScript(absoluteUrl+'/SiteAssets/JS/popper.min.js');
    SPComponentLoader.loadScript(absoluteUrl+'/SiteAssets/JS/bootstrap.min.js');
  }
  componentDidMount() {
  
    try {
      const url = window.location.href;
      const urlObject = new URL(url);
      uniqueId = urlObject.searchParams.get('itemID') == '' || urlObject.searchParams.get('itemID') == null ? 0 : parseInt(urlObject.searchParams.get('itemID'));
      
      // Call default form details
      this.getFormDefaultDetails();
      this.getLoggedUsersGroup();
      if (uniqueId != 0) {
        isViewMode = true;
        isEditMode = false;
        
       this.getEditFormDetailsComp();
      }
      else {
        isViewMode = false;
        isEditMode = true;
      }
        
      
    }
    catch (e) {
      console.log('componentDidMount: ' + e);
    }
  }

  getFormDefaultDetails = () => {
    try {
      UserGuideAction.getcategorieslistitemDetails();
      UserGuideAction.getUserRoleslistitemDetails();
      UserGuideStore.on('getcategorieslistitemDetailschange', this.Createcategorieschoicedetails); 
      UserGuideStore.on('getUserRoleslistitemDetailschange', this.CreateUserrolesdetails);
      UserGuideStore.on('insertResultchange', this.assignInsertResultStore);
      
    } catch (e) {
      console.log('getFormDefaultDetails' + e);
    }
  }
  getEditFormDetailsComp = () => {
    try {
      UserGuideAction.getEditFormDetails(uniqueId);
     UserGuideStore.on('getEditFormDetailschange', this.assignEditFormDetailsStore);
     
    } catch (e) {
      console.log('getEditFormDetailsComp' + e);
    }
  }

  public assignInsertResultStore = () => {
    try {
      if (UserGuideStore.getInserResultStoreValue() != undefined) {
        if (actionBtnClicked == "saveClose") {
          dialogModelContentProps.subText = 'This Form has been submitted sucessfully. Click Ok to exit';
          loadSpinner = false;
          this.setState({ isModaldialogClose: false });
        } 
      }
    } catch (e) {
      console.log('assignInsertResultStore: ' + e);
    }
  }
  // public assigncategorieslistitemDetailsStore = () => {
  //   debugger;

  //   categorieslistDetails = UserGuideStore.getcategorieslistitemStoreValue();
  //   let domparser = new DOMParser();
  //   let s = new XMLSerializer();
  //   if (categorieslistDetails.length != 0) {

  //     this.setState({
  //       subcategories:categorieslistDetails.Subcategories,
  //       category:categorieslistDetails.Category,
  //       UserRole:categorieslistDetails.AspireUserRoles,
        

  //     });
  //   }
  // }

  public assignEditFormDetailsStore = () => {
    debugger;

    EditFormDetails = UserGuideStore.getEditFormDetailsStoreValue();
    let domparser = new DOMParser();
    let s = new XMLSerializer();
    let subcategorydisplayarr=[];
    let categoryitemsarr=[];
    let tempserachterms=EditFormDetails.SearchTerms!=null?EditFormDetails.SearchTerms.split('\n'):[];
    if (EditFormDetails.length != 0) {
      let tempcategoryitem= EditFormDetails.Category!=null?EditFormDetails.Category.split(', '):[];
      this.categoryitemsfilterdetails(tempcategoryitem);

      this.setState({
         subcategories:EditFormDetails.Subcategory!=null?EditFormDetails.Subcategory.split(', '):[],
        
         category:EditFormDetails.Category!=null?EditFormDetails.Category.split(', '):[],
         UserRole:EditFormDetails.AspireUserRoles!=null?EditFormDetails.AspireUserRoles.split('\n'):[],
        SearchTerms:tempserachterms!=null?tempserachterms.join(', '):'',
        Status:EditFormDetails.Status,
        Synopsys:EditFormDetails.Synopsys,
        DocTitle:EditFormDetails.Title,
        UpdateAttachments:EditFormDetails.AttachmentFiles,
        Section:EditFormDetails.Section,
        Date:EditFormDetails.Created,
        
        Lncreated:EditFormDetails.LNCreated!=null? moment(EditFormDetails.LNCreated).format('MM/DD/YYYY LTS') : null,
        Lnmodified:EditFormDetails.LNModified!=null? moment(EditFormDetails.LNModified).format('MM/DD/YYYY LTS')  : null,
        Lncreatedby:EditFormDetails.LNCreatedBy,
        Lnmodifiedby:EditFormDetails.LNModifiedBy,
        viewcategory:EditFormDetails.Category,
        viewsubcategory:EditFormDetails.Subcategory,
        EhDate:EditFormDetails.EhDate,
        EhEditor:EditFormDetails.EhEditor,
        EhRev:EditFormDetails.EhRev,
        viewUserroles:EditFormDetails.AspireUserRoles,

      });
      this.setState({testloaditem:EditFormDetails});   
    }
  }
  
  public insertForm = () => {
    debugger;
    try {
      loadSpinner=true;
      this.setState({ isModalClose: true,buttoncheck:'disabledbutton'});
      let selectedcategorydetails= (this.state.category || []).join(', ');
      let SelectedSubcategoriesdetails=(this.state.subcategories || []).join(', ');
      let Selectedcheckboxdetails=(this.state.UserRole || []).join('\n');
      let username=this.props.context.pageContext.user.displayName;
      let date=moment().format('MM/DD/YYYY LTS');
      let editor=this.props.context.pageContext.user.displayName;
      let ehDate=moment().format('MM/DD/YYYY LTS');
      let Ehrev='0';
      let enrev=parseInt(this.state.EhRev);
      let year=moment(new Date()).format("YYYY");
    
      
        if(uniqueId==0){
       UserGuideAction.SaveForm(SelectedSubcategoriesdetails, this.state.SearchTerms,Selectedcheckboxdetails,selectedcategorydetails,this.state.Section,this.state.Status,this.state.DocTitle,this.state.Synopsys,this.state.Attachments,this.state.Date,date,username,date,username,Ehrev,editor,ehDate,year); 
        }
        else{
        let newdate= moment().format('MM/DD/YYYY LTS')+"\n"+this.state.EhDate;
          // let Dateupdate=newdate.join('\r\n')
          let newrev=enrev+1 ;
          let rev=newrev.toString()+"\n"+this.state.EhRev;
          let newEditor=this.props.context.pageContext.user.displayName+"\n"+this.state.EhEditor;
        
          UserGuideAction.updateForm(uniqueId,SelectedSubcategoriesdetails, this.state.SearchTerms,Selectedcheckboxdetails,selectedcategorydetails,this.state.Section,this.state.Status,this.state.DocTitle,this.state.Synopsys,this.state.Attachments,this.state.UpdateAttachments,this.state.delAttach,date,username,rev,newEditor,newdate);
        }
     
    }
    
    catch (e) {
      console.log('insertForm: ' + e);
    }
  }

  private CreateUserrolesdetails=()=>{
  
    try{
      let splitUserrolesarr=[];
      let Userrolesdetails;
     
     let Userroleslistitems=[];
     Userroleslistarr=UserGuideStore.getUserRoleslistitemStoreValue();
     Userrolesdetails=Userroleslistarr[0].AspireUserRoles;
      splitUserrolesarr=Userrolesdetails!=undefined?Userrolesdetails.split(/[\n,;]+/):[];
  
     if(splitUserrolesarr.length!=0){
     splitUserrolesarr.map((item)=>{
      Userroleslistitems.push({key: item, text:item,id:'AspireUserRoles'});
    
     
     });
    }
     this.setState({Userrolesdetailsarr:Userroleslistitems});
    
    }
    catch (e) {
     console.log('CreateUserrolesdetails: ' + e);
   }
  }

 private Createcategorieschoicedetails=()=>{
  debugger;
   try{
    categorylistarr=UserGuideStore.getcategorieslistitemStoreValue();
    if (categorylistarr != undefined && categorylistarr.length != 0) {
      categorylistarr.sort(function (a, b) {
        if (a.Title < b.Title) { return -1; }
        if (a.Title > b.Title) { return 1; }
        return 0;
      });
      this.setState({sortedcategoryarr:categorylistarr});
    let categorieslistchoice=[];
    if(this.state.sortedcategoryarr.length!=0){
    this.state.sortedcategoryarr.map((item) => {
      categorieslistchoice.push({ key: item.Title, text: item.Title, id:'Category' });
    });
  }
this.setState({categorieschoice:categorieslistchoice});
   }
  }
   catch (e) {
    console.log('Createcategorieschoicedetails: ' + e);
  }
 }
 
 private inputmultiplecheckboxChange = (ev: React.FormEvent<HTMLInputElement>, isChecked: boolean) => {

 try {
       let inputvalue=ev.currentTarget.title;
         let selectedUserRoles=this.state.UserRole;
       
         if(isChecked==true){
          selectedUserRoles=[...selectedUserRoles,inputvalue];
        
         }
         else{
          selectedUserRoles=selectedUserRoles.filter(key=>key!=inputvalue);
           }
           this.setState({ UserRole: selectedUserRoles });
        //  this.UserRolesitemsfilterdetails(inputValue);
      
       
          }
          
 catch (e) {
   console.log('inputmultiplecheckboxChange: ' + e);
 }
}
private checkboxdetails=()=>{

  try{
   
   
    let options=this.state.Userrolesdetailsarr;
  let retrieveduserrole =this.state.UserRole;

 return options.map((checkBoxItem) => { 
   let status=false;
  for(var j=0; j<retrieveduserrole.length; j++){
  if(checkBoxItem.text==retrieveduserrole[j]){
status=true;

  }
  }
      return (
           <div className='form-check form-check-inline' ><Checkbox label={checkBoxItem.text} title={checkBoxItem.text} defaultChecked={status}   onChange={this.inputmultiplecheckboxChange}/></div>
   );
   });
    
  }

  catch (e) {
    console.log('checkboxdetails: ' + e);
  }
}

bindAttachmentFileNames() {
  try {
      return this.state.UpdateAttachments.map((item, idx) => {
          //let fileName = item.FileName;
               let downloadUrl = this.props.context.pageContext.web.absoluteUrl + "/_layouts/download.aspx?sourceurl=" + this.state.UpdateAttachments[idx].ServerRelativeUrl;  
          return (
              <div><span><a data-interception="off" target='_blank' href={this.state.UpdateAttachments[idx].ServerRelativePath.DecodedUrl}>{this.state.UpdateAttachments[idx].FileName}</a>
                  <IconButton className='mt-1' iconProps={{ iconName: 'Delete' }} title='Delete' ariaLabel='Delete' onClick={this.deleteAttachment.bind(this, this.state.UpdateAttachments[idx].FileName)} />
                  </span></div>
              )

      });
  }
  catch (e) {
      console.log('bindAttachmentFileNames ' + e);
  }
}
private deleteAttachment = (DeleteFileName) => {
debugger;
  try{
 //remove(this.state.EditAttachments);
 let tempEditAttachment=this.state.UpdateAttachments;
 let tempDeleteAttachment=this.state.delAttach;
 let result;
  
  // let index=tempEditAttachment.indexOf(DeleteFileName);
  var index = tempEditAttachment.findIndex(function(DeleteItem) {
    return DeleteItem.FileName == DeleteFileName
   
  });
  tempEditAttachment.splice(index,1);
  this.setState({UpdateAttachments:tempEditAttachment});

  tempDeleteAttachment.push(DeleteFileName);

  this.setState({delAttach:tempDeleteAttachment})




}
catch (e) {
  console.log('deleteAttachment: ' + e);
}
}


 private inputDropDownDetailsChange = (inputValue) => {
  
  debugger;
  try {
    switch (inputValue.id) {
      case 'Category':
        {
          let selectedcategory=this.state.category;
        
          if(inputValue.selected){
            // selectedcategory.push(inputValue.key);
            selectedcategory=[...selectedcategory,inputValue.key];
          this.setState({ category: selectedcategory });
          }
          else{
          //  let index=selectedcategory.indexOf(inputValue.key);
          //     selectedcategory.splice(index,1);
          selectedcategory=selectedcategory.filter(key=>key!=inputValue.key);
              this.setState({category:selectedcategory});
            
            }
      
          this.categoryitemsfilterdetails(selectedcategory);
        
          break;
        }
        case 'Subcategories':

        {
         
          let selectedsubcategory= this.state.subcategories;
          
          if(inputValue.selected){
           
            selectedsubcategory=[...selectedsubcategory,inputValue.key];
         
          }
          else{
            // let index=selectedsubcategory.indexOf(inputValue.key);
            //    selectedsubcategory.splice(index,1);
            selectedsubcategory=selectedsubcategory.filter(key=>key!=inputValue.key);
               
             }
             this.setState({ subcategories: selectedsubcategory });
        
          break;
        }
    }
  }
  catch (e) {
    console.log('inputDropDownDetailsChange: ' + e);
  }
}

getLoggedUsersGroup = async () => {
  try { 
    await sp.web.currentUser.groups().then(LoggedUsersGroup=>{
    let permissionupdated=false;
    LoggedUsersGroup.map((groupItem) => {
     if(permissionupdated==false) {
      if (groupItem.Title == "USZ_ZSPIREHomePage_Access_Admins"||groupItem.Title == "USZ_ZSPIREHomePage_Admins"||groupItem.Title == "USZ_ZSPIREHomePage_Editors"
    ||groupItem.Title == "Z-SPIRE Homepage & User guide Owners"||groupItem.Title == "Z-SPIRE Homepage & User guide Members")
     {
      permissionupdated=true;
      this.setState({isEditor:true});
    } 
     }
    
    }) 
  }); 
  } catch (e) {
  console.log('getLoggedUsersGroup' + e);
  }
  } 
checkFormValidation = (actionClick) => {
  
  try {
    Doctitlevalidation='';
    searchtermsvalidation='';
    statusvalidation='';
    userrolesvalidation='';
    attachmentvalidation='';
    updateAttachmentvalidation='';
    // Assign action value
    actionBtnClicked = actionClick;

    // Validation Check
    let Attachments=(this.state.Attachments || []).join(', ')
    let UpdateAttachments=(this.state.UpdateAttachments || []).join(', ')
    searchtermsvalidation = this.state.SearchTerms == '' ? 'Please enter the search keywords' : '';
    Doctitlevalidation = this.state.DocTitle == '' ? 'Please enter the title' : '';
    userrolesvalidation = this.state.UserRole == '' ? 'Please provide user role' : '';
    attachmentvalidation = (Attachments   == ''  && UpdateAttachments=='') ?'Please add an attachment' : '';
    // updateAttachmentvalidation = (this.state.UpdateAttachments   == '' && this.state. ? 'Please add an attachment' : '';
    if ( searchtermsvalidation != '' || Doctitlevalidation != '' || userrolesvalidation !='' || attachmentvalidation!='' ) {
      this.setState({ isvalidRecord: false });
    } else {
      this.modalPopupOpen(actionBtnClicked);
      this.setState({ isvalidRecord: true });
    }
  }
  catch (e) {
    console.log('checkFormValidationChange: ' + e);
  }
}

modalPopupOpen = (actionCall) => {

  try {
    actionBtnClicked = actionCall;
    if (actionBtnClicked == 'close') {
      dialogContentProps.title = 'Close Confirmation';
      dialogContentProps.subText = 'Are you sure you want to close this Form?';
    } else if (actionBtnClicked == 'saveClose') {
      dialogContentProps.title = 'Save Confirmation';
      dialogContentProps.subText = 'Do you want to save this details?';
    }
    
    this.setState({ isModalClose: false });
  } catch (e) {
    console.log('modalPopup: ' + e);
  }
}

modalPopupClose = () => {
  try {
    this.setState({ isModalClose: true });
  } catch (e) {
    console.log('modalPopup: ' + e);
  }
}

modalSubmitClick = () => {
 
  try {
    if (actionBtnClicked == 'close') {
      this.Exitform();
    }
     else if (actionBtnClicked == 'saveClose') {
      //actionBtnClicked = this.state.ProcessStatus == 'Complete' ? 'Complete' : actionBtnClicked;
      this.insertForm();
    }
  } catch (e) {
    console.log('modalSubmitClick: ' + e);
  }
}
selectedsubcategoriesdetails=(Subcategorieschoice)=>{
  debugger;
  try{
    let tempsubcategory=[];
    
    this.state.subcategories.map((subcategoriesitems)=>{
    let  subcategorycheck=Subcategorieschoice.filter(item=>item.key==subcategoriesitems);
    
     if(subcategorycheck.length!=0){
       tempsubcategory.push(subcategoriesitems);
     }
  });
  this.setState({subcategories:tempsubcategory});


    // let splitsubcategories=[];
    // let subcategoriesdetail;
 
    // subcategoriesdetail=result[0].Subcategories;
    // splitsubcategories=subcategoriesdetail!=undefined?subcategoriesdetail.split(/[\n,;]+/):[];
    // for(var j=0; j<splitsubcategories.length; j++){
    // for(var i=0; i<selectedsubcategory.length; i++){
    // if(splitsubcategories[j]!=selectedsubcategory[i]){
    //   let index=selectedsubcategory.indexOf(splitsubcategories[j]);
    //   selectedsubcategory.splice(index,1);
    //   this.setState({subcategories:selectedsubcategory});

    // }
    // else{
      
    //   this.setState({subcategories:selectedsubcategory[i]});
     
    // }
    // }
  

 
 

  }
  catch (e) {
    console.log('retrievedsubcategoriesdetails: ' + e);
  }
}
private categoryitemsfilterdetails = (selectedcategory) => {
debugger;
 try {
  
   let subcategoriesdetails;
   let Subcategorieschoice=[];
   let splitsubcategoriesarr=[];
 selectedcategory.map((selectedsubcategoriesitems)=>{
  
 result=categorylistarr.filter(item=>item.Title==selectedsubcategoriesitems);
console.log(result);
subcategoriesdetails=result[0].Subcategories;
splitsubcategoriesarr=subcategoriesdetails!=undefined?subcategoriesdetails.split(/[\n,;]+/):[];
if(splitsubcategoriesarr.length!=0)

{
  splitsubcategoriesarr.map((subcategoriesitems)=>{
Subcategorieschoice.push({key: subcategoriesitems, text: subcategoriesitems, id:'Subcategories'});
  });
  
}

});
this.setState({subCategrieschoicearr:Subcategorieschoice});
this.selectedsubcategoriesdetails(Subcategorieschoice);

 }
 catch (e) {
   console.log('categoryitemsfilterdetails: ' + e);
 }
}


  // Get Input Details
  private inputFormChange = (inputValue) => {
  
    try {
      switch (inputValue.target.name) {

        case 'DocTitle':
          {
            this.setState({ DocTitle: inputValue.target.value });
            break;
          }
          case 'Synopsys':
            {
              this.setState({ Synopsys: inputValue.target.value });
              break;
            }
            case 'Section':
          {
            this.setState({ Section: inputValue.target.value });
            break;
          }
          case 'SearchTerms':
          {
            this.setState({ SearchTerms: inputValue.target.value });
            break;
          }
         
      }
    }
    catch (e) {
      console.log('inputFormChange: ' + e);
    }
  }
  private draftRadioBtnChange = (ev: React.FormEvent<HTMLInputElement>, option: any) => {
   

    this.setState({ Status:option.Key });
  
  }
  private filesave=(newattach)=>{
 
    try {
 
      let fileInfos = [];
     
    for(var i=0;i<newattach.target.files.length;i++){
      debugger;
            fileInfos.push({
                name:newattach.target.files[i].name,
                content:newattach.target.files[i]
            }); 
          }
    this.setState({ Attachments:fileInfos});
      
    } catch (e) {
      console.log('filesave: ' + e);
    }

  }
  private showattach= ()=>{
    try{
      debugger;
      let showitem=this.state.Attachments;
      return showitem.map((item, idx) => {
      
        return(
              <div><span><a href=''>{showitem[idx].name}</a>
              </span>
              </div>
        )
    })
    }
    catch(e){
      console.log('showattach: ' + e);
  
  }
  }
  modalPopupOpenView = (actionCall) => {
    debugger;

    try {
      actionBtnClicked = actionCall; 
      if (actionBtnClicked == 'close') {  
        dialogContentProps.title = 'close Confirmation'; 
        dialogContentProps.subText = 'Are you sure you want to close the form?'; 
      }
      this.setState({ isModalClose: false });     
    } catch (e) { 
      console.log('modalPopup: ' + e);  
    }
  }
  Exitform = () => {
    debugger;
    try {
      window.open('','_parent','');
      window.close();
  
    } catch (e) {
  
      console.log('Exitform: ' + e);
    } 
  }
  Exit = () => {

    try {
      window.open('','_parent','');
      window.close();

    } catch (e) {

      console.log('CloseForm: ' + e);
    }
  }
  private tabledetails = () => {
    debugger;
    try {
    let splitEheditor=this.state.EhEditor!=undefined?this.state.EhEditor.split('\n'):[];
    let splitEhrev=this.state.EhRev!=undefined?this.state.EhRev.split('\n'):[];
    let splitEhdate=this.state.EhDate!=undefined?this.state.EhDate.split('\n'):[];
    // for(var i=0; i<splitEhrev.length; i++){
    //   splitEhrev[i] = splitEhrev[i] + '<br />'
    // }
    return(
      <table className="table table-bordered border-spacing:2px text-center ">
                      <thead>
                        <tr>
                          <th scope="col">Rev.</th>
                          <th scope="col">Editor</th>
                          <th scope="col">Edit Date</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        {splitEhrev.filter((item, index) => index < 10).map((items,index)=>{
                          // for(var j=0; j<splitEheditor.length;j++ ){
                          // for(var k=0; k<splitEhdate.length;k++){
                          //   if(index==j){
                          //     if(j==k){
                          return(
                        <tr >
                          <td className='text-center'>{items}</td>
                          
                          <td className='text-center'>{splitEheditor[index]}</td>
                          <td className='text-center'>{splitEhdate[index]}</td>
                          
                        </tr>
                          )
                        // )}}}}
                          })}
                      </tbody>
                    </table>
    )
   
    
    } catch (e) {
  
      console.log('tabledetails: ' + e);
    } 
  }
  public EditClickBtn = () => {
    try {
      isEditMode = true;
      isViewMode = false;
      this.getEditFormDetailsComp();
    } catch (e) {
      console.log('EditClickBtn' + e);
    }
  }

  public ViewClickBtn = () => {
    try {
      isEditMode = false;
      isViewMode = true;
      this.getEditFormDetailsComp();
    } catch (e) {
      console.log('ViewClickBtn' + e);
    }
  }

 
  public render(): React.ReactElement<IUserGuideFormProps> {
    debugger;
    return (
      <ThemeProvider theme={myTheme}>
        <div className={this.state.buttoncheck+' container'}>
          <div className='border p-3' style={{ backgroundColor: '#23366f' }}>
            <div className='row'>
              <div className='col-md-6'><h3 className="text-light ">{this.props.description}</h3></div>
              <div className='col-md-6 text-right'><img src={this.props.logo} alt='Logo' width='50' height='50' /></div>
            </div>
            
          </div> 
          {isViewMode == true && isEditMode == false ?
          <div>
            <div className='buttonCls mt-2'>
            <DefaultButton className=' m1-1 md-2' text='Close Window' onClick={this.modalPopupOpenView.bind(this, 'close')} allowDisabledFocus />
            {this.state.isEditor==true?<PrimaryButton className='ml-1 ' text='Edit Document' onClick={this.EditClickBtn} allowDisabledFocus />:null}
            
           <div className= 'mt-1'><Pivot aria-label="Basic Pivot Example">
           <PivotItem className='mt-3' headerText="Document Info ">
           <div style={{ backgroundColor: '' }}><ViewUserGuide {...this.state} /></div>
      </PivotItem>
           <PivotItem className='mt-3' headerText="Edit history">
       <label className='col md-12'>{this.tabledetails()}</label>
      </PivotItem>
    </Pivot>
    </div>
            </div> </div> :
          <div>
          <div className='buttonCls mt-2'>
            
          <DefaultButton className='' text='Close' onClick={this.modalPopupOpen.bind(this, 'close')} allowDisabledFocus />
            <PrimaryButton className='ml-1' text='Save & Close' onClick={this.checkFormValidation.bind(this, 'saveClose')} allowDisabledFocus />
          </div>
          {loadSpinner==true?<ProgressIndicator label="Submitting Details" />:null}
          
         
          <div className='row p-6 mt-2'>
            <div className='col-md-6'><p >Created on {(this.state.Date!=null)?(moment(this.state.Date).format('MM/DD/YYYY')):moment().format('MM/DD/YYYY')}</p></div>
            <div className='col-md-6 text-right style required'><b className='control'></b> Signifies a Required Field</div>
              </div>
          
          
          <div className='border p-3 mt-1'>
          <div className='row mt-2 '>
                <div  className='col-md-3 form-group required'><b className='control-label' >Document Title:</b></div>
                <div className='col-md-8'> 
                 <TextField className='w-75'  value={this.state.DocTitle} placeholder={'Enter the Document title'} name='DocTitle' errorMessage={Doctitlevalidation} onChange={this.inputFormChange}  />
                 </div>
                </div>
                <div className='row mt-2'>
                <div  className='col-md-3 '><b >Synopsis:</b></div>
                <div className='col-md-8'>
                <TextField className='w-75' value={this.state.Synopsys}  placeholder={'Enter the synopsis'} name='Synopsys' onChange={this.inputFormChange}/> 
                </div>
               </div>
               <div className='row mt-2'>
                 <div  className='col-md-3'><b >Topic Number:</b></div>
                 <div className='col-md-8'>
                 <TextField className='w-75'  value={this.state.Section} name='Section' placeholder={'Enter the Topic number'}  onChange={this.inputFormChange}/>
                 </div>
               </div>
               <div className='row mt-2'>
                 <div  className='col-md-3'><b >Category:</b></div>
                 <div className='col-md-8'>
                 <Dropdown className='w-75' styles={dropdownStyles} placeholder={'Select Category'}  multiSelect errorMessage={CategoryError}   selectedKeys={this.state.category}  options={this.state.categorieschoice} onChanged={this.inputDropDownDetailsChange}  />
                 </div>
               </div>
               <div className='row mt-2'>
                 <div  className='col-md-3'><b >Subcategory:</b></div>
                 <div className='col-md-8'>
                 <Dropdown className='w-75' styles={dropdownStyles} placeholder={'Select Subcategories'} multiSelect errorMessage={CategoryError}  selectedKeys={this.state.subcategories}  options={this.state.subCategrieschoicearr} onChanged={this.inputDropDownDetailsChange}  />
                 </div>
               </div>
               <div className='row mt-2'>
                 <div  className='col-md-3 form-group required'><b className='control-label'>Search Keywords:</b></div>
                 <div className='col-md-8'>
                 <TextField className='w-75' multiline value={this.state.SearchTerms} placeholder={'Enter the Search keywords'} maxLength={250} name='SearchTerms' errorMessage={searchtermsvalidation} onChange={this.inputFormChange}/>
                 </div>
               </div>
               <div className='row mt-2'>
                 <div  className='col-md-3 form-group required'><b className='control-label'>Document Status:</b></div>
                 <div className='col-md-8 form-horizontal'> <ChoiceGroup className='w-100 inlineflex radio-inline'  selectedKey={this.state.Status}  options={this.state.StatusChoiceArr} onChange={this.draftRadioBtnChange} />
                 </div>
               </div>
               <div className='row mt-2'>
                 <div  className='col-md-3 form-group required'><b className='control-label'>User roles:</b></div>
                 <div className='col-md-6 '> {this.checkboxdetails()} 
                 <div className=' text'>{userrolesvalidation}</div>
                 </div>
   
               </div>
               
               <div className='row mt-2'>
                 <div className='col-md-3 form-group required'><b className='control-label'>Attachment:</b></div>
                 <div className='col-md-8'>
                 <input className='ReactFieldEditor-Attachments-UploadInput mt-2' type='file' name='attachmentFiles' title='Attach Files' aria-required='false' aria-label='Attach Files' multiple onChange={this.filesave}/>
                 <div>{this.showattach()}</div>
                 <div>{this.bindAttachmentFileNames()}</div>
                 <span className='text'>{attachmentvalidation}</span>
                 {/* {this.state.Attachments==''?<span className='text-danger'>{attachmentvalidation}</span>:null}
                 {this.state.UpdateAttachments==''?<span className='text-danger'>{updateAttachmentvalidation}</span>:null} */}
                 </div>
               </div>
    
                  </div>
                  </div>}
                  <Dialog minWidth={'460px'} maxWidth={'520px'} hidden={this.state.isModalClose} onDismiss={this.modalPopupClose} dialogContentProps={dialogContentProps}>
            <DialogFooter>
              <DefaultButton onClick={this.modalPopupClose} text="No" />
              <PrimaryButton onClick={this.modalSubmitClick} text="Yes" />
            </DialogFooter>
          </Dialog>
          <Dialog minWidth={'380px'} hidden={this.state.isModaldialogClose} dialogContentProps={dialogModelContentProps}>

            <DialogFooter>

              <PrimaryButton style={{ textAlign: 'center' }} onClick={this.Exit} text="OK" />

            </DialogFooter>

          </Dialog>
        </div>
        
        </ThemeProvider>
    );
  }
}
