declare interface IUserGuideFormWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'UserGuideFormWebPartStrings' {
  const strings: IUserGuideFormWebPartStrings;
  export = strings;
}
