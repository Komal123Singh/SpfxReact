import { EventEmitter } from 'events';
declare class ReleaseDocumentStore extends EventEmitter {
    constructor();
    storeChange(action: any): void;
    getEditClickStoreValue(): any[];
    getInserResultStoreValue(): any;
    getDropdownDetailsStoreValue(): any[];
}
declare let objReleaseDocumentStore: ReleaseDocumentStore;
export default objReleaseDocumentStore;
//# sourceMappingURL=ReleaseDocumentStore.d.ts.map