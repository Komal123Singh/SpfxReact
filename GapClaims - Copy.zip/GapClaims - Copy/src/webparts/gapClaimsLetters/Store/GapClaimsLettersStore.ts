import {EventEmitter} from 'events';
import { Dispatcher } from 'simplr-flux';


let mrk_deleteStoreResp= [];
let EditFormDetails = [];
let savedResult;
let savevalue;

let getTypedetails=[];

class GapClaimsLettersStore extends EventEmitter {

constructor() {
super();
}

storeChange(action){
switch(action.action.type){
case 'getEditFormDetailsType':
{
EditFormDetails = action.action.response;
this.emit('getEditFormDetailschange');
break;
}
case 'insertResultType':
{
savedResult = action.action.response;
this.emit('insertResultchange');
break;
}
case 'AssignResultType':
    {
        savevalue=action.action.response;
        this.emit('AssignResultchange')
    }
case 'getPaymentTypevalues':
    {
        getTypedetails=action.action.response;
        this.emit('PaymenTypeChange');
    }
case 'getmrk_deleteChoiceType':
{
mrk_deleteStoreResp=action.action.response.Choices;
this.emit('mrk_deletechange');
break;
}
}
}
getEditClickStoreValue(){
return EditFormDetails;
}
getInserResultStoreValue(){
return savedResult;
}
getPaymentTypeDetailsList() {

    return getTypedetails;

}

getmrk_deleteChoiceStoreValue() {
return mrk_deleteStoreResp;
}
}

let objGapClaimsLettersStore = new GapClaimsLettersStore();

Dispatcher.register(objGapClaimsLettersStore.storeChange.bind(objGapClaimsLettersStore));

export default objGapClaimsLettersStore;
