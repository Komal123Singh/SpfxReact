/* tslint:disable */
require("./savedata.module.css");
const styles = {
  parent: 'parent_4d2847d4',
  child: 'child_4d2847d4',
  subchild: 'subchild_4d2847d4',
  h: 'h_4d2847d4',
  txt: 'txt_4d2847d4',
  lbl1: 'lbl1_4d2847d4',
  lbl: 'lbl_4d2847d4',
  mar1: 'mar1_4d2847d4',
  btn: 'btn_4d2847d4',
  sett: 'sett_4d2847d4'
};

export default styles;
/* tslint:enable */