import * as React from 'react';
import styles from './Crud.module.scss';
import { ICrudProps } from './ICrudProps';
import { escape } from '@microsoft/sp-lodash-subset';
import {
  SPHttpClient,
  SPHttpClientResponse
} from '@microsoft/sp-http';
export default class Crud extends React.Component<ICrudProps, {}> {
  private Create = (): void => {
    const body: string = JSON.stringify({
      'Title': document.getElementById("Name")['value'],
     
    });
    this.props.context.spHttpClient.post(`${this.props.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('Spfxlist')/items`,
      SPHttpClient.configurations.v1, {
      headers: {
        'Accept': 'application/json;odata=nometadata',
        'Content-type': 'application/json;odata=nometadata',
        'odata-version': ''
      },
      body: body
    })
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            console.log(responseJSON);
            alert(`Item created successfully with ID: ${responseJSON.ID}`);
          });
        } else {
          response.json().then((responseJSON) => {
            console.log(responseJSON);
            alert(`Something went wrong! Check the error in the browser console.`);
          });
        }
      }).catch(error => {
        console.log(error);
      });
  }
  private Read = (): void => {
    this.props.context.spHttpClient.get(this.props.context.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('Spfxlist')/items`,
      SPHttpClient.configurations.v1,
      {
        headers: {
          'Accept': 'application/json;odata=nometadata',
          'odata-version': ''
        }
      })
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            var html = `<table><tr><th>ID</th><th>Full Name</th><th>Age</th></tr>`;
            responseJSON.value.map((item, index) => {
              html += `<tr><td>${item.ID}</td><td>${item.Title}</td></li>`;
            });
            html += `</table>`;
            document.getElementById("getall").innerHTML = html;
            console.log(responseJSON);
          });
        } else {
          response.json().then((responseJSON) => {
            console.log(responseJSON);
            alert(`Something went wrong! Check the error in the browser console.`);
          });
        }
      }).catch(error => {
        console.log(error);
      });
  }
 
  private Update = (): void => {
    const id: number = document.getElementById('itemId')['value'];
    const body: string = JSON.stringify({
      'Title': document.getElementById("Name")['value'],
      // 'Age': document.getElementById("age")['value']
    });
    if (id > 0) {
      this.props.context.spHttpClient.post(`${this.props.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('Spfxlist')/items(${id})`,
        SPHttpClient.configurations.v1,
        {
          headers: {
            'Accept': 'application/json;odata=nometadata',
            'Content-type': 'application/json;odata=nometadata',
            'odata-version': '',
            'IF-MATCH': '*',
            'X-HTTP-Method': 'MERGE'
          },
          body: body
        })
        .then((response: SPHttpClientResponse) => {
          if (response.ok) {
            alert(`Item with ID: ${id} updated successfully!`);
          } else {
            response.json().then((responseJSON) => {
              console.log(responseJSON);
              alert(`Something went wrong! Check the error in the browser console.`);
            });
          }
        }).catch(error => {
          console.log(error);
        });
    }
    else {
      alert(`Please enter a valid item id.`);
    }
  }
 
  
// Delete Item
  private Delete = (): void => {
    const id: number = parseInt(document.getElementById('itemId')['value']);
    if (id > 0) {
      this.props.context.spHttpClient.post(`${this.props.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('Spfxlist')/items(${id})`,
        SPHttpClient.configurations.v1,
        {
          headers: {
            'Accept': 'application/json;odata=nometadata',
            'Content-type': 'application/json;odata=verbose',
            'odata-version': '',
            'IF-MATCH': '*',
            'X-HTTP-Method': 'DELETE'
          }
        })
        .then((response: SPHttpClientResponse) => {
          if (response.ok) {
            alert(`Item ID: ${id} deleted successfully!`);
          }
          else {
            alert(`Something went wrong!`);
            console.log(response.json());
          }
        });
    }
    else {
      alert(`Please enter a valid item id.`);
    }
  }
  public render(): React.ReactElement<ICrudProps> {
    return (
      <div className={ styles.crud }>
        <div className={ styles.container }>
          <div className={ styles.row }>
            <div className={ styles.column }>
            <div>
               <div>Id:</div>
               <input type="text" id='itemId'></input>
             </div>
            <div>
               <div>Location:</div>
               <input type="text" id='Name'></input>
             </div>
             <div id="getall"></div>
            
             <div className={styles.button}>
                 <span className={styles.label} onClick={this.Create}>Create</span>
               </div>
               <div className={styles.button}>
                 <span className={styles.label} onClick={this.Read}>Read</span>
               </div>
               <div className={styles.button}>
                  <span className={styles.label} onClick={this.Update}>Update</span>
                </div>
                <div className={styles.button}>
                  <span className={styles.label} onClick={this.Delete}>Delete</span>
                </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

}
