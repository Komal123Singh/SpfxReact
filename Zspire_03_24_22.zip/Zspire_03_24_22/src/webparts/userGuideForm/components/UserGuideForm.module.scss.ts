/* tslint:disable */
require("./UserGuideForm.module.css");
const styles = {
  userGuideForm: 'userGuideForm_5f27dbab',
  container: 'container_5f27dbab',
  row: 'row_5f27dbab',
  column: 'column_5f27dbab',
  'ms-Grid': 'ms-Grid_5f27dbab',
  title: 'title_5f27dbab',
  subTitle: 'subTitle_5f27dbab',
  description: 'description_5f27dbab',
  button: 'button_5f27dbab',
  label: 'label_5f27dbab'
};

export default styles;
/* tslint:enable */