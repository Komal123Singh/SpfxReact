import { EventEmitter } from 'events';
import { Dispatcher } from 'simplr-flux';
let EditFormDetails = [];
let savedResult;
class NewsArticleStore extends EventEmitter {

    constructor() {
        super();
    }
    storeChange(action) {
        switch (action.action.type) {
            case 'getEditFormDetailsType':
                {
                    EditFormDetails = action.action.response;
                    this.emit('getEditFormDetailschange');
                    break;
                }
            case 'insertResultType':
                {
                    savedResult = action.action.response;
                    this.emit('insertResultchange');
                    break;
                }
        }
    }
    getEditClickStoreValue() {
        return EditFormDetails;
    }
    getInserResultStoreValue() {
        return savedResult;
    } 
}

let objNewsArticleStore = new NewsArticleStore();

Dispatcher.register(objNewsArticleStore.storeChange.bind(objNewsArticleStore));

export default objNewsArticleStore;

