export interface IHelloWorldProps {
  description: string;
}
