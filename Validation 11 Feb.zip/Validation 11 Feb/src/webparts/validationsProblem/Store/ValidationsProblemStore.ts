import {EventEmitter} from 'events';
import { Dispatcher } from 'simplr-flux';


let EditFormDetails = [];
let savedResult;
let DocConfigDetails = [];
let AdminDetails = [];
let ProblemDetails =[];

class ValidationsProblemStore extends EventEmitter {

constructor() {
super();
}

storeChange(action){
    debugger;
switch(action.action.type){
case 'getEditFormDetailsType':
{
EditFormDetails = action.action.response;
this.emit('getEditFormDetailschange');
break;
}
case 'insertResultType':
{
savedResult = action.action.response;
this.emit('insertResultchange');
break;
}
case 'getDocTypeType' :
                 {
                     DocConfigDetails = action.action.response;
                     this.emit('getDocTypechange');
                     break;
                 }
case 'getAdminvalues':
                 {
                   AdminDetails = action.action.response
                   this.emit('Adminlist');
                   break;
                 }
 case 'getProbelmvalues':
                    {
                      ProblemDetails = action.action.response
                      this.emit('Problemlist');
                      break;
                    }                


}
}
getEditClickStoreValue(){
return EditFormDetails;
}
getInserResultStoreValue(){
return savedResult;
}
getDocConfigDetails() {
    return DocConfigDetails;
}
getAdminDetails(){
    return AdminDetails;
}
getProblemDetails(){
    return ProblemDetails;
}

}

let objValidationsProblemStore = new ValidationsProblemStore();

Dispatcher.register(objValidationsProblemStore.storeChange.bind(objValidationsProblemStore));

export default objValidationsProblemStore;