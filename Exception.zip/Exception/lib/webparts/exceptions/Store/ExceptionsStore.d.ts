import { EventEmitter } from 'events';
declare class ExceptionsStore extends EventEmitter {
    constructor();
    storeChange(action: any): void;
    getEditClickStoreValue(): any[];
    getInserResultStoreValue(): any;
    getListChoicesStoreValue(): any[];
    getAdminDetailsStoreValue(): any[];
    getDefSubCatgDetailsStoreValue(): any[];
    getDefScopeDetailsStoreValue(): any[];
    getListMakeDetailsStoreValue(): any[];
    getUserGroupDetailsStoreValue(): any[];
    getAccountNumberDetailsStoreValue(): any[];
    getUserInfoDetailStoreValue(): any[];
    sendEmailStoreValue(): any[];
    getExceptionLogStoreValue(): any[];
}
declare let objExceptionsStore: ExceptionsStore;
export default objExceptionsStore;
//# sourceMappingURL=ExceptionsStore.d.ts.map