import { EventEmitter } from 'events';
declare class UserGuideStore extends EventEmitter {
    constructor();
    storeChange(action: any): void;
    getEditFormDetailsStoreValue(): any[];
    getcategorieslistitemStoreValue(): any[];
    getUserRoleslistitemStoreValue(): any[];
    getInserResultStoreValue(): any;
}
declare let objUserGuideStore: UserGuideStore;
export default objUserGuideStore;
//# sourceMappingURL=UserGuideStore.d.ts.map