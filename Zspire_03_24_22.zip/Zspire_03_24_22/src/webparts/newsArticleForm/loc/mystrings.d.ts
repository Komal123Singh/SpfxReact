declare interface INewsArticleFormWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'NewsArticleFormWebPartStrings' {
  const strings: INewsArticleFormWebPartStrings;
  export = strings;
}
