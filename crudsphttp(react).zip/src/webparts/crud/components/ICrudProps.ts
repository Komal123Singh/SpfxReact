export interface ICrudProps {
  description: string;
  context: any;
}
