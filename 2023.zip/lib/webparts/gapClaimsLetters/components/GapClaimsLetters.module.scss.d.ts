declare const styles: {
    gapClaimsLetters: string;
    container: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=GapClaimsLetters.module.scss.d.ts.map