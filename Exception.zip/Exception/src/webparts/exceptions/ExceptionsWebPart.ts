import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'ExceptionsWebPartStrings';
import Exceptions from './components/Exceptions';
import { IExceptionsProps } from './components/IExceptionsProps';

import { sp } from "@pnp/sp";
import { PropertyFieldColorPicker, PropertyFieldColorPickerStyle } from '@pnp/spfx-property-controls/lib/PropertyFieldColorPicker';

export interface IExceptionsWebPartProps {
  description: string;
  logo: string;
  bannerBackground : string;
  bodyBackground : string;
  exitLink:string;
}

export default class ExceptionsWebPart extends BaseClientSideWebPart<IExceptionsWebPartProps> {

  public onInit(): Promise<void> {

    return super.onInit().then(_ => {
      // other init code may be present
      sp.setup({
        spfxContext: this.context
      });
    });
  }

  public render(): void {
    const element: React.ReactElement<IExceptionsProps> = React.createElement(
      Exceptions,
      {
       description: this.properties.description,
        context: this.context,
        logo : this.properties.logo,
        bannerBackground:this.properties.bannerBackground,
        bodyBackground:this.properties.bodyBackground,
        exitLink:this.properties.exitLink
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                }),
                PropertyPaneTextField('logo', {
                  label: 'Logo',
                  value:this.properties.logo
                }),
                PropertyPaneTextField('exitLink', {
                  label: 'Exit Url',
                  value:this.properties.exitLink
                })
                // PropertyFieldColorPicker('bannerBackground', {
                //   label: 'Banner Background',
                //   selectedColor: this.properties.bannerBackground,
                //   onPropertyChange: this.onPropertyPaneFieldChanged,
                //   properties: this.properties,
                //   disabled: false,
                //   isHidden: false,
                //   alphaSliderHidden: false,
                //   style: PropertyFieldColorPickerStyle.Full,
                //   iconName: 'Precipitation',
                //   key: 'colorFieldId'
                // }),
                // PropertyFieldColorPicker('bodyBackground', {
                //   label: 'Form Body Background',
                //   selectedColor: this.properties.bodyBackground,
                //   onPropertyChange: this.onPropertyPaneFieldChanged,
                //   properties: this.properties,
                //   disabled: false,
                //   isHidden: false,
                //   alphaSliderHidden: false,
                //   style: PropertyFieldColorPickerStyle.Full,
                //   iconName: 'Precipitation',
                //   key: 'colorFieldId'
                // })
              ]
            }
          ]
        }
      ]
    };
  }
}
