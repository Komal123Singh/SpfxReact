import * as React from 'react';
import { MyState } from './Exceptions';
import { Label } from '@fluentui/react';
import { SecurityTrimmedControl, PermissionLevel, } from '@pnp/spfx-controls-react/lib/SecurityTrimmedControl';
import { SPPermission } from '@microsoft/sp-page-context';
import * as moment from "moment";
export default class ViewExceptions extends React.Component<MyState> {
     componentDidMount()
     {
         
     }
    render() {
      
        return (
            <div>


                <div className='border p-3 mt-1'>
                    <div className='row'>
                    </div>
                    {/* <div className='row'>
                      <div className='col-md-12 divRequested'>
                        <span>Requested by:</span>&nbsp;<span>{this.props.ReqByText}</span>&nbsp;<span>On</span> <span>{this.props.ReqDate!=null && this.props.ReqDate != undefined && this.props.ReqDate != '' && this.props.ReqDate != null ?moment(this.props.ReqDate).format('L') : null}</span>
                        </div>
                      </div> */}
                    <div className='row'>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Exception Type</Label><span>{this.props.ExceptType}</span>
                        </div>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Product Line</Label><span>{this.props.ProdLine}</span>
                        </div>
                    </div>
                    {/* commented for CR1
                    <div className='row'>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Category</Label><span>{this.props.ExceptCatg}</span>
                        </div>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> SubCategory</Label><span>{this.props.ExceptSubCatg}</span>
                        </div>
                    </div> */}
                    <div className='row'>
                    </div>
                    <div className='row' style={{ display: this.props.ExceptType != 'Contract' ? 'none' : 'flex' }}>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Customer Name  </Label><span>{this.props.Customer}</span>
                        </div>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Contract Date</Label>
                            <span>{this.props.ContractDate != undefined && this.props.ContractDate != '' && this.props.ContractDate != null ?moment(this.props.ContractDate).format('L') : null}</span>
                        </div>
                    </div>
                    <div className='row'>
                    </div>
                    {/* <div className='row'>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> State(s)</Label><span>{(this.props.States!=null && this.props.States!=undefined && this.props.States.length>0)?this.props.States.map((element)=>{return element+";"}):""}</span>
                        </div>
                        <div className='col-md-6' style={{ display: this.props.ExceptType == 'Contract' ? 'none' : 'block' }}>
                            <Label className='font-weight-bold w-100'> Area</Label><span>{(this.props.Scope!=null && this.props.Scope!=undefined && this.props.Scope.length>0)?this.props.Scope.map((element)=>{return element+";"}):""}</span>
                        </div>
                    </div> */}
                    <div className='row'>
                    </div>
                    <div className='row' >
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'>States(s)</Label><span style={{wordBreak:'break-all'}} >{this.props.StatesScope}</span>
                        </div>
                        <div className='col-md-6'>
                            
                        </div>
                    </div>
                    <div className='row' style={{ display: this.props.ExceptType != 'Dealer Group' ? 'none' : 'flex' }}>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'>Dealer Group Name</Label><span>{this.props.DlrGroupNm}</span>
                        </div>
                    </div>
                    <div className='row'>
                    </div>
                    <div className='row' style={{ display: (this.props.ExceptType == 'Program' || this.props.ExceptType == 'Dealer Group') ? 'none' : 'flex' }}>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Account Number</Label><span>{this.props.AcctNo}</span>
                        </div>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Account Name</Label><span>{this.props.AcctNm}</span>
                        </div>
                    </div>
                    {/* commented for CR1
                    <div className='row' style={{ display: (this.props.ExceptType == 'Program' || this.props.ExceptType == 'Dealer Group') ? 'none' : 'flex' }}>
                        <div className='col-md-6' >
                            <Label className='font-weight-bold w-100'> Division</Label><span>{this.props.Div}</span>
                        </div>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Region</Label><span>{this.props.Rgn}</span>
                        </div>
                    </div> */}
                    <div className='row'>
                        {/* commented for CR1
                        <div className='col-md-6' style={{ display: (this.props.ExceptType == 'Program' || this.props.ExceptType == 'Dealer Group') ? 'none' : 'block' }}>
                            <Label className='font-weight-bold w-100'> Territory</Label><span>{this.props.Terr}</span>
                        </div> */}
                        
                        <div className='col-md-6' >
                            <div style={{ display: (this.props.ProdLine != 'Credit' || this.props.ExceptType != 'Contract') ? 'none' : 'block' }}>
                                <Label className='font-weight-bold w-100'> Certificate</Label><span>{this.props.Certificate}</span>
                            </div>
                            {/* commented for CR1
                             <div style={{ display: (this.props.ProdLine == 'VSC' || this.props.ProdLine == 'LW') ? 'block' : 'none' }}>
                                <Label className='font-weight-bold w-100'> Program Year</Label><span>{this.props.PgmYr}</span>
                            </div> */}
                        </div>

                    </div>
                    <div className='row'>
                    </div>
                    <div className='row'>
                    </div>
                    <div className='row'>
                    </div>
                    <div className='row'>
                    </div>
                    <div className='row'>
                        <div className='col-md-6' style={{ display: (this.props.ProdLine !== 'Credit' || this.props.ExceptType! !== 'Contract') ? 'none' : 'block' }}>
                            <Label className='font-weight-bold w-100'> Customer DOB </Label><span>{this.props.DOB != undefined && this.props.DOB != '' && this.props.DOB != null ? moment(this.props.DOB).format('L') : null}</span>
                        </div>
                        <div className='col-md-6' style={{ display: (this.props.ProdLine != 'Credit' || this.props.ExceptType != 'Contract') ? 'none' : 'block' }}>
                            <Label className='font-weight-bold w-100'> Term(Months)</Label><span>{this.props.CLITerm}</span>
                        </div>
                    </div>
                    <div className='row'>
                        <div className='col-md-6' style={{ display: (this.props.ProdLine !== 'Credit' || this.props.ExceptType! !== 'Contract') ? 'none' : 'block' }}>
                            <Label className='font-weight-bold w-100'>Age </Label><span>{this.props.Age}</span>
                        </div>
                    </div>
                    <div className='row' style={{ display: (this.props.ProdLine != 'Credit' || this.props.ExceptType != 'Contract') ? 'none' : 'flex' }}>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'>Life Coverage </Label><span>{this.props.LifeCovg}</span>
                        </div>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> A&H Coverage</Label><span>{this.props.AHCovg}</span>
                        </div>
                    </div>
                    <div className='row' style={{ display: (this.props.ProdLine != 'Credit' || this.props.ExceptType != 'Contract') ? 'none' : 'flex' }}>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'>Initial Coverage </Label><span>{this.props.InitCvg}</span>
                        </div>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Monthly Benefit</Label><span>${this.props.MoBenefit}</span>
                        </div>
                    </div>
                    <div className='row' style={{ display: (this.props.ProdLine == 'VSC' || this.props.ProdLine == 'LW') ? 'flex' : 'none' }}>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> New/Used </Label><span>{this.props.NewOrUsed}</span>
                        </div>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Deductible</Label><span>{this.props.DedType}</span>
                        </div>
                    </div>
                    <div className='row' style={{ display: (this.props.ProdLine == 'VSC' || this.props.ProdLine == 'LW') ? 'flex' : 'none' }}>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Contract</Label><span>{this.props.Contract}</span>
                        </div>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Model Year</Label><span>{this.props.ModelYr}</span>
                        </div>
                    </div>
                    <div className='row' style={{ display: (this.props.ProdLine == 'VSC' || this.props.ProdLine == 'LW') ? 'flex' : 'none' }}>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Make</Label><span>{this.props.Make}</span>
                        </div>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Model</Label><span>{this.props.Model}</span>
                        </div>
                    </div>
                    <div className='row' style={{ display: (this.props.ProdLine == 'VSC' || this.props.ProdLine == 'LW') ? 'flex' : 'none' }}>
                        
                        {/*commented for CR1
                         <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Symbol</Label><span>{this.props.Symbol}</span>
                        </div> */}
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Odometer Reading</Label><span>{this.props.Odometer}</span>
                        </div>
                    </div>
                    <div className='row' style={{ display: (this.props.ProdLine == 'VSC' || this.props.ProdLine == 'LW') ? 'flex' : 'none' }}>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Term</Label><span>{this.props.VSCTerm}</span>
                        </div>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Coverage</Label><span>{this.props.VSCCovg}</span>
                        </div>
                    </div>
                    {/* commented for CR1
                    <div className='row' style={{ display: (this.props.ProdLine == 'VSC' || this.props.ProdLine == 'LW') ? 'flex' : 'none' }}>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Coverage Level</Label><span>{this.props.CovgLevel}</span>
                        </div>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Dealer Remit</Label><span>${this.props.CalcRate}</span>
                        </div>
                    </div>
                    <div className='row' style={{ display: (this.props.ProdLine == 'VSC' || this.props.ProdLine == 'LW') && this.props.isUnderWriter == true? 'flex' : 'none' }}>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Rating Factor</Label><span>{this.props.RatingFactor}</span>
                        </div>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Term Factor</Label><span>{this.props.TermFactor}</span>
                        </div>
                    </div>
                    <div className='row' style={{ display: (this.props.ProdLine == 'VSC' || this.props.ProdLine == 'LW') &&  this.props.isUnderWriter == true ? 'flex' : 'none' }}>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Coverage Factor</Label><span>{this.props.CoverageFactor}</span>
                        </div>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Base Rate</Label><span>${this.props.BaseRate}</span>
                        </div>
                    </div>
                    <div className='row' style={{ display: (this.props.ProdLine == 'VSC' || this.props.ProdLine == 'LW') && this.props.isUnderWriter == true? 'flex' : 'none' }}>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Odometer Factor</Label><span>{this.props.OdometerFactor}</span>
                        </div>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Ded. Surcharge/Credit</Label><span>${this.props.DedSurcharge}</span>
                        </div>
                    </div>
                    {(this.props.ProdLine == 'VSC' || this.props.ProdLine == 'LW') && this.props.isUnderWriter == true ? <div className='row' >
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Admin Fees</Label><span>${this.props.AdminFee}</span>
                        </div>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Other Fees</Label><span>${this.props.OtherFees}</span>
                        </div>
                    </div>:null}
                    { (this.props.ProdLine == 'VSC' || this.props.ProdLine == 'LW') &&  this.props.isUnderWriter == true?
                    <div className='row' >
                        <div className='col-md-6'>
                        <Label className='font-weight-bold w-100'>Over Remit</Label><span>${this.props.OverRemit}</span>
                          
                        </div>
                      </div>:null}
                      */}
  
                    <div className='row' style={{ display: (this.props.IsNewDoc == true && this.props.isAccountAdmin == true) ? 'none' : 'flex' }}>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Underwriter Comments</Label><span>{this.props.UnderwriterComments}</span>
                        </div>
                    </div>
                   
                   
                    <div className='row'>
                        <div className='col-md-6'>
                            <Label className='font-weight-bold w-100'> Criteria</Label><span>{this.props.Criteria}</span>
                        </div>
                    </div>
                    <div className='row'>
                        <div className='col-md-6'>
                            <div style={{ display: (this.props.RecordStatus != "Requested" && !this.props.isAccountAdmin) ? 'none' : 'block' }}>
                                <Label className='font-weight-bold w-100'> Underwriter Assigned</Label><span>{this.props.UnderwriterAssgndText}</span>
                            </div>
                            <div style={{ display: (this.props.IsNewDoc || this.props.RecordStatus != "Approved") ? 'none' : 'block' }}>
                                <Label className='font-weight-bold w-100'> ApprovedBy</Label><span>{this.props.ApprovedByText}</span>
                            </div>
                        </div>
                        <div className='col-md-6'style={{ display: (this.props.IsNewDoc || this.props.RecordStatus != "Approved") ? 'none' : 'block' }}>
                            <Label className='font-weight-bold w-100'> Approved Date</Label><span>{ this.props.ApprovedDate != undefined && this.props.ApprovedDate != '' && this.props.ApprovedDate != null ?  moment(this.props.ApprovedDate).format('L') : null}</span>
                        </div>
                    </div>
                    <div className='row'>
                        <div className='col-md-6' style={{ display: ( this.props.RecordStatus != "Cancelled") ? 'none' : 'block' }}>
                            <Label className='font-weight-bold w-100'> Cancelled By</Label><span>{this.props.CancelledByText}</span>
                        </div>
                        <div className='col-md-6'style={{ display: (this.props.RecordStatus != "Cancelled") ? 'none' : 'block' }}>
                            <Label className='font-weight-bold w-100'> Cancelled Date</Label><span>{this.props.CancelledDate != undefined && this.props.CancelledDate != '' && this.props.CancelledDate != null ? moment(this.props.CancelledDate).format('L') : null}</span>
                        </div>
                    </div>
                    <div className='row'>
                        <div className='col-md-6' style={{ display: ( this.props.RecordStatus != "Denied") ? 'none' : 'block' }}>
                            <Label className='font-weight-bold w-100'> Denied By</Label><span>{this.props.DeniedByText}</span>
                        </div>
                        <div className='col-md-6' style={{ display: (this.props.RecordStatus != "Denied") ? 'none' : 'block' }}>
                            <Label className='font-weight-bold w-100'> Denied Date</Label><span>{this.props.DeniedDate != undefined && this.props.DeniedDate != '' && this.props.DeniedDate != null ? moment(this.props.DeniedDate).format('L') : null}</span>
                        </div>
                    </div>
                    <div className='row'>
                        <div className='col-md-6'style={{ display: (this.props.IsNewDoc || this.props.RecordStatus != "Approved" || this.props.ExceptType=="Contract") ? 'none' : 'block' }}>
                            <Label className='font-weight-bold w-100'> Review Date</Label><span>{this.props.ReviewDate != undefined && this.props.ReviewDate != '' && this.props.ReviewDate != null ? moment(this.props.ReviewDate).format('L') : null}</span>
                        </div>
                        <div className='col-md-6'style={{ display: (!this.props.isUnderWriter ) ? 'none' : 'block' }}>
                            <Label className='font-weight-bold w-100'> Available for Logging?</Label><span>{this.props.AAOK}</span>
                        </div>
                    </div>
                    <div className='row'>
                    </div>
                    <div className='row'>
                    </div>
                    <div className='row'>
                    </div>
                    <div className='row'>
                        <div className='col-md-6'style={{ display: (this.props.IsNewDoc || this.props.RecordStatus != "Approved" || this.props.ExceptType=="Contract") ? 'none' : 'block' }}>
                            <Label className='font-weight-bold w-100'> Expiration Date</Label><span>{this.props.ExpDate != undefined && this.props.ExpDate != '' && this.props.ExpDate != null ? moment( this.props.ExpDate).format('L') : null}</span>
                        </div>
                    </div>
                </div>

                <div className='border p-3 mt-1'>
                    <div className='row'>
                        <div className='col-md-12' >
                            <Label className='font-weight-bold w-25'> Notes</Label><span><div dangerouslySetInnerHTML={{ __html: this.props.Notes }}></div></span>
                        </div>
                    </div>
                </div>
                
                <div className='border p-3 mt-1'>
                    
                    <div className='row'>
                        <div className='col-md-12 containImage' >
                            <Label className='font-weight-bold w-25'> Attached Files</Label><span><div> { 
                        (  this.props.UploadedExFiles!=null && this.props.UploadedExFiles!=undefined && this.props.UploadedExFiles.length>0)?this.props.UploadedExFiles.map(element=>{return <div>{element.props.children[0]}</div>}):null
                            }</div></span>
                        </div>
                    </div>
                </div>

            </div>
        )
    }
}