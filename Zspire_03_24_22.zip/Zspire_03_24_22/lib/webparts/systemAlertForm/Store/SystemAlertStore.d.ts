import { EventEmitter } from 'events';
declare class SystemAlertStore extends EventEmitter {
    constructor();
    storeChange(action: any): void;
    getEditFormDetailsStoreValue(): any[];
    getInserResultStoreValue(): any;
}
declare let objSystemAlertStore: SystemAlertStore;
export default objSystemAlertStore;
//# sourceMappingURL=SystemAlertStore.d.ts.map