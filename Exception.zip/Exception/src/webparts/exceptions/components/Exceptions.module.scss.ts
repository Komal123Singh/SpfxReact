/* tslint:disable */
require("./Exceptions.module.css");
const styles = {
  exceptions: 'exceptions_6b3a4c4d',
  container: 'container_6b3a4c4d',
  row: 'row_6b3a4c4d',
  column: 'column_6b3a4c4d',
  'ms-Grid': 'ms-Grid_6b3a4c4d',
  title: 'title_6b3a4c4d',
  subTitle: 'subTitle_6b3a4c4d',
  description: 'description_6b3a4c4d',
  button: 'button_6b3a4c4d',
  label: 'label_6b3a4c4d'
};

export default styles;
/* tslint:enable */