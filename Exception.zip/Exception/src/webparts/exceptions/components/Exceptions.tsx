import * as React from 'react';
import { IExceptionsProps } from './IExceptionsProps';
import * as ExceptionsAction from '../Action/ExceptionsAction';
import ExceptionsStore from '../Store/ExceptionsStore';
import { PeoplePicker, PrincipalType } from '@pnp/spfx-controls-react/lib/PeoplePicker';
import { DateTimePicker, DateConvention, TimeConvention } from '@pnp/spfx-controls-react/lib/dateTimePicker';
import { Separator, DatePicker, DefaultButton, Dialog, DialogType, DialogFooter, ThemeProvider, createTheme, TextField, Dropdown, IDropdownStyles, Checkbox, Label, Link, PrimaryButton, Toggle, ChoiceGroup, IconButton, IIconProps, ComboBox } from '@fluentui/react';
import { Stack } from 'office-ui-fabric-react/lib/Stack';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { SecurityTrimmedControl, PermissionLevel, } from '@pnp/spfx-controls-react/lib/SecurityTrimmedControl';
import { SPPermission } from '@microsoft/sp-page-context';
import * as moment from "moment";
import ViewExceptions from './ViewExceptions';
import { WebPartContext } from '@microsoft/sp-webpart-base';

import './ExceptionsCss.css';
//require('./ExceptionsCss.css')
//import  ctrlStyles from './Exceptions.module.scss'
import SunEditor from 'suneditor-react';
//import parse from 'html-react-parser';
import 'suneditor/dist/css/suneditor.min.css';
// let _ = require('lodash');
import * as _ from '@microsoft/sp-lodash-subset'
import { arraysEqual } from 'office-ui-fabric-react/lib/Utilities';
import { Spinner, SpinnerSize } from '@fluentui/react/lib/Spinner';
import { ActionButton } from 'office-ui-fabric-react/lib/Button';
import { relativeTimeThreshold } from 'moment';
import { ExtendedSelectedItem, Icon } from 'office-ui-fabric-react';
import { UrlQueryParameterCollection } from '@microsoft/sp-core-library';
import { Delete16Filled, ErrorCircleSettings16Regular, ErrorCircleSettings20Regular } from '@fluentui/react-icons';


//theme variables

// Styles Setting
const myTheme = createTheme({
  palette: {
    themePrimary: '#23366f',
    themeLighterAlt: '#f3f4f9',
    themeLighter: '#cfd5e8',
    themeLight: '#a9b4d4',
    themeTertiary: '#6476a9',
    themeSecondary: '#344781',
    themeDarkAlt: '#203165',
    themeDark: '#1b2a55',
    themeDarker: '#141f3f',
    neutralLighterAlt: '#faf9f8',
    neutralLighter: '#f3f2f1',
    neutralLight: '#edebe9',
    neutralQuaternaryAlt: '#e1dfdd',
    neutralQuaternary: '#d0d0d0',
    neutralTertiaryAlt: '#c8c6c4',
    neutralTertiary: '#a19f9d',
    neutralSecondary: '#605e5c',
    neutralPrimaryAlt: '#3b3a39',
    neutralPrimary: '#323130',
    neutralDark: '#201f1e',
    black: '#000000',
    white: '#ffffff',
  }
});

// Global Variable

//let currentListName="ExceptionList5";
let absoluteUrl;
let relativeURL;
let exceptionlistName;
let exceptionlogListName;
let arrAllPrevAttachments: string[] = [];


let arrPrevSavedFiles = [];
let arrPrevSavedFilesHtml = [];
let arrPrevTobeRemovedFiles = [];
let newUploadedFileArray = [];
let uploadedRichTextFiles = [];
let prevUploadedFilesObj = { arrPrevSavedFiles, arrPrevSavedFilesHtml, arrPrevTobeRemovedFiles, newUploadedFileArray, uploadedRichTextFiles };


//let alluploadedfilesinRichText=[];
//let newUploadedFileArray=[];
let deleteFiles = [];
//status of the Record
//let recordstatus = '';
let processed = 'No';
//let isNewDoc = false;
//roles
// let isAdmin = false;
// let isAccountAdmin = false;
// let isUnderWriter = false;
let loggedinUserDetail;

//let UndComment="No";
//two decimal regular expression
const twoDecimal = /^\d+(\.\d{1,2})?$/;

const twoDecimalType = /^\d+(\.\d{0,2})?$/;

const threeDecimal = /^\d+(\.\d{1,3})?$/;

const threeDecimalType = /^\d+(\.\d{0,3})?$/;

const varyingDecimal=/^\d+(\.\d{1,})?$/;

const varyingDecimalType=/^\d+(\.\d{0,})?$/;;

const integerCurrency=/^[0-9]*$/;


//for styles
const styles = {
  root: [{
    selectors: {
      '::before': {
        background: 'green',
        height: '7px'
      },
    }
  }]
};
const dropdownStyles: Partial<IDropdownStyles> = {

  dropdownItems: { maxHeight: '250px' },

}

// const url = window.location.href;
// const urlObject = new URL(url);
// let uniqueId = urlObject.searchParams.get('itemID') == '' || urlObject.searchParams.get('itemID') == null ? 0 : parseInt(urlObject.searchParams.get('itemID'));
// let itemListName = urlObject.searchParams.get('listID') == '' || urlObject.searchParams.get('listID') == null ? '' : urlObject.searchParams.get('listID');
let uniqueId:number;
let itemListName ='';
let isEditMode = false;
let isViewMode = false;
let EditFormDetails;
const stackTokens = { childrenGap: 3 };
const addIcon: IIconProps = { iconName: 'Add' };
const subIcon: IIconProps = { iconName: 'CalculatorMultiply' };
var XMLserialize = new XMLSerializer();
var AdminExceptListMatrix = [
  { AdminCol: "ProdLines", ExceptionCol: "ProdLine" },
  //commented for CR1
  // { AdminCol: "ExceptCatgs", ExceptionCol: "ExceptCatg" },
  { AdminCol: "States", ExceptionCol: "States" },
  { AdminCol: "Divisions", ExceptionCol: "Div" },
  { AdminCol: "Regions", ExceptionCol: "Rgn" },
  { AdminCol: "VSCDedTypes", ExceptionCol: "DedType" },
  { AdminCol: "LWDedTypes", ExceptionCol: "DedType" },
  //commented for CR1
  // { AdminCol: "VSCSymbols", ExceptionCol: "Symbol" },
  // { AdminCol: "LWSymbols", ExceptionCol: "Symbol" },
  { AdminCol: "VSCNewTerms", ExceptionCol: "VSCTerm" },
  { AdminCol: "VSCUsedTerms", ExceptionCol: "VSCTerm" },
  { AdminCol: "LWNewTerms", ExceptionCol: "VSCTerm" },
  { AdminCol: "LWUsedTerms", ExceptionCol: "VSCTerm" },
  { AdminCol: "VSCCvgs", ExceptionCol: "VSCCovg" },
  { AdminCol: "LWCvgs", ExceptionCol: "VSCCovg" },
  { AdminCol: "Underwriters", ExceptionCol: "UnderwriterAssgnd" },
  { AdminCol: "AcctEmail", ExceptionCol: "AcctEmail" },
  { AdminCol: "Dlremail", ExceptionCol: "Dlremail" },
  { AdminCol: "UndEmail", ExceptionCol: "UndEmail" },
  { AdminCol: "AllListNames", ExceptionCol: "AllListNames" }
]


var stateScopeMatrix = [];
var arrayProdLinesData = []
let actionBtnClicked = '';
//let completionBtnClicked='';
let dialogContentProps = {
  type: DialogType.normal,
  title: 'Confirmation',
  closeButtonAriaLbel: 'Close',
  subText: '',
};

let dialogCompletionProps = {
  type: DialogType.normal,
  title: 'Confirmation',
  closeButtonAriaLbel: 'Close',
  subText: '',
};
let dialogModalError = {
  type: DialogType.normal,
  title: 'Confirmation',
  closeButtonAriaLbel: 'Close',
  subText: '',
};

// interface  ProdLineObjFormat{
//   ProdLineValue:string,
//   AcNoMaxLen:string;
// }
let isDealerGroupDisplay = true;

//let exitLocation = "https://www.google.com";

//Business Objects Starts //
export interface MyState {
  webpartContxt: WebPartContext;
  FormAttachment: any;
  FormAttachmentNames: any;

  RecordStatus: string;
  IsNewDoc: boolean;
  isAdmin: boolean;
  isAccountAdmin: boolean;
  isUnderWriter: boolean;
  ExceptType: string;
  ProdLine: string;
  /*Commented for CR1
  ExceptCatg: string;
  ExceptSubCatg: string;
  */
  Customer: string;
  ContractDate: any;
  States: any;
  //commented for CR1
  // CatgComments: string;
  // CommentInd: string;
  // Scope: any;
  StatesScope: string;
  DlrGroupNm: string;
  AcctNo: string;
  AcctNm: string;
  //commented for CR1
  // Div: string;
  // Rgn: string;
  // Terr: string;
  // PgmYr: string;
  DOB: any;
  CLITerm: any;
  Age: any;
  LifeCovg: any;
  AHCovg: any;
  InitCvg: any;
  MoBenefit: any;
  NewOrUsed: string;
  NewOrUsedChoiceArr: any;
  DedType: string;
  Contract: string;
  ModelYr: string;
  Make: string;
  Model: string;
  // Symbol: string;
  Odometer: string;
  VSCTerm: string;
  VSCCovg: string;
  //commented for CR1
  // CovgLevel: string;
  // CalcRate: string;
  // RatingFactor: string;
  // TermFactor: string;
  // CoverageFactor: string;
  // BaseRate: string;
  // OdometerFactor: string;
  // DedSurcharge: string;
  // AdminFee: string;
  // OtherFees: string;
  // OverRemit: string;
  UnderwriterComments: string;
  Criteria: string;
  UnderwriterAssgnd: string;
  UnderwriterAssgndEmail: string;
  UnderwriterAssgndText:string;
  ApprovedById: any;
  ApprovedDate: any;

  DeniedById: any;
  DeniedDate: any;
  CancelledById: any;

  CancelledDate: any;
  ExpDate: any;
  ReviewDate: any;
  ReqById: any;
  ReqByEmail: any;
  ReqByText:any;
  Notes: string;
  Certificate: string;
  AAOK: string;
  ReqDate: any;

  ExceptTypeChoiceArr: any;
  ProdLineChoiceArr: any;
  //commented for CR1
  // ExceptCatgChoiceArr: any;
  // ExceptSubCatgChoiceFilteredArr: any
  // ExceptSubCatgChoiceAllArr: any;
  StatesChoiceArr: any;
  ScopeChoiceArr: any;
  DivChoiceArr: any;
  RgnChoiceArr: any;
  DedTypeChoiceArr: any,
  LWDedTypeChoiceArr: any;
  VSCDedTypeChoiceArr: any;
  MakeChoiceArr: any;


  ModelChoiceFilteredArr: any;
  ModelChoiceAllArr: any;
  // commenting for CR1
  // SymbolChoiceArr: any;
  // LWSymbolChoiceArr: any;
  // VSCSymbolChoiceArr: any;
  VSCTermChoiceArr: any;
  VSCNewTermChoiceArr: any;
  VSCUsedTermChoiceArr: any;
  LWNewTermChoiceArr: any;
  LWUsedTermChoiceArr: any;
  VSCCovgChoiceArr: any;
  VSCCvgsChoiceArr: any;
  LWCvgsChoiceArr: any;
  UnderwriterAssgndChoiceArr: any;
  AAOKChoiceArr: any;
  //for errormessage
  errorExceptType: string;
  errorExceptCatg:string;
  errorAccountNumber: string;
  errorDealerGroupName: string;
  errorAccountName: string,
  errorDivision: string,
  errorRegion: string,
  errorTerritory: string,
  errorUnderwriterComments: string,
  errorCriteria: string,
  // errorProgramYear: string,
  errorNewUsed: string,
  errorDeductionType: string,
  errorModelYear: string,
  errorMake: string,
  errorMakeNew: string,
  errorModel: string,
  errorModelNew: string,
  // errorSymbol: string,
  errorOdometer: string,
  errorVSCTerm: string,
  errorVSCCoverage: string,
  //commented for CR1
  //errorCoverageLevel: string,
  errorCertificate: string,
  errorCLITerm: string,
  errorDOB: string,
  errorAge: string,
  errorProdline: string,
  errorStates: string,
  IsMakeNew: boolean;
  MakeNew: string;
  IsModelNew: boolean,
  ModelNew: string,
  errorAnHCoverage: string,
  errorMonthlyBenefit: string,
  errorInitialCoverage: string,
  errorLifeCoverage: string,
  //commented for CR1
  //errorRatingFactor: string,
 // errorTermFactor: string,
  //errorCoverageFactor: string,
 // errorOdometerFactor: string,
  errorCalcRate: string,
 // errorBaseRate: string,
 // errorDedSurcharge: string,
  //errorAdminFee: string,
 // errorOtherFees: string,
 // errorOverRemit: string,

  //modal open
  isModalClose: boolean;
  isModalCompletionClose: boolean;
  isModalErrorClose:boolean;
  isSpinnerHide: boolean;
  isLoaded: boolean;
  ApprovedByText: string;
  CancelledByText: string;
  DeniedByText: string;
  AcctemailChoiceArr: any,
  DlremailChoiceArr: any,
  UndemailChoiceArr: any,

  selectedFiles: any,
  UploadedExFiles: any,
  AllListNamesArr:any



}
//Business Objects End //

export default class Exceptions extends React.Component<IExceptionsProps, MyState> {
  constructor(prop) {
    super(prop);

    this.state = {
      webpartContxt: this.props.context,
      FormAttachment: [],
      FormAttachmentNames: [],
      RecordStatus: '',
      IsNewDoc: false,
      isAdmin: false,
      isAccountAdmin: false,
      isUnderWriter: false,
      ExceptType: '',
      ProdLine: "",
      /*
      commented for CR1
      ExceptCatg: '',
      ExceptSubCatg: '',
      */
      Customer: '',
      ContractDate: null,
      States: [],
      //commented for CR1
      // CatgComments: "",
      // CommentInd: "",
      // Scope: [],
      StatesScope: '',
      DlrGroupNm: '',
      AcctNo: '',
      AcctNm: '',
      //Commented for CR1
      // Div: '',
      // Rgn: '',
      // Terr: '',
      // PgmYr: '',
      DOB: null,
      CLITerm: '',
      Age: null,
      LifeCovg: null,
      AHCovg: null,
      InitCvg: null,
      MoBenefit: null,
      NewOrUsed: '',
      NewOrUsedChoiceArr: [],
      DedType: '',
      Contract: '',
      ModelYr: '',
      Make: '',
      Model: '',
      //commented for CR1
      // Symbol: '',
      Odometer: null,
      VSCTerm: '',
      VSCCovg: '',
      //commented for CR1
      // CovgLevel: '',
      // CalcRate: "0",
      // RatingFactor: null,
      // TermFactor: null,
      // CoverageFactor: null,
      // BaseRate: null,
      // OdometerFactor: null,
      // DedSurcharge: null,
      // AdminFee: null,
      // OtherFees: null,
      // OverRemit: null,
      UnderwriterComments: '',
      Criteria: '',
      UnderwriterAssgnd: '-1',
      UnderwriterAssgndEmail: '',
      UnderwriterAssgndText:'',
      ApprovedById: '-1',
      ApprovedDate: null,
      DeniedById: '-1',
      DeniedDate: null,
      CancelledById: "-1",
      CancelledDate: null,
      ReviewDate: null,
      ExpDate: null,
      ReqById: "-1",
      ReqByEmail: '',
      ReqByText:'',
      Notes: '',
      Certificate: '',
      AAOK: 'No',
      ReqDate: null,
      ExceptTypeChoiceArr: [],
      ProdLineChoiceArr: [],
      //commented for CR1
      // ExceptCatgChoiceArr: [],
      // ExceptSubCatgChoiceFilteredArr: [],
      // ExceptSubCatgChoiceAllArr: [],
      StatesChoiceArr: [],
      ScopeChoiceArr: [],
      DivChoiceArr: [],
      RgnChoiceArr: [],
      DedTypeChoiceArr: [],
      LWDedTypeChoiceArr: [],
      VSCDedTypeChoiceArr: [],
      MakeChoiceArr: [],
      ModelChoiceFilteredArr: [],
      ModelChoiceAllArr: [],
      // commenting for CR1
      // SymbolChoiceArr: [],
      // LWSymbolChoiceArr: [],
      // VSCSymbolChoiceArr: [],
      VSCTermChoiceArr: [],
      VSCNewTermChoiceArr: [],
      VSCUsedTermChoiceArr: [],
      LWNewTermChoiceArr: [],
      LWUsedTermChoiceArr: [],
      VSCCovgChoiceArr: [],
      VSCCvgsChoiceArr: [],
      LWCvgsChoiceArr: [],
      UnderwriterAssgndChoiceArr: [],
      AAOKChoiceArr: [],
      //for errormessage
      errorExceptType: '',
      errorExceptCatg:'',

      errorAccountNumber: '',
      errorDealerGroupName: '',
      errorAccountName: '',
      errorDivision: '',
      errorRegion: '',
      errorTerritory: '',
      errorUnderwriterComments: '',
      errorCriteria: '',
      //commnted for CR1
      // errorProgramYear: '',
      errorNewUsed: '',
      errorDeductionType: '',
      errorModelYear: '',
      errorMake: '',
      errorMakeNew: '',
      errorModel: '',
      errorModelNew: '',
      //commented for CR1
      // errorSymbol: '',
      errorOdometer: '',
      errorVSCTerm: '',
      errorVSCCoverage: '',
      //commented for CR1
     // errorCoverageLevel: '',
      errorCertificate: '',
      errorCLITerm: '',
      errorDOB: '',
      errorAge: '',
      errorProdline: '',
      errorStates: '',
      errorAnHCoverage: '',
      errorMonthlyBenefit: '',
      errorInitialCoverage: '',
      errorLifeCoverage: '',
      //Commnted for CR1
      //errorRatingFactor: '',
      //errorTermFactor: '',
      //errorCoverageFactor: '',
      //errorOdometerFactor: '',
      errorCalcRate: '',
      //errorBaseRate: '',
     // errorDedSurcharge: '',
     // errorAdminFee: '',
     // errorOtherFees: '',
     // errorOverRemit: '',

      IsMakeNew: false,
      MakeNew: '',
      IsModelNew: false,
      ModelNew: '',
      isModalClose: true,
      isModalCompletionClose: true,
      isModalErrorClose:true,
      isSpinnerHide: true,
      isLoaded: false,
      ApprovedByText: '',
      CancelledByText: '',
      DeniedByText: '',
      AcctemailChoiceArr: [],
      DlremailChoiceArr: [],
      UndemailChoiceArr: [],
      selectedFiles: [],
      UploadedExFiles: [],
      AllListNamesArr:[]


    }


    absoluteUrl = this.props.context.pageContext.site.absoluteUrl;
    relativeURL = this.props.context.pageContext.site.serverRelativeUrl;
    exceptionlistName = "";
    SPComponentLoader.loadCss('https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
    SPComponentLoader.loadCss('https://cdn.jsdelivr.net/npm/suneditor@latest/dist/css/suneditor.min.css');
    SPComponentLoader.loadScript('https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js');
    SPComponentLoader.loadScript('https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js');
    SPComponentLoader.loadScript('https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js');
    this.CheckFileBeforeUpload = this.CheckFileBeforeUpload.bind(this);
  }



  componentDidMount() {
    try {

const url = window.location.href;
const urlObject = new URL(url);
 uniqueId = urlObject.searchParams.get('itemID') == '' || urlObject.searchParams.get('itemID') == null ? 0 : parseInt(urlObject.searchParams.get('itemID'));
 itemListName = urlObject.searchParams.get('listID') == '' || urlObject.searchParams.get('listID') == null ? '' : urlObject.searchParams.get('listID');
 //currentListName = urlObject.searchParams.get('currDestID') == '' || urlObject.searchParams.get('currDestID') == null ? '' : urlObject.searchParams.get('currDestID');
      this.getscompile();
      ExceptionsAction.getUserGroupDetails();
      ExceptionsStore.on('UserGroupDetailsChange', this.getLoggedUsersGroup);
      ExceptionsAction.getUserInfoDetails();
      ExceptionsStore.on('UserInfoDetailsChange', this.getLoggedUserInfo);
      isViewMode = true;
      if (uniqueId != 0) {
        exceptionlistName=itemListName;
        isEditMode = true;
        //this.getEditFormDetailsComp();
        this.getFormDefaultDetails();

      console.log("lg1 "+uniqueId);
      console.log("lg1loc"+ location.search);
      }
      else {
        console.log("lg2 "+uniqueId);
        console.log("lg2oc"+ location.search);
        //   recordstatus= "Requested";
        this.setState({ RecordStatus: "Requested" })
        //isNewDoc = true;
        this.setState({ IsNewDoc: true });
        //this is for setting newform choice values
       // exceptionlistName=currentListName;
        this.getFormDefaultDetails();

      }
    }
    catch (e) {
      console.log('componentDidMount: ' + e);
    }
  }

  getscompile = () => {

    ExceptionsStore.on('insertResultchange', this.assignInsertResultStore);
    ExceptionsStore.on('AccountNumberDetailsChange', this.RetrieveAccountDetails);
    ExceptionsStore.on('insertExceptionChange', this.RetrieveAccountDetails);

    ExceptionsStore.on('AdminDetailsChange', this.adminDetailStore);
    // ExceptionsStore.on('ListChoiceschange', this.assignListChoiceStore);
    ExceptionsStore.on('sendEmailChange', this.sendEmailStore);
    ExceptionsStore.on('insertExceptionChange', this.ExceptionLogStore);
    ExceptionsStore.on('getEditFormDetailschange', this.assignEditFormDetailsStore);
  }


  getFormDefaultDetails = () => {
    try {

      //  ExceptionsAction.getListChoicesDetails();
      this.updateStaticListChoice();
      ExceptionsAction.getAllAdminDetails();
      if (!isEditMode) {
        this.getAsyncDataDetails();
        //in editform this method will be called as callback to setstate
      }


    } catch (e) {
      console.log('getFormDefaultDetails' + e);
    }
  }
  updateStaticListChoice = () => {
    let neworUsedArray = [];
    let AAOKArray = [];
    neworUsedArray.push({ key: "", text: "", id: "NewOrUsed" });
    neworUsedArray.push({ key: "New", text: "New", id: "NewOrUsed" })
    neworUsedArray.push({ key: "Used", text: "Used", id: "NewOrUsed" })
    this.setState({ NewOrUsedChoiceArr: neworUsedArray })
    AAOKArray.push({ key: "No", text: "No", id: "AAOK" })
    AAOKArray.push({ key: "Yes", text: "Yes", id: "AAOK" })
    this.setState({ AAOKChoiceArr: AAOKArray })
  }
  getAsyncDataDetails = () => {
   /*
    code commented for the CR1
    // console.log(this.state.Notes);
    // ExceptionsAction.getDefSubCatgDetails();
    // ExceptionsStore.on('DefSubCatgDetailsChange', this.DefSubCatgDetailStore);
    // ExceptionsAction.getDefScopeDetails();
    // ExceptionsStore.on('DefScopeDetailsChange', this.DefScopeDetailStore);
*/
    this.updateDedTypeOptions();
    //this.updateSymbolOptions();
    this.updateVSCTermOptions();
    this.updateVSCCvgsOptions();
    //this.LoadNonEditables();
    if (isEditMode) {
      this.UpdateMissingExtypeChoice();
      this.UpdateMissingProdLineChoice();
      /* commented for CR1
      this.UpdateMissingRegionChoice();
      this.UpdateMissingDivChoice();
      */
    }

    else {

    }
    ExceptionsAction.getListMakeDetails();
    ExceptionsStore.on('ListMakeDetailsChange', this.ListMakeDetailStore);

  }

  UpdateMissingExtypeChoice = () => {
    let arrExceptTypechoice = this.state.ExceptTypeChoiceArr;
    let selExceptType = this.state.ExceptType;
    if (arrExceptTypechoice != null && arrExceptTypechoice != undefined && arrExceptTypechoice.length > 0) {
      if (selExceptType != null && selExceptType != undefined && selExceptType.length > 0) {
        if (!arrExceptTypechoice.some(el => el.key === selExceptType)) {
          arrExceptTypechoice.push({ key: selExceptType.trim(), text: selExceptType, id: "ExceptType" });
          this.setState({ ExceptTypeChoiceArr: arrExceptTypechoice })
        }

      }

    }

  }




  UpdateMissingProdLineChoice = () => {
    let arrProdLinechoice = this.state.ProdLineChoiceArr;
    let selProdLine = this.state.ProdLine;

    if (arrProdLinechoice != null && arrProdLinechoice != undefined && arrProdLinechoice.length > 0) {
      if (selProdLine != null && selProdLine != undefined && selProdLine.length > 0) {
        if (!arrProdLinechoice.some(el => el.key === selProdLine)) {
          arrProdLinechoice.push({ key: selProdLine.trim(), text: selProdLine.trim(), id: "ProdLine" });
          this.setState({ProdLine:""},()=>{this.setState({ ProdLineChoiceArr: arrProdLinechoice },()=>{ this.setState({ ProdLine: selProdLine })})});


        }

      }

    }


  }
/*commented for CR1

  UpdateMissingRegionChoice = () => {
    let arrRegionchoice = this.state.RgnChoiceArr;
    let selRegion = this.state.Rgn;
    if (arrRegionchoice != null && arrRegionchoice != undefined && arrRegionchoice.length > 0) {
      if (selRegion != null && selRegion != undefined && selRegion.length > 0) {
        if (!arrRegionchoice.some(el => el.key === selRegion)) {
          arrRegionchoice.push({ key: selRegion.trim(), text: selRegion, id: "Rgn" });
          this.setState({Rgn:""},()=>{this.setState({ RgnChoiceArr: arrRegionchoice },()=>{ this.setState({ Rgn: selRegion })})});
        }

      }

    }

  }
  UpdateMissingDivChoice = () => {
    let arrDivChoice = this.state.DivChoiceArr;
    let selDiv = this.state.Div;
    if (arrDivChoice != null && arrDivChoice != undefined && arrDivChoice.length > 0) {
      if (selDiv != null && selDiv != undefined && selDiv.length > 0) {
        if (!arrDivChoice.some(el => el.key === selDiv)) {
          arrDivChoice.push({ key: selDiv.trim(), text: selDiv, id: "Div" });
          this.setState({Div:""},()=>{this.setState({ DivChoiceArr: arrDivChoice },()=>{ this.setState({ Div: selDiv })})});
        }

      }

    }

  }
  */
  TriggerAfterVSCChange = () => {
    this.TriggerUpdateDedType();
    //this.TriggerUpdateSymbol();
    this.TriggerUpdateVSCTerm();
    this.TriggerUpdateVSCCvgs();
  }
  TriggerUpdateDedType = () => {
    this.setState({ DedType: '' })
    this.updateDedTypeOptions();
  }
  // TriggerUpdateSymbol = () => {
  //   this.setState({ Symbol: '' })
  //   this.updateSymbolOptions();
  // }
  TriggerUpdateVSCTerm = () => {
    this.setState({ VSCTerm: '' })
    this.updateVSCTermOptions();
  }
  TriggerUpdateVSCCvgs = () => {
    this.setState({ VSCCovg: '' })
    this.updateVSCCvgsOptions();
  }
  TriggerUpdateModel = () => {
    this.setState({ Model: '' })
    this.updateModelOptions();
  }
  /*
  commented for CR!
  TriggerSubCatgBindWithComments = () => {
    this.updateSubCategoryOptions();
    this.TriggerCommentsVisibility();
  }

  TriggerUpdateSubCategory = () => {
    this.setState({ ExceptSubCatg: '' }, this.TriggerCommentsVisibility);
    this.updateSubCategoryOptions();
  }
  TriggerCommentsVisibility() {
    var key = "";
    var UndComment = "";
    let commentInd = "";
    if (this.state.ExceptCatg == "") {
      key = "";

    }
    else if (this.state.ExceptSubCatg == "") {
      key = this.state.ExceptCatg;
    }
    else {
      key = this.state.ExceptCatg + this.state.ExceptSubCatg;
    }
    if (key == "") {
      // UndComment="No";
    }
    else {
      let allsubcategory = this.state.ExceptSubCatgChoiceAllArr;
      let category = this.state.ExceptCatg;
      let subcategory = this.state.ExceptSubCatg;

      if (category != '') {
        if (allsubcategory != null && allsubcategory.length > 0) {
          allsubcategory.forEach(element => {
            if (element.category == category && element.subcategory == subcategory) {
              //filteredSubCategories.push({ key: element.subcategory, text: element.subcategory, id: 'ExceptSubCatg' })
              if (element.undComment != null && element.undComment != '') {

                commentInd = "Yes";
                UndComment = element.undComment;


              }
            }
          });
        }
      }


    }
    this.setState({ CommentInd: commentInd });
    this.setState({ CatgComments: UndComment })
  }
  */
  TriggerStatesScope = () => {
    let strStatesScope = '';
    /*commented for CR1
    if (this.state.Scope != null && this.state.Scope.length > 0) {
      let arrScopes=this.state.Scope;
    for(let scopeCount=0;scopeCount<arrScopes.length;scopeCount++ )
    {
      let elementScope=arrScopes[scopeCount];
      if(elementScope=="Nationwide")
      {
        for(let statescopeCount=0;statescopeCount<stateScopeMatrix.length;statescopeCount++)
        {
           let elStateScope=stateScopeMatrix[statescopeCount];
           if(elStateScope.AreaName==elementScope)
           {
             strStatesScope=elStateScope.States;
           }
        }
        break;
      }


      else
      {
       for(let statescopeCount=0;statescopeCount<stateScopeMatrix.length;statescopeCount++)
       {
          let elStateScope=stateScopeMatrix[statescopeCount];
          if(elStateScope.AreaName==elementScope)
          {
            if(strStatesScope=='')
            {
            strStatesScope=elStateScope.States;
            }
            else
            {
              strStatesScope+=";"+elStateScope.States;
            }
          }
       }
      }

    }

    }
     else {
    */

      if (this.state.States != null && this.state.States.length > 0) {
        let arrAllStates = this.state.States;
        let allStates = '';
        arrAllStates.forEach(element => {
          if (allStates != '') {
            allStates += ";" + element;
          }
          else {
            allStates += element;
          }
        });

        strStatesScope = allStates;
      }
    //}
    this.setState({ StatesScope: strStatesScope })
  }
  getEditFormDetailsComp = () => {
    try {
      // if(edit)
      if (isEditMode) {
        this.getFormDefaultDetails();
      }
      else {
        ExceptionsAction.getEditFormDetails(uniqueId,exceptionlistName);
      }
      //    ExceptionsStore.on('getEditFormDetailschange', this.assignEditFormDetailsStore);
    } catch (e) {
      console.log('EditClickBtn' + e);
    }
  }

  populateExceptType(isAdmin, isAccountAdmin, isUnderWriter) {
    let excepttypeArray = [];

    if (isAccountAdmin) {
      excepttypeArray.push({ key: "Contract", text: "Contract", id: "ExceptType" })
      // this.setState({key:"Contract"});
      if(uniqueId == 0)
      {
      this.setState({ExceptType:"Contract"});
      }
    }
    else {
      excepttypeArray.push({ key: "", text: "", id: "ExceptType" });
      excepttypeArray.push({ key: "Account", text: "Account", id: "ExceptType" });
      excepttypeArray.push({ key: "Contract", text: "Contract", id: "ExceptType" });
      excepttypeArray.push({ key: "Dealer Group", text: "Dealer Group", id: "ExceptType" });
      excepttypeArray.push({ key: "Program", text: "Program", id: "ExceptType" });
    }
    this.setState({ ExceptTypeChoiceArr: excepttypeArray });
  }
  getLoggedUsersGroup = async () => {
    try {
      let isAdmin = false;
      let isAccountAdmin = false;
      let isUnderWriter = false;
      let LoggedUsersGroup = ExceptionsStore.getUserGroupDetailsStoreValue();
      if (LoggedUsersGroup != null && LoggedUsersGroup.length > 0) {

        LoggedUsersGroup.map((groupItem) => {
          if (groupItem.Title == "Exception_Admin") {
            this.setState({ isAdmin: true })
            isAdmin = true;
          } if (groupItem.Title == "Exception_AccountAdmin") {
            this.setState({ isAccountAdmin: true })
            isAccountAdmin = true;
          } if (groupItem.Title == "Exception_UnderWriter") {
            this.setState({ isUnderWriter: true })
            isUnderWriter = true;
          }
        });
      }
      this.populateExceptType(isAdmin, isAccountAdmin, isUnderWriter)

      // isUnderWriter && this.state.Status == 'Draft' ?
      //     this.setState({ Status: 'Assigned' }) : null;

    } catch (e) {
      console.log('getLoggedUsersGroup' + e);
    }
  }

  getLoggedUserInfo = async () => {
    try {

      loggedinUserDetail = ExceptionsStore.getUserInfoDetailStoreValue();

      //seting reqbyid only for new doc to display in the page
      if (uniqueId != 0)
      {

      }
      else{
        this.setState({ReqByText:loggedinUserDetail.Title});
        this.setState({ReqById:loggedinUserDetail.Id});
        this.setState({ReqByEmail:loggedinUserDetail.Email});
        let todayDate=new Date();
        this.setState({ReqDate:todayDate});
      }

      // isUnderWriter && this.state.Status == 'Draft' ?
      //     this.setState({ Status: 'Assigned' }) : null;

    } catch (e) {
      console.log('getLoggedInUserDetail' + e);
    }
  }
  EditClickBtn = () => {
    try {
      if(this.state.RecordStatus == "Cancelled" ||( this.state.RecordStatus == "Contract" && processed=="Yes")){

			alert("Cancelled, or processed exceptions may not be edited.")
    }
    else{
      isEditMode = true;
      isViewMode = false;
      this.getEditFormDetailsComp();
    }
    } catch (e) {
      console.log('EditClickBtn' + e);
    }
  }

  ViewClickBtn = () => {
    try {
      isEditMode = false;
      isViewMode = true;
      this.getEditFormDetailsComp();
    } catch (e) {
      console.log('ViewClickBtn' + e);
    }
  }



  assignEditFormDetailsStore = () => {
    EditFormDetails = ExceptionsStore.getEditClickStoreValue();
    let domparser = new DOMParser();
    let s = new XMLSerializer();
    if (EditFormDetails.length != 0) {

      let parsedNotes = domparser.parseFromString(EditFormDetails.Notes, 'text/html');
      parsedNotes.querySelectorAll('[class*=se-component]').forEach((ext) => { ext.removeAttribute('class'); });
      // let attachmentNotes=[];
      // var allAnchors=parsedNotes.querySelectorAll('img');
      // if(allAnchors!=null && allAnchors!=undefined && allAnchors.length>0)
      // {
      //   allAnchors.forEach(element=>{
      //     if(element!=null && element!=undefined && element.src!=null && element.src!=undefined)
      //     {
      //       let listAttachment="Exception/Attachments";
      //       if(element.src.indexOf(listAttachment)>-1)
      //       {
      //         attachmentNotes.push({FileName:element.getAttribute('data-file-name'),FileUrl:element.src})
      //       }
      //     }
      //   })
      // }

      let serializeNotes = s.serializeToString(parsedNotes);
      //  let choiceTemp = this.state.ExceptSubCatgChoiceAllArr;
      //let choiceTempf = this.state.ExceptSubCatgChoiceFilteredArr;
      //  recordstatus = EditFormDetails.Status;

      //let arrPrevSavedFilesDetails= EditFormDetails.UploadedFiles;
      prevUploadedFilesObj = this.GetPrevSavedFiles(EditFormDetails.UploadedFiles);

      arrAllPrevAttachments = this.getAllAttachments(EditFormDetails.AttachmentFiles);
      processed = EditFormDetails.Processed;



      this.setState({
        RecordStatus: EditFormDetails.Status,
        ExceptType: EditFormDetails.ExceptType != null ? EditFormDetails.ExceptType : '',
        ProdLine: EditFormDetails.ProdLine != null ? EditFormDetails.ProdLine : '',
        /*
        commented for CR1
        ExceptCatg: EditFormDetails.ExceptCatg != null ? EditFormDetails.ExceptCatg : '',
        ExceptSubCatg: EditFormDetails.ExceptSubCatg != null ? EditFormDetails.ExceptSubCatg : '',
        */
        Customer: EditFormDetails.Customer != null ? EditFormDetails.Customer : '',
        ContractDate: (EditFormDetails.ContractDate != null && EditFormDetails.ContractDate != undefined && EditFormDetails.ContractDate != '') ? new Date(EditFormDetails.ContractDate) : null,
        States: (EditFormDetails.States != null && EditFormDetails.States != '') ? this.GetMultiChoiceArray(EditFormDetails.States, "States") : [],
        //commented for CR1
        // CatgComments: EditFormDetails.CatgComments != null ? EditFormDetails.CatgComments : '',
        // CommentInd: EditFormDetails.CommentInd != null ? EditFormDetails.CommentInd : '',
        //Scope: EditFormDetails.Scope != null && EditFormDetails.Scope!=''? this.GetMultiChoiceArray(EditFormDetails.Scope, "Scope") : [],
        StatesScope: EditFormDetails.StatesScope != null ? EditFormDetails.StatesScope : '',
        DlrGroupNm: EditFormDetails.DlrGroupNm != null ? EditFormDetails.DlrGroupNm : '',
        AcctNo: EditFormDetails.AcctNo != null ? EditFormDetails.AcctNo : '',
        AcctNm: EditFormDetails.AcctNm != null ? EditFormDetails.AcctNm : '',
        //commented for CR1
        // Div: EditFormDetails.Div != null ? EditFormDetails.Div : '',
        //Rgn: EditFormDetails.Rgn != null ? EditFormDetails.Rgn : '',
        //Terr: EditFormDetails.Terr != null ? EditFormDetails.Terr : '',
        // PgmYr: EditFormDetails.PgmYr != null ? EditFormDetails.PgmYr : '',
        DOB: (EditFormDetails.DOB != null && EditFormDetails.DOB != undefined && EditFormDetails.DOB != '') ? new Date(EditFormDetails.DOB) : null,
        CLITerm: EditFormDetails.CLITerm != null ? EditFormDetails.CLITerm : '',
        Age: EditFormDetails.Age != null ? EditFormDetails.Age : null,
        LifeCovg: EditFormDetails.LifeCovg != null ? EditFormDetails.LifeCovg : null,
        AHCovg: EditFormDetails.AHCovg != null ? EditFormDetails.AHCovg : null,
        InitCvg: EditFormDetails.InitCvg != null ? EditFormDetails.InitCvg : null,
        MoBenefit: EditFormDetails.MoBenefit != null ? EditFormDetails.MoBenefit : null,
        NewOrUsed: EditFormDetails.NewOrUsed != null ? EditFormDetails.NewOrUsed : '',
        DedType: EditFormDetails.DedType != null ? EditFormDetails.DedType : '',
        Contract: EditFormDetails.Contract != null ? EditFormDetails.Contract : '',
        ModelYr: EditFormDetails.ModelYr != null ? EditFormDetails.ModelYr : '',
        Make: EditFormDetails.Make != null ? EditFormDetails.Make : '',
        Model: EditFormDetails.Model != null ? EditFormDetails.Model : '',
        //commented for CR1
        // Symbol: EditFormDetails.Symbol != null ? EditFormDetails.Symbol : '',
        Odometer: EditFormDetails.Odometer != null ? EditFormDetails.Odometer : null,
        VSCTerm: EditFormDetails.VSCTerm != null ? EditFormDetails.VSCTerm : '',
        VSCCovg: EditFormDetails.VSCCovg != null ? EditFormDetails.VSCCovg : '',
        //commented for CR1
        // CovgLevel: EditFormDetails.CovgLevel != null ? EditFormDetails.CovgLevel : '',
        // CalcRate: EditFormDetails.CalcRate != null ? EditFormDetails.CalcRate : "0",
        // RatingFactor: EditFormDetails.RatingFactor != null ? EditFormDetails.RatingFactor : null,
        //TermFactor: EditFormDetails.TermFactor != null ? EditFormDetails.TermFactor : null,
        //CoverageFactor: EditFormDetails.CoverageFactor != null ? EditFormDetails.CoverageFactor : null,
       //BaseRate: EditFormDetails.BaseRate != null ? EditFormDetails.BaseRate : null,
       // OdometerFactor: EditFormDetails.OdometerFactor != null ? EditFormDetails.OdometerFactor : null,
        // DedSurcharge: EditFormDetails.DedSurcharge != null ? EditFormDetails.DedSurcharge : null,
        // AdminFee: EditFormDetails.AdminFee != null ? EditFormDetails.AdminFee : null,
        // OtherFees: EditFormDetails.OtherFees != null ? EditFormDetails.OtherFees : null,
        // OverRemit: EditFormDetails.OverRemit != null ? EditFormDetails.OverRemit : null,
        UnderwriterComments: EditFormDetails.UnderwriterComments != null ? EditFormDetails.UnderwriterComments : '',
        Criteria: EditFormDetails.Criteria != null ? EditFormDetails.Criteria : '',
        UnderwriterAssgnd: EditFormDetails.UnderwriterAssgndId != null && EditFormDetails.UnderwriterAssgndId!=undefined? EditFormDetails.UnderwriterAssgndId : '-1',
        UnderwriterAssgndEmail: EditFormDetails.UnderwriterAssgnd != null && EditFormDetails.UnderwriterAssgnd != undefined  ? EditFormDetails.UnderwriterAssgnd.EMail : '',
        UnderwriterAssgndText:EditFormDetails.UnderwriterAssgndText!=null?EditFormDetails.UnderwriterAssgndText:'',
        ApprovedById: EditFormDetails.ApprovedById != null && EditFormDetails.ApprovedById != undefined ? EditFormDetails.ApprovedById : '-1',
        ApprovedByText: EditFormDetails.ApprovedByText != null && EditFormDetails.ApprovedByText != undefined  ? EditFormDetails.ApprovedByText : '',
        ApprovedDate: (EditFormDetails.ApprovedDate != null && EditFormDetails.ApprovedDate != undefined && EditFormDetails.ApprovedDate != '') ? new Date(EditFormDetails.ApprovedDate) : null,
        CancelledById: EditFormDetails.CancelledById != null && EditFormDetails.CancelledById != undefined ? EditFormDetails.CancelledById : '-1',
        CancelledByText: EditFormDetails.CancelledByText != null && EditFormDetails.CancelledByText != undefined  ? EditFormDetails.CancelledByText : '',
        CancelledDate: (EditFormDetails.CancelledDate != null && EditFormDetails.CancelledDate != undefined && EditFormDetails.CancelledDate != '') ? new Date(EditFormDetails.CancelledDate) : null,
        DeniedById: EditFormDetails.DeniedById != null && EditFormDetails.DeniedById != undefined ? EditFormDetails.DeniedById : '-1',
        DeniedByText: EditFormDetails.DeniedByText != null && EditFormDetails.DeniedByText != undefined  ? EditFormDetails.DeniedByText : '',
        DeniedDate: (EditFormDetails.DeniedDate != null && EditFormDetails.DeniedDate != undefined && EditFormDetails.DeniedDate != '') ? new Date(EditFormDetails.DeniedDate) : null,
        ReviewDate: (EditFormDetails.ReviewDate != null && EditFormDetails.ReviewDate != undefined && EditFormDetails.ReviewDate != '') ? new Date(EditFormDetails.ReviewDate) : null,
        AAOK: EditFormDetails.AAOK != null ? EditFormDetails.AAOK : '',
        Notes: EditFormDetails.Notes != null ? (_.unescape(serializeNotes) != null ? _.unescape(serializeNotes) : '') : '',
        ExpDate: (EditFormDetails.ExpDate != null && EditFormDetails.ExpDate != undefined && EditFormDetails.ExpDate != '') ? new Date(EditFormDetails.ExpDate) : null,
        ReqById: EditFormDetails.ReqById != null &&  EditFormDetails.ReqById != undefined ? EditFormDetails.ReqById : '-1',
        ReqByEmail: EditFormDetails.ReqBy != null && EditFormDetails.ReqBy != undefined  ? EditFormDetails.ReqBy.EMail : '',
        ReqDate: (EditFormDetails.ReqDate != null && EditFormDetails.ReqDate != undefined && EditFormDetails.ReqDate != '') ? new Date(EditFormDetails.ReqDate) : null,
        UploadedExFiles: prevUploadedFilesObj.arrPrevSavedFilesHtml,
        Certificate: EditFormDetails.Certificate != null ? EditFormDetails.Certificate : '',
        ReqByText: EditFormDetails.ReqByText != null ? EditFormDetails.ReqByText : '',

        isLoaded: true
      }, this.getAsyncDataDetails);
    }
  }



  assignListChoiceStore = () => {
    try {
      //  let NewOrUsedChoice = [];
      if (ExceptionsStore.getListChoicesStoreValue().length != 0) {
        var AllChoiceData = ExceptionsStore.getListChoicesStoreValue();
        AllChoiceData.forEach(element => {
          this.mapListChoiceStateToData(element);
        });
      }
    }

    catch (e) {
      console.log('assignNewOrUsedStore: ' + e);
    }
  }
  adminDetailStore = () => {
    try {
      if (ExceptionsStore.getAdminDetailsStoreValue().length != 0) {
        var AdminData = ExceptionsStore.getAdminDetailsStoreValue()[0];
        console.log(AdminData);
        exceptionlogListName=AdminData.CurrentLogList;
        if(this.state.IsNewDoc){
          exceptionlistName=AdminData.CurrentExceptionList;
        }
       // exceptionlistName=AdminData.
        this.BindAdminColumnToState(AdminData);
        if (isEditMode) {
          if(!this.state.IsNewDoc)
          {
          ExceptionsAction.getEditFormDetails(uniqueId,exceptionlistName);
          }
          else
          {
            this.getAsyncDataDetails();
          }
        }

      }
    } catch (e) {
      console.log('AdminDetailStore: ' + e);
    }
  }
  sendEmailStore = () => {
    try {
      console.log("Mail sent");
      this.setState({ isSpinnerHide: true });
      if (actionBtnClicked == "log") {
       // alert("Exception has been logged");
       dialogCompletionProps.subText="Exception has been logged";
       this.setState({isModalCompletionClose:false});
      }
      else if (actionBtnClicked == "approve") {
       // alert("This exception has been approved");
       dialogCompletionProps.subText="This exception has been approved";
        this.setState({isModalCompletionClose:false});
      }
      else if (actionBtnClicked == "overturn") {
       // alert("This exception has been approved");
       dialogCompletionProps.subText="This exception has been approved";
        this.setState({isModalCompletionClose:false});
      }
      else if (actionBtnClicked == "submit") {
       // alert("This exception has been submitted");
        dialogCompletionProps.subText="This exception has been submitted";
        this.setState({isModalCompletionClose:false});
      }
      else
      {

      }
     // this.exitForm();
    }
    catch (e) {
      console.log('sendEmailStore' + e)
    }
  }
  ExceptionLogStore = () => {
    try {
      console.log("Exception Log");
      if (ExceptionsStore.getExceptionLogStoreValue != undefined) {
        this.setState({ isSpinnerHide: true });

       // alert("Exception has been logged");
       dialogCompletionProps.subText="Exception has been logged";
       this.setState({isModalCompletionClose:false});

       // this.exitForm();
      }
    }
    catch (e) {
      console.log('sendEmailStore' + e)
    }
  }
  /*
  code commented for CR1
  // DefSubCatgDetailStore = () => {
  //   try {
  //     if (ExceptionsStore.getDefSubCatgDetailsStoreValue().length != 0) {
  //       var definitionData = ExceptionsStore.getDefSubCatgDetailsStoreValue();
  //       let excep = this.state.ExceptCatg;
  //       this.BindDefAllSubCategoryToState(definitionData);
  //     }

  //   } catch (e) {
  //     console.log('definitionDetailStore: ' + e);
  //   }
  // }
  */

  /*
  code commented for CR1
  // DefScopeDetailStore = () => {
  //   try {

  //     if (ExceptionsStore.getDefScopeDetailsStoreValue().length != 0) {

  //       var definitionData = ExceptionsStore.getDefScopeDetailsStoreValue();

  //       console.log(definitionData);

  //       this.BindDefScopeToState(definitionData);
  //       console.log("this data is fopr definition" + this.state.ExceptSubCatgChoiceAllArr);
  //     }
  //     //this.setState({ NewOrUsedChoiceArr: NewOrUsedChoice });
  //   } catch (e) {
  //     console.log('definitionDetailStore: ' + e);
  //   }
  // }
  */


  ListMakeDetailStore = () => {
    try {
      if (ExceptionsStore.getListMakeDetailsStoreValue().length != 0) {
        var makeListData = ExceptionsStore.getListMakeDetailsStoreValue();
        let Make = this.state.Make;
        this.BindAllModelToState(makeListData);
      }

    } catch (e) {
      console.log('definitionDetailStore: ' + e);
    }
  }


  // Call action save Result method
  assignInsertResultStore = () => {
    try {

      if (ExceptionsStore.getInserResultStoreValue() != undefined) {
       let resID=ExceptionsStore.getInserResultStoreValue();


        if (actionBtnClicked == "saveonly") {
          this.setState({ isSpinnerHide: true });

          // alert('The exception has been saved');
          // this.exitForm();
          dialogCompletionProps.subText="The exception has been saved";
          this.setState({isModalCompletionClose:false});
        }
        else if (actionBtnClicked == "submit") {

          let To = [];

          if (this.state.UnderwriterAssgndEmail != null && this.state.UnderwriterAssgndEmail != '') {

            To.push(this.state.UnderwriterAssgndEmail);
            let subject = "An F&I Exception Has Been Submitted for Approval";
           // let body = "Detail body";
           let body=absoluteUrl + "/SitePages/ExceptionPage.aspx?listID="+exceptionlistName+"&itemID="+resID;
            this.sendMail(To, "", "", subject, body);


          }
          else {
            this.setState({ isSpinnerHide: true });
            // alert("This exception has been submitted");
            // this.exitForm();
            dialogCompletionProps.subText="This exception has been submitted";
            this.setState({isModalCompletionClose:false});
          }
        }
        else if (actionBtnClicked == "approve" ) {


          let ToEmail = [];

          let subject = "";
          if (this.state.ExceptType == "Contract" && !this.state.IsNewDoc) {
            var reqEmail = this.state.ReqByEmail;
            ToEmail.push(reqEmail);
            subject = "Your F&I Exception Has Been Approved";
          }
          else if (this.state.ExceptType == "Account") {
            let subject = "An F&I Account Exception Has Been Approved";
            if (this.state.AcctemailChoiceArr != null && this.state.AcctemailChoiceArr.length > 0) {
              let AcctemailAll = this.state.AcctemailChoiceArr;

              AcctemailAll.forEach(element => {
                let emailID = element.text;
                ToEmail.push(emailID);
              });
            }
          }
          else if (this.state.ExceptType == "Dealer Group") {
            subject = "An F&I Dealer Group Exception Has Been Approved";

            if (this.state.DlremailChoiceArr != null && this.state.DlremailChoiceArr.length > 0) {
              let DlremailAll = this.state.DlremailChoiceArr;

              DlremailAll.forEach(element => {
                let emailID = element.text;
                ToEmail.push(emailID);
              });
            }
          }


          else {
            subject = "An F&I Exception Has Been Approved";
           // ToEmail = this.state.UndemailChoiceArr;
            if (this.state.UndemailChoiceArr != null && this.state.UndemailChoiceArr.length > 0) {
              let UndemailAll = this.state.UndemailChoiceArr;

              UndemailAll.forEach(element => {
                let emailID = element.text;
                ToEmail.push(emailID);
              });
            }
          }''
          //this needs to be changed with the properr url of edit form
          //let body = absoluteUrl;
          let body=absoluteUrl + "/SitePages/ExceptionPage.aspx?listID="+exceptionlistName+"&itemID="+resID;
          this.sendMail(ToEmail, "", "", subject, body);
        }
        else if (actionBtnClicked == "log") {
          if (this.state.ExceptType == "Contract" || this.state.ExceptType == "Account") {
            this.saveExceptionLog();
          }
          else {
            //open log exception form
            this.logFormRedirect();
          }

        }


        else if (actionBtnClicked == "deny") {
          let ToEmail = [];
          // if(this.state.IsNewDoc)
          // {
          //   ToEmail.push();
          // }
          // else{

          // }
          ToEmail.push(this.state.ReqByEmail);
          let subject = "Your Exception has been Denied";
          //needs to be changed as per the edit Url
         // let body = absoluteUrl;
         let body=absoluteUrl + "/SitePages/ExceptionPage.aspx?listID="+exceptionlistName+"&itemID="+resID;
          this.sendMail(ToEmail, "", "", subject, body);
         // alert("This exception has been denied");
         dialogCompletionProps.subText="This exception has been denied";
         this.setState({isModalCompletionClose:false});

        }





        else if (actionBtnClicked == "cancel") {

          this.setState({ isSpinnerHide: true });
         // alert("This exception has been cancelled");
          dialogCompletionProps.subText="This exception has been cancelled";
          this.setState({isModalCompletionClose:false});
        }
        else if (actionBtnClicked == "overturn") {

          let ToEmail = [];

          let subject = "";
          if (this.state.ExceptType == "Contract" && !this.state.IsNewDoc) {
            var reqEmail = this.state.ReqByEmail;
            ToEmail.push(reqEmail);
            subject = "Your F&I Exception Has Been Approved";
          }
          else if (this.state.ExceptType == "Account") {
            let subject = "An F&I Account Exception Has Been Approved";
            if (this.state.AcctemailChoiceArr != null && this.state.AcctemailChoiceArr.length > 0) {
              let AcctemailAll = this.state.AcctemailChoiceArr;
              //let To = this.state.AcctemailChoiceArr;
              AcctemailAll.forEach(element => {
                let emailID = element.text;
                ToEmail.push(emailID);
              });
            }
          }
          else if (this.state.ExceptType == "Dealer Group") {
            subject = "An F&I Dealer Group Exception Has Been Approved";

            if (this.state.DlremailChoiceArr != null && this.state.DlremailChoiceArr.length > 0) {
              let DlremailAll = this.state.DlremailChoiceArr;
              //let To = this.state.AcctemailChoiceArr;
              DlremailAll.forEach(element => {
                let emailID = element.text;
                ToEmail.push(emailID);
              });
            }
          }

          else {
            subject = "An F&I Exception Has Been Approved";
           // ToEmail = this.state.UndemailChoiceArr;
            if (this.state.UndemailChoiceArr != null && this.state.UndemailChoiceArr.length > 0) {
              let UndemailAll = this.state.UndemailChoiceArr;
              //let To = this.state.AcctemailChoiceArr;
              UndemailAll.forEach(element => {
                let emailID = element.text;
                ToEmail.push(emailID);
              });
            }
          }
          //this needs to be changed with the properr url of edit form
        //  let body = absoluteUrl;
        let body=absoluteUrl + "/SitePages/ExceptionPage.aspx?listID="+exceptionlistName+"&itemID="+resID;
          this.sendMail(ToEmail, "", "", subject, body);
        }
        else if (actionBtnClicked == "delete")
        {
          dialogCompletionProps.subText="This exception has been deleted";
          this.setState({isModalCompletionClose:false});
        }
      }
    } catch (e) {
      console.log('assignInsertResultStore: ' + e);
    }
  }
  saveExceptionLog = () => {
    let createdby = loggedinUserDetail.Id;
    let createdbyText=loggedinUserDetail.Title;
    let date = new Date();
    let exceptType = this.state.ExceptType;
    let prodLine = this.state.ProdLine;
    /* commnted for CR1
    let exceptCatg = this.state.ExceptCatg;
    let exceptSubCatg = this.state.ExceptSubCatg;
    */
    let statesScope = this.state.StatesScope;
    let accNo = this.state.AcctNo;
    let accNm = this.state.AcctNm;
    //commented for CR1
    // let div = this.state.Div;
    // let rgn = this.state.Rgn;
    // let terr = this.state.Terr;
    ExceptionsAction.updateExceptionLog(exceptionlogListName, createdby,createdbyText, date, exceptType, prodLine,  statesScope, accNo, accNm)
  }
  sendMail = (To, cc, bcc, subject, body) => {
    //call send mail but no store has been defined for this action
    ExceptionsAction.SendEmail(To, cc, bcc, subject, body);
  }
  checkValidationRoutine = () => {

    let finalValidation = true;
    let flagValidation = true;
    let CreditLineValidation = true;
    let VSCValidation = true;
    if (this.state.ExceptType == '') {
      this.setState({ errorExceptType: "Please select the exception type" });
      flagValidation = false;
    }

    if (this.state.ProdLine == '') {
      this.setState({ errorProdline: "Please select the product line." });
      flagValidation = false;
    }
   /*
   commented for CR1
    if (this.state.ExceptCatg == '') {
      this.setState({ errorExceptCatg: "Please select the exception category." });
      flagValidation = false;
    }
    */
    if (this.state.States == '') {
      this.setState({ errorStates: "Please select the state(s) and/or area(s) to which this exception applies." });
      flagValidation = false;
    }
    if ((this.state.ExceptType == "Dealer Group") && (this.state.DlrGroupNm == '')) {
      this.setState({ errorDealerGroupName: "Please enter the dealer group name" });
      flagValidation = false;
    }
    if ((this.state.RecordStatus != "Requested") && (this.state.UnderwriterComments == '')) {
      this.setState({ errorUnderwriterComments: "Please enter an explaination in the underwriter comments field" });
      flagValidation = false;
    }

    if ((this.state.ExceptType == "Contract" || this.state.ExceptType == "Account") && (this.state.AcctNo == '')) {
      this.setState({ errorAccountNumber: "Please enter the account number" });
      flagValidation = false;
    }
    if ((this.state.ExceptType == "Contract" || this.state.ExceptType == "Account") && (this.state.AcctNm == '')) {
      this.setState({ errorAccountName: "Please enter the account name." });
      flagValidation = false;
    }
    /*
    if ((this.state.ExceptType == "Contract" || this.state.ExceptType == "Account") && (this.state.Div == '')) {
      this.setState({ errorDivision: "Please select the division." });
      flagValidation = false;
    }
    if ((this.state.ExceptType == "Contract" || this.state.ExceptType == "Account") && (this.state.Rgn == '')) {
      this.setState({ errorRegion: "Please select the region." });
      flagValidation = false;
    }
    if ((this.state.ExceptType == "Contract" || this.state.ExceptType == "Account") && (this.state.Terr == '')) {
      this.setState({ errorTerritory: "Please enter the territory." });
      flagValidation = false;
    }
    */
    if ((this.state.RecordStatus != "Requested") && (this.state.UnderwriterComments == "")) {
      this.setState({ errorUnderwriterComments: "Please enter an explanation in the Underwriter Comments field" });
      flagValidation = false;
    }
    if (this.state.ProdLine == "Credit") {
      CreditLineValidation = this.checkValidationProdlineCredit();
    }
    if (this.state.ProdLine == "VSC") {
      VSCValidation = this.checkValidationProdlineVSC();
    }
    if (this.state.Criteria == '') {
      this.setState({ errorCriteria: "Please enter the exception criteria." });
      flagValidation = false;
    }
    finalValidation = flagValidation && CreditLineValidation && VSCValidation;
    return finalValidation;
  }




  checkValidationProdlineCredit = () => {
    let flagValidation = true;

    if (this.state.ExceptType == 'Contract') {

      if (this.state.Certificate == '') {

        this.setState({ errorCertificate: "Please Enter the Certificate" });
        flagValidation = false;
      }

      if ((this.state.DOB == null || this.state.DOB == undefined || this.state.DOB == '') && (this.state.Age==null || this.state.Age == '')) {
        this.setState({ errorDOB: "Please enter either the DOB or the age." });
        flagValidation = false;
      }

      if (this.state.CLITerm == '') {
        this.setState({ errorCLITerm: "Please enter the term in months." });
        flagValidation = false;
      }

    }
    return flagValidation;
  }




  checkValidationProdlineVSC = () => {
    let flagValidation = true;
    if (this.state.ExceptType == "Contract") {
      //commented for CR1
      // if ((this.state.PgmYr === '')) {
      //   this.setState({ errorProgramYear: "Please enter the program year." });
      //   flagValidation = false;
      // }
      if (this.state.NewOrUsed === '') {
        this.setState({ errorNewUsed: "Please select either new or used." });
        flagValidation = false;
      }
      if (this.state.DedType === '') {
        this.setState({ errorDeductionType: "Please select the deductible type." });
        flagValidation = false;
      }
      if (this.state.ModelYr === '') {
        this.setState({ errorModelYear: "Please enter the model year." });
        flagValidation = false;
      }
      if (this.state.IsMakeNew == false && this.state.Make === '') {
        this.setState({ errorMake: "Please enter the make." });
        flagValidation = false;
      }
      if (this.state.IsModelNew === false && this.state.Model === '') {
        this.setState({ errorModel: "Please enter the model."
      });
        flagValidation = false;
      }
      //commented for CR1
      // if (this.state.Symbol === '') {
      //   this.setState({ errorSymbol: "Please select the Symbol." });
      //   flagValidation = false;
      // }
      if (this.state.Odometer==null || this.state.Odometer ==='') {
        this.setState({ errorOdometer: "Please enter the odometer reading" });
        flagValidation = false;
      }
      if (this.state.VSCTerm === '') {
        this.setState({ errorVSCTerm:  "Please select the term." });
        flagValidation = false;
      }
      if (this.state.VSCCovg === '') {
        this.setState({ errorVSCCoverage: "Please select the VSC coverage." });
        flagValidation = false;
      }
      //Commented for CR1
      // if (this.state.CovgLevel === '') {
      //   this.setState({ errorCoverageLevel: "Please select the coverage level." });
      //   flagValidation = false;
      // }
    }
    return flagValidation;
  }
  checkDecimalValidation = () => {
    let decimalFlag = true;

    if (this.state.AHCovg != null && this.state.AHCovg !== '') {
      if (!varyingDecimal.test(this.state.AHCovg)) {
        this.setState({ errorAnHCoverage: "Please Enter valid decimal" });
        decimalFlag = false;
      }
      else {
        this.setState({
          errorAnHCoverage: ''
        })

      }
    }
    if (this.state.MoBenefit != null && this.state.MoBenefit !== '') {
      if (!twoDecimal.test(this.state.MoBenefit)) {
        this.setState({ errorMonthlyBenefit: "Please Enter valid decimal" });
        decimalFlag = false;
      }
      else {
        this.setState({
          errorMonthlyBenefit: ''
        })
      }
    }
    if (this.state.InitCvg != null && this.state.InitCvg !== '') {
      if (!varyingDecimal.test(this.state.InitCvg)) {
        this.setState({ errorInitialCoverage: "Please Enter valid decimal" });
        decimalFlag = false;
      }
      else {
        this.setState({
          errorInitialCoverage: ''
        })
      }
    }
    if (this.state.Age != null && this.state.Age !== '') {
      if (!varyingDecimal.test(this.state.Age)) {
        this.setState({ errorAge: "Please Enter valid decimal" });
        decimalFlag = false;
      }
      else {
        this.setState({
          errorAge: '',
          errorDOB:''
        })
      }
    }
    if (this.state.LifeCovg != null && this.state.LifeCovg !== '') {
      if (!varyingDecimal.test(this.state.LifeCovg)) {
        this.setState({ errorLifeCoverage: "Please Enter valid decimal" });
        decimalFlag = false;
      }
      else {
        this.setState({
          errorLifeCoverage: ''
        })
      }
    }
    /* commented for CR1
    if (this.state.RatingFactor != null && this.state.RatingFactor !== '') {
      if (!threeDecimal.test(this.state.RatingFactor)) {
        this.setState({ errorRatingFactor: "Please Enter valid decimal" });
        decimalFlag = false;
      }
      else {
        this.setState({
          errorRatingFactor: ''
        })
      }
    }
    */
    if (this.state.Odometer != null && this.state.Odometer !== '') {
      if (!varyingDecimal.test(this.state.Odometer)) {
        this.setState({ errorOdometer: "Please Enter valid decimal" });
        decimalFlag = false;
      }
      else {
        this.setState({
          errorOdometer: ''
        })
      }
    }
    /* commented for CR1
    if (this.state.TermFactor != null && this.state.TermFactor !== '') {
      if (!threeDecimal.test(this.state.TermFactor)) {
        this.setState({ errorTermFactor: "Please Enter valid decimal" });
        decimalFlag = false;
      }
      else {
        this.setState({
          errorTermFactor: ''
        })
      }
    }

    if (this.state.CoverageFactor != null && this.state.CoverageFactor !== '') {
      if (!threeDecimal.test(this.state.CoverageFactor)) {
        this.setState({ errorCoverageFactor: "Please Enter valid decimal" });
        decimalFlag = false;
      }
      else {
        this.setState({
          errorCoverageFactor: ''
        })
      }
    }
    if (this.state.OdometerFactor != null && this.state.OdometerFactor !== '') {
      if (!threeDecimal.test(this.state.OdometerFactor)) {
        this.setState({ errorOdometerFactor: "Please Enter valid decimal" });
        decimalFlag = false;
      }
      else {
        this.setState({
          errorOdometerFactor: ''
        })
      }
    }

    if (this.state.DedSurcharge != null && this.state.DedSurcharge !== '') {
      if (!integerCurrency.test(this.state.DedSurcharge)) {
        this.setState({ errorDedSurcharge: "Please Enter value in whole number" });
        decimalFlag = false;
      }
      else {
        this.setState({
          errorDedSurcharge: ''
        })
      }
    }
    if (this.state.AdminFee != null && this.state.AdminFee !== '') {
      if (!integerCurrency.test(this.state.AdminFee)) {
        this.setState({ errorAdminFee: "Please enter value in whole number" });
        decimalFlag = false;
      }
      else {
        this.setState({
          errorAdminFee: ''
        })
      }
    }
    if (this.state.BaseRate != null && this.state.BaseRate !== '') {
      if (!integerCurrency.test(this.state.BaseRate)) {
        this.setState({ errorBaseRate: "Please enter value in whole number" });
        decimalFlag = false;
      }
      else {
        this.setState({
          errorBaseRate: ''
        })
      }
    }
    if (this.state.OtherFees != null && this.state.OtherFees !== '') {
      if (!integerCurrency.test(this.state.OtherFees)) {
        this.setState({ errorOtherFees: "Please enter value in whole number" });
        decimalFlag = false;
      }
      else {
        this.setState({
          errorOtherFees: ''
        })
      }
    }
    if (this.state.OverRemit != null && this.state.OverRemit !== '') {
      if (!integerCurrency.test(this.state.OverRemit)) {
        this.setState({ errorOverRemit: "Please enter value in whole number" });
        decimalFlag = false;
      }
      else {
        this.setState({
          errorOtherFees: ''
        })
      }
    }
    */
    return decimalFlag;
  }



  checkValidationAccountNo = () => {
    let flagValidation = false;
    let accountLen = '';
    let prodLine = this.state.ProdLine;
    arrayProdLinesData.forEach((element) => {
      if (element.ProdName == prodLine) {
        accountLen = element.AccountLen;
      }
    })
    if (accountLen == null || accountLen == '') {
      this.setState({ errorAccountNumber: "Please contact with the system administrator to set up the length of the account number in ProdLine"+ this.state.ProdLine +"in the Admin document" });
      flagValidation = false;

    }
    else {
      var accountlenNum = parseInt(accountLen);
      if (accountlenNum != null && accountlenNum != NaN) {
        if (accountlenNum === this.state.AcctNo.length) {
          flagValidation = true;
        }
        else {
          this.setState({ errorAccountNumber: "Please enter the " + accountlenNum + "-character account number." });
        }
      }
      else {
        this.setState({ errorAccountNumber: "Please contact with the system administrator to set up the length of the account number in ProdLine." });
      }
    }
    return flagValidation;
  }







  checkMakeModelValidation = () => {
    let flagMakeModel = true;
    if (this.state.IsMakeNew == true) {
      if (this.state.MakeNew.trim() == '') {
        this.setState({ errorMakeNew: "Please enter New Make" })
        flagMakeModel = false;
      }
      else {
        this.setState({ errorMakeNew: "" })
      }
    }
    if (this.state.IsModelNew == true) {
      if (this.state.ModelNew.trim() == '') {
        this.setState({ errorModelNew: "Please enter New  Model" })
        flagMakeModel = false;
      }
      else {
        this.setState({ errorModelNew: "" })
      }
    }
    return flagMakeModel;
  }
  DeleteRecordMethod=()=>{
  ExceptionsAction.deleteForm(exceptionlistName,uniqueId);
  }
  InsertUpdateMethod = (nextStatus, nextProcessed) => {

    try {
      let underWriterAssigned = '-1';
      let underWriterAssigndtext='';
      let approvedByText="";
      let approvedBy = "-1";
      let approvedDate: any;
      let deniedByText="";
      let deniedBy = "-1";
      let deniedDate: any;
      let cancelledByText="";
      let cancelledBy = "-1";
      let cancelledDate: any;
      let requestedBy = "-1";
      let requestedByText='';
      let requestedDate: any;
      let make = this.state.Make;
      let model = this.state.Model;
      let nextStates = '';
     // commented for CR1
     // let nextScopes='';
      if (this.state.States.length > 0) {
        let stateArray = this.state.States;
        stateArray.forEach(element => {
          if (nextStates != '') {
            nextStates += ";" + element;
          }
          else {
            nextStates = element;
          }
        });
      }
      /* commented for CR1
      if (this.state.Scope.length > 0) {
        let scopeArray = this.state.Scope;
        scopeArray.forEach(element => {
          if (nextScopes != '') {
            nextScopes += ";" + element;
          }
          else {
            nextScopes = element;
          }
        });
      }
      */



      if (this.state.IsNewDoc == true) {
        requestedBy = loggedinUserDetail.Id;
        requestedByText=loggedinUserDetail.Title;
        requestedDate = new Date();

      }
      else {
        if (this.state.ReqById !== null && this.state.ReqById!=undefined &&  this.state.ReqById !== '' && this.state.ReqById!='-1' ) {
          requestedBy = this.state.ReqById;
          requestedByText=this.state.ReqByText;
        }
        requestedDate = this.state.ReqDate;
      }
      if (this.state.UnderwriterAssgnd != null && this.state.UnderwriterAssgnd != undefined && this.state.UnderwriterAssgnd != '' && this.state.UnderwriterAssgnd!='-1') {
      //  underWriterAssignedArr.push(this.state.UnderwriterAssgnd)
      underWriterAssigned=this.state.UnderwriterAssgnd;
        underWriterAssigndtext=this.state.UnderwriterAssgndText;
      }


      else {

      }
      if (actionBtnClicked == "approve" ) {
        approvedBy = loggedinUserDetail.Id;
        approvedByText=loggedinUserDetail.Title;
        approvedDate = new Date();

      }


      else  if (actionBtnClicked =="overturn" ) {
        approvedBy = loggedinUserDetail.Id;
        approvedByText=loggedinUserDetail.Title;
        approvedDate = new Date();

      }
      else {
        if (this.state.ApprovedById != null && this.state.ApprovedById != undefined && this.state.ApprovedById != '' && this.state.ApprovedById != "-1") {
          approvedBy = this.state.ApprovedById;
          approvedByText=this.state.ApprovedByText;
        }
        approvedDate = this.state.ApprovedDate;
      }
      if (actionBtnClicked == "deny") {
        deniedBy = loggedinUserDetail.Id;
        deniedByText=loggedinUserDetail.Title;
        deniedDate = new Date();


      }
      else {
        if (this.state.DeniedById != null && this.state.DeniedById != undefined && this.state.DeniedById != '' && this.state.DeniedById != '-1') {
          deniedBy = this.state.DeniedById;
          deniedByText=this.state.DeniedByText;
        }
        deniedDate = this.state.DeniedDate;
      }
      if (actionBtnClicked == "cancel") {
        cancelledBy = loggedinUserDetail.Id;
        cancelledByText=loggedinUserDetail.Title;
        cancelledDate = new Date();

        //cancel reason filed is not provided as there is no field attached to that in lotus notes
      }
      else {
        if (this.state.CancelledById != null && this.state.CancelledById!=undefined && this.state.CancelledById != '' && this.state.CancelledById != '-1' ) {
          cancelledBy = this.state.CancelledById;
          cancelledByText=this.state.CancelledByText;
        }
        cancelledDate = this.state.CancelledDate;
      }
      if (this.state.IsMakeNew == true) {
        make = this.state.MakeNew;
      }
      if (this.state.IsModelNew == true) {
        model = this.state.ModelNew;
      }
      //commented for CR1
     // let calcRateToUpdate=this.calculateRate();
      if (uniqueId == 0) {
        this.setState({ isSpinnerHide: false });

        ExceptionsAction.saveForm(exceptionlistName, this.state.ExceptType, this.state.ProdLine,  this.state.Customer, this.state.ContractDate, nextStates,  this.state.DlrGroupNm, this.state.AcctNo, this.state.AcctNm,   this.state.DOB, this.state.CLITerm, this.state.Age, this.state.LifeCovg, this.state.AHCovg, this.state.InitCvg, this.state.MoBenefit, this.state.NewOrUsed, this.state.DedType, this.state.Contract, this.state.ModelYr, make, this.state.IsMakeNew, model, this.state.IsModelNew,  this.state.Odometer, this.state.VSCTerm, this.state.VSCCovg,  this.state.UnderwriterComments, this.state.Criteria, underWriterAssigned, approvedBy, approvedDate, this.state.ExpDate, this.state.Notes, prevUploadedFilesObj.uploadedRichTextFiles, nextStatus, nextProcessed, cancelledBy, cancelledDate, deniedBy, deniedDate, this.state.ReviewDate, this.state.AAOK, requestedBy, requestedDate,  this.state.StatesScope, prevUploadedFilesObj.newUploadedFileArray, prevUploadedFilesObj.arrPrevTobeRemovedFiles, prevUploadedFilesObj.arrPrevSavedFiles, this.state.Certificate,underWriterAssigndtext,requestedByText,approvedByText,deniedByText, cancelledByText, absoluteUrl);

      }


      else {
        this.setState({ isSpinnerHide: false });
        ExceptionsAction.updateForm(exceptionlistName,uniqueId, this.state.ExceptType, this.state.ProdLine,  this.state.Customer, this.state.ContractDate,  nextStates, this.state.DlrGroupNm, this.state.AcctNo, this.state.AcctNm,   this.state.DOB, this.state.CLITerm, this.state.Age, this.state.LifeCovg, this.state.AHCovg, this.state.InitCvg, this.state.MoBenefit, this.state.NewOrUsed, this.state.DedType, this.state.Contract, this.state.ModelYr, make, this.state.IsMakeNew, model, this.state.IsModelNew,  this.state.Odometer, this.state.VSCTerm, this.state.VSCCovg,  this.state.UnderwriterComments, this.state.Criteria, underWriterAssigned, approvedBy, approvedDate, this.state.ExpDate, this.state.Notes, prevUploadedFilesObj.uploadedRichTextFiles, nextStatus, nextProcessed, cancelledBy, cancelledDate, deniedBy, deniedDate, this.state.ReviewDate, this.state.AAOK, requestedBy, requestedDate,  this.state.StatesScope, prevUploadedFilesObj.newUploadedFileArray, prevUploadedFilesObj.arrPrevTobeRemovedFiles, prevUploadedFilesObj.arrPrevSavedFiles, this.state.Certificate,underWriterAssigndtext,requestedByText,approvedByText,deniedByText,cancelledByText, absoluteUrl);
      }
    }
    catch (e) {
      console.log('insertForm: ' + e);
    }
  }




  mapListChoiceStateToData = (element) => {
    if (element != null) {

      let choiceArr = this.GetChoiceArray(element);
      switch (element.InternalName) {

        // case 'ExceptType':
        //   {

        //     this.setState({ ExceptTypeChoiceArr: choiceArr })
        //     break;
        //   }
        // case 'ProdLine':
        //   {

        //     this.setState({ ProdLineChoiceArr:choiceArr })
        //     break;
        //   }
        case 'NewOrUsed':
          {

            this.setState({ NewOrUsedChoiceArr: choiceArr })
            break;
          }
        case 'AAOK':
          {

            this.setState({ AAOKChoiceArr: choiceArr })
            break;
          }
      }
      //    }
      //  )
    }
    // ExceptionsStore.getNewOrUsedChoiceStoreValue().map((item) => {
    //   NewOrUsedChoice.push({ key: item, text: item, id: 'NewOrUsed' })
    // })
    // this.setState({ NewOrUsedChoiceArr: NewOrUsedChoice })


  }
  onFileChange = event => {
    // Update the state
    if (event != null && event.target != null && event.target.files.length > 0) {
      let fileName = event.target.files[0].name;
      if (event.target.files[0].size > 0) {
        var allowUpload = this.CheckFileBeforeUpload(fileName);
        if (allowUpload) {
          //  let fileArr=this.state.selectedFiles ;
          //  if(fileArr==null)
          //  {
          //    fileArr=[];
          //  }
          let AllNewFiles = [];
          if (this.state.selectedFiles != null && this.state.selectedFiles != undefined && this.state.selectedFiles.length > 0) {




            AllNewFiles = this.state.selectedFiles;
            AllNewFiles.push(<div id={event.target.files[0].name}>{event.target.files[0].name}<IconButton iconProps={{ iconName: 'Delete' }} name={event.target.files[0].name} onClick={(event) => this.onRemoveNewSelectedFile(fileName)} ></IconButton></div>)
            prevUploadedFilesObj.newUploadedFileArray.push(event.target.files[0]);
          }


          else {

            AllNewFiles.push(<div id={event.target.files[0].name}>{event.target.files[0].name}<IconButton iconProps={{ iconName: 'Delete' }} name={event.target.files[0].name} onClick={(event) => this.onRemoveNewSelectedFile(fileName)} ></IconButton></div>);
            prevUploadedFilesObj.newUploadedFileArray.push(event.target.files[0]);
          }

          this.setState({ selectedFiles: AllNewFiles });
        }
      }
      else {
       // alert('The file is having blank');
       dialogModalError.subText="The file is having blank";
       this.setState({isModalErrorClose:false});
      }
    }

  }
  onRemoveNewSelectedFile = (fileName) => {


    console.log(fileName);
    let allFiles = this.state.selectedFiles;
    let counter = 0;
    prevUploadedFilesObj.newUploadedFileArray.forEach((element) => {

      if (element.name == fileName) {
        prevUploadedFilesObj.newUploadedFileArray.splice(counter, 1);
        allFiles.splice(counter, 1);
      }
      counter = counter + 1;
    })

    this.setState({ selectedFiles: allFiles });
  }


  onRemoveExUploadedFile = (fileName) => {

    let existingSpan = this.state.UploadedExFiles;
    let allExFilesArrHtml = prevUploadedFilesObj.arrPrevSavedFilesHtml;
    let allExFilesArr = prevUploadedFilesObj.arrPrevSavedFiles;
    let alltobeRemovedArr = prevUploadedFilesObj.arrPrevTobeRemovedFiles;
    let counter = 0;
    allExFilesArrHtml.forEach((element) => {

      if (element.props.id == fileName) {
        // newUploadedFileArray.splice(counter,1);
        allExFilesArrHtml.splice(counter, 1);
        allExFilesArr.splice(counter, 1);

        this.insertToArrayTobeRemoved(fileName);

      }
      counter = counter + 1;
    })


    prevUploadedFilesObj.arrPrevSavedFilesHtml = allExFilesArrHtml;
    prevUploadedFilesObj.arrPrevSavedFiles = allExFilesArr;
    // prevUploadedFilesObj.arrPrevTobeRemovedFiles=alltobeRemovedArr;
    this.setState({ UploadedExFiles: allExFilesArrHtml });
  }
  // Get Input Details
  inputFormChange = (inputValue) => {
    try {
      //#region BindStateValue
      switch (inputValue.target.name) {


        case 'Customer':
          {
            this.setState({ Customer: inputValue.target.value })
            break;
          }
        case 'ContractDate':
          {
            this.setState({ ContractDate: inputValue.target.value })
            break;
          }
        case 'States':
          {
            this.setState({ States: inputValue.target.value })
            break;
          }
        //commented for CR1
        // case 'CatgComments':
        //   {
        //     this.setState({ CatgComments: inputValue.target.value })
        //     break;
        //   }
        case 'DlrGroupNm':
          {
            this.setState({ DlrGroupNm: inputValue.target.value })
            this.setState({ errorDealerGroupName: '' });
            break;
          }
        case 'AcctNo':
          {

            this.setState({ AcctNo: inputValue.target.value })
            this.setState({ errorAccountNumber: '' });
            break;
          }
        case 'AcctNm':
          {
            this.setState({ AcctNm: inputValue.target.value })
            this.setState({ errorAccountName: '' });
            break;
          }
        //commented for CR1
        // case 'Terr':
        //   {
        //     this.setState({ Terr: inputValue.target.value })
        //     this.setState({ errorTerritory: '' });
        //     break;
        //   }
        case 'Certificate':
          {
            this.setState({ Certificate: inputValue.target.value })
            this.setState({ errorCertificate: '' });
            break;
          }
          //commented for CR1
        // case 'PgmYr':
        //   {
        //     this.setState({ PgmYr: inputValue.target.value })
        //     this.setState({ errorProgramYear: '' });
        //     break;
        //   }

        case 'DOB':
          {
            this.setState({ DOB: inputValue.target.value })
            break;
          }
        case 'CLITerm':
          {
            this.setState({ CLITerm: inputValue.target.value })
            this.setState({ errorCLITerm: '' });
            break;
          }
        case 'Age':
          {
            // this.setState({ Age: inputValue.target.value })
            // this.setState({ errorAge: '' });
            if (inputValue.target.value != '' && !varyingDecimalType.test(inputValue.target.value)) {
              this.setState({ errorAge: "Please Enter valid decimal" });

            }
            else {
              this.setState({ Age: inputValue.target.value })
              this.setState({ errorAge: "" });
              this.setState({ errorDOB: "" });
            }
            break;
          }
        case 'LifeCovg':
          {
            if (inputValue.target.value != '' && !varyingDecimalType.test(inputValue.target.value)) {
              this.setState({ errorLifeCoverage: "Please Enter valid decimal" });

            }
            else {
              this.setState({ LifeCovg: inputValue.target.value })
              this.setState({ errorLifeCoverage: "" });
            }
            break;
          }
        case 'AHCovg':
          {
            if (inputValue.target.value != '' && !varyingDecimalType.test(inputValue.target.value)) {
              this.setState({ errorAnHCoverage: "Please Enter valid decimal" });

            }
            else {
              this.setState({ AHCovg: inputValue.target.value })
              this.setState({ errorAnHCoverage: "" });
            }
            break;
          }
        case 'InitCvg':
          {
            if (inputValue.target.value != '' && !varyingDecimalType.test(inputValue.target.value)) {
              this.setState({ errorInitialCoverage: "Please Enter valid decimal" });

            }
            else {
              this.setState({ InitCvg: inputValue.target.value })
              this.setState({ errorInitialCoverage: "" });
            }
            break;
          }
        case 'MoBenefit':
          {
            if (inputValue.target.value != '' && !twoDecimalType.test(inputValue.target.value)) {
              this.setState({ errorMonthlyBenefit: "Please Enter valid decimal" });

            }
            else {
              this.setState({ MoBenefit: inputValue.target.value })
              this.setState({ errorMonthlyBenefit: "" });
            }
            break;
          }

        // case 'DedType':
        //   {
        //     this.setState({ DedType: inputValue.target.value })
        //     break;
        //   }
        case 'Contract':
          {
            this.setState({ Contract: inputValue.target.value })
            break;
          }
        case 'ModelYr':
          {
            this.setState({ ModelYr: inputValue.target.value })
            this.setState({ errorModelYear: '' });
            break;
          }
        case 'Odometer':
          {
            // this.setState({ Odometer: inputValue.target.value })
            // this.setState({ errorOdometer: '' });
            if (inputValue.target.value != '' && !varyingDecimalType.test(inputValue.target.value)) {
              this.setState({ errorOdometer: "Please Enter valid decimal" });

            }
            else {
              this.setState({ Odometer: inputValue.target.value })
              this.setState({ errorOdometer: "" });
            }
            break;
          }

        /* commented for CR1
        case 'CovgLevel':
          {

            this.setState({ CovgLevel: inputValue.target.value })
            this.setState({ errorCoverageLevel: "" });

            break;
          }

        case 'RatingFactor':
          {
            if (inputValue.target.value != '' && !threeDecimalType.test(inputValue.target.value)) {
              this.setState({ errorRatingFactor: "Please Enter valid decimal" });

            }
            else {
              this.setState({ RatingFactor: inputValue.target.value })
              this.setState({ errorRatingFactor: "" });
            }
            break;
          }
        case 'TermFactor':
          {
            if (inputValue.target.value != '' && !threeDecimalType.test(inputValue.target.value)) {
              this.setState({ errorTermFactor: "Please Enter valid decimal" });

            }
            else {
              this.setState({ TermFactor: inputValue.target.value })
              this.setState({ errorTermFactor: "" });
            }
            // this.setState({ TermFactor: inputValue.target.value })
            break;
          }
        case 'CoverageFactor':
          {
            if (inputValue.target.value != '' && !threeDecimalType.test(inputValue.target.value)) {
              this.setState({ errorCoverageFactor: "Please Enter valid decimal" });

            }
            else {
              this.setState({ CoverageFactor: inputValue.target.value })
              this.setState({ errorCoverageFactor: "" });
            }
            break;
          }
        case 'BaseRate':
          {
            if (inputValue.target.value != '' && !integerCurrency.test(inputValue.target.value)) {
              this.setState({ errorBaseRate: "Please enter value in whole number" });

            }
            else {
              this.setState({ BaseRate: inputValue.target.value })
              this.setState({ errorBaseRate: "" });
            }
            break;
          }
        case 'OdometerFactor':
          {

            if (inputValue.target.value != '' && !threeDecimalType.test(inputValue.target.value)) {
              this.setState({ errorOdometerFactor: "Please Enter valid decimal" });

            }
            else {
              this.setState({ OdometerFactor: inputValue.target.value })
              this.setState({ errorOdometerFactor: "" });
            }
            break;
          }
        case 'DedSurcharge':
          {
            if (inputValue.target.value != '' && !integerCurrency.test(inputValue.target.value)) {
              this.setState({ errorDedSurcharge: "Please Enter value in whole number" });

            }
            else {
              this.setState({ DedSurcharge: inputValue.target.value })
              this.setState({ errorDedSurcharge: "" });
            }
            break;
          }
        case 'AdminFee':
          {

            if (inputValue.target.value != '' && !twoDecimalType.test(inputValue.target.value)) {
              this.setState({ errorAdminFee: "Please enter value in whole number" });

            }
            else {
              this.setState({ AdminFee: inputValue.target.value })
              this.setState({ errorAdminFee: "" });
            }
            break;
          }
        case 'OtherFees':
          {
            if (inputValue.target.value != '' && !integerCurrency.test(inputValue.target.value)) {
              this.setState({ errorOtherFees: "Please enter value in whole number" });

            }
            else {
              this.setState({ OtherFees: inputValue.target.value })
              this.setState({ errorOtherFees: "" });
            }
            break;
          }
        case 'OverRemit':
          {
            if (inputValue.target.value != '' && !integerCurrency.test(inputValue.target.value)) {
              this.setState({ errorOverRemit: "Please enter value in whole number" });

            }
            else {
              this.setState({ OverRemit: inputValue.target.value })
              this.setState({ errorOverRemit: "" });
            }
            break;
          }
          */
        case 'UnderwriterComments':
          {
            this.setState({ UnderwriterComments: inputValue.target.value })
            this.setState({ errorUnderwriterComments: '' });
            break;
          }
        case 'Criteria':
          {
            this.setState({ Criteria: inputValue.target.value })
            this.setState({ errorCriteria: '' });
            break;
          }
        // case 'UnderwriterAssgnd':
        //   {
        //     this.setState({ UnderwriterAssgnd: inputValue.target.value })
        //     break;
        //   }
        // case 'ApprovedByName':
        //   {
        //     this.setState({ ApprovedByName: inputValue.target.value })
        //     break;
        //   }
        case 'ApprovedDate':
          {
            this.setState({ ApprovedDate: inputValue.target.value })
            break;
          }
        case 'ExpDate':
          {
            this.setState({ ExpDate: inputValue.target.value })
            break;
          }
        case 'Notes':
          {
            this.setState({ Notes: inputValue.target.value })
            break;
          }
        case 'MakeNew':
          {
            this.setState({ MakeNew: inputValue.target.value })
            break;
          }
        case 'ModelNew':
          {
            this.setState({ ModelNew: inputValue.target.value })
            break;
          }
      }
      //#endregion
    }
    catch (e) {
      console.log('inputFormChange: ' + e);
    }
  }


  // Get Input RichText Details
  handleRichTextChange = (fieldName, content) => {
    try {
      switch (fieldName) {

        case 'Notes':
          this.setState({ Notes: content });
          break;
      }
    }
    catch (e) {
      console.log('handleRichTextChange: ' + e);
    }
  }
  private insertToArrayTobeRemoved(fileName) {
    if ((arrAllPrevAttachments != null && arrAllPrevAttachments != undefined && arrAllPrevAttachments.length > 0 && arrAllPrevAttachments.indexOf(fileName) > -1)) {
      let alltobeRemovedArr = prevUploadedFilesObj.arrPrevTobeRemovedFiles;
      if (alltobeRemovedArr != null && alltobeRemovedArr != undefined) {
        if (alltobeRemovedArr.length > 0 && alltobeRemovedArr.indexOf(fileName) < 0) {
          alltobeRemovedArr.push(fileName);
        }

        else {

          alltobeRemovedArr.push(fileName);


        }
      }

      else {
        alltobeRemovedArr.push(fileName);
      }
      prevUploadedFilesObj.arrPrevTobeRemovedFiles = alltobeRemovedArr;
    }
  }


  private GetPrevSavedFiles(arrPrevSavedFilesDetails: any) {
    let arrPrevSavedFiles = [];
    let arrPrevSavedFilesHtml = [];
    let arrPrevTobeRemovedFiles = [];
    let newUploadedFileArray = [];
    let uploadedRichTextFiles = [];
    if (arrPrevSavedFilesDetails != null && arrPrevSavedFilesDetails != '') {
      let arrAllPrevFiles = [];

      arrAllPrevFiles = arrPrevSavedFilesDetails.split(';');
      if (arrAllPrevFiles != null && arrAllPrevFiles != undefined && arrAllPrevFiles.length > 0) {

        arrAllPrevFiles.forEach((filElement) => {

          // NewFileDetails.push({FuileName:})
          if (filElement != null && filElement != undefined && filElement.length > 0) {
            // let splittedDetails = filElement;
            let fileUrl = absoluteUrl + "/Lists/" + exceptionlistName + "/Attachments/" + uniqueId + "/" + filElement;
            arrPrevSavedFiles.push({ FileName: filElement, FileUrl: fileUrl });

            arrPrevSavedFilesHtml.push(<div id={filElement} style={{ display: "inline" }}><a href={fileUrl} download>{filElement}</a><IconButton iconProps={{ iconName: 'Delete' }} onClick={(event) => this.onRemoveExUploadedFile(filElement)}></IconButton></div>);
          }
        });
      }
      // this.setState({AttachedFiles:NewFileDetails});
    }
    let allPrevFiles = { arrPrevSavedFiles, arrPrevSavedFilesHtml, arrPrevTobeRemovedFiles, newUploadedFileArray, uploadedRichTextFiles }
    return allPrevFiles;
  }

  private getAllAttachments(AllAttachments) {
    let AlAttachmentFiles = [];
    if (AllAttachments != null && AllAttachments.length > 0) {
      AllAttachments.forEach(element => {
        AlAttachmentFiles.push(element.FileName);
      });
    }
    return AlAttachmentFiles;
  }
/* commented for CR1
  private BindDefAllSubCategoryToState(definitionData: any) {

    let subCategoryMatrix = [];
    definitionData.forEach(element => {
      // subCategoryMatrix.push(element["CatgTitle"]);
      subCategoryMatrix.push({ category: element.CatgTitle, subcategory: element.Subcatg, undComment: element.UndComment });

    });
    this.setState({ ExceptSubCatgChoiceAllArr: subCategoryMatrix }, this.TriggerSubCatgBindWithComments);

  }
*/

  private BindAllModelToState(MakeModelData: any) {

    // let modelMatrix = [];
    // let makeChoices = [];

    // MakeModelData.forEach(element => {
    //   let flagMakePresent: boolean = false;
    //   if (makeChoices.length > 0) {
    //     makeChoices.forEach((el) => {
    //       if (el.key == element.Make) {
    //         flagMakePresent = true;
    //       }
    //     })
    //     if (flagMakePresent == false) {
    //       makeChoices.push({ key: element.Make, text: element.Make, id: 'Make' })
    //     }
    //   }
    //   else {
    //     makeChoices.push({ key: element.Make, text: element.Make, id: 'Make' })
    //   }

    //   //  let modelArray = this.CreateChoiceFromAdminData(element.Model, "Model")
    //   modelMatrix.push({ Make: element.Make, Model: element.Model });

    // });
    // this.setState({ MakeChoiceArr: makeChoices });
    // this.setState({ ModelChoiceAllArr: modelMatrix }, this.updateModelOptions);
    let modelMatrix = [];
    let makeChoices = [];
    let unsortedMakeChoices=[];
    let sortedMakeChoices=[];
    makeChoices.push({ key: "", text: "", id: 'Make' })
    MakeModelData.forEach(element => {
      // subCategoryMatrix.push(element["CatgTitle"]);
      unsortedMakeChoices.push({ key: element.Make, text: element.Make, id: 'Make' })
      let modelArray = this.CreateChoiceFromAdminData(element.Model, "Model")
      modelMatrix.push({ Make: element.Make, Model: modelArray });

    });
    sortedMakeChoices=this.sortArray(unsortedMakeChoices);  
    makeChoices.push(...sortedMakeChoices);
    this.setState({ MakeChoiceArr: makeChoices });
    this.setState({ ModelChoiceAllArr: modelMatrix }, this.updateModelOptions);



  }
  private BindDefScopeToState(definitionData: any) {

    let ScopeAllChoice = [];
    let arrstateScope = [];
    definitionData.forEach(element => {
      // subCategoryMatrix.push(element["CatgTitle"]);
      if (element.AreaName != null && element.AreaName != '') {
        ScopeAllChoice.push({ key: element.AreaName, text: element.AreaName, id: "Scope" });
        arrstateScope.push({ AreaName: element.AreaName, States: element.States })
      }

    });
    this.setState({ ScopeChoiceArr: ScopeAllChoice });
    stateScopeMatrix = arrstateScope;
    console.log("within savedefinitiondata" + ScopeAllChoice);

  }

  // private BindMakeToState(makemodelData:any)
  // {

  //  if(makemodelData!=null && makemodelData.length>0)
  //  {
  //    let makeArray=[];
  //    let MakeModelMatrix=[];
  //     makemodelData.forEach(element => {
  //       makeArray.push({key:element.Make,text:element.Make,id:"Make"});
  //       let ModelArraySub= this.CreateChoiceFromAdminData(element.Model,"Model");
  //       MakeModelMatrix.push({Make:element.Make,Models:ModelArraySub});
  //     });

  //  }
  //  }

  private BindAdminColumnToState(AdminData: any) {
    AdminExceptListMatrix.forEach((element) => {

      let admincolumnData = AdminData[element.AdminCol];
      let exceptionColName = element.ExceptionCol;

      let choicesfromData = this.CreateChoiceFromAdminData(admincolumnData, exceptionColName);

      switch (element.ExceptionCol) {

        //here switch should be implemented with the names from the ExceptionList list
        case "ProdLine":
          this.setState({ ProdLineChoiceArr: choicesfromData });
          break;
          //commented for CR1
        // case "ExceptCatg":
        //   this.setState({ ExceptCatgChoiceArr: choicesfromData });
        //   break;
        case "States":
          this.setState({ StatesChoiceArr: choicesfromData });
          break;
        case "Div":
          this.setState({ DivChoiceArr: choicesfromData });
          break;
        case "Rgn":
          this.setState({ RgnChoiceArr: choicesfromData });
          break;
        case "DedType":

          if (element.AdminCol == "VSCDedTypes") {

            this.setState({ VSCDedTypeChoiceArr: choicesfromData });
          }
          else if (element.AdminCol == "LWDedTypes") {

            this.setState({ LWDedTypeChoiceArr: choicesfromData });
          }
          break;
          // commenting for CR1
        // case "Symbol":

        //   if (element.AdminCol == "VSCSymbols") {

        //     this.setState({ VSCSymbolChoiceArr: choicesfromData });
        //   }
        //   else if (element.AdminCol == "LWSymbols") {

        //     this.setState({ LWSymbolChoiceArr: choicesfromData });
        //   }
        //   break;
        case "VSCTerm":

          if (element.AdminCol == "VSCNewTerms") {

            this.setState({ VSCNewTermChoiceArr: choicesfromData });
          }
          else if (element.AdminCol == "VSCUsedTerms") {

            this.setState({ VSCUsedTermChoiceArr: choicesfromData });
          }
          else if (element.AdminCol == "LWNewTerms") {

            this.setState({ LWNewTermChoiceArr: choicesfromData });
          }
          else if (element.AdminCol == "LWUsedTerms") {

            this.setState({ LWUsedTermChoiceArr: choicesfromData });
          }
          break;
        case "VSCCovg":

          if (element.AdminCol == "VSCCvgs") {
            this.setState({ VSCCvgsChoiceArr: choicesfromData });
          }
          else if (element.AdminCol == "LWCvgs") {
            this.setState({ LWCvgsChoiceArr: choicesfromData });
          }
          break;
        case "UnderwriterAssgnd":
          this.setState({ UnderwriterAssgndChoiceArr: choicesfromData });
          break;
        case "AcctEmail":
          this.setState({ AcctemailChoiceArr: choicesfromData });
          break;
        case "Dlremail":
          this.setState({ DlremailChoiceArr: choicesfromData });
          break;
        case "UndEmail":
          this.setState({ UndemailChoiceArr: choicesfromData });
          break;
          case "AllListNames":
          this.setState({ AllListNamesArr: choicesfromData });
          break;
      }
    })
  }


  private CreateChoiceFromAdminData(adminColumnData: any, columnName: string) {
    let AdminColChoice = [];
    let unsortedAdminColChoice=[];
    let sortedAdminColChoice=[];
    try {
      if (adminColumnData != null && adminColumnData.length > 0) {
       
        if (columnName == "UnderwriterAssgnd") {
          AdminColChoice.push({ key:"", text: "", id: columnName, Email: ""});
          adminColumnData.map((item) => {
            if (item != null && item != '') {
              AdminColChoice.push({ key: item.ID, text: item.Title, id: columnName, Email: item.EMail });
            }
          });
        }
        else if (columnName == "AcctEmail") {
          
          adminColumnData.map((item) => {
            if (item != null && item != '') {
              AdminColChoice.push({ key: item.ID, text: item.EMail, id: columnName });
            }
          });
        }
        else if (columnName == "Dlremail") {
          
          adminColumnData.map((item) => {
            if (item != null && item != '') {
              AdminColChoice.push({ key: item.ID, text: item.EMail, id: columnName });
            }
          });
        }
        else if (columnName == "UndEmail") {
          
          adminColumnData.map((item) => {
            if (item != null && item != '') {
              AdminColChoice.push({ key: item.ID, text: item.EMail, id: columnName });
            }
          });
        }
        else {
          let AdminColDataArr = adminColumnData.split(';');
         
          if (columnName == "ProdLine") {
            AdminColChoice.push({ key: "", text: "", id: "" });
            AdminColDataArr.map((item) => {
              if (item != null && item != '') {
                let arrProdLine = item.split('-');
                if (arrProdLine != null) {
                  if (arrProdLine.length == 2) {
                    arrayProdLinesData.push({ ProdName: arrProdLine[0].trim(), AccountLen: arrProdLine[1].trim() })
                  }
                }
                AdminColChoice.push({ key: arrProdLine[0].trim(), text: arrProdLine[0].trim(), id: columnName });
              }
            });
          }
          else if(columnName=="States")
          {
           // As state is multiline so for states no blank multiline
              AdminColDataArr.map((item) => {
                if (item != null && item != '') {
                  AdminColChoice.push({ key: item.trim(), text: item.trim(), id: columnName });
                }
              });
  
          
          }
          else if(columnName=="AllListNames")
          {
            //As listName no blank value required for AllListNames
            AdminColDataArr.map((item) => {
              if (item != null && item != '') {
                AdminColChoice.push({ key: item.trim(), text: item.trim(), id: columnName });
              }
            });
          }
          else {
            AdminColChoice.push({ key: "", text: "", id: "" });
            AdminColDataArr.map((item) => {
              if (item != null && item != '') {
                unsortedAdminColChoice.push({ key: item.trim(), text: item.trim(), id: columnName });
              }
            });
           sortedAdminColChoice= this.sortArray(unsortedAdminColChoice);
           AdminColChoice.push(...sortedAdminColChoice);
          }
        }
      }
    }
    catch (e) {
      console.log('error' + e);
    }
    return AdminColChoice;
  }

  private sortArray(dataCopy)

  {

     dataCopy.sort(function(a,b){

   if(a.text.toUpperCase()<b.text.toUpperCase())

   {

  return  -1;

   }

   else if(a.text.toUpperCase()<b.text.toUpperCase())

   {

       return 1

   }

   else{

      return 0 

   }

});
return dataCopy;
  }
  private GetChoiceArray(element: any) {
    let ListColChoice = [];
    element.Choices.map((resChoice) => {
      ListColChoice.push({ key: resChoice, text: resChoice, id: element.InternalName });
    });
    return ListColChoice;
  }
  private GetMultiChoiceArray(fieldValue: any, fieldName) {

    let ListColChoice = [];
    if (fieldValue != null && fieldValue != '') {

      let arrField = fieldValue.split(';');
      if (arrField != null && arrField.length > 0) {
        arrField.map((resChoice) => {
          ListColChoice.push(resChoice);
        });
      }
    }
    return ListColChoice;
  }

  handleImageUploadBefore(files, info, uploadHandler) {
    let fileName = files[0].name;
    // this.CheckFileBeforeUpload(fileName).then((val)=>{return val});
    // return allowUploadImage;
    var allowUploadImage = true;
    if ((arrAllPrevAttachments != null && arrAllPrevAttachments != undefined && arrAllPrevAttachments.length > 0 && arrAllPrevAttachments.indexOf(fileName) > -1)) {

      let AttachmentPresent = false;
      for (let data in arrAllPrevAttachments) {
        if (data != null && data != undefined && data.length > 0) {
          if (arrAllPrevAttachments[data].toUpperCase() === fileName.toUpperCase()) {

            AttachmentPresent = true;
            break;
          }
        }
      }
      if (AttachmentPresent && prevUploadedFilesObj.arrPrevTobeRemovedFiles != null && prevUploadedFilesObj.arrPrevTobeRemovedFiles != undefined && prevUploadedFilesObj.arrPrevTobeRemovedFiles.length > 0 && prevUploadedFilesObj.arrPrevTobeRemovedFiles.indexOf(fileName) < 0) {
        allowUploadImage = false;
        alert("The file is already present.Please remove or upload file with a different Name");
      //  dialogModalError.subText="The file is already present.Please remove or upload file with a diffrent Name";
      //  this.setState({isModalErrorClose:false});
      }
    }



    if (allowUploadImage && prevUploadedFilesObj.newUploadedFileArray != null && prevUploadedFilesObj.newUploadedFileArray != undefined && prevUploadedFilesObj.newUploadedFileArray.length > 0 && prevUploadedFilesObj.newUploadedFileArray.some(el => el.name === fileName)) {
      allowUploadImage = false;
      alert("The file is already present in the new selected files.Please remove or upload file with a different Name");
      // dialogModalError.subText="The file is already present in the new selected files.Please remove or upload file with a diffrent Name";
      // this.setState({isModalErrorClose:false});
    }

    if (allowUploadImage && prevUploadedFilesObj.uploadedRichTextFiles != null && prevUploadedFilesObj.uploadedRichTextFiles != undefined && prevUploadedFilesObj.uploadedRichTextFiles.some(el => el.imgFileName === fileName)) {
      allowUploadImage = false;
      alert("The file is already present in the notes as  files.Please remove or upload file with a different Name");
    // dialogModalError.subText="The file is already present in the notes as  files.Please remove or upload file with a diffrent Name";
    // this.setState({isModalErrorClose:false});
    }
    if(allowUploadImage && files[0].type!="image/png" && files[0].type!="image/PNG" && files[0].type!="image/JPEG" && files[0].type!="image/jpeg" && files[0].type!="image/jpg" && files[0].type!="image/JPG")
   {
     allowUploadImage=false;
     alert("The image file should be in JPEG or PNG format.Please upload with specified format");
    //  dialogModalError.subText="The image file should be in JPEG or PNG format.Please upload with specified format";
    //  this.setState({isModalErrorClose:false});
   }
    return allowUploadImage;
  }
  CheckFileBeforeUpload = (fileName: any) => {
    var allowUploadImage = true;
    // return allowUploadImage;
    var allowUploadImage = true;
    if ((arrAllPrevAttachments != null && arrAllPrevAttachments != undefined && arrAllPrevAttachments.length > 0)) {

      let AttachmentPresent = false;
      for (let data in arrAllPrevAttachments) {
        if (data != null && data != undefined && data.length > 0) {
          if (arrAllPrevAttachments[data].toUpperCase() === fileName.toUpperCase()) {

            AttachmentPresent = true;
            break;
          }
        }
      }
      if (AttachmentPresent && prevUploadedFilesObj.arrPrevTobeRemovedFiles != null && prevUploadedFilesObj.arrPrevTobeRemovedFiles != undefined && prevUploadedFilesObj.arrPrevTobeRemovedFiles.indexOf(fileName) < 0) {
        allowUploadImage = false;
      //  alert("The file is already present.Please remove or upload file with a diffrent name");
      dialogModalError.subText="The file is already present.Please remove or upload file with a diffrent name";
      this.setState({isModalErrorClose:false});
      }
    }
    if (prevUploadedFilesObj.newUploadedFileArray != null && prevUploadedFilesObj.newUploadedFileArray != undefined && prevUploadedFilesObj.newUploadedFileArray.length > 0 && prevUploadedFilesObj.newUploadedFileArray.some(el => el.name === fileName)) {
      allowUploadImage = false;
      //alert("The file is already present in the new selected files.Please remove or upload file with a diffrent Name");
      dialogModalError.subText="The file is already present in the new selected files.Please remove or upload file with a different Name";
      this.setState({isModalErrorClose:false});
    }

    if (prevUploadedFilesObj.uploadedRichTextFiles != null && prevUploadedFilesObj.uploadedRichTextFiles != undefined && prevUploadedFilesObj.uploadedRichTextFiles.some(el => el.imgFileName === fileName)) {
      allowUploadImage = false;
      // alert("The file is already present in the notes as  files.Please remove or upload file with a diffrent Name");
      dialogModalError.subText="The file is already present in the notes as  files.Please remove or upload file with a different Name";
      this.setState({isModalErrorClose:false});
    }
    return allowUploadImage;

  }

  handleImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {

    if (imageInfo != null) {
      let files = prevUploadedFilesObj.uploadedRichTextFiles;
      let dataURI = imageInfo.src;
      let fileName = imageInfo.name;
      // let fileName=event.target.files[0].name;

      if (dataURI.split(',')[0].indexOf('base64') >= 0) {
        var arr = dataURI.split(','),
          mime = arr[0].match(/:(.*?);/)[1],
          bstr = atob(arr[1]),
          n = bstr.length,
          u8arr = new Uint8Array(n);
        while (n--) {
          u8arr[n] = bstr.charCodeAt(n);
        }



        const file = new File([u8arr], fileName, { type: mime });
        let fExists = files.some((f) => f.imgIndex === index);
        if (fExists) {
          //let fileTobeUpdated = files.findIndex((e)=> { return e.imgIndex === index });
          // files.push({imgIndex:index,imgFileName:fileName, imgFile: file});
          files.forEach(element => {
            if (element.imgIndex == index) {
              element.imgFileName = fileName;
              element.imgFile = file;
              element.IsBase64 = true;
            }
          });
        }
        else {
          files.push({ imgIndex: index, imgFileName: fileName, imgFile: file, IsBase64: true });
        }
        prevUploadedFilesObj.uploadedRichTextFiles = files;

      }
      else if (state == "update" && event == undefined) {

        if (files != null && files != undefined && files.length > 0) {
          let fExists = files.some((f) => f.imgIndex === index);
          if (fExists) {
            // files.forEach(element => {
            //   if(element.imgIndex==index)
            //   {
            //     //files.push({imgIndex:index,imgFileName:fileName, imgFile: null,IsBase64:false});
            //     //as same data no need to update
            //   }

            // });
          }
          else {
            files.push({ imgIndex: index, imgFileName: fileName, imgFile: null, IsBase64: false });
          }

        }
        else {
          files.push({ imgIndex: index, imgFileName: fileName, imgFile: null, IsBase64: false });
        }
        prevUploadedFilesObj.uploadedRichTextFiles = files;
      }


    }
    if ((state == "delete" && document.activeElement.className.indexOf('sun-editor-editable') > 0)) {
      // var isIndexPresent=  alluploadedfilesinRichText.some(el => el.ImgID === index);
      var counter = 0;
      if (prevUploadedFilesObj.uploadedRichTextFiles != null && prevUploadedFilesObj.uploadedRichTextFiles != undefined && prevUploadedFilesObj.uploadedRichTextFiles.length > 0) {
        prevUploadedFilesObj.uploadedRichTextFiles.forEach(element => {
          if (element.imgIndex === index) {
            prevUploadedFilesObj.uploadedRichTextFiles.splice(counter, 1);
            if (arrAllPrevAttachments != null && arrAllPrevAttachments != undefined && arrAllPrevAttachments.length > 0 && arrAllPrevAttachments.indexOf(element.imgFileName) > -1) {
              let alltobeRemovedArr = prevUploadedFilesObj.arrPrevTobeRemovedFiles;
              if (alltobeRemovedArr != null && alltobeRemovedArr != undefined) {
                if (alltobeRemovedArr.length > 0 && alltobeRemovedArr.indexOf(element.imgFileName) < 0) {

                  alltobeRemovedArr.push(element.imgFileName);
                }

                else {

                  alltobeRemovedArr.push(element.imgFileName);


                }
              }

              else {
                alltobeRemovedArr.push(element.imgFileName);
              }
              prevUploadedFilesObj.arrPrevTobeRemovedFiles = alltobeRemovedArr;
            }

          }
          counter++;
        });
      }

    }

  }

  checkWithoutCase = (dataArray: string[], filename) => {
    let flagFilePresent = 400;
    if ((dataArray != null && dataArray != undefined && dataArray.length > 0) && (filename != null && filename != undefined && filename.length > 0)) {
      for (let data in dataArray) {
        if (data != null && data != undefined && data.length > 0) {
          if (data.toUpperCase() == filename.toUpperCase) {
            flagFilePresent = 401;
            break;
          }
        }
      };
    }
    return flagFilePresent;
  }

inputhtmlDropDownChange=(event)=>{
let targetName=event.target.name;
let targetValue=event.target.value;
switch(targetName)
{
  case 'ExceptType':{
    this.setState({ExceptType:targetValue});
    this.setState({ errorExceptType: '' });
    break;
  }
  case 'ProdLine':{
    this.setState({ProdLine:targetValue},this.TriggerAfterVSCChange);
    this.setState({errorProdline:''});
    break;
  }
  case 'NewOrUsed':
          {
            this.setState({ NewOrUsed: targetValue }, this.TriggerUpdateVSCTerm);
            this.setState({ errorNewUsed: '' });
            break;
          }
  case 'DedType':
          {
            this.setState({ DedType: targetValue });
            this.setState({ errorDeductionType: '' });
            break;
          }
  case 'Make':
          {
            this.setState({ Make: targetValue }, this.TriggerUpdateModel);
            this.setState({ errorMake: '' });
            break;
          }
  case 'Model':
          {
            this.setState({ Model: targetValue });
            this.setState({ errorModel: '' });
            break;
          }
          //commented for CR1
  // case 'Symbol':
  //           {
  //             this.setState({ Symbol: targetValue });
  //             this.setState({ errorSymbol: '' });
  //             break;
  //           }
  case 'VSCTerm':
          {
            this.setState({ VSCTerm: targetValue });
            this.setState({ errorVSCTerm: '' });
            break;
          }
  case 'VSCCovg':
            {
              this.setState({ VSCCovg: targetValue});
              this.setState({ errorVSCCoverage: '' });
              break;
            }
case 'UnderwriterAssgnd':
              {
                this.setState({ UnderwriterAssgnd: targetValue })
              let userEmail= event.target.options[event.target.selectedIndex].attributes["data-email"].value;
              let userName= event.target.options[event.target.selectedIndex].attributes["data-text"].value;
                 this.setState({ UnderwriterAssgndEmail: userEmail })
                 this.setState({ UnderwriterAssgndText: userName })
                break;
              }
}

}

  // Get DropDownDetails
  inputDropDownDetailsChange = (inputValue) => {

    try {

      switch (inputValue.id) {

        case 'ExceptType':          {
            this.setState({ ExceptType: inputValue.key });
            this.setState({ errorExceptType: '' });
            break;
          }
        case 'NewOrUsed':
          {
            this.setState({ NewOrUsed: inputValue.key }, this.TriggerUpdateVSCTerm);
            this.setState({ errorNewUsed: '' });
            break;
          }
        case 'ProdLine':
          {
            console.log(inputValue.AcNoMaxLen)
            this.setState({ ProdLine: inputValue.key }, this.TriggerAfterVSCChange);
            this.setState({ errorProdline: '' })
            break;
          }
          /* commented for CR1
        case 'ExceptCatg':
          {
            this.setState({ ExceptCatg: inputValue.key }, this.TriggerUpdateSubCategory);
            this.setState({ errorExceptCatg: '' })
            break;
          }
        case 'ExceptSubCatg':
          {
            this.setState({ ExceptSubCatg: inputValue.key }, this.TriggerCommentsVisibility);

            break;
          }

        case 'Scope':
          {
            this.setState({ Scope: inputValue.key }, this.TriggerStatesScope);
            break;
          }

        case 'Div':
          {
            this.setState({ Div: inputValue.key });
            this.setState({ errorDivision: '' });
            break;
          }
        case 'Rgn':
          {
            this.setState({ Rgn: inputValue.key });
            this.setState({ errorRegion: '' });
            break;
          }
          */
        case 'DedType':
          {
            this.setState({ DedType: inputValue.key });
            this.setState({ errorDeductionType: '' });
            break;
          }
        case 'Make':
          {
            this.setState({ Make: inputValue.key }, this.TriggerUpdateModel);
            this.setState({ errorMake: '' });
            break;
          }
        case 'Model':
          {
            this.setState({ Model: inputValue.key });
            this.setState({ errorModel: '' });
            break;
          }
          //commented for CR1
        // case 'Symbol':
        //   {
        //     this.setState({ Symbol: inputValue.key })
        //     this.setState({ errorSymbol: '' });
        //     break;
        //   }
        case 'VSCTerm':
          {
            this.setState({ VSCTerm: inputValue.key })
            this.setState({ errorVSCTerm: '' });
            break;
          }
        case 'VSCCovg':
          {
            this.setState({ VSCCovg: inputValue.key })
            this.setState({ errorVSCCoverage: '' });
            break;
          }
        case 'UnderwriterAssgnd':
          {
            this.setState({ UnderwriterAssgnd: inputValue.key })
            // this.setState({errorUnderwriterComments:''});
            this.setState({ UnderwriterAssgndEmail: inputValue.Email })
            this.setState({ UnderwriterAssgndText: inputValue.text })
            break;
          }
        case 'AAOK':
          {
            this.setState({ AAOK: inputValue.key });
            // this.setState({ errorExceptType: '' });
            break;
          }

      }
    }
    catch (e) {
      console.log('inputDropDownDetailsChange: ' + e);
    }
  }
  inputCheckBoxChange = (inputValue) => {

    let targetValue = inputValue.target.checked;
    switch (inputValue.target.name) {

      case 'IsMakeNew':
        this.setState({ IsMakeNew: targetValue })
        this.setState({ Make: '' });
        this.setState({ errorMake: '' });
        this.setState({ Model: '' });
       // this.setState({ ModelChoiceFilteredArr: [] });
       this.setState({ ModelChoiceFilteredArr: [{ key: "", text: "", id: 'Model' }] });
       
        if (targetValue == false) {
          this.setState({ MakeNew: '' });
          this.setState({ errorMakeNew: '' });

        }
        break;
      case 'IsModelNew':
        this.setState({ IsModelNew: targetValue });
        this.setState({ Model: '' });
        this.setState({ errorModel: '' });
        if (targetValue == false) {
          this.setState({ ModelNew: '' });
          this.setState({ errorModelNew: '' });
        }
        break;
    }
  }

  inputMultiselectDropDownChange = (inputValue) => {
    switch (inputValue.id)
    {
    case 'States':
    {
    let seleteditemarr = [];
    if (inputValue.selected) {

      seleteditemarr = this.state.States;
      seleteditemarr.push(inputValue.key);
      this.setState({ errorStates: '' })
    }
    else {
      seleteditemarr = this.state.States;
      let i = seleteditemarr.indexOf(inputValue.key);
      if (i >= 0) {
        seleteditemarr.splice(i, 1);
      }

    }
    this.setState({ States: seleteditemarr }, this.TriggerStatesScope);
    break;
  }
  /*commented for CR1
  case 'Scope':
  {
  let seleteditemarr = [];
  if (inputValue.selected) {

    seleteditemarr = this.state.Scope;
    seleteditemarr.push(inputValue.key);
  //  this.setState({ errorSc: '' })
  }
  else {
    seleteditemarr = this.state.Scope;
    let i = seleteditemarr.indexOf(inputValue.key);
    if (i >= 0) {
      seleteditemarr.splice(i, 1);
    }

  }
  this.setState({ Scope: seleteditemarr }, this.TriggerStatesScope);
  break;
}
*/
  }
  }
  private _getContractDateDatePickerItems = (items) => {
    this.setState({ ContractDate: items })
  }
  private _getApprovedDateDatePickerItems = (items) => {
    this.setState({ ApprovedDate: items })
  }
  private _getCancelledDateDatePickerItems = (items) => {
    this.setState({ CancelledDate: items })
  }
  private _getDeniedDateDatePickerItems = (items) => {
    this.setState({ DeniedDate: items })
  }
  private _getReviewDateDatePickerItems = (items) => {
    this.setState({ ReviewDate: items })
  }
  private _getExpDateDatePickerItems = (items) => {
    this.setState({ ExpDate: items })
  }
  private _getDOBDateDatePickerItems = (items) => {

    this.setState({ DOB: items })
    this.setState({ errorDOB: '' })
    this.setState({ errorAge: '' })
  }




  PrintScreen = () => {
    try {
      window.print();
    } catch (e) {
      console.log('PrintScreen: ' + e);
    }
  }


  /*
  commented for CR1
  updateSubCategoryOptions() {

    let filteredSubCategories = [];
    let category = this.state.ExceptCatg;
    let allsubcategory = this.state.ExceptSubCatgChoiceAllArr;
    if (category != '') {
      if (allsubcategory != null && allsubcategory.length > 0) {
        allsubcategory.forEach(element => {
          if (element.category == category) {
            filteredSubCategories.push({ key: element.subcategory, text: element.subcategory, id: 'ExceptSubCatg' })

          }
        });
      }
    }
    // this.setState({ExceptSubCatg:''});
    this.setState({ ExceptSubCatgChoiceFilteredArr: filteredSubCategories })
  }
*/

  updateModelOptions() {

    let filteredModels = [];
    let make = this.state.Make;
    let allModel = this.state.ModelChoiceAllArr;
    if (make!=null && make!=undefined && make != '') {
      if (allModel != null && allModel.length > 0) {
        allModel.forEach(element => {
          if (element.Make == make) {
            //  filteredModels.push({ key: element.Model, text: element.Model, id: 'Model' })
            filteredModels = element.Model;
          }
        });
      }
    }
    else{
      filteredModels.push({ key: "", text: "", id: 'Model' });
    }
    // this.setState({Model:''});
    this.setState({ ModelChoiceFilteredArr: filteredModels })
  }


  updateDedTypeOptions = () => {

    var dedTypeArr = [];
    if (this.state.ProdLine == "VSC") {
      dedTypeArr = this.state.VSCDedTypeChoiceArr;
    }
    else {
      dedTypeArr = this.state.LWDedTypeChoiceArr;
    }
    //this.setState({DedType:''});
    this.setState({ DedTypeChoiceArr: dedTypeArr })
  }
  // updateSymbolOptions = () => {

  //   var symbolArr = [];
  //   if (this.state.ProdLine == "VSC") {
  //     symbolArr = this.state.VSCSymbolChoiceArr;
  //   }
  //   else {
  //     symbolArr = this.state.LWSymbolChoiceArr;
  //   }
  //   //this.setState({Symbol:''});
  //   this.setState({ SymbolChoiceArr: symbolArr })
  // }
  updateVSCTermOptions = () => {

    var VSCTermArr = [];
    if (this.state.ProdLine == "VSC" && this.state.NewOrUsed == "New") {
      VSCTermArr = this.state.VSCNewTermChoiceArr;
    }
    else if (this.state.ProdLine == "VSC" && this.state.NewOrUsed == "Used") {
      VSCTermArr = this.state.VSCUsedTermChoiceArr;
    }
    else if (this.state.ProdLine == "LW" && this.state.NewOrUsed == "New") {
      VSCTermArr = this.state.LWNewTermChoiceArr;
    }
    else if (this.state.ProdLine == "LW" && this.state.NewOrUsed == "Used") {
      VSCTermArr = this.state.LWUsedTermChoiceArr;
    }
    else
    {
      VSCTermArr=[{ key: "", text: "", id: "VSCTerm" }];
    }
    // this.setState({VSCTerm:''});
    this.setState({ VSCTermChoiceArr: VSCTermArr });
  }
  updateVSCCvgsOptions = () => {

    var VSCvgsArr = [];
    if (this.state.ProdLine == "VSC") {
      VSCvgsArr = this.state.VSCCvgsChoiceArr;
    }
    else {
      VSCvgsArr = this.state.LWCvgsChoiceArr;
    }

    this.setState({ VSCCovgChoiceArr: VSCvgsArr });
  }
  RetrieveAccountDetails = () => {

    var accountData = ExceptionsStore.getAccountNumberDetailsStoreValue();
    if (accountData != null && accountData.length > 0) {
      // this.setState({
      //   AcctNm:accountData[0].AcctNm,
      //    Div:accountData[0].Div,
      //    Rgn:accountData[0].Rgn,
      //    Terr:accountData[0].Terr})
      if (accountData[0] != null && accountData[0].length>0 && accountData[0][0]!=null) {
        if (accountData[0][0].AcctNm != null && accountData[0][0].AcctNm != '') {
          this.setState({ AcctNm: accountData[0][0].AcctNm, errorAccountName: '' })
        }
      /*commented for CR1
        if (accountData[0][0].Div != null && accountData[0][0].Div != '') {
          this.setState({ Div: accountData[0][0].Div, errorDivision: '' },this.UpdateMissingDivChoice);
        }
        if (accountData[0][0].Rgn != null && accountData[0][0].Rgn != '') {
          this.setState({ Rgn: accountData[0][0].Rgn, errorRegion: '' },this.UpdateMissingRegionChoice);
        }
        if (accountData[0][0].Terr != null && accountData[0][0].Terr != '') {
          this.setState({ Terr: accountData[0][0].Terr, errorTerritory: '' })
        }
     */
      }
    }

  }


  PopulateAccountDetails = () => {

    ExceptionsAction.getAccountNumberDetails(this.state.AcctNo,this.state.AllListNamesArr);

  }
  ExitMethod = () => {
    var isExit = this.modalPopupOpen('exit');

  }
  SaveMethod = () => {
    console.log(isDealerGroupDisplay);
    let checkFieldValidation = this.checkDecimalValidation();
    let checkMakeModelValidation = this.checkMakeModelValidation();
    if (checkFieldValidation == true && checkMakeModelValidation == true) {
      var isExit = this.modalPopupOpen('saveonly');
    }
    else {

    }

  }

  SubmitMethod = () => {
    let checkDecimalDataEntry = this.checkDecimalValidation();
    let checkMakeModelValidation = this.checkMakeModelValidation();
    if (checkDecimalDataEntry == true && checkMakeModelValidation == true) {
      let flag = this.checkValidationRoutine();
      if (flag == true) {
        if (this.state.ExceptType != "Program" && this.state.ExceptType != "Dealer Group") {
          flag = this.checkValidationAccountNo();
        }
        if (flag == true) {
          this.modalPopupOpen('submit');
        }
      }
    }
  }
  ApproveMethod = () => {

    let checkDecimalDataEntry = this.checkDecimalValidation();
    let checkMakeModelValidation = this.checkMakeModelValidation();
    if (checkDecimalDataEntry == true && checkMakeModelValidation == true) {
      let flag = this.checkValidationRoutine();
      if (flag == true) {
        if (this.state.ExceptType != "Program" && this.state.ExceptType != "Dealer Group") {
          flag = this.checkValidationAccountNo();
        }
        if (flag == true) {
          this.modalPopupOpen('approve');
        }
      }
    }
  }
  LogExceptionMethod = () => {
    var checkDecimalDataEntry = this.checkDecimalValidation();
    let checkMakeModelValidation = this.checkMakeModelValidation();

    if (checkDecimalDataEntry == true && checkMakeModelValidation == true) {
      // actionBtnClicked = "log";


      this.modalPopupOpen('log');
    }

  }
  LogExceptionInViewMethod = () => {
    //This is additional function incorporated to edit screen before
    try {
      this.modalPopupOpen('log');
    } catch (e) {
      console.log('LogExceptionInView' + e);
    }
  }
  DenyMethod = () => {

    var checkDecimalDataEntry = this.checkDecimalValidation();
    let checkMakeModelValidation = this.checkMakeModelValidation();
    if (checkDecimalDataEntry == true && checkMakeModelValidation == true) {
      let flag = this.checkValidationRoutine();
      if (flag == true) {
        if (this.state.ExceptType != "Program" && this.state.ExceptType != "Dealer Group") {
          flag = this.checkValidationAccountNo();
        }
        if (flag == true) {
          // actionBtnClicked = "deny";
          this.modalPopupOpen('deny');
        }
      }
    }
  }
  OverTurnMethod = () => {
    var checkDecimalDataEntry = this.checkDecimalValidation();
    let checkMakeModelValidation = this.checkMakeModelValidation();
    if (checkDecimalDataEntry == true && checkMakeModelValidation == true) {
      let flag = this.checkValidationRoutine();
      if (flag == true) {
        if (this.state.ExceptType != "Program" && this.state.ExceptType != "Dealer Group") {
          flag = this.checkValidationAccountNo();
        }
        if (flag == true) {
          this.modalPopupOpen('overturn');
        }
      }
    }
  }
  CancelMethod = () => {

    var checkDecimalDataEntry = this.checkDecimalValidation();
    let checkMakeModelValidation = this.checkMakeModelValidation();
    if (checkDecimalDataEntry == true && checkMakeModelValidation == true) {
      let flag = this.checkValidationRoutine();
      if (flag == true) {
        if (this.state.ExceptType != "Program" && this.state.ExceptType != "Dealer Group") {
          flag = this.checkValidationAccountNo();
        }
        if (flag == true) {
          //  actionBtnClicked = "cancel";
          this.modalPopupOpen('cancel');
        }
      }
    }
  }

  DeleteMethod=()=> {
    this.modalPopupOpen('delete');
  }
  modalPopupOpen = (actionCall) => {
    try {
      actionBtnClicked = actionCall;
      if (actionBtnClicked == 'exit') {
        dialogContentProps.subText = 'Do you want to exit this request without saving?';
      } else if (actionBtnClicked == 'saveonly') {
        dialogContentProps.subText = 'You are about to save this document without approving or denying.  No notifications will be sent.Do you wish to continue?';

      } else if (actionBtnClicked == 'submit') {
        dialogContentProps.subText = 'You are about to submit this exception for approval.  Do you wish to continue?';
      }

      else if (actionBtnClicked == 'approve') {
        dialogContentProps.subText = 'You are about to approve this exception. Do you wish to continue?';
      }
      else if (actionBtnClicked == 'overturn') {
        dialogContentProps.subText = 'You are about to approve this exception. Do you wish to continue?';
      }
      else if (actionBtnClicked == 'delete') {
        dialogContentProps.subText = 'You are about to delete this exception.  Do you wish to continue?';
      }
      else if (actionBtnClicked == 'deny') {
        dialogContentProps.subText = 'You are about to deny this exception.  Do you wish to continue?';
      }
      else if (actionBtnClicked == 'log') {
        dialogContentProps.subText = 'You are about to Log  this exception.  Do you wish to continue?';
      }
      else if (actionBtnClicked == 'logview') {
        dialogContentProps.subText = 'Please check  the records before logging View .  Do you wish to continue?';
      }
      else if (actionBtnClicked == 'overturn') {
        dialogContentProps.subText = 'You are about to overturn  this request.  Do you wish to continue?';
      }
      else if (actionBtnClicked == 'cancel') {
        dialogContentProps.subText = 'Warning! Once you cancel an exception, it may no longer be edited.Do you wish to continue? ' ;_

      }
      this.setState({ isModalClose: false });
    } catch (e) {
      console.log('modalPopup: ' + e);
    }
  }
  modalPopupClose = () => {
    try {
      this.setState({ isModalClose: true });
    } catch (e) {
      console.log('modalPopup: ' + e);
    }
  }
  completionForm=()=>{
    this.exitForm();
  }
  ErrorModalForm=()=>{
   this.setState({isModalErrorClose:true})
  }

  modalSubmitClick = () => {
    try {
      this.setState({ isModalClose: true });

      if (actionBtnClicked == 'exit') {
        this.exitForm();
      } else if (actionBtnClicked == 'saveonly') {
        let nextStatus = this.state.RecordStatus;
        this.InsertUpdateMethod(nextStatus, processed);
      } else if (actionBtnClicked == 'submit') {
        let nextStatus = this.state.RecordStatus;

        this.InsertUpdateMethod(nextStatus, processed);

      }
      else if (actionBtnClicked == 'approve') {
        let nextStatus = "Approved";
        this.InsertUpdateMethod(nextStatus, processed);

      }
      else if (actionBtnClicked == 'deny') {
        let nextStatus = "Denied";
        this.InsertUpdateMethod(nextStatus, processed);

      }
      else if (actionBtnClicked == 'delete') {
        let nextStatus = "Delete";
       // this.InsertUpdateMethod(nextStatus, processed);
        this.DeleteRecordMethod();
      }
      else if (actionBtnClicked == 'cancel') {
        let nextStatus = "Cancelled";
        this.InsertUpdateMethod(nextStatus, processed);

      }
      else if (actionBtnClicked == 'logview') {
        //let nextStatus = "Cancelled";
        this.EditClickBtn();

      }
      else if (actionBtnClicked == 'log') {
        //   let nextStatus="Log";
        //   this.InsertUpdateMethod(nextStatus);
        let nextStatus = this.state.RecordStatus;
        let nextProcessed = processed;
        if (this.state.ExceptType == "Contract") {
          // let nextStatus = this.state.RecordStatus;
          // let nextProcessed = processed;

          nextStatus = "Processed";
          nextProcessed = "Yes";
        }
        this.InsertUpdateMethod(nextStatus, nextProcessed);



        // else {
        //   //the logic for else logic to be included after discussion
        // }

      }
      else if (actionBtnClicked == 'overturn') {
        let nextStatus = "Approved";
        this.InsertUpdateMethod(nextStatus, processed);

      }
    } catch (e) {
      console.log('modalSubmitClick: ' + e);
    }
  }
  
  exitForm = () => {
    try {
      let exitLocation = this.props.exitLink;
      window.location.href = exitLocation;
    } catch (e) {
      console.log('exitForm: ' + e);
    }
  }
  logFormRedirect = () => {
    try {
      let exitLocation = absoluteUrl + "/SitePages/ExceptionLogPage.aspx?exListID="+exceptionlistName+"&exID="+uniqueId;
      window.location.href = exitLocation;
    } catch (e) {
      console.log('exitForm: ' + e);
    }
  }
  /* commented for CR1
  calculateRate=():number=>{

   let tmpRF:number = (this.state.RatingFactor!=null && this.state.RatingFactor!="" && parseFloat (this.state.RatingFactor)!=NaN)?parseFloat (this.state.RatingFactor):0;

   let tmpTF:any =(this.state.TermFactor!=null && this.state.TermFactor!="" && parseFloat (this.state.TermFactor)!=NaN)?parseFloat (this.state.TermFactor):0;
   let tmpCF:any =(this.state.CoverageFactor!=null && this.state.CoverageFactor!="" && parseFloat (this.state.CoverageFactor)!=NaN)?parseFloat (this.state.CoverageFactor):0;
   let tmpBR:any =(this.state.BaseRate!=null && this.state.BaseRate!="" && parseFloat (this.state.BaseRate)!=NaN)?parseFloat (this.state.BaseRate):0;
   let tmpOF:any =(this.state.OdometerFactor!=null && this.state.OdometerFactor!="" && parseFloat (this.state.OdometerFactor)!=NaN)?parseFloat (this.state.OdometerFactor):0;
   let tmpDS:any =(this.state.DedSurcharge!=null && this.state.DedSurcharge!="" && parseFloat (this.state.DedSurcharge)!=NaN)?parseFloat (this.state.DedSurcharge):0;
   let tmpAF:any =(this.state.AdminFee!=null && this.state.AdminFee!="" && parseFloat (this.state.AdminFee)!=NaN)?parseFloat (this.state.AdminFee):0;
   let tmpOTF:any = (this.state.OtherFees!=null && this.state.OtherFees!="" && parseFloat (this.state.OtherFees)!=NaN)?parseFloat (this.state.OtherFees):0;

   let calculatedFinal=0;
   calculatedFinal=this.state.isUnderWriter?(tmpRF * tmpTF * tmpCF * tmpBR * tmpOF) + tmpDS + tmpAF + tmpOTF:(this.state.CalcRate == ""?0:this.state.CalcRate);

   return calculatedFinal;
  }

  setCalcRateValue=()=>{
    let CalcRateValue=this.calculateRate();
    this.setState({CalcRate: CalcRateValue.toString()});
  }
*/
  RemoveAgeError=()=>{
    if (this.state.Age != '' && varyingDecimal.test(this.state.Age)) {
      this.setState({ errorAge: "" });
     }
    }
    RemoveLifeCovgError=()=>{
      if (this.state.LifeCovg != '' && varyingDecimal.test(this.state.LifeCovg)) {
        this.setState({ errorLifeCoverage: "" });
       }
      }
   RemoveAHCovgError=()=>{
        if (this.state.AHCovg != '' && varyingDecimal.test(this.state.AHCovg)) {
          this.setState({ errorAnHCoverage: "" });
         }
        }
        RemoveInitCovgError=()=>{
          if (this.state.InitCvg != '' && varyingDecimal.test(this.state.InitCvg)) {
            this.setState({ errorInitialCoverage: "" });
           }
          }
          RemoveOdometerReadingError=()=>{
            if (this.state.Odometer != '' && varyingDecimal.test(this.state.Odometer)) {
              this.setState({ errorOdometer: "" });
             }
            }
            RemoveMOBenefitError=()=>{
              if (this.state.MoBenefit != '' && twoDecimal.test(this.state.MoBenefit)) {
                this.setState({ errorMonthlyBenefit: "" });
               }
              }
              /*Commented for CR1
              RemoveRatingFactorError=()=>{
                if (this.state.RatingFactor != '' && threeDecimal.test(this.state.RatingFactor)) {
                  this.setState({ errorRatingFactor: "" });
                 }
                }
                RemoveTermFactorError=()=>{
                  if (this.state.TermFactor != '' && threeDecimal.test(this.state.TermFactor)) {
                    this.setState({ errorTermFactor: "" });
                   }
                  }
                  RemoveCoverageFactorError=()=>{
                    if (this.state.CoverageFactor != '' && threeDecimal.test(this.state.CoverageFactor)) {
                      this.setState({ errorCoverageFactor: "" });
                     }
                    }
                    RemoveOdometerFactorError=()=>{
                      if (this.state.OdometerFactor != '' && threeDecimal.test(this.state.OdometerFactor)) {
                        this.setState({ errorOdometerFactor: "" });
                       }
                      }
                      RemoveDedSurchargeError=()=>{
                        if (this.state.DedSurcharge != '' && integerCurrency.test(this.state.DedSurcharge)) {
                          this.setState({ errorDedSurcharge: "" });
                         }
                        }
                        RemoveAdminFeeError=()=>{
                          if (this.state.AdminFee != '' && integerCurrency.test(this.state.AdminFee)) {
                            this.setState({ errorAdminFee: "" });
                           }
                          }
                          RemoveOverRemitError=()=>{
                            if (this.state.OverRemit != '' && integerCurrency.test(this.state.OverRemit)) {
                              this.setState({ errorOverRemit: "" });
                             }
                            }
                            RemoveBaseRateError=()=>{
                              if (this.state.BaseRate != '' && integerCurrency.test(this.state.BaseRate)) {
                                this.setState({ errorBaseRate: "" });
                               }
                              }
                              RemoveOtherFeesError=()=>{
                                if (this.state.OtherFees != '' && integerCurrency.test(this.state.OtherFees)) {
                                  this.setState({ errorOtherFees: "" });
                                 }
                                }
                                */
  //Render Method //
  public render(): React.ReactElement<IExceptionsProps> {
    // console.log("lg3 "+uniqueId);
    // console.log("lg3loc"+ location.search);
    if (this.state.isLoaded == true || !isEditMode || this.state.IsNewDoc) {
      // console.log("lg4 "+uniqueId);
      // console.log("lg4loc"+ location.search);
      return (

        <ThemeProvider theme={myTheme}>

          <div className='container'>
            <div className='border p-3' style={{ backgroundColor: '#23366f' }}>
              <div className='row'>
                <div className='col-md-6 text-light'><h3>{this.props.description}</h3></div>
                <div className='col-md-6 text-right'><img src={this.props.logo} alt='Logo' width='50' height='50' /></div>
              </div>
            </div>
            {/* {isViewMode == true && isEditMode == false ? */}
            {isViewMode == true && !this.state.IsNewDoc ?

             <div>
                <div className='buttonCls dvTop'>
                  <PrimaryButton className='' text='Exit' allowDisabledFocus onClick={this.ExitMethod} />
                  {(this.state.RecordStatus == "Processed" || this.state.RecordStatus == "Cancelled") ? null : (this.state.isAccountAdmin) ? (this.state.RecordStatus == "Requested") ? <PrimaryButton className='ml-1' text='Edit' onClick={this.EditClickBtn} allowDisabledFocus /> : null : (this.state.isAccountAdmin || this.state.isAdmin || this.state.isUnderWriter) ? <PrimaryButton className='ml-1' text='Edit' onClick={this.EditClickBtn} allowDisabledFocus /> : null}
                  {!this.state.isAccountAdmin || this.state.RecordStatus != 'Approved' ? null : <PrimaryButton className='ml-1' text='Log Exception' onClick={this.LogExceptionMethod} allowDisabledFocus />}
                  { <PrimaryButton className='ml-1' text='Print' onClick={this.PrintScreen} allowDisabledFocus /> }
                </div>
                <div className='row'>
                <div className='col-md-12 divStatus'>
                  <span>{this.state.RecordStatus}</span>&nbsp;&nbsp;<span>Exception</span>
                  </div>
                  </div>
                <Separator styles={styles}></Separator>
                <div className='row'>
                 <div className='col-md-12 divRequested'>
                     <span>Requested by:</span>&nbsp;<span>{this.state.ReqByText}</span>&nbsp;<span>On</span> <span>{this.state.ReqDate!=null && this.state.ReqDate != undefined && this.state.ReqDate != '' && this.state.ReqDate != null ?moment(this.state.ReqDate).format('L') : null}</span>
                 </div>
               </div>
                <div style={{ backgroundColor: this.props.bodyBackground }}>

                  <ViewExceptions {...this.state} /></div></div> :

              <div>

                <div className='buttonCls mt-2'>
                  <PrimaryButton className='' text='Exit' allowDisabledFocus onClick={this.ExitMethod} />
                  {isEditMode == true ? <PrimaryButton className='ml-1' text='View' onClick={this.ViewClickBtn} allowDisabledFocus /> : null}
                  {((this.state.isAdmin || this.state.isUnderWriter) && this.state.RecordStatus == 'Requested') ? <PrimaryButton className='ml-1' text='Save' onClick={this.SaveMethod} allowDisabledFocus /> : null}
                  {!this.state.isAccountAdmin || this.state.RecordStatus != 'Approved' ? null : <PrimaryButton className='ml-1' text='Log Exception' onClick={this.LogExceptionMethod} allowDisabledFocus />}
                  {this.state.isAccountAdmin && this.state.IsNewDoc ? <PrimaryButton className='ml-1' text='Submit' onClick={this.SubmitMethod} allowDisabledFocus /> : null}
                  {(this.state.isAdmin || this.state.isUnderWriter) && (this.state.RecordStatus == "Requested" || this.state.RecordStatus == "Approved") ? <PrimaryButton className='ml-1' text='Approve' onClick={this.ApproveMethod} allowDisabledFocus /> : null}
                  {(this.state.RecordStatus != "Requested" || this.state.IsNewDoc) ? null : <PrimaryButton className='ml-1' text='Delete' onClick={this.DeleteMethod} allowDisabledFocus />}
                  {(this.state.RecordStatus == "Denied" && (this.state.isAdmin || this.state.isUnderWriter)) ? <PrimaryButton className='ml-1' text='Overturn' onClick={this.OverTurnMethod} allowDisabledFocus /> : null}
                  {(this.state.RecordStatus == "Requested" && (this.state.isAdmin || this.state.isUnderWriter)) ? <PrimaryButton className='ml-1' text='Deny' onClick={this.DenyMethod} allowDisabledFocus /> : null}


                {this.state.IsNewDoc?null:((this.state.RecordStatus=="Approved") && (this.state.isAdmin|| this.state.isUnderWriter)) ?<PrimaryButton className='ml-1' text='Cancel' onClick={this.CancelMethod} allowDisabledFocus />:null}
                </div>
                <div className='row'>
                <div className='col-md-12 divStatus'>
                  <span>{this.state.RecordStatus}</span>&nbsp;&nbsp;<span>Exception</span>
                  </div>
                  </div>



                <Separator styles={styles}></Separator>
                <div className='row'>
                 <div className='col-md-12 divRequested'>
                     <span>Requested by:</span>&nbsp;<span>{this.state.ReqByText}</span>&nbsp;<span>On</span> <span>{this.state.ReqDate!=null && this.state.ReqDate != undefined && this.state.ReqDate != '' && this.state.ReqDate != null ?moment(this.state.ReqDate).format('L') : null}</span>
            </div>
               </div>
                {!this.state.isSpinnerHide ? <Spinner label=" still loading..." size={SpinnerSize.large} hidden={this.state.isSpinnerHide} ariaLive="assertive" labelPosition="top">   </Spinner> :
                  <div>
                    <div className='border p-3  mt-2'>
                      <div className='row'>
                      </div>

                      <div className='row'>
                        <div className='col-md-6'>

                          {/* <Dropdown className='w-100' styles={dropdownStyles} label='Exception Type' errorMessage={this.state.errorExceptType} selectedKey={this.state.ExceptType} options={this.state.ExceptTypeChoiceArr} onChanged={this.inputDropDownDetailsChange} /> */}
                          {/* <Dropdown className='w-100' styles={dropdownStyles} label='Exception Type' errorMessage={this.state.errorExceptType} selectedKey={this.state.ExceptType} options={this.state.ExceptTypeChoiceArr} onChanged={this.inputDropDownDetailsChange} /> */}
                          <div className="titlePadding divTitleText">
                          Exception Type
                          </div>


                         <div>
                          <select  name="ExceptType"  className="form-select selCtrl" value={this.state.ExceptType} onChange={this.inputhtmlDropDownChange}  >
                          {this.state.ExceptTypeChoiceArr.map((dataChoice)=>{return <option data-key={dataChoice.key} data-text={dataChoice.text}  value={dataChoice.key}>{dataChoice.text}</option>})}
                            </select>
                            </div>
                            <div className="errorMsgSel">
                             {this.state.errorExceptType}
                            </div>
                        </div>
                        <div className='col-md-6'>
                          {/* <Dropdown className='w-100' styles={dropdownStyles} label='Product Line' errorMessage={this.state.errorProdline} selectedKey={this.state.ProdLine} options={this.state.ProdLineChoiceArr} onChanged={this.inputDropDownDetailsChange} /> */}
                          {/* <ComboBox className='w-100' styles={dropdownStyles} label='Product Line' allowFreeform={true} errorMessage={this.state.errorProdline} selectedKey={this.state.ProdLine} options={this.state.ProdLineChoiceArr}  autoComplete="on"  /> */}
                        <div className="titlePadding divTitleText">
                           Product Line
                          </div>
                         <div>
                          <select  name="ProdLine"  className="form-select selCtrl" value={this.state.ProdLine} onChange={this.inputhtmlDropDownChange}  >
                          {this.state.ProdLineChoiceArr.map((dataChoice)=>{return <option data-key={dataChoice.key} data-text={dataChoice.text}  value={dataChoice.key}>{dataChoice.text}</option>})}
                            </select>
                            </div>

                            <div className="errorMsgSel">
                             {this.state.errorProdline}
                            </div>
                        
                        </div>
                      </div>
                      {/*
                      commented for CR1
                       <div className='row'>
                        <div className='col-md-6'>
                          <Dropdown className='w-100' styles={dropdownStyles} label='Category' errorMessage={this.state.errorExceptCatg} selectedKey={this.state.ExceptCatg} options={this.state.ExceptCatgChoiceArr} onChanged={this.inputDropDownDetailsChange} />
                        </div>
                        <div className='col-md-6'>
                          <Dropdown className='w-100' label='SubCategory' selectedKey={this.state.ExceptSubCatg} options={this.state.ExceptSubCatgChoiceFilteredArr} onChanged={this.inputDropDownDetailsChange} />
                        </div>
                      </div>
                      <div className='row'>
                        <div className='col-md-6' style={{ display: this.state.CommentInd != 'Yes' ? 'none' : 'flex' }}>
                          <TextField className='w-100' disabled={true} label='Comment' value={this.state.CatgComments} name='Comment' onChange={this.inputFormChange} />
                        </div>

                      </div>
                      <div className='row'>
                      </div> */}
                      <div className='row' style={{ display: this.state.ExceptType != 'Contract' ? 'none' : 'flex' }}>

                        <div className='col-md-6'>
                          <TextField className='w-100' label='Customer Name' value={this.state.Customer} name='Customer' onChange={this.inputFormChange} />
                        </div>
                        <div className='col-md-6'>
                          <div className='w-100'><DateTimePicker label='Contract Date ' dateConvention={DateConvention.Date} showLabels={false}
                            value={this.state.ContractDate} onChange={this._getContractDateDatePickerItems} /></div>
                        </div>
                      </div>
                      <div className='row'>
                      </div>
                      <div className='row'>
                        <div className='col-md-6'>
                          <Dropdown className='w-100' styles={dropdownStyles}  label='Scope: State' multiSelect errorMessage={this.state.errorStates} defaultSelectedKeys={this.state.States} options={this.state.StatesChoiceArr} onChanged={this.inputMultiselectDropDownChange} />
                        </div>
                        {/* commented for CR1
                        <div className='col-md-6' style={{ display: this.state.ExceptType == 'Contract' ? 'none' : 'flex' }}>
                          <Dropdown className='w-100' styles={dropdownStyles} label='Area' multiSelect defaultSelectedKeys={this.state.Scope} options={this.state.ScopeChoiceArr} onChanged={this.inputMultiselectDropDownChange} />
                        </div> */}
                      </div>
                      <div className='row' >
                        <div className='col-md-6'>
                          <TextField className='w-100 multiLineMaxHeight' label='State(s)' value={this.state.StatesScope} name='StatesScope' disabled multiline />
                        </div>
                      </div>
                      <div className='row'>
                      </div>
                      <div className='row' style={{ display: this.state.ExceptType != 'Dealer Group' ? (isDealerGroupDisplay = false, 'none') : (isDealerGroupDisplay = true, 'flex') }}>
                        <div className='col-md-6'>
                          <TextField className='w-100' label='Dealer Group Name' errorMessage={this.state.errorDealerGroupName} value={this.state.DlrGroupNm} name='DlrGroupNm' onChange={this.inputFormChange} />
                        </div>
                      </div>

                      <div className='row'>
                      </div>
                      <div className='row' style={{ display: (this.state.ExceptType == 'Program' || this.state.ExceptType == 'Dealer Group') ? 'none' : 'flex' }}>
                        <div className='col-md-6'>
                          <TextField className='w-100' label='Account Number' errorMessage={this.state.errorAccountNumber} value={this.state.AcctNo} name='AcctNo' onChange={this.inputFormChange} onBlur={this.PopulateAccountDetails} />
                        </div>
                        <div className='col-md-6'>
                          <TextField className='w-100' label='Account Name' errorMessage={this.state.errorAccountName} value={this.state.AcctNm} name='AcctNm' onChange={this.inputFormChange} />
                        </div>
                      </div>
                      { /* commented for CR1
                       <div className='row' style={{ display: (this.state.ExceptType == 'Program' || this.state.ExceptType == 'Dealer Group') ? 'none' : 'flex' }}>
                        <div className='col-md-6'>
                          <Dropdown className='w-100' styles={dropdownStyles} label='Division' errorMessage={this.state.errorDivision} selectedKey={this.state.Div} options={this.state.DivChoiceArr} onChanged={this.inputDropDownDetailsChange} />
                        </div>
                        <div className='col-md-6'>
                          <Dropdown className='w-100' styles={dropdownStyles} label='Region' errorMessage={this.state.errorRegion} selectedKey={this.state.Rgn} options={this.state.RgnChoiceArr} onChanged={this.inputDropDownDetailsChange} />
                        </div>
                      </div> */}
                      <div className='row' >
                        {/*
                        commented for CR1
                         <div className='col-md-6' style={{ display: (this.state.ExceptType == 'Program' || this.state.ExceptType == 'Dealer Group') ? 'none' : 'flex' }}>
                          <TextField className='w-100' label='Territory' errorMessage={this.state.errorTerritory} value={this.state.Terr} name='Terr' onChange={this.inputFormChange} />
                        </div> */}
                        <div className='col-md-6'>
                          <div style={{ display: (this.state.ProdLine != 'Credit' || this.state.ExceptType != 'Contract') ? 'none' : 'flex' }}>
                            <TextField className='w-100' label='Certificate' errorMessage={this.state.errorCertificate} value={this.state.Certificate} name='Certificate' onChange={this.inputFormChange} />
                          </div>
                          {/* commented for CR1
                           <div style={{ display: (this.state.ProdLine == 'VSC' || this.state.ProdLine == 'LW') ? 'flex' : 'none' }}>
                            <TextField className='w-100' label='Program year' errorMessage={this.state.errorProgramYear} value={this.state.PgmYr} name='PgmYr' onChange={this.inputFormChange} />
                          </div> */}
                        </div>
                      </div>
                      <div className='row' >
                        <div className='col-md-6' style={{ display: (this.state.ProdLine !== 'Credit' || this.state.ExceptType! !== 'Contract') ? 'none' : 'flex' }}>
                          <div className='w-100'>
                            <DatePicker label='Customer DOB' textField={{ errorMessage: this.state.errorDOB }}
                              value={this.state.DOB} onSelectDate={this._getDOBDateDatePickerItems} /></div>
                        </div>
                        <div className='col-md-6' style={{ display: (this.state.ProdLine != 'Credit' || this.state.ExceptType != 'Contract') ? 'none' : 'flex' }}>
                          <TextField className='w-100' label='Term(Months)' errorMessage={this.state.errorCLITerm} value={this.state.CLITerm} name='CLITerm' onChange={this.inputFormChange} />
                        </div>
                      </div>
                      <div className='row' style={{ display: (this.state.ProdLine != 'Credit' || this.state.ExceptType != 'Contract') ? 'none' : 'flex' }}>
                        <div className='col-md-6'>
                          <TextField className='w-100' label='Age' value={this.state.Age} name='Age' errorMessage={this.state.errorAge} onChange={this.inputFormChange}  onBlur={this.RemoveAgeError}/>
                        </div>
                      </div>

                      <div className='row' >
                        <div className='col-md-6' style={{ display: (this.state.ProdLine != 'Credit' || this.state.ExceptType != 'Contract') ? 'none' : 'flex' }}>
                          <TextField className='w-100' label='Life Coverage' errorMessage={this.state.errorLifeCoverage} value={this.state.LifeCovg} name='LifeCovg' onChange={this.inputFormChange} onBlur={this.RemoveLifeCovgError} />
                        </div>
                        <div className='col-md-6' style={{ display: (this.state.ProdLine != 'Credit' || this.state.ExceptType != 'Contract') ? 'none' : 'flex' }}>
                          <TextField className='w-100' label='A&H Coverage' errorMessage={this.state.errorAnHCoverage} value={this.state.AHCovg} name='AHCovg' onChange={this.inputFormChange} onBlur={this.RemoveAHCovgError} />
                        </div>
                      </div>
                      <div className='row' >
                        <div className='col-md-6' style={{ display: (this.state.ProdLine != 'Credit' || this.state.ExceptType != 'Contract') ? 'none' : 'flex' }}>
                          <TextField className='w-100' label='Initial Coverage' errorMessage={this.state.errorInitialCoverage} value={this.state.InitCvg} name='InitCvg' onChange={this.inputFormChange} onBlur={this.RemoveInitCovgError} />
                        </div>
                        <div className='col-md-6' style={{ display: (this.state.ProdLine != 'Credit' || this.state.ExceptType != 'Contract') ? 'none' : 'flex' }}>
                          <TextField className='w-100' label='Monthly Benefit' prefix="$" errorMessage={this.state.errorMonthlyBenefit} value={this.state.MoBenefit} name='MoBenefit' onChange={this.inputFormChange} onBlur={this.RemoveMOBenefitError} />
                        </div>
                      </div>
                      <div className='row'>
                      </div>
                      <div className='row'>
                      </div>
                      <div className='row'>
                      </div>
                      <div className='row'>
                      </div>

                      <div className='row' style={{ display: (this.state.ProdLine == 'VSC' || this.state.ProdLine == 'LW') ? 'flex' : 'none' }}>
                        <div className='col-md-6'>
                          {/* <Dropdown className='w-100' styles={dropdownStyles} label='New/Used' errorMessage={this.state.errorNewUsed} selectedKey={this.state.NewOrUsed} options={this.state.NewOrUsedChoiceArr} onChanged={this.inputDropDownDetailsChange} /> */}
                          <div className="titlePadding divTitleText">
                          New/Used
                          </div>
                         <div>
                          <select  name="NewOrUsed"  className="form-select selCtrl" value={this.state.NewOrUsed} onChange={this.inputhtmlDropDownChange}  >
                          {this.state.NewOrUsedChoiceArr.map((dataChoice)=>{return <option data-key={dataChoice.key} data-text={dataChoice.text}  value={dataChoice.key}>{dataChoice.text}</option>})}
                            </select>
                            </div>

                            <div className="errorMsgSel">
                             {this.state.errorNewUsed}
                            </div>
                        
                        </div>
                        <div className='col-md-6'>
                          {/* <Dropdown className='w-100' styles={dropdownStyles} label='Deductible' errorMessage={this.state.errorDeductionType} selectedKey={this.state.DedType} options={this.state.DedTypeChoiceArr} onChanged={this.inputDropDownDetailsChange} /> */}
                          <div className="titlePadding divTitleText">
                          Deductible
                          </div>
                         <div>
                          <select  name="DedType"  className="form-select selCtrl" value={this.state.DedType} onChange={this.inputhtmlDropDownChange}  >
                          {this.state.DedTypeChoiceArr.map((dataChoice)=>{return <option data-key={dataChoice.key} data-text={dataChoice.text}  value={dataChoice.key}>{dataChoice.text}</option>})}
                            </select>
                            </div>

                            <div className="errorMsgSel">
                             {this.state.errorDeductionType}
                            </div>
                        
                        </div>
                      </div>
                      <div className='row' style={{ display: (this.state.ProdLine == 'VSC' || this.state.ProdLine == 'LW') ? 'flex' : 'none' }}>
                        <div className='col-md-6'>
                          <TextField className='w-100' label='Contract' value={this.state.Contract} name='Contract' onChange={this.inputFormChange} />
                        </div>
                        <div className='col-md-6'>
                          <TextField className='w-100' label='Model Year' errorMessage={this.state.errorModelYear} value={this.state.ModelYr} name='ModelYr' onChange={this.inputFormChange} />
                        </div>
                      </div>
                      <div className='row' style={{ display: (this.state.ProdLine == 'VSC' || this.state.ProdLine == 'LW') ? 'flex' : 'none' }}>
                        <div className='col-md-6'>
                          {/* <Dropdown className='w-100 MakeModelPadding' styles={dropdownStyles} label='Make' errorMessage={this.state.errorMake} selectedKey={this.state.Make} disabled={this.state.IsMakeNew == true} options={this.state.MakeChoiceArr} onChanged={this.inputDropDownDetailsChange} /> */}
                         
                          <div className="titlePadding divTitleText">
                          Make
                          </div>
                         <div>
                          <select  name="Make"  className="form-select selCtrl" disabled={this.state.IsMakeNew} value={this.state.Make} onChange={this.inputhtmlDropDownChange}  >
                          {this.state.MakeChoiceArr.map((dataChoice)=>{return <option data-key={dataChoice.key} data-text={dataChoice.text}  value={dataChoice.key}>{dataChoice.text}</option>})}
                            </select>
                            </div>

                            <div className="errorMsgSel">
                             {this.state.errorMake}
                            </div> <Checkbox label="Create a new Make" checked={this.state.IsMakeNew} name="IsMakeNew" onChange={this.inputCheckBoxChange} />
                          <TextField className='w-100' label='New Make Entry' value={this.state.MakeNew} errorMessage={this.state.errorMakeNew} disabled={this.state.IsMakeNew == false ? true : false} name='MakeNew' onChange={this.inputFormChange} />
                        </div>
                        <div className='col-md-6'>
                          {/* <Dropdown className='w-100 MakeModelPadding' styles={dropdownStyles} label='Model' errorMessage={this.state.errorModel} selectedKey={this.state.Model} disabled={this.state.IsModelNew == true} options={this.state.ModelChoiceFilteredArr} onChanged={this.inputDropDownDetailsChange} /> */}
                          <div className="titlePadding divTitleText">
                          Model
                          </div>
                         <div>
                          <select  name="Model"  className="form-select selCtrl" disabled={this.state.IsModelNew} value={this.state.Model} onChange={this.inputhtmlDropDownChange}  >
                          {this.state.ModelChoiceFilteredArr.map((dataChoice)=>{return <option data-key={dataChoice.key} data-text={dataChoice.text}  value={dataChoice.key}>{dataChoice.text}</option>})}
                            </select>
                            </div>

                            <div className="errorMsgSel">
                             {this.state.errorModel}
                            </div>
                          <Checkbox label="Create a new Model" checked={this.state.IsModelNew} name="IsModelNew" onChange={this.inputCheckBoxChange} />
                          <TextField className='w-100' label='New Model Entry' value={this.state.ModelNew} errorMessage={this.state.errorModelNew} disabled={this.state.IsModelNew == false ? true : false} name='ModelNew' onChange={this.inputFormChange} />
                        </div>
                      </div>

                      <div className='row' style={{ display: (this.state.ProdLine == 'VSC' || this.state.ProdLine == 'LW') ? 'flex' : 'none' }}>
                        {/* <div className='col-md-6'>
                         
                          <div className="titlePadding divTitleText">
                          Symbol
                          </div>
                         <div>
                          <select  name="Symbol"  className="form-select selCtrl"  value={this.state.Symbol} onChange={this.inputhtmlDropDownChange}  >
                          {this.state.SymbolChoiceArr.map((dataChoice)=>{return <option data-key={dataChoice.key} data-text={dataChoice.text}  value={dataChoice.key}>{dataChoice.text}</option>})}
                            </select>
                            </div>

                            <div className="errorMsgSel">
                             {this.state.errorSymbol}
                            </div>
                        </div> */}
                        <div className='col-md-6'>
                          <TextField className='w-100' label='Odometer Reading' errorMessage={this.state.errorOdometer} value={this.state.Odometer} name='Odometer' onChange={this.inputFormChange} onBlur={this.RemoveOdometerReadingError} />
                        </div>
                      </div>
                      <div className='row' style={{ display: (this.state.ProdLine == 'VSC' || this.state.ProdLine == 'LW') ? 'flex' : 'none' }}>
                        <div className='col-md-6'>
                          {/* <Dropdown className='w-100' styles={dropdownStyles} label='Term' errorMessage={this.state.errorVSCTerm} selectedKey={this.state.VSCTerm} options={this.state.VSCTermChoiceArr} onChanged={this.inputDropDownDetailsChange} /> */}
                          <div className="titlePadding divTitleText">
                          Term
                          </div>
                         <div>
                          <select  name="VSCTerm"  className="form-select selCtrl" value={this.state.VSCTerm} onChange={this.inputhtmlDropDownChange}  >
                          {this.state.VSCTermChoiceArr.map((dataChoice)=>{return <option data-key={dataChoice.key} data-text={dataChoice.text}  value={dataChoice.key}>{dataChoice.text}</option>})}
                            </select>
                            </div>
                            <div className="errorMsgSel">
                             {this.state.errorVSCTerm}
                            </div>
                        </div>
                        <div className='col-md-6'>
                          {/* <Dropdown className='w-100' styles={dropdownStyles} label='Coverage' errorMessage={this.state.errorVSCCoverage} selectedKey={this.state.VSCCovg} options={this.state.VSCCovgChoiceArr} onChanged={this.inputDropDownDetailsChange} /> */}
                          <div className="titlePadding divTitleText">
                          Coverage
                          </div>
                         <div>
                          <select  name="VSCCovg"  className="form-select selCtrl" value={this.state.VSCCovg} onChange={this.inputhtmlDropDownChange}  >
                          {this.state.VSCCovgChoiceArr.map((dataChoice)=>{return <option data-key={dataChoice.key} data-text={dataChoice.text}  value={dataChoice.key}>{dataChoice.text}</option>})}
                            </select>
                            </div>
                            <div className="errorMsgSel">
                             {this.state.errorVSCCoverage}
                            </div>
                        </div>
                      </div>
                      {/* commented for CR1
                      <div className='row' style={{ display: (this.state.ProdLine == 'VSC' || this.state.ProdLine == 'LW') ? 'flex' : 'none' }}>
                        <div className='col-md-6'>
                          <TextField className='w-100' label='Coverage Level' errorMessage={this.state.errorCoverageLevel} value={this.state.CovgLevel} name='CovgLevel' onChange={this.inputFormChange} />
                        </div>
                        <div className='col-md-6 prefBGColor'>
                          <TextField className='w-100' style={{}} label='Dealer Remit' prefix="$" value={this.state.CalcRate} errorMessage={this.state.errorCalcRate} name='CalcRate'  disabled/>
                        </div>
                      </div>
                      <div className='row' style={{ display: (this.state.ProdLine == 'VSC' || this.state.ProdLine == 'LW') && this.state.isUnderWriter == true ? 'flex' : 'none' }}>
                        <div className='col-md-6'>
                          <TextField className='w-100' label='Rating Factor' errorMessage={this.state.errorRatingFactor} value={this.state.RatingFactor} name='RatingFactor' onChange={this.inputFormChange} onBlur={this.RemoveRatingFactorError} />
                        </div>
                        <div className='col-md-6'>
                          <TextField className='w-100' label='Term Factor' errorMessage={this.state.errorTermFactor} value={this.state.TermFactor} name='TermFactor' onChange={this.inputFormChange} onBlur={this.RemoveTermFactorError} />
                        </div>
                      </div>
                      <div className='row' style={{ display: (this.state.ProdLine == 'VSC' || this.state.ProdLine == 'LW') && this.state.isUnderWriter == true ? 'flex' : 'none' }}>
                        <div className='col-md-6'>
                          <TextField className='w-100' label='Coverage Factor' errorMessage={this.state.errorCoverageFactor} value={this.state.CoverageFactor} name='CoverageFactor' onChange={this.inputFormChange} onBlur={this.RemoveCoverageFactorError} />
                        </div>
                        <div className='col-md-6'>
                          <TextField className='w-100' label='Base Rate' prefix="$" value={this.state.BaseRate} errorMessage={this.state.errorBaseRate} name='BaseRate' onChange={this.inputFormChange} />
                        </div>
                      </div>
                      <div className='row' style={{ display: (this.state.ProdLine == 'VSC' || this.state.ProdLine == 'LW') && this.state.isUnderWriter == true ? 'flex' : 'none' }}>
                        <div className='col-md-6'>
                          <TextField className='w-100' label='Odometer Factor' errorMessage={this.state.errorOdometerFactor} value={this.state.OdometerFactor} name='OdometerFactor' onChange={this.inputFormChange} onBlur={this.RemoveOdometerFactorError} />
                        </div>
                        <div className='col-md-6'>
                          <TextField className='w-100' label='Ded. Surcharge/Credit' prefix="$" value={this.state.DedSurcharge} errorMessage={this.state.errorDedSurcharge} name='DedSurcharge' onChange={this.inputFormChange} onBlur={this.RemoveDedSurchargeError} />
                        </div>
                      </div>
                      <div className='row' style={{ display: (this.state.ProdLine == 'VSC' || this.state.ProdLine == 'LW') && this.state.isUnderWriter == true ? 'flex' : 'none' }}>
                        <div className='col-md-6'>
                          <TextField className='w-100' label='Admin Fees' prefix="$" value={this.state.AdminFee} name='AdminFee' errorMessage={this.state.errorAdminFee} onChange={this.inputFormChange} onBlur={this.RemoveAdminFeeError} />
                        </div>
                        <div className='col-md-6'>
                          <TextField className='w-100' label='Other Fees' prefix="$" value={this.state.OtherFees} name='OtherFees' errorMessage={this.state.errorOtherFees} onChange={this.inputFormChange} onBlur={this.RemoveOtherFeesError} />
                        </div>
                      </div>
                      <div className='row' style={{ display: (this.state.ProdLine == 'VSC' || this.state.ProdLine == 'LW') && this.state.isUnderWriter == true ? 'flex' : 'none' }}>
                        <div className='col-md-6'>
                          <TextField className='w-100' label='Over Remit' prefix="$" value={this.state.OverRemit} errorMessage={this.state.errorOverRemit} name='OverRemit' onChange={this.inputFormChange} />
                        </div>
                      </div>
                      <div className='row'  style={{ display: (this.state.ProdLine == 'VSC' || this.state.ProdLine == 'LW') && this.state.isUnderWriter == true ? 'flex' : 'none' }}>
                      <div className='col-md-12 btngenerate'>
                      <PrimaryButton text="Calculate" onClick={this.setCalcRateValue}></PrimaryButton>
                        </div>
                        </div>
                      */}
                      <div className='row' style={{ display: (this.state.IsNewDoc == true && this.state.isAccountAdmin == true) ? 'none' : 'flex' }}>
                        <div className='col-md-6'>
                          <TextField className='w-100' label='Underwriter Comments' errorMessage={this.state.errorUnderwriterComments} value={this.state.UnderwriterComments} name='UnderwriterComments' onChange={this.inputFormChange} />
                        </div>
                      </div>
                      <div className='row'>
                        <div className='col-md-6'>
                          <TextField className='w-100 multiLineMaxHeight' multiline label='Criteria' errorMessage={this.state.errorCriteria} value={this.state.Criteria} name='Criteria' onChange={this.inputFormChange} />
                        </div>
                      </div>


                      <div className='row'>
                        <div className='col-md-6'>
                         
                          <div style={{ display: (this.state.RecordStatus != "Requested" && !this.state.isAccountAdmin) ? 'none' : 'block' }}>
                            {/* <Dropdown className='w-100' styles={dropdownStyles} label='Underwriter Assigned'  selectedKey={this.state.UnderwriterAssgnd} options={this.state.UnderwriterAssgndChoiceArr} onChanged={this.inputDropDownDetailsChange} /> */}
                            <div className="titlePadding divTitleText">
                            Underwriter Assigned
                            </div>
                            <div>
                               <select  name="UnderwriterAssgnd"  className="form-select selCtrl" value={this.state.UnderwriterAssgnd} onChange={this.inputhtmlDropDownChange}  >
                                  {this.state.UnderwriterAssgndChoiceArr.map((dataChoice)=>{return <option data-key={dataChoice.key} data-text={dataChoice.text} data-email={dataChoice.Email}  value={dataChoice.key}>{dataChoice.text}</option>})}
                               </select>
                            </div>
                          </div>
                          </div>
                          </div>
                          <div className='row'>
                        <div className='col-md-6'>
                          <div style={{ display: (this.state.IsNewDoc || this.state.RecordStatus != "Approved") ? 'none' : 'flex' }}>
                            <TextField className='w-100' disabled={true} label='Approved By' value={this.state.ApprovedByText} name='ApprovedByName'  />
                          </div>
                        </div>
                        <div className='col-md-6' style={{ display: (this.state.IsNewDoc || this.state.RecordStatus != "Approved") ? 'none' : 'flex' }}>
                          <div className='w-100'><DateTimePicker label='Approved Date ' dateConvention={DateConvention.Date} showLabels={false} disabled={true}
                            value={this.state.ApprovedDate} onChange={this._getApprovedDateDatePickerItems} /></div>

                        </div>
                      </div>
                      <div className='row'>
                        <div className='col-md-6'>
                          <div style={{ display: (this.state.RecordStatus != "Cancelled") ? 'none' : 'flex' }}>
                            <TextField className='w-100' disabled={true} label='Cancelled By' value={this.state.CancelledByText} name='CancelledByName' onChange={this.inputFormChange} />
                          </div>
                        </div>
                        <div className='col-md-6' style={{ display: (this.state.RecordStatus != "Cancelled") ? 'none' : 'flex' }}>
                          <div className='w-100'><DateTimePicker label='Cacelled Date ' dateConvention={DateConvention.Date} showLabels={false} disabled={true}
                            value={this.state.CancelledDate} onChange={this._getCancelledDateDatePickerItems} /></div>
                        </div>
                      </div>
                      <div className='row'>
                        <div className='col-md-6'>
                          <div style={{ display: (this.state.RecordStatus != "Denied") ? 'none' : 'flex' }}>
                            <TextField className='w-100' disabled={true} label='Denied By' value={this.state.DeniedByText} name='DeniedByName' onChange={this.inputFormChange} />
                          </div>
                        </div>
                        <div className='col-md-6' style={{ display: (this.state.RecordStatus != "Denied") ? 'none' : 'flex' }}>
                          <div className='w-100'><DateTimePicker label='Denied Date ' dateConvention={DateConvention.Date} showLabels={false} disabled={true}
                            value={this.state.DeniedDate} onChange={this._getDeniedDateDatePickerItems} /></div>
                        </div>
                      </div>
                      <div className='row'>
                        <div className='col-md-6' style={{ display: (this.state.IsNewDoc || this.state.RecordStatus != "Approved" || this.state.ExceptType=="Contract") ? 'none' : 'flex' }}>
                          <div className='w-100'><DateTimePicker label='Review Date ' dateConvention={DateConvention.Date} showLabels={false}
                            value={this.state.ReviewDate} onChange={this._getReviewDateDatePickerItems} /></div>
                        </div>
                        <div className='col-md-6' style={{ display: (!this.state.isUnderWriter ) ? 'none' : 'flex' }}>
                          <Dropdown className='w-100' styles={dropdownStyles} label='Available for Logging?' selectedKey={this.state.AAOK} options={this.state.AAOKChoiceArr} onChanged={this.inputDropDownDetailsChange} />
                        </div>
                      </div>
                      <div className='row'>
                      </div>
                      {/* <div className='row'>
                      </div>
                      <div className='row'>
                      </div> */}
                      <div className='row'>
                        <div className='col-md-6' style={{ display: (this.state.IsNewDoc || this.state.RecordStatus != "Approved" || this.state.ExceptType=="Contract") ? 'none' : 'flex' }}>
                          <div className='w-100'><DateTimePicker label='Expiration Date ' dateConvention={DateConvention.Date} showLabels={false}
                            value={this.state.ExpDate} onChange={this._getExpDateDatePickerItems} /></div>

                        </div>
                      </div>
                    </div>
                    <div className='border p-3 mt-2'>
                      <div className='row'>
                        <div className='col-md-12'>
                          <Label className='font-weight-bold w-25'> Notes </Label>
                          <SunEditor name="NotesText" enableToolbar={true} lang='en' placeholder='Please type here...' setContents={this.state.Notes} setOptions={{
                            mode: 'classic', height: '300', buttonList: [
                              ['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
                              ['table', 'link', 'image'],],
                          }}
                            onChange={this.handleRichTextChange.bind(this, 'Notes')}
                            onImageUpload={this.handleImageUpload} onImageUploadBefore={this.handleImageUploadBefore} />
                        </div>
                      </div>
                    </div>
                    <div className='row'>
                      <div className='col-md-6' >
                        <Label className='font-weight-bold w-100'>Attach Files</Label>
                        <input type="file" name="FileUpload" onChange={this.onFileChange} />
                      </div>
                      <div className='col-md-6'>
                        {this.state.selectedFiles}
                      </div>
                    </div>
                    <div className='row'>

                      <div className='col-md-6'>
                        {this.state.UploadedExFiles}
                      </div>
                    </div>

                  </div>}
              </div>}
            <Dialog minWidth={'250px'} hidden={this.state.isModalClose} dialogContentProps={dialogContentProps}>
              <DialogFooter>
                <DefaultButton onClick={this.modalPopupClose} text="No" />
                <PrimaryButton onClick={this.modalSubmitClick} text="Yes" />
              </DialogFooter>
            </Dialog>
            <Dialog minWidth={'250px'} maxWidth={'40px'} hidden={this.state.isModalCompletionClose} dialogContentProps={dialogCompletionProps}>
           <DialogFooter>
            <PrimaryButton onClick={this.completionForm} text="Yes" />
            </DialogFooter>
            </Dialog>
            <Dialog minWidth={'250px'} maxWidth={'40px'} hidden={this.state.isModalErrorClose} dialogContentProps={dialogModalError}>
           <DialogFooter>
            <PrimaryButton onClick={this.ErrorModalForm} text="Yes" />
            </DialogFooter>
            </Dialog>
          </div>
        </ThemeProvider>
      );
    }
    else {
      return <div>Loading...(Please refresh your browser if content not loading properly)</div>
    }
  }
}