import * as React from 'react';
import { IGapClaimsLettersProps } from './IGapClaimsLettersProps';
import { IGapClaimsLettersStates } from './IGapClaimsLettersStates';
import { IDropdownOption, IChoiceGroupOption } from '@fluentui/react';
import "@pnp/sp/site-users/web";
import './GapClaimsLettersCss.css';
import 'suneditor/dist/css/suneditor.min.css';
import 'suneditor/dist/css/suneditor.min.css';
export default class GapClaimsLetters extends React.Component<IGapClaimsLettersProps, IGapClaimsLettersStates, {}> {
    constructor(props: any);
    componentDidMount(): void;
    getFormDefaultDetails: () => void;
    getLoggedUsersgroup: () => Promise<void>;
    private SplitAndEncodeURIComponent;
    getEditFormDetailsComp: () => void;
    EditClickBtn: () => void;
    ViewClickBtn: () => void;
    getPaymentValues: () => void;
    getEditFormBodyDetails: (uniqueId: any, LettersListID: any) => void;
    getPaymentTypevaluesStore: () => void;
    onPaymentTypeChange: (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption) => void;
    Assign_to_Claimm: () => Promise<void>;
    open_dialog: () => void;
    getuserEmail: (Id: any) => Promise<import("@pnp/sp/site-users/types").ISiteUserInfo>;
    assignEditFormDetailsStore: () => Promise<void>;
    static get mrk_deleteChoice(): IChoiceGroupOption[];
    assignmrk_deleteStore: () => void;
    assignInsertResultStore: () => void;
    Dialog_close: () => void;
    ValidClaim: () => void;
    ValidResponseApi: () => void;
    Dialog_close2: () => void;
    UploadFiless: () => Promise<void>;
    Dialog_save: (actionCall: any) => Promise<void>;
    _close: () => void;
    ExitForm: () => void;
    insertForm: () => void;
    /***Modalclsoe */
    modalPopupOpen: (actionCall: any) => void;
    modalPopupClose: () => void;
    modalSubmitClick: () => Promise<void>;
    ExitmodalPopupOpen: (actionCall: any) => void;
    private inputFormChange1;
    private inputFormChange;
    private handleRichTextChange;
    /****RichTextMy */
    private handleImageUpload;
    handleAttachmentChange: (chTarget: any) => Promise<void>;
    addDeleteFiles: (fileName: any) => Promise<void>;
    private inputDropDownDetailsChange;
    private _getSendToPeoplePickerItems;
    private _getCopyToPeoplePickerItems;
    private _getBlindCopyToPeoplePickerItems;
    private _getFromPeoplePickerItems;
    private _getTempAdjPeoplePickerItems;
    private _getDateDatePickerItems;
    private mrk_deleteRadioBtnChange;
    PrintScreen: () => void;
    /***********8Cover Lettters */
    txtfile: () => void;
    /*****Azureapicall */
    private getAccessToken;
    getDatafromApi: (LettersListID: any) => Promise<void>;
    IsNullOrUndefined<T>(obj: T | null | undefined): obj is null | undefined;
    private UploadfilestoApi;
    /***************** */
    render(): React.ReactElement<IGapClaimsLettersProps>;
}
//# sourceMappingURL=GapClaimsLetters.d.ts.map