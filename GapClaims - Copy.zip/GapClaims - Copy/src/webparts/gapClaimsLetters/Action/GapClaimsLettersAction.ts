import { Dispatcher } from 'simplr-flux';
import {sp} from "@pnp/sp";
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import {IItem} from '@pnp/sp/items';
import '@pnp/sp/fields';
import {IAttachmentFileInfo} from '@pnp/sp/attachments';
import { SPHttpClient} from '@microsoft/sp-http';
let AttachmentFiles;
let uploadedRichTextFiles;
let absoluteUrl;
// Get Admin List Details

// const getPaymentTypeDetails = async () => {

//     debugger;

//     await sp.web.lists.getByTitle("Type").items.get().then(res =>{

//         console.log(res);

//         Dispatcher.dispatch({ type: 'getPaymentTypevalues', response: res});

//     }).catch(error => {

//         console.log('getPaymentTypevalues', +error)

//     })

// }

// export {getPaymentTypeDetails}  
// Get the edit click details
const getEditFormDetails = (Id) => {
sp.web.lists.getByTitle('Letters').items.getById(Id).select('*',
'AttachmentFiles',

'SendTo/ID','SendTo/EMail','SendTo/FirstName','SendTo/LastName',
'CopyTo/ID','CopyTo/EMail','CopyTo/FirstName','CopyTo/LastName',
'BlindCopyTo/ID','BlindCopyTo/EMail','BlindCopyTo/FirstName','BlindCopyTo/LastName',
'From/ID','From/EMail','From/FirstName','From/LastName',).expand('AttachmentFiles','SendTo','CopyTo','BlindCopyTo','From',).get().then(res => {
Dispatcher.dispatch({ type: 'getEditFormDetailsType', response:res});
}).catch(error => {
console.log('getEditFormDetails ' + error);
});
  }
export {getEditFormDetails};
//save assigntoclaim
const closeDialog = (GAPAgreeN,InsuredLastN,InsuredFirstN) =>{
  sp.web.lists.getByTitle('Letters').items.add({
    'GAPAgreeNum': GAPAgreeN,
    'InsuredLastName': InsuredLastN,
    'InsuredFirstName': InsuredFirstN,
  })
  }
 export {closeDialog}

  

// Get Input Details
const saveForm = (GAPAgreeNum,NotesType,VSCAdj,InsuredLastName,InsuredFirstName,InsuredStreetAddress,
  InsuredCity,InsuredState,InsZip,mrk_delete,SendTo,CopyTo,BlindCopyTo,From,Date,Subject,Body,
  uploadedRichTextFiles,uploadedFileArray,tobeRemovedArray,arrPrevSavedFiles,AttachmentFiles)=> {
sp.web.lists.getByTitle('Letters').items.add({

'GAPAgreeNum': GAPAgreeNum,
'VSCAdj': VSCAdj,
'InsuredLastName': InsuredLastName,
'InsuredFirstName': InsuredFirstName,
'InsuredStreetAddress': InsuredStreetAddress,
'InsuredCity': InsuredCity,
'InsuredState': InsuredState,
'InsZip': InsZip,
'NotesType':NotesType,
'mrk_delete': mrk_delete,
'SendToId': {results:SendTo},
'CopyToId': {results:CopyTo},
'BlindCopyToId': {results:BlindCopyTo},
'FromId': From.length > 0 ? From[0] : null,
'Date': Date,
'Subject': Subject,
'Body': uploadedRichTextFiles.length > 0 ? '' : Body,
}).then(res => {

if (res.data != undefined && res.data != null) {
if(AttachmentFiles.length > 0)
{
insertFormAttachment(res.data.Id, AttachmentFiles);
} else 
{
Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
}
}


// if(res != null && uploadedRichTextFiles.length > 0) {
// insertAttachRichTextFile(res, uploadedRichTextFiles, 0);
// }
if(res !=null && uploadedFileArray.length>0|| tobeRemovedArray.length>0 || uploadedRichTextFiles.length>0)
    {
    addNewAttachments(res.data.ID,tobeRemovedArray,uploadedFileArray,uploadedRichTextFiles,arrPrevSavedFiles,Body,absoluteUrl);

    }
    else
    {
      Dispatcher.dispatch({ type: 'insertResultType', response: res.data.ID });
    }
}).catch(error => {
console.log('saveForm ' + error);
});
}
export {saveForm};

// Update Existing Item
const updateForm = (uniqueId,NotesType,GAPAgreeNum,VSCAdj,InsuredLastName,InsuredFirstName,
  
  InsuredStreetAddress,InsuredCity,InsuredState,InsZip,mrk_delete,SendTo,CopyTo,BlindCopyTo,
  From,Date,Subject,Body,uploadedRichTextFiles,AttachmentFiles, deleteFiles)=> {
sp.web.lists.getByTitle('Letters').items.getById(uniqueId).update({

'GAPAgreeNum': GAPAgreeNum,
'VSCAdj': VSCAdj,
'InsuredLastName': InsuredLastName,
'InsuredFirstName': InsuredFirstName,
'NotesType':NotesType,
'InsuredStreetAddress': InsuredStreetAddress,
'InsuredCity': InsuredCity,
'InsuredState': InsuredState,
'InsZip': InsZip,
'mrk_delete': mrk_delete,
'SendToId': {results:SendTo},
'CopyToId': {results:CopyTo},
'BlindCopyToId': {results:BlindCopyTo},
'FromId': From.length > 0 ? From[0] : null,
'Date': Date,
'Subject': Subject,
'Body': [uploadedRichTextFiles,Body],
}).then(res => {

 if (res.data != undefined && res.data != null) {
if (deleteFiles.length > 0) {
DeleteFormAttachment(uniqueId, deleteFiles, AttachmentFiles);
} else if (AttachmentFiles.length > 0) {
insertFormAttachment(uniqueId, AttachmentFiles);
} else {
Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
}
}


if(res != null) {
updateAttachRichTextFile(res, uploadedRichTextFiles, uniqueId);
}
}).catch(error => {
console.log('updateForm ' + error);
});
  }
export {updateForm};


const insertFormAttachment = (uniqueID, AttachmentFiles) => {
sp.web.lists.getByTitle('Letters').items.getById(uniqueID).attachmentFiles.addMultiple(AttachmentFiles).
then(res => {
Dispatcher.dispatch({ type: 'insertResultType', response: uniqueID });
}).catch(error => {
console.log('insertFormAttachment ' + error);
});
}
export { insertFormAttachment };


const DeleteFormAttachment = (uniqueID, deleteFiles, AttachmentFiles) => {
let deleteFilesNames = deleteFiles.map(a => a);
sp.web.lists.getByTitle('Letters').items.getById(uniqueID).attachmentFiles.deleteMultiple(...deleteFilesNames).
then(res => {
if (AttachmentFiles.length > 0) {
insertFormAttachment(uniqueID, AttachmentFiles);
}else {
Dispatcher.dispatch({ type: 'insertResultType', response: uniqueID });
}
}).catch(error => {
console.log('insertFormAttachment ' + error);
});
}
export { DeleteFormAttachment };


const insertAttachRichTextFile = (results, files, itemId) => {
let domparser = new DOMParser();
let fileInfos = [];
if (files != null) {
for (let f of files) {
let fileRead = new FileReader();
fileRead.onloadend = (e) => {
fileInfos.push({
name: f.name,
content: fileRead.result,
});
results.item.attachmentFiles.addMultiple(fileInfos).then(() => {
results.item
.select('ID,AttachmentFiles,Body')
.expand('AttachmentFiles').get().then(async (results: any) => {
let itemID = results.ID;
let fileData = results.AttachmentFiles;

let Body = results.Body;

let parsedBody = domparser.parseFromString(Body,'text/html');
await Promise.all([

await parsedBody.querySelectorAll('img').forEach((img) => {fileData.forEach((fData) => {
img.getAttribute('data-file-name') ===fData['FileName']? img.setAttribute('src',fData['ServerRelativeUrl'])
: null;});}),
]);
updateRichItem(itemID ,parsedBody);
});
});};
fileRead.readAsArrayBuffer(f);
}}}
export { insertAttachRichTextFile };


const updateAttachRichTextFile = (results, files, itemId) => {
let domparser = new DOMParser();
sp.web.lists.getByTitle('Letters').items.getById(itemId).select('ID,AttachmentFiles,Body')
.expand('AttachmentFiles').get().then(async (fileResults: any) => {
let fileData = fileResults.AttachmentFiles;
let aFiles = [...fileData];

let Body = fileResults.Body;
aFiles.forEach(async (aFile) => {
let isExists = files.some((f) => f['name'] === aFile['FileName']);
if (isExists) {
parseUpdate(fileData, itemId,Body)
}
});
if (files.length > 0) {
let fileInfos = [];
for (let f of files) {
let fileRead = new FileReader();
fileRead.onloadend = (e) => {
fileInfos.push({
name: f.name,
content: fileRead.result,
});
results.item.attachmentFiles.addMultiple(fileInfos).then(() => {
results.item.select('ID,AttachmentFiles,Body')
.expand('AttachmentFiles').get().then(async (results: any) => {
let itemID = results.ID;
let fileData = results.AttachmentFiles;

let Body = results.Body;
parseUpdate(fileData, itemId,Body);


let parsedBody = domparser.parseFromString(Body,'text/html');
await Promise.all([


await parsedBody.querySelectorAll('img').forEach((img) => {fileData.forEach((fData) => {
img.getAttribute('data-file-name') ===fData['FileName']? img.setAttribute('src',fData['ServerRelativeUrl'])
: null;});}),

]);

updateRichItem(itemID ,parsedBody);
});
});
};
fileRead.readAsArrayBuffer(f);
}}
else if (files.length == 0) {
parseUpdate(fileData, itemId,Body)
}});}
export { updateAttachRichTextFile };
/********/
const addNewAttachments=async (res,tobeRemovedArray, uploadedFileArray,uploadedRichTextFiles,arrPrevSavedFiles,unSavedNotes,absoluteUrl)=>
{
  debugger;
  const item: IItem = sp.web.lists.getByTitle('Letters').items.getById(res);
  
  //const info2: IAttachmentInfo = await item.attachmentFiles.getByName(uploadedFileArray[0])();
if(item!=null)
{
  let fileInfos: IAttachmentFileInfo[] = []; 
  let AllfileNames=null;
  if(uploadedFileArray!=null && uploadedFileArray!=undefined && uploadedFileArray.length>0)
  {
  uploadedFileArray.forEach(element => {
    fileInfos.push({
      name: element.name,
      content: element
  });
 
  if(AllfileNames!=null && AllfileNames!='')
  {
  AllfileNames+=";"+element.name;
  }
  else{
    AllfileNames=element.name;
  }
  });
}
if(arrPrevSavedFiles!=null && arrPrevSavedFiles!=undefined && arrPrevSavedFiles.length>0)
{
  arrPrevSavedFiles.forEach(element => {
    if(AllfileNames!=null && AllfileNames!='')
  {
  AllfileNames+=";"+element.FileName;
  }
  else{
   AllfileNames=element.FileName;
  }
  });
}

  let allRichFiles=[];
  if(uploadedRichTextFiles!=null && uploadedRichTextFiles!=undefined && uploadedRichTextFiles.length>0)
  {
    allRichFiles = uploadedRichTextFiles.map(a => a.imgFile);
  }
  let fileInfosRich: IAttachmentFileInfo[] = []; 
  let serializeNotes=null;
  if(allRichFiles!=null && allRichFiles!=undefined && allRichFiles.length>0)
  {
   
  for (let f of allRichFiles) {
    
    // fileRead.onloadend = (e) => {
      fileInfosRich.push({
        name: f.name,
        content: f,
      });
   // }
  }
  let Body =unSavedNotes;
  let domparser = new DOMParser();
  let  parsedNotes = domparser.parseFromString(Body,'text/html');;
  
   

    if(parsedNotes!=null && parsedNotes!=undefined)
    {
     
     parsedNotes.querySelectorAll('img').forEach((img) => {allRichFiles.forEach((fData) => {
   
      if(img.getAttribute('data-file-name') ===fData['name'])
      {
       let newImageUrl=absoluteUrl+"/Lists/"+'Letters'+"/Attachments/"+res+"/"+fData['name'];
       img.setAttribute('src',newImageUrl) 
     }
     else
     {
   
     }
   })
   })

  }
     let s = new XMLSerializer();

      serializeNotes = s.serializeToString(parsedNotes);
}
  //if(tobeRemovedArray.length>0)
  {
    if(tobeRemovedArray.length>0)
    {

    }
    else{
      tobeRemovedArray=[];
    }
  await item.attachmentFiles.deleteMultiple(...tobeRemovedArray).then((el)=>{
  console.log("deleteting complete Proceeding for addition");
   item.attachmentFiles.addMultiple(fileInfos).then(v => {
    //updateListColumns(res,uploadedFileArray);
    console.log("Added files Uploaded");
    item.update({
      UploadedFiles:AllfileNames
    }).then(allNames=>{
      console.log('File upload updated and modified')
     
      item.attachmentFiles.addMultiple(fileInfosRich).then(()=>{
        console.log("Rich text upoloaded")
        if(serializeNotes!=null)
        {

          item.update({
            Body:serializeNotes
          }).then(()=>{ 
          console.log("Notes filed upldated")
          Dispatcher.dispatch({ type: 'insertResultType', response: res }
          )
        })
        }
        else{
          console.log("No note updation required")
          Dispatcher.dispatch({ type: 'insertResultType', response: res })
        }
       
     
      })
    //}
      
    });
  });
})
}

}
} 
const updateRichItem = (itemID ,parsedBody) => {
let s = new XMLSerializer();

let serializeBody = s.serializeToString(parsedBody);
sp.web.lists.getByTitle('Letters').items.getById(itemID).update({

'Body':serializeBody,
}).then(res => {
if (res.data != undefined) {
Dispatcher.dispatch({ type: 'insertResultType', response: itemID });
}
}).catch(error => {
console.log('updateRichItem ' + error);
});
}
export { updateRichItem };

const parseUpdate = async (fileData,itemId,Body) => {
let fileLevlInfos = [];
let domparser = new DOMParser();


let parsedBody = domparser.parseFromString(Body,'text/html');

parsedBody.querySelectorAll('img').forEach((img) => {
let iName = img.getAttribute('data-file-name');
fileData.forEach((fData) => {
img.getAttribute('data-file-name') === fData['FileName']
? img.setAttribute('src', fData['ServerRelativeUrl']): null;
});
fileLevlInfos.indexOf(iName)
? console.log('exisitng file')
: fileLevlInfos.push(iName);
});
let item = await sp.web.lists.getByTitle('Letters').items.getById(itemId);
if (fileData.length !== fileLevlInfos.length) {
let fInfos = [];
fileData.forEach((aFile) => {
fInfos.push(aFile['FileName']);
});
let ainfos = fInfos.join('","');
let infos = ainfos.toString();
fileLevlInfos.length !== 0
? fileLevlInfos.forEach((rFile) => {
fileData.forEach(async (aFile) => {
rFile === aFile['FileName']? console.log(''): await item.attachmentFiles
.getByName(aFile['FileName']).delete();});})
: await item.attachmentFiles.deleteMultiple(infos);
}
}
export { parseUpdate };


const getmrk_deleteDetails = (Title) => {
sp.web.lists.getByTitle('Letters').fields.getByTitle(Title).get().then(res => {
Dispatcher.dispatch({ type: 'getmrk_deleteChoiceType', response:res});
}).catch(error => {
console.log('getDetails ' + error);
});
}
export {getmrk_deleteDetails};


