import * as React from 'react';
import { IUserguidenewformProps } from './IUserguidenewformProps';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import "@pnp/sp/webs";
import "@pnp/sp/site-users/web";
export interface MyState {
    webpartContxt: WebPartContext;
    isEditor: boolean;
}
export default class Userguidenewform extends React.Component<IUserguidenewformProps, MyState> {
    constructor(prop: any);
    componentDidMount(): void;
    userguidenewform: () => void;
    getLoggedUsersGroup: () => Promise<void>;
    render(): React.ReactElement<IUserguidenewformProps>;
}
//# sourceMappingURL=Userguidenewform.d.ts.map