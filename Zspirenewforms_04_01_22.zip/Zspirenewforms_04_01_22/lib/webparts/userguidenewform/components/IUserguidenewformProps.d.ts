import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IUserguidenewformProps {
    description: string;
    context: WebPartContext;
    exitLocation: string;
}
//# sourceMappingURL=IUserguidenewformProps.d.ts.map