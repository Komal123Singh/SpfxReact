import * as React from 'react';
import { IValidationsProblemStates } from './IValidationsProblemStates';
import {Label} from '@fluentui/react';
import moment from 'moment';
export default class ViewValidationsProblem extends React.Component<IValidationsProblemStates> {
  private showReadOnlyAttachment=()=>{
    try{
      
  
      if(this.props.oldAttachments.length!=0){
        console.log(this.props.oldAttachments);
        let AttachmentList=this.props.oldAttachments;
        // let AttachmentListArray=[];
        let filtereditem = AttachmentList.filter(attachmentitems =>!(attachmentitems.FileName.match(/=/g)));
        let filtereditem2 = filtereditem.filter(attachmentitems2 =>!(attachmentitems2.FileName.match(/.(jpg|jpeg|png|gif)$/i)));
        return filtereditem2.map((item)=>{
        
          let downloadUrl = this.props.AbsoluteUrl + "/_layouts/download.aspx?sourceurl=" + item.ServerRelativeUrl;  
          return(
            <div id={item.FileName}><span><a href={downloadUrl}>{item.FileName}</a></span></div>
          
          )
        })
        
    
    }
  
   } catch (e){
  
      console.log('bindAttachment: ' + e);
  
    }
  

  }

render() {
return (
<div>


<div className='border p-3 mt-1'>
<div className='row'>
<div className='col-md-2'>
 <Label className='font-weight-bold w-100'> Document Type</Label>
</div>
<div className='col-md-4'>
 {this.props.DocType}
</div>
{(this.props.ishide)?
<div>
<div className='col-md-2'>
 <Label className='font-weight-bold w-100'> IO#</Label>
</div>
<div className='col-md-4'>
 {this.props.IONum}
</div>
</div>
:null}

</div>
<div className='row'>
<div className='col-md-2'>
 <Label className='font-weight-bold w-100'> Title</Label>
</div>
<div className='col-md-4'>
 {this.props.Title}
</div>
<div className='col-md-2'>
 <Label className='font-weight-bold w-100'> Document ID</Label>
</div>
<div className='col-md-4'>
 {this.props.DocNumber}
</div>

</div>
{(this.props.ishide)?
<div className='row'>
<div className='col-md-2'>
 <Label className='font-weight-bold w-100'> Reporting Area</Label>
</div>
<div className='col-md-4'>
 {this.props.ReptArea}
</div>
<div className='col-md-2'>
 <Label className='font-weight-bold w-100'> Reporting Manager</Label>
</div>
<div className='col-md-4'>
 {this.props.ReptMgr}
</div>
</div>
:null}
<div className='row'>
<div className='col-md-2'>
 <Label className='font-weight-bold w-100'> Status</Label>
</div>
<div className='col-md-4'>
 {this.props.Status}
</div>
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
<div className='col-md-2'>
  {this.props.DocType == 'Validations'?<Label className='font-weight-bold w-100'>Result Ranking</Label>:<Label className='font-weight-bold w-100'> Priority</Label>}
</div>
:null}
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
<div className='col-md-4'>
 {this.props.Priority}
</div>
:null}


</div>
<div className='row'>
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
<div className='col-md-2'>
{this.props.DocType == 'Validations'?<Label className='font-weight-bold w-100'>Risk Level</Label>:<Label className='font-weight-bold w-100'>Severity</Label>}
 </div>
:null}
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
<div className='col-md-4'>
 {this.props.Severity}
</div>
:null}
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues' || this.props.DocType == 'Discussion Item')?
<div className='col-md-2'>
  {(this.props.DocType == 'Issues' || this.props.DocType == "Discussion Item")?<Label className='font-weight-bold w-100'>Category</Label>:<Label className='font-weight-bold w-100'>Jurisdiction</Label>}
</div>
:null}
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues' || this.props.DocType == 'Discussion Item')?
<div className='col-md-4'>
 {this.props.UpdateKeywords.map((item)=>{
   return (<>
    {item} , </>
   )
 })}

</div>
:null}
</div>
<div className='row'>
<div className='col-md-2'>
  {this.props.DocType == 'Discussion Item'?<Label className='font-weight-bold w-100'>Product Line</Label>:this.props.DocType == 'Issues'?<Label className='font-weight-bold w-100'>Project Area</Label>:<Label className='font-weight-bold w-100'>CPL Action</Label>}
 
</div>
<div className='col-md-4'>
 {this.props.ProjectArea}
</div>
{this.props.DocType == 'Issues'?
<div className='col-md-2'>
 <Label className='font-weight-bold w-100'> ApplicationArea</Label>
</div>
:null}
{this.props.DocType == 'Issues'?
<div className='col-md-4'>
 {this.props.ApplicationArea}
</div>
:null}
</div>

{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
<div className='row'>
<div className='col-md-2'>
  {this.props.DocType == 'Validations'?<Label className='font-weight-bold w-100'>BU(s) Affected</Label>:<Label className='font-weight-bold w-100'>Environment Type</Label>}
 </div>
<div className='col-md-4'>

 {this.props.UpdateEnvType.map((item)=>{
   return (<>{item} ,</>)
  })}

</div>
<div className='col-md-2'>
{this.props.DocType == 'Validations'?<Label className='font-weight-bold w-100'>Ready date</Label>:<Label className='font-weight-bold w-100'>Test Case #</Label>}
</div>
<div className='col-md-4'>
{this.props.TestCase!=undefined&&this.props.TestCase!=''&&this.props.TestCase!=null?moment(this.props.TestCase.toUTCString()).format('L'):null}
</div>
</div>
:null}
{(this.props.DocType == 'Issues')?
<div className='row'>
<div className='col-md-2'>
<Label className='font-weight-bold w-100'>Participants</Label>
</div>
<div className='col-md-4'>
{this.props.ActivePlayersDefaultItems.length > 0 ? this.props.ActivePlayersDefaultItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
<div className='col-md-2'>
<Label className='font-weight-bold w-100'>ProjectManagers</Label>

</div>
<div className='col-md-4'>
{this.props.ProjectManagersDefaultItems.length > 0 ? this.props.ProjectManagersDefaultItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
</div>
:null}
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
<div className='row'>
<div className='col-md-2'>
  {this.props.DocType == 'Validations'?<Label className='font-weight-bold w-100'>Record Created By</Label>:<Label className='font-weight-bold w-100'>Reported By</Label>}
 
</div>
<div className='col-md-4'>
{this.props.ReportedByDefaultItems.length > 0 ? this.props.ReportedByDefaultItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
<div className='col-md-2'>
{this.props.DocType == 'Validations'?<Label className='font-weight-bold w-100'>Date Created</Label>:<Label className='font-weight-bold w-100'>Date Reported</Label>}

</div>
<div className='col-md-4'>
{this.props.ReptDt!=undefined&&this.props.ReptDt!=''&&this.props.ReptDt!=null?moment(this.props.ReptDt.toUTCString()).format('L'):null}
</div>
</div>
:null}

{(this.props.ishide)?
<div className='row'>
<div className='col-md-2'>
 <Label className='font-weight-bold w-100'> PhaseDetect</Label>
</div>
<div className='col-md-4'>
{this.props.PhaseDetect}
</div>
<div className='col-md-2'>
 <Label className='font-weight-bold w-100'> PhaseIntro </Label><span></span>
</div>
<div className='col-md-4'>
{this.props.PhaseIntro}
</div>
</div>
:null}
{(this.props.DocType == 'Validations')?
<div className='row'>
<div className='col-md-2'>
 <Label className='font-weight-bold w-100'> LOB(s) Affected</Label>
</div>
<div className='col-md-4'>

 {this.props.UpdateVendors.map((item)=>{
   return (<>{item} ,</>)
})}

</div>
<div className='col-md-2'>
<Label className='font-weight-bold w-100'>Val Completion Date</Label>
</div>
<div className='col-md-4'>
{this.props.WONum!=undefined&&this.props.WONum!=''&&this.props.WONum!=null?moment(this.props.WONum.toUTCString()).format('L'):null}
</div>
</div>
:null}

{(this.props.DocType == 'Validations')?
<div className='row'>
<div className='col-md-2'>
 <Label className='font-weight-bold w-100'> Ins. Categories</Label>
</div>
<div className='col-md-4'>
 {this.props.UpdateRootCause.map((item)=>{
   return (<> {item} ,</>)
 })}
</div>
</div>
:null}
{(this.props.DocType == 'Issues')?
<div className='row'>
<div className='col-md-2'>
<Label className='font-weight-bold w-100'> Assigned To </Label>

</div>
<div className='col-md-4'>
{this.props.AssignedToDefaultItems.length > 0 ? this.props.AssignedToDefaultItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
{this.props.AssignedTo != ''?
<div className='col-md-2'>
<Label className='font-weight-bold w-100'>Date Assigned</Label>
</div>
:null}
{this.props.AssignedTo != ''?
<div className='col-md-4'>
{this.props.AssignedDt!=undefined&&this.props.AssignedDt!=''&&this.props.AssignedDt!=null?moment(this.props.AssignedDt.toUTCString()).format('L'):null}
</div>
:null}
</div>
:null}
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
<div className='row'>
<div className='col-md-2'>
  {this.props.DocType == 'Validations'?<Label className='font-weight-bold w-100'>Estimated Completion Date</Label>:<Label className='font-weight-bold w-100'>Est Comp Date</Label>}
</div>
<div className='col-md-4'>
{this.props.EstCompDt!=undefined&&this.props.EstCompDt!=''&&this.props.EstCompDt!=null?moment(this.props.EstCompDt.toUTCString()).format('L'):null}
</div>
<div className='col-md-2'>
{this.props.DocType == 'Validations'?<Label className='font-weight-bold w-100'>Re-Val/Final Completion Date</Label>:<Label className='font-weight-bold w-100'>Date Resolved</Label>}

</div>
<div className='col-md-4'>
{this.props.DateResolved!=undefined&&this.props.DateResolved!=''&&this.props.DateResolved!=null?moment(this.props.DateResolved.toUTCString()).format('L'):null}
</div>
</div>
:null}
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
<div className='row'>
<div className='col-md-2'>
<Label className='font-weight-bold w-100'> Closed By </Label>
</div>
<div className='col-md-4'>
{this.props.ApprovedByDefaultItems.length > 0 ? this.props.ApprovedByDefaultItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
{this.props.Status == 'Closed'?
<div className='col-md-2'>
<Label className='font-weight-bold w-100'> Closed Date </Label>
</div>
:null}
{this.props.Status == 'Closed'?
<div className='col-md-4'>
{this.props.ApprovedDt!=undefined&&this.props.ApprovedDt!=''&&this.props.ApprovedDt!=null?moment(this.props.ApprovedDt.toUTCString()).format('L'):null}
</div>
:null}
</div>
:null}
<div className='row'>
<div className='col-md-2'>
<Label className='font-weight-bold w-100'> Send Email Notifications To </Label>

</div>
<div className='col-md-4'>

{this.props.SendToDefaultItems}
</div>
</div>

<div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold w-100'>Description</Label>
<div dangerouslySetInnerHTML={{__html:this.props.Probdesc}} />
  {/* <RichText className='border' isEditMode={false} value={this.props.Probdesc} /> */}
</div>
</div>
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
<div className='row'>
<div className='col-md-12'>
{this.props.DocType == 'Validations'? <label className='font-weight-bold'>Validation Results & Recommendations:</label>: <label className='font-weight-bold'>Proposed Resolution</label>}
<div dangerouslySetInnerHTML={{__html:this.props.Proposedres}} />
</div>
</div>
:null}
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
<div className='row'>
<div className='col-md-12'>
{this.props.DocType == 'Validations'? <label className='font-weight-bold'>Re-Validation Results & Recommendations</label>: <label className='font-weight-bold'>Final Resolution</label>}
<div dangerouslySetInnerHTML={{__html:this.props.Resolution}} />
</div>
</div>
:null}
{this.props.DocType == 'Validations'?
<div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold w-100'>Follow Up Activities</Label>
<div dangerouslySetInnerHTML={{__html:this.props.Suggest}} />
</div>
</div>
:null}
<div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold w-100'> Comments </Label>
<div dangerouslySetInnerHTML={{__html:this.props.Comments}} />

</div>
</div>
<div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold w-100'> Attachments </Label>
{this.showReadOnlyAttachment()}
</div>
</div>

</div>




</div>
)
}
}