import * as React from 'react';
import * as moment from 'moment';
import { MyState } from './UserGuideForm';
import {  Link } from '@fluentui/react';

export default class ViewUserGuide extends React.Component<MyState> {
  
    bindAttachmentFileNames() {
        try {
            return this.props.UpdateAttachments.map((item, idx) => {
                let fileName = item.FileName;
                return (
                    <div><span><Link data-interception="off" target='_blank' href={item.ServerRelativePath.DecodedUrl}>{fileName}</Link></span></div>
                )
            });
        }
        catch (e) {
            console.log('bindAttachmentFileNames ' + e);
        }
    }

    render() {
    debugger;
        return (
            <div>
                 <div className='row p-6 mt-1'>
            <div className='col-md-6'><p >Created on {(this.props.Date!=null)?(moment(this.props.Date).format('MM/DD/YYYY')):moment().format('MM/DD/YYYY')}</p></div>
            </div>
                <div className='border p-4 mt-1'>
              <div className='row'>
              <div className='col-md-3 font-weight-bold'>
                  <p> Doc Title:</p>
                </div>
                <div className='col-md-8 font-weight-normal'>
                    
                   <span>{this.props.DocTitle}</span>
                </div>
                    </div>
                    <div className='row mt-1'>
                <div className='col-md-3 font-weight-bold'>
                  <p>Synopsys:</p>
                </div>
                <div className='col-md-8 font-weight-normal'>
                <span>{this.props.Synopsys} </span>
                </div>
              </div>
              <div className='row mt-1'>
                <div className='col-md-3 font-weight-bold'>
                  <p>Topic Number:</p>
                </div>
                <div className='col-md-8 font-weight-normal'>
                <span>{this.props.Section} </span>
                </div>
              </div>
              <div className='row mt-1'>
                <div className='col-md-3 font-weight-bold'>
                  <p>Category:</p>
                </div>
                <div className='col-md-8 font-weight-normal'>
                {this.props.viewcategory}
                </div>
              </div>
              <div className='row mt-1'>
                <div className='col-md-3 font-weight-bold'>
                  <p>Subcategory:</p>
                </div>
                <div className='col-md-8 font-weight-normal'>
                <span>{this.props.viewsubcategory} </span>
                </div>
              </div>
              <div className='row mt-1'>
                <div className='col-md-3 font-weight-bold'>
                  <p>Search Keywords:</p>
                </div>
                <div className='col-md-8 font-weight-normal'>
                <span>{this.props.SearchTerms} </span>
                </div>
              </div>
              <div className='row mt-1'>
                <div className='col-md-3 font-weight-bold'>
                  <p>Document Status:</p>
                </div>
                <div className='col-md-8 font-weight-normal'>
                <span>{this.props.Status} </span>
                </div>
              </div>
              <div className='row mt-1'>
                <div className='col-md-3 font-weight-bold'>
                  <p>User Roles:</p>
                </div>
                <div className='col-md-8 font-weight-normal'>
                <span>{this.props.UserRole!=null?this.props.UserRole.join(', '):''} </span>
                </div>
              </div>
              <div className='row mt-1'>
                <div className='col-md-3 font-weight-bold'>
                  <p>Attachment:</p>
                </div>
                <div className='col-md-8 font-weight-normal'>
                {this.bindAttachmentFileNames()}
                </div>
              </div>
                </div>
            </div>
        )
        }
}