import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/fields';
import '@pnp/sp/attachments';
import "@pnp/sp/sputilities";
import "@pnp/sp/files";
import "@pnp/sp/folders";
declare const getEditFormDetails: (Id: any) => void;
export { getEditFormDetails };
declare const saveForm: (Status: any, date: any, Author: any, AlertTitle: any, alerttitle: any, Body: any, AlertDesc: any, DocAvail: any, Created: any, year: any, lncreated: any, lncreatedby: any, lnmodified: any, lnmodifiedby: any, Ehrev: any, EhEditor: any, Ehdate: any, DocType: any, Attachment: any, uploadedRichTextFiles: any) => void;
export { saveForm };
declare const updateForm: (uniqueId: any, Status: any, date: any, Author: any, AlertTitle: any, alerttitle: any, Body: any, DocAvail: any, AlertDesc: any, Attachments: any, EditAttachments: any, delattach: any, lnmodified: any, lnmodifiedby: any, Ehrev: any, EhEditor: any, Ehdate: any, uploadedRichTextFiles: any) => void;
export { updateForm };
declare const insertAttachRichTextFile: (results: any, files: any, itemId: any, Attachments0Rich: any, Attachments: any, responseId: any) => void;
export { insertAttachRichTextFile };
declare const updateRichItem: (itemID: any, parsedAttachments0: any, Attachments: any, responseId: any) => void;
export { updateRichItem };
//# sourceMappingURL=SystemAlertAction.d.ts.map