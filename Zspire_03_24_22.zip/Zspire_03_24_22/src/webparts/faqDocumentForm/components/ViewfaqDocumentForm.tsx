import * as React from 'react';
import * as moment from 'moment';
import { MyState } from './FaqDocumentForm';
import { Link } from '@fluentui/react';

export default class ViewfaqDocumentForm extends React.Component<MyState> {
  bindAttachmentFileNames() {
    try {
      let editattchments = this.props.UpdateAttachments;

      // let fileExtension = fileName.split('.').pop();
      let filtereditem = editattchments.filter(attachmentitems => !attachmentitems.FileName.match(/.(jpg|jpeg|png|gif)$/i))
      return filtereditem.map((item, idx) => {
        let fileName = item.FileName;
        return (
          <div><span><Link data-interception="off" target='_blank' href={item.ServerRelativePath.DecodedUrl}>{fileName}</Link></span></div>
        )
      });
    }
    catch (e) {
      console.log('bindAttachmentFileNames ' + e);
    }

  }


  render() {
    debugger;
    return (
      <div>
        <div className='row p-6 mt-1'>
          <div className='col-md-6'><p >Created on {(this.props.Created != null) ? (moment(this.props.Created).format('MM/DD/YYYY')) : moment().format('MM/DD/YYYY')}</p></div>
        </div>
        <div className='border p-4 mt-1'>
          <div className='row'>
            <div className='col-md-3 font-weight-bold'>
              <p>Document Status :</p>
            </div>
            <div className='col-md-8 font-weight-normal'>

              <span>{this.props.Status}</span>
            </div>
          </div>
          <div className='row mt-1'>
            <div className='col-md-3 font-weight-bold'>
              <p>Date:</p>
            </div>
            <div className='col-md-8 font-weight-normal'>
              <span>{moment(this.props.Date).format('L')}</span>
            </div>
          </div>
          <div className='row mt-1'>
            <div className='col-md-3 font-weight-bold'>
              <p>Author:</p>
            </div>
            <div className='col-md-8 font-weight-normal'>
              <span>{this.props.Author} </span>
            </div>
          </div>
          <div className='row mt-1'>
            <div className='col-md-3 font-weight-bold'>
              <p>Category:</p>
            </div>
            <div className='col-md-8 font-weight-normal'>
              {this.props.viewcategory}
            </div>
          </div>

          <div className='row mt-1'>
            <div className='col-md-3 font-weight-bold'>
              <p>Question:</p>
            </div>
            <div className='col-md-8 font-weight-normal'>
              <span>{this.props.Question} </span>
            </div>
          </div>
          <div className='row mt-2'>
            <div className='col-md-3 font-weight-bold'>
              <p> Answer:</p> </div>
          </div>
          <div className='row mt-2'>
            <div className='col-md-10'>
              <span dangerouslySetInnerHTML={{ __html: this.props.Answer, }} />
            </div>
          </div>

          <div className='row mt-1'>
            <div className='col-md-3 font-weight-bold'>
              <p>Attachment:</p>
            </div>
            <div className='col-md-8 font-weight-normal'>
              {this.bindAttachmentFileNames()}
            </div>
          </div>
        </div>
      </div>
    )
  }

}