declare interface INewFormsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'NewFormsWebPartStrings' {
  const strings: INewFormsWebPartStrings;
  export = strings;
}
