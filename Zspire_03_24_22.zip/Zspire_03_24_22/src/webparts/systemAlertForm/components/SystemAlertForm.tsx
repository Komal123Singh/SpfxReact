import * as React from 'react';
import { sp } from "@pnp/sp";
import "@pnp/sp/webs"; 
import "@pnp/sp/site-users/web"; 
import { ISystemAlertFormProps } from './ISystemAlertFormProps';
import * as _ from '@microsoft/sp-lodash-subset';
import { DefaultButton } from 'office-ui-fabric-react';
import { TextField } from 'office-ui-fabric-react/lib/components/TextField/TextField';
import {  ThemeProvider, createTheme,ProgressIndicator,ChoiceGroup,PrimaryButton,Checkbox,Dropdown,IDropdownStyles, DialogType, Dialog, DialogFooter,IconButton,Icon,Label,Pivot,PivotItem,ILabelStyles,IStyleSet} from '@fluentui/react';
import { DateTimePicker, DateConvention, TimeConvention, TimeDisplayControlType } from '@pnp/spfx-controls-react/lib/dateTimePicker';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { RichText } from '@pnp/spfx-controls-react/lib/RichText';
import { remove } from 'lodash';
import * as  SystemAlertAction from '../Action/SystemAlertAction';
import SystemAlertStore from '../Store/SystemAlertStore';
import './SystemAlertCss.css'
import ViewSystemAlert from './ViewSystemAlert';
import * as moment from 'moment';
import SunEditor from 'suneditor-react';
import 'suneditor/dist/css/suneditor.min.css';



let radiobtn=null;
let absoluteUrl;
let EditFormDetails;
let uniqueId = 0;
let isEditMode = false;
let isViewMode = false;
let Radiobtnchange=null;
let actionBtnClicked='';
let loadSpinner=false;
let exitLocation;
let Bodyvalidation='';
let Alertdescvalidation='';
let Alertvalidation='';
let uploadedRichTextFiles=[];


const myTheme = createTheme({
  palette: {
    themePrimary: '#23366f',
    themeLighterAlt: '#f3f4f9',
    themeLighter: '#cfd5e8',
    themeLight: '#a9b4d4',
    themeTertiary: '#6476a9',
    themeSecondary: '#344781',
    themeDarkAlt: '#203165',
    themeDark: '#1b2a55',
    themeDarker: '#141f3f',
    neutralLighterAlt: '#faf9f8',
    neutralLighter: '#f3f2f1',
    neutralLight: '#edebe9',
    neutralQuaternaryAlt: '#e1dfdd',
    neutralQuaternary: '#d0d0d0',
    neutralTertiaryAlt: '#c8c6c4',
    neutralTertiary: '#a19f9d',
    neutralSecondary: '#605e5c',
    neutralPrimaryAlt: '#3b3a39',
    neutralPrimary: '#323130',
    neutralDark: '#201f1e',
    black: '#000000',
    white: '#ffffff',
  }
});
const iconStyle = {
  root: {
    color: '#107c10',
    fontSize: '50px',
  }
};

let dialogContentProps = {
  type: DialogType.normal,
  title: 'Confirmation',
  closeButtonAriaLabel: 'Close',
  subText: '',
};

let dialogModelContentProps = {
  type: DialogType.normal,
  title: <div className="text-center"><div><Icon styles={iconStyle} iconName="SkypeCircleCheck"></Icon></div><div>Success</div></div>,
  closeButtonAriaLabel: 'Close',
  subText: '',
};


export interface MyState {
  webpartContxt: WebPartContext;
  Status:any;
  Date:any;
  Author:any;
  DocStatusChoiceArr:any;
  DocAvailable:any;
  DocAvailablearr:any;
  AlertTitle:any;
  ALertDesc:any;
  Body:any;
  Attachment:any;
  UpdateAttachments:any;
  delAttach:any;
  Lncreated:any;
  Lncreatedby:any;
  Lnmodified:any;
  Lnmodifiedby:any;
  DocType:string;
  EhDate:any;
  EhRev:any;
  EhEditor:any;
  Created:any;
  isModalClose: boolean;
  isModaldialogClose: boolean;
  isvalidRecord: boolean;
  isEditor:boolean;
  buttoncheck:any;

}
export default class SystemAlertForm extends React.Component<ISystemAlertFormProps, MyState> {
  constructor(prop) {
    super(prop);
    this.state = {
      webpartContxt: this.props.context,
      Status:'In-Progress',
      DocStatusChoiceArr:[{ key: 'In-Progress', text: 'In-Progress' },{key:'Publish',text:'Publish'}],
      Author:this.props.context.pageContext.user.displayName,
      Date:new Date(),
      DocAvailable:'Internal only',
      DocAvailablearr:[{key: 'Internal only', text: 'Internal only' },{key: 'Internal and External', text: 'Internal and External' } ],
      AlertTitle:'',
      ALertDesc:'',
      Body:'',
      Attachment:[],
      UpdateAttachments:[],
      delAttach:[], 
      Lncreated:null,
      Lncreatedby:null,
      Lnmodified:null,
      Lnmodifiedby:null,
      EhDate:null,
      EhEditor:null,
      EhRev:null,
      DocType:'System Alert',
      Created:null,
      isvalidRecord: false,
      isModalClose: true,
      isModaldialogClose: true,
      isEditor:false,
      buttoncheck:'',
    }
    absoluteUrl= this.props.context.pageContext.site.absoluteUrl;
    SPComponentLoader.loadCss(absoluteUrl+'/SiteAssets/StyleSheet/bootstrap.min.css');
    SPComponentLoader.loadCss(absoluteUrl+'/SiteAssets/StyleSheet/suneditor.min.css');
    SPComponentLoader.loadCss('https://cdn.jsdelivr.net/npm/suneditor@latest/dist/css/suneditor.min.css');
    SPComponentLoader.loadScript(absoluteUrl+'/SiteAssets/JS/jquery.min.js');
    SPComponentLoader.loadScript(absoluteUrl+'/SiteAssets/JS/popper.min.js');
    SPComponentLoader.loadScript(absoluteUrl+'/SiteAssets/JS/bootstrap.min.js');
  }
  
  componentDidMount() {
  
    try {
      const url = window.location.href;
      const urlObject = new URL(url);
      uniqueId = urlObject.searchParams.get('itemID') == '' || urlObject.searchParams.get('itemID') == null ? 0 : parseInt(urlObject.searchParams.get('itemID'));
      
      // Call default form details
      this.getFormDefaultDetails();
      this.getLoggedUsersGroup();
      if (uniqueId != 0) {
        isViewMode = true;
        isEditMode = false;
        
       this.getEditFormDetailsComp();
      }
      else {
        isViewMode = false;
        isEditMode = true;
      }
        
      
    }
    catch (e) {
      console.log('componentDidMount: ' + e);
    }
  }
  getFormDefaultDetails = () => {
    try {
   
      SystemAlertStore.on('insertResultchange', this.assignInsertResultStore);
      
    } catch (e) {
      console.log('getFormDefaultDetails' + e);
    }
  }
  public assignInsertResultStore = () => {
    try {
      if (SystemAlertStore.getInserResultStoreValue() != undefined) {
        if (actionBtnClicked == "saveClose") {
          dialogModelContentProps.subText = 'This Form has been submitted sucessfully. Click Ok to exit';
          loadSpinner = false;
          this.setState({ isModaldialogClose: false });
        } 
      }
    } catch (e) {
      console.log('assignInsertResultStore: ' + e);
    }
  }

  getEditFormDetailsComp = () => {
    try {
      SystemAlertAction.getEditFormDetails(uniqueId);
     SystemAlertStore.on('getEditFormDetailschange', this.assignEditFormDetailsStore);
     
    } catch (e) {
      console.log('EditClickBtn' + e);
    }
  }
  public assignEditFormDetailsStore = () => {
    debugger;
    EditFormDetails = SystemAlertStore.getEditFormDetailsStoreValue();
   
    if (EditFormDetails.length != 0) {
      let domparser = new DOMParser();
      let s = new XMLSerializer();

      let parsedAttachments0 = domparser.parseFromString(EditFormDetails.Body, 'text/html');
      parsedAttachments0.querySelectorAll('[class*=se-component]').forEach((ext) => { ext.removeAttribute('class'); }); let serializeAttachments0 = s.serializeToString(parsedAttachments0);
      this.setState({
      Author:EditFormDetails.DocAuthor,
      Status:EditFormDetails.DocStatus,
      AlertTitle:EditFormDetails.Title0, 
      DocAvailable:EditFormDetails.Docavailable,
      Body: serializeAttachments0 != '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>null</body></html>' ? _.unescape(serializeAttachments0) : '',
      ALertDesc:EditFormDetails.AlertDesp,
      Created:EditFormDetails.Created,
      Date:EditFormDetails.CreationDate!=null?new Date(EditFormDetails.CreationDate):null,
      Lncreated:EditFormDetails.LNCreated!=null? moment(EditFormDetails.LNCreated).format('MM/DD/YYYY LTS') : null,
        Lnmodified:EditFormDetails.LNModified!=null? moment(EditFormDetails.LNModified).format('MM/DD/YYYY LTS')  : null,
        Lncreatedby:EditFormDetails.LNCreatedBy,
        Lnmodifiedby:EditFormDetails.LNModifiedBy,
        EhDate:EditFormDetails.EhDate,
        EhEditor:EditFormDetails.EhEditor,
        EhRev:EditFormDetails.EhRev,
        UpdateAttachments:EditFormDetails.AttachmentFiles,
      
      });
    }
  }
  
  public insertForm = () => {
    loadSpinner=true;
    this.setState({ isModalClose: true,buttoncheck:'disabledbutton'});
  
    let year=moment(new Date()).format("YYYY");
    let username=this.props.context.pageContext.user.displayName;
    let date=moment().format('MM/DD/YYYY LTS');
    let editor=this.props.context.pageContext.user.displayName;
    let ehDate=moment().format('MM/DD/YYYY LTS');
    let Ehrev='0';
    let enrev=parseInt(this.state.EhRev);
    try {
      if (uniqueId == 0) {
        SystemAlertAction.saveForm(this.state.Status,this.state.Date,this.state.Author,this.state.AlertTitle,this.state.AlertTitle,this.state.Body,this.state.ALertDesc,this.state.DocAvailable,this.state.Created,year,date,username,date,username,Ehrev,editor,ehDate,this.state.DocType,this.state.Attachment,uploadedRichTextFiles )
      }

      else {
        let newdate= moment().format('MM/DD/YYYY LTS')+"\n"+this.state.EhDate;
        // let Dateupdate=newdate.join('\r\n')
        let newrev=enrev+1 ;
        let rev=newrev.toString()+"\n"+this.state.EhRev;
        let newEditor=this.props.context.pageContext.user.displayName+"\n"+this.state.EhEditor;
        SystemAlertAction.updateForm(uniqueId,this.state.Status,this.state.Date,this.state.Author,this.state.AlertTitle,this.state.AlertTitle,this.state.Body,this.state.DocAvailable,this.state.ALertDesc,this.state.Attachment,this.state.UpdateAttachments,this.state.delAttach,date,username,rev,newEditor,newdate,uploadedRichTextFiles)
      }
    }
    catch (e) {
      console.log('insertForm: ' + e);
    }
  }

  handleRichTextChange = (fieldName, content) => {

    try {
      switch (fieldName) {

        case 'Body':
          this.setState({ Body: content });
          break;
      }
    }
    catch (e) {
      console.log('handleRichTextChange: ' + e);
    }
  }
  handleImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {
   
    if (imageInfo != null) {
      let files = uploadedRichTextFiles;
      let dataURI = imageInfo.src;
      let fileName = imageInfo.name;
      if (dataURI.split(',')[0].indexOf('base64') >= 0) {
        var arr = dataURI.split(','),
          mime = arr[0].match(/:(.*?);/)[1],
          bstr = atob(arr[1]),
          n = bstr.length,
          u8arr = new Uint8Array(n);
        while (n--) {
          u8arr[n] = bstr.charCodeAt(n);
        }
        const file = new File([u8arr], fileName, { type: mime });
        let fExists = files.some((f) => f['name'] === file['name']);
        if (!fExists) {
          files.push(file);
        }
        uploadedRichTextFiles = files;
      }
    }
  }

private RadioBtnChange = (ev: React.FormEvent<HTMLInputElement>, option: any) => {


radiobtn=option.key;
this.setState({ Status:radiobtn });

}
private RadioBtnChange2 = (ev: React.FormEvent<HTMLInputElement>, option: any) => {


  Radiobtnchange=option.key;
  this.setState({ DocAvailable:Radiobtnchange });
  
  }
private _getDateDatePickerItems = (items) => {

  this.setState({ Date: items });
}
private inputFormChange = (inputValue) => {
  
  try {
    switch (inputValue.target.name) {

      case 'AlertTitle':
        {
          this.setState({ AlertTitle: inputValue.target.value });
          break;
        }
        case 'AlertDesc':
          {
            this.setState({ ALertDesc: inputValue.target.value });
            break;
          } 
          case 'body':
          {
            this.setState({ Body: inputValue.target.value });
            break;
          }       
       
    }
  }
  catch (e) {
    console.log('inputFormChange: ' + e);
  }
}
getLoggedUsersGroup = async () => {
  debugger;
  try { 
  let LoggedUsersGroup = await sp.web.currentUser.groups();
  let permissionupdated=false;
  LoggedUsersGroup.map((groupItem) => {
   if(permissionupdated==false) {
    if (groupItem.Title == "USZ_ZSPIREHomePage_Access_Admins"||groupItem.Title == "USZ_ZSPIREHomePage_Admins"||groupItem.Title == "USZ_ZSPIREHomePage_Editors"
  ||groupItem.Title == "Z-SPIRE Homepage & User guide Owners"||groupItem.Title == "Z-SPIRE Homepage & User guide Members")
   {
    permissionupdated=true;
    this.setState({isEditor:true});
  } 
   }
  
  }) 
  
  } catch (e) {
  console.log('getLoggedUsersGroup' + e);
  }
  }
public EditClickBtn = () => {
  try {
    isEditMode = true;
    isViewMode = false;
    this.getEditFormDetailsComp();
  } catch (e) {
    console.log('EditClickBtn' + e);
  }
}
  public ViewClickBtn = () => {
    try {
      isEditMode = false;
      isViewMode = true;
      this.getEditFormDetailsComp();
    } catch (e) {
      console.log('ViewClickBtn' + e);
    }
  }
private filesave=(newattach)=>{
 
   
  try {

    let fileInfos = [];
     
    for(var i=0;i<newattach.target.files.length;i++){
      debugger;
            fileInfos.push({
                name:newattach.target.files[i].name,
                content:newattach.target.files[i]
            }); 
          }
    this.setState({ Attachment:fileInfos});
    
  } catch (e) {
    console.log('filesave: ' + e);
  }

}


private showattach= ()=>{
  try{
    debugger;
    let showitem=this.state.Attachment;
    return showitem.map((item, idx) => {
    
      return(
            <div><span><a href=''>{showitem[idx].name}</a>
            </span>
            </div>
      )
  })
  }
  catch(e){
    console.log('showattach: ' + e);

}
}
bindAttachmentFileNames() {
  try {
    debugger;
    let editattchments=this.state.UpdateAttachments;

// let fileExtension = fileName.split('.').pop();
let filtereditem = editattchments.filter(attachmentitems =>!attachmentitems.FileName.match(/.(jpg|jpeg|png|gif)$/i))
      return filtereditem.map((item, idx) => {
          //let fileName = item.FileName;
               let downloadUrl = this.props.context.pageContext.web.absoluteUrl + "/_layouts/download.aspx?sourceurl=" + filtereditem[idx].ServerRelativeUrl;  
          return (
              <div><span><a data-interception="off" target='_blank' href={filtereditem[idx].ServerRelativePath.DecodedUrl}>{filtereditem[idx].FileName}</a>
                  <IconButton className='mt-1' iconProps={{ iconName: 'Delete' }} title='Delete' ariaLabel='Delete' onClick={this.deleteAttachment.bind(this, filtereditem[idx].FileName)} />
                  </span></div>
              )

      });
  }
  catch (e) {
      console.log('bindAttachmentFileNames ' + e);
  }
}
private deleteAttachment = (DeleteFileName) => {
debugger;
  try{
 //remove(this.state.EditAttachments);
 let tempEditAttachment=this.state.UpdateAttachments;
 let tempDeleteAttachment=this.state.delAttach;
 let result;
  
  // let index=tempEditAttachment.indexOf(DeleteFileName);
  var index = tempEditAttachment.findIndex(function(DeleteItem) {
    return DeleteItem.FileName == DeleteFileName
   
  });
  tempEditAttachment.splice(index,1);
  this.setState({UpdateAttachments:tempEditAttachment});

  tempDeleteAttachment.push(DeleteFileName);

  this.setState({delAttach:tempDeleteAttachment})


  console.log(this.state.delAttach);

}
catch (e) {
  console.log('deleteAttachment: ' + e);
}
}
            
checkFormValidation = (actionClick) => {
  
  try {
    
    Alertvalidation='';
    Bodyvalidation='';
     Alertdescvalidation='';
    // Assign action value
    actionBtnClicked = actionClick;

    // Validation Check
    
    
    Alertvalidation = this.state.AlertTitle == '' ? 'Please enter the Alert title' : '';
  Alertdescvalidation = this.state.ALertDesc == '' ? 'Please enter the Alert Description' : '';
   
    if ( Alertvalidation != '' || Alertdescvalidation != '') {
      this.setState({ isvalidRecord: false });
    } else {
      this.modalPopupOpen(actionBtnClicked);
      this.setState({ isvalidRecord: true });
    }
  }
  catch (e) {
    console.log('checkFormValidationChange: ' + e);
  }
}
            modalPopupOpenView = (actionCall) => {
              debugger;
          
              try {
                actionBtnClicked = actionCall; 
                if (actionBtnClicked == 'close') {  
                  dialogContentProps.title = 'close Confirmation'; 
                  dialogContentProps.subText = 'Are you sure you want to close the form?'; 
                }
                this.setState({ isModalClose: false });     
              } catch (e) { 
                console.log('modalPopup: ' + e);  
              }
            }
            modalPopupOpen = (actionCall) => {

              try {
                actionBtnClicked = actionCall;
                if (actionBtnClicked == 'close') {
                  dialogContentProps.title = 'Close Confirmation';
                  dialogContentProps.subText = 'Are you sure you want to close this Form?';
                } else if (actionBtnClicked == 'saveClose') {
                  dialogContentProps.title = 'Save Confirmation';
                  dialogContentProps.subText = 'Do you want to save this details?';
                }
                
                this.setState({ isModalClose: false });
              } catch (e) {
                console.log('modalPopup: ' + e);
              }
            }
            modalPopupClose = () => {
              try {
                this.setState({ isModalClose: true });
              } catch (e) {
                console.log('modalPopup: ' + e);
              }
            }
            
            modalSubmitClick = () => {
             
              try {
                if (actionBtnClicked == 'close') {
                  this.Exitform();
                }
                 else if (actionBtnClicked == 'saveClose') {
                  //actionBtnClicked = this.state.ProcessStatus == 'Complete' ? 'Complete' : actionBtnClicked;
                  this.insertForm();
                }
              } catch (e) {
                console.log('modalSubmitClick: ' + e);
              }
            }
            Exitform = () => {
              debugger;
              try {
                window.open('','_parent','');
              window.close();
              } catch (e) {
            
                console.log('Exitform: ' + e);
              } 
            }
            Exit = () => {

              try {
                window.open('','_parent','');
                window.close();
          
              } catch (e) {
          
                console.log('CloseForm: ' + e);
              }
            }
            
private tabledetails = () => {
  debugger;
  try {
  let splitEheditor=this.state.EhEditor!=undefined?this.state.EhEditor.split('\n'):[];
  let splitEhrev=this.state.EhRev!=undefined?this.state.EhRev.split('\n'):[];
  let splitEhdate=this.state.EhDate!=undefined?this.state.EhDate.split('\n'):[];
  // for(var i=0; i<splitEhrev.length; i++){
  //   splitEhrev[i] = splitEhrev[i] + '<br />'
  // }
  return(
    <table className="table table-bordered border-spacing:2px text-center ">
                    <thead>
                      <tr>
                        <th scope="col">Rev.</th>
                        <th scope="col">Editor</th>
                        <th scope="col">Edit Date</th>
                        
                      </tr>
                    </thead>
                    <tbody>
                      {splitEhrev.filter((item, index) => index < 10).map((items,index)=>{
                        // for(var j=0; j<splitEheditor.length;j++ ){
                        // for(var k=0; k<splitEhdate.length;k++){
                        //   if(index==j){
                        //     if(j==k){
                        return(
                      <tr >
                        <td className='text-center'>{items}</td>
                        
                        <td className='text-center'>{splitEheditor[index]}</td>
                        <td className='text-center'>{splitEhdate[index]}</td>
                        
                      </tr>
                        )
                      // )}}}}
                        })}
                    </tbody>
                  </table>
  )
 
  
  } catch (e) {

    console.log('tabledetails: ' + e);
  } 
}

  public render(): React.ReactElement<ISystemAlertFormProps> {
    return (
      <ThemeProvider theme={myTheme}>
      <div className={this.state.buttoncheck+' container'}>
        <div className='border p-3' style={{ backgroundColor: '#23366f' }}>
          <div className='row'>
            <div className='col-md-6'><h3 className="text-light ">{this.props.description}</h3></div>
            <div className='col-md-6 text-right'><img src={this.props.logo} alt='Logo' width='50' height='50' /></div>
          </div>
          </div>
                    
          {isViewMode == true && isEditMode == false ?
          <div>
            <div className='buttonCls mt-2'>
            <DefaultButton className=' m1-1 md-2' text='Close' onClick={this.modalPopupOpenView.bind(this, 'close')} allowDisabledFocus />
            {this.state.isEditor==true?<PrimaryButton className='ml-1 ' text='Edit' onClick={this.EditClickBtn} allowDisabledFocus />:null}
            
           <div className= 'mt-1'><Pivot aria-label="Basic Pivot Example">
           <PivotItem className='mt-3' headerText="System Alert ">
           <div style={{ backgroundColor: '' }}><ViewSystemAlert {...this.state} /></div>
      </PivotItem>
           <PivotItem className='mt-3' headerText="Edit history">
       <label className='col md-12'>{this.tabledetails()}</label>
      </PivotItem>
    </Pivot>
    </div>
            </div> </div> :
          <div>
          <div className='buttonCls mt-2'>
            
          <DefaultButton className='' text='Close' onClick={this.modalPopupOpen.bind(this, 'close')} allowDisabledFocus />
            <PrimaryButton className='ml-1' text='Save & Close' onClick={this.checkFormValidation.bind(this, 'saveClose')} allowDisabledFocus />
          </div>
          {loadSpinner==true?<ProgressIndicator label="Submitting Details" />:null}
          <div className='row p-6 mt-2'>
            <div className='col-md-6'><p >Created on {(this.state.Created!=null)?(moment(this.state.Created).format('MM/DD/YYYY')):moment().format('MM/DD/YYYY')}</p></div>
            <div className='col-md-6 text-right style required'><b className='control'></b> Signifies a Required Field</div>
              </div>
          <div className='border p-3 mt-1'> 
          <div className='row mt-2'>
                 <div  className='col-md-3 form-group required'><b className='control-label'>Document Status:</b></div>
                 <div className='col-md-9'> <ChoiceGroup className='w-100 inlineflex radio-inline'  selectedKey={this.state.Status}  options={this.state.DocStatusChoiceArr} onChange={this.RadioBtnChange} />
                 </div>
                 
               </div>
                
                <div className='row mt-2'>
                <div className='col-md-3 form-group required'><b className='control-label'>Date:</b></div>
                <div className='col-md-4 '>
                <DateTimePicker dateConvention={DateConvention.Date} showLabels={false}  value={this.state.Date} formatDate={(date: Date) => date.toLocaleDateString('en-US',{month:"2-digit", day:"2-digit", year:"numeric"})}   onChange={this._getDateDatePickerItems}/> 
                </div>
                
               </div>
                <div className='row mt-2'>
                <div  className='col-md-3 form-group required'><b className='control-label'>Author:</b></div>
                <div className='col-md-8'>
                <Label className='w-4 normal'> {this.state.Author}</Label>
                </div>
                
               </div>
               <div className='row mt-2'>
                 <div  className='col-md-3 form-group required'><b className='control-label'>Document Available to:</b></div>
                 <div className='col-md-9'> <ChoiceGroup className='w-100 inlineflex radio-inline'  selectedKey={this.state.DocAvailable}  options={this.state.DocAvailablearr} onChange={this.RadioBtnChange2} />
                 </div>
                 
               </div>
               <div className='row mt-2'>
                 <div  className='col-md-3 form-group required'><b className='control-label'>Alert Tilte:</b></div>
                 <div className='col-md-6'>
                 <TextField   value={this.state.AlertTitle} name='AlertTitle' placeholder={'Enter the Alert Title'} errorMessage={Alertvalidation}  onChange={this.inputFormChange}/>
                 </div>
               </div>
               <div className='row mt-2'>
                 <div  className='col-md-3 form-group required'><b className='control-label'>Alert Description:</b></div>
                 <div className='col-md-6'>
                 <TextField  value={this.state.ALertDesc} name='AlertDesc' placeholder={'Enter the Alert Description'} errorMessage={Alertdescvalidation} onChange={this.inputFormChange}/>
                 </div>
               </div>
               <div className='row mt-2'>
                 <div  className='col-md-3'><b>Body:</b></div>
               
                 <div className='col-md-9'>
                 
                 <div className='border p-3 mt-2'>
                 <SunEditor enableToolbar={true} placeholder='Please type here...' setContents={this.state.Body} showToolbar={true} setOptions={{
                        minHeight: '170px', mode: 'classic', buttonList: [
                          ['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
                          ['table', 'link', 'image'],],
                      }} onChange={this.handleRichTextChange.bind(this, 'Body')} onImageUpload={this.handleImageUpload} />
                 </div>                 
                 
                 </div>
                 </div>

               <div className='row mt-2'>
                 <div className='col-md-3'><b >Attachment:</b></div>
                 <div className='col-md-8'>
                 <input className='ReactFieldEditor-Attachments-UploadInput mt-2' type='file' name='attachmentFiles' title='Attach Files' aria-required='false' aria-label='Attach Files' multiple onChange={this.filesave}/> 
                 <div>{this.showattach()}</div>
                  <div>{this.bindAttachmentFileNames()}</div>
                
                  {/* {this.state.Attachments==''?<span className='text-danger'>{attachmentvalidation}</span>:null}
                 {this.state.UpdateAttachments==''?<span className='text-danger'>{updateAttachmentvalidation}</span>:null} */} 
                 </div>
               </div>
    
                  </div>
      </div>}
      <Dialog minWidth={'460px'} maxWidth={'520px'} hidden={this.state.isModalClose} onDismiss={this.modalPopupClose} dialogContentProps={dialogContentProps}>
            <DialogFooter>
              <DefaultButton onClick={this.modalPopupClose} text="No" />
              <PrimaryButton onClick={this.modalSubmitClick} text="Yes" />
            </DialogFooter>
          </Dialog>
          <Dialog minWidth={'380px'} hidden={this.state.isModaldialogClose} dialogContentProps={dialogModelContentProps}>

            <DialogFooter>

              <PrimaryButton style={{ textAlign: 'center' }} onClick={this.Exit} text="OK" />

            </DialogFooter>

          </Dialog>
   </div>
      </ThemeProvider>
    );
  }
}
