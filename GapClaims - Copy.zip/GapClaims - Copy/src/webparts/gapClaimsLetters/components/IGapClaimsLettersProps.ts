import { WebPartContext } from "@microsoft/sp-webpart-base";
import { HttpClient } from "@microsoft/sp-http";
export interface IGapClaimsLettersProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  // context:any;
  logo:string;
  bannerBackground:string;
  bodyBackground:string;
  context:WebPartContext;
  myhttpclient:HttpClient;
}
