import * as React from 'react';
import { MyState } from './ReleaseDocumentForm';
export default class ViewReleaseDocument extends React.Component<MyState> {
    bindAttachmentFileNames(): any;
    render(): JSX.Element;
}
//# sourceMappingURL=ViewReleaseDocument.d.ts.map