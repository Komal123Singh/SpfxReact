import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IUserGuideFormProps {
    description: string;
    context: WebPartContext;
    logo: string;
    exitLocation: string;
}
//# sourceMappingURL=IUserGuideFormProps.d.ts.map