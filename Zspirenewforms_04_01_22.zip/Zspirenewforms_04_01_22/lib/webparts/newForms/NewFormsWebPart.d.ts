import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface INewFormsWebPartProps {
    description: string;
    ReleaseDocLocation: string;
    NewsArcticleLocation: string;
    FaqLocation: string;
    SystemAlertLocation: string;
    exitLocation: string;
    isUserguideform: boolean;
    isHomepageforms: boolean;
}
export default class NewFormsWebPart extends BaseClientSideWebPart<INewFormsWebPartProps> {
    onInit(): Promise<void>;
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=NewFormsWebPart.d.ts.map