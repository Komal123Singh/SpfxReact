import { EventEmitter } from 'events';
declare class faqDocumentStore extends EventEmitter {
    constructor();
    storeChange(action: any): void;
    getEditFormDetailsStoreValue(): any[];
    getInserResultStoreValue(): any;
    getcategorieslistitemStoreValue(): any[];
}
declare let objFaqdocumentStore: faqDocumentStore;
export default objFaqdocumentStore;
//# sourceMappingURL=faqDocumentStore.d.ts.map