import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IExceptionsProps {
    description: string;
    context: WebPartContext;
    logo: string;
    bannerBackground: string;
    bodyBackground: string;
    exitLink: string;
}
//# sourceMappingURL=IExceptionsProps.d.ts.map