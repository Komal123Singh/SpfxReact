import * as React from 'react';
import { IGapClaimsLettersProps } from './IGapClaimsLettersProps';
import { IGapClaimsLettersStates } from './IGapClaimsLettersStates';
import * as GapClaimsLettersAction from '../Action/GapClaimsLettersAction';
import GapClaimsLettersStore from '../Store/GapClaimsLettersStore';
import { PeoplePicker, PrincipalType } from '@pnp/spfx-controls-react/lib/PeoplePicker';
import { DateTimePicker, DateConvention, TimeConvention } from '@pnp/spfx-controls-react/lib/dateTimePicker';
import htmlToFormattedText from "html-to-formatted-text";
import { TextField, Dropdown,DatePicker, IDropdownOption,Checkbox,DialogFooter,DialogType,Icon, IChoiceGroupOption,Label, Link, PrimaryButton, Toggle, ChoiceGroup,IconButton, IIconProps , Dialog, elementContainsAttribute} from '@fluentui/react';
import { Stack } from 'office-ui-fabric-react/lib/Stack';
import {sp} from "@pnp/sp";
import "@pnp/sp/site-users/web";
import * as moment from "moment";

import { SPComponentLoader } from '@microsoft/sp-loader';
import { SecurityTrimmedControl, PermissionLevel, } from '@pnp/spfx-controls-react/lib/SecurityTrimmedControl';
import { SPPermission } from '@microsoft/sp-page-context';
import ViewGapClaimsLetters from './ViewGapClaimsLetters';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import './GapClaimsLettersCss.css';
import 'suneditor/dist/css/suneditor.min.css';
import SunEditor from 'suneditor-react';
import 'suneditor/dist/css/suneditor.min.css';
import * as _ from '@microsoft/sp-lodash-subset';
import { containsInvalidFileFolderChars } from '@pnp/sp';
import {saveAs} from "file-saver";
import { Attachments } from '@pnp/sp/attachments';
import { first, split } from 'lodash';
import {HttpClient,HttpClientResponse,IHttpClientOptions} from "@microsoft/sp-http";
// Global Variable
let absoluteUrl;
let relativeURL;
let uploadedRichTextFiles = [];
let AttachmentTextName=[];
let deleteFiles = [];
let toDelNames=[];
let toDeleteAttachments=[];
let attachmentfilenames;
let actionclicked;
let delAttachList;
let includes=[];
let localSendToEmail=[];
let localSendToID=[];
let localSendToUser=[];
let localCopyToEmail=[];
let localCopyToID=[];
let localCopyToUser=[];
let localBlindCopyToEmail=[];
let localBlindCopyToID=[];
let localBlindCopyToUser=[];
let localFromEmail=[];
let localFromID=[];
let localFromUser=[];
let Typevalues=[];
let serbody;
const url = window.location.href;
const urlObject = new URL(url);
let uniqueId = urlObject.searchParams.get('itemID')==''||urlObject.searchParams.get('itemID')==null?0:parseInt(urlObject.searchParams.get('itemID'));
let iddd=uniqueId;
let isEditMode=false;
let isAssignToClaim=false;
let isViewMode=false;
let EditFormDetails;
// let editid=EditFormDetails.ID;
let openDailog2 = false;
const stackTokens = { childrenGap: 3 };
const addIcon: IIconProps = { iconName: 'Add' };
const subIcon: IIconProps = { iconName: 'CalculatorMultiply' };
var XMLserialize = new XMLSerializer();

const onFormatDate = (date?: Date): string => {
  
  var ampm = date.getHours() >= 12 ? ' PM ' : ' AM ';
  
  return !date ? '' : (date.getMonth() + 1) + '/' + date.getDate() + '/' + (date.getFullYear() % 100) +" "+[date.getHours(),
    date.getMinutes()].join(':')+ampm;

};

export default class GapClaimsLetters extends React.Component<IGapClaimsLettersProps, IGapClaimsLettersStates,{}> {
constructor(props) {
super(props);
this.state = {
  selectedFiles:[],
webpartContxt:this.props.context,
FormAttachment:[],//Attachment
FormAttachmentNames:[],
oldAttachments:'',
Attachments:'',
toDeleteAttachments:'',
attachmentType:[],
hideDialog:true,
hideDialog2:true,
id:0,

toDelNames:[],
GAPAgreeNum : '',
GAPAgreeNumA:'',
VSCAdj : '',
InsuredLastName : '',
InsuredFirstName : '',
InsuredLastNameA : '',
InsuredFirstNameA : '',
InsuredStreetAddress : '',
InsuredCity : '',
InsuredState : '',
InsZip : '',
NotesType:'',
PaymentTypeOptions:[],
mrk_delete : '',
mrk_deleteChoiceArr :[{key:'Yes',text:'Yes'},{key:'No',text:'No'}],
SendTo : [],
SendToText:[],
SendToDefaultItems:[],
SendToUserItems:[],
CopyTo : [],
CopyToText:[],
CopyToDefaultItems:[],
filec:1,
CopyToUserItems:[],
BlindCopyTo : [],
BlindCopyToText:[],
BlindCopyToDefaultItems:[],
BlindCopyToUserItems:[],
From : [],
FromText:[],
FromDefaultItems:[],
FromUserItems:[],
Date : null,
Title : '',
Body : '',
};
absoluteUrl = this.props.context.pageContext.site.absoluteUrl;
relativeURL = this.props.context.pageContext.site.serverRelativeUrl;
SPComponentLoader.loadCss('https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
SPComponentLoader.loadCss('https://cdn.jsdelivr.net/npm/suneditor@latest/dist/css/suneditor.min.css');
SPComponentLoader.loadScript('https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js');
SPComponentLoader.loadScript('https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js');
SPComponentLoader.loadScript('https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js');
/***************** */
SPComponentLoader.loadScript("https://cdnjs.cloudflare.com/ajax/libs/javascript-canvas-to-blob/3.4.0/js/canvas-to-blob.min.js");

}


  componentDidMount() {
  try {
    debugger;
    const url = window.location.href;

const urlObject = new URL(url);

uniqueId = urlObject.searchParams.get('itemID')==''||urlObject.searchParams.get('itemID')==null?0:parseInt(urlObject.searchParams.get('itemID'));


   
if(uniqueId!=0)
{
// isEditMode=true;
isViewMode=true;
this.getEditFormDetailsComp();
this.getPaymentValues();
}
// else if(isAssignToClaim=true){
// this.Dialog_save();

// }
else {
this.getFormDefaultDetails();
this.getPaymentValues();
}
  }
  catch (e) {
  console.log('componentDidMount: ' + e);
  }
  }

getFormDefaultDetails = () => {
 try {
GapClaimsLettersStore.on('insertResultchange', this.assignInsertResultStore);

GapClaimsLettersAction.getmrk_deleteDetails('mrk_delete');
GapClaimsLettersAction.getPaymentTypeDetails();
GapClaimsLettersStore.on('mrk_deletechange', this.assignmrk_deleteStore);
} catch (e) {
console.log('getFormDefaultDetails' + e);
  }
  }
//AssigntoClaim
getAssignToClaimDetails=()=>{

}
  
getEditFormDetailsComp = () => {
 try {
   debugger;
this.getFormDefaultDetails();

GapClaimsLettersAction.getEditFormDetails(uniqueId);

GapClaimsLettersStore.on('getEditFormDetailschange', this.assignEditFormDetailsStore);
} catch (e) {
console.log('EditClickBtn' + e);
  }
  }

public EditClickBtn = () => {
 try {
 isEditMode = true;
isViewMode = false;
this.getEditFormDetailsComp();
} catch (e) {
console.log('EditClickBtn' + e);
  }
  }

public ViewClickBtn = () => {
 try {
 isEditMode = false;
isViewMode = true;
this.getEditFormDetailsComp();
} catch (e) {
console.log('ViewClickBtn' + e);
  }
  };

//Getting PaymentType values
public getPaymentValues = () => {

  try {

     GapClaimsLettersStore.on('PaymenTypeChange',this.getPaymentTypevaluesStore);
     
     GapClaimsLettersAction.getPaymentTypeDetails();

  }  

 catch (e) {

       console.log('getAdminListValues' + e);


}
}

public getPaymentTypevaluesStore = () => {

Typevalues= GapClaimsLettersStore.getPaymentTypeDetailsList();

  //Getting Type Values from PaymentTypeList

  let TypeDropDown=[];

  let VarType;

  let splitPaymentTypearr=[];

  VarType=Typevalues[0].NotesType;

  splitPaymentTypearr=VarType!=undefined?VarType.split(/[\n,;]+/):[];
;
  splitPaymentTypearr.map((item)=>{

     TypeDropDown.push({ key: item, text: item});    

  });

  this.setState({

    PaymentTypeOptions:TypeDropDown

                });

  console.log(this.state.PaymentTypeOptions);
              }
              public onPaymentTypeChange = (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): void => {

                this.setState({ NotesType: item.key as string });
              
                console.log(this.state.NotesType);
              }



//Creating a dialog pop up
public open_dialog=()=>{
  isAssignToClaim=true;
  this.setState({hideDialog:false});
  // this.txtfile();
  // this.txtattachfile();

}
public getuserEmail = async(Id) =>{

  return await sp.web.siteUsers.getById(Id).get() ;

}
public assignEditFormDetailsStore = async() => {localSendToEmail
  debugger;
EditFormDetails = GapClaimsLettersStore.getEditClickStoreValue();
let domparser = new DOMParser();
let s = new XMLSerializer();

if (EditFormDetails.length != 0)
{

localSendToEmail=[];
localSendToID=[];
localSendToUser=[];
let sarr=[];
if(EditFormDetails.SendTo==undefined){
 localSendToEmail=[""].concat(localSendToEmail)
}
else if(EditFormDetails.SendTo!=undefined){
for(var i=0;i < EditFormDetails.SendTo.length; i++){
// localSendToEmail.push(EditFormDetails.SendTo[i].EMail);
localSendToID.push(EditFormDetails.SendTo[i].ID);
await this.getuserEmail(EditFormDetails.SendTo[i].ID).then(async(usr) => {
  localSendToEmail.push(usr.Email)
   sarr = localSendToEmail.filter((val, id, array) => array.indexOf(val) == id);
  localSendToEmail=[...sarr];  
  });
localSendToUser.push(EditFormDetails.SendTo[i].Title);
sarr = localSendToUser.filter((val, id, array) => array.indexOf(val) == id);
localSendToUser=[...sarr];
}}

let carr=[]
localCopyToEmail=[];
localCopyToID=[];
localCopyToUser=[];
if(EditFormDetails.CopyTo==undefined){
  localCopyToEmail=[""].concat(localCopyToEmail)
 }
else if(EditFormDetails.CopyTo!=undefined){
for(var i=0;i < EditFormDetails.CopyTo.length; i++){
// localCopyToEmail.push(EditFormDetails.CopyTo[i].EMail);
await this.getuserEmail(EditFormDetails.CopyTo[i].ID).then(async(usr) => {
  localCopyToEmail.push(usr.Email)
   carr = localCopyToEmail.filter((val, id, array) => array.indexOf(val) == id);
  localCopyToEmail=[...carr];  
  });
localCopyToID.push(EditFormDetails.CopyTo[i].ID);
localCopyToUser.push(EditFormDetails.CopyTo[i].Title);
carr = localCopyToUser.filter((val, id, array) => array.indexOf(val) == id);
localCopyToUser=[...carr];
}}


localBlindCopyToEmail=[];
localBlindCopyToID=[];
localBlindCopyToUser=[];
let bccarr=[];
if(EditFormDetails.BlindCopyTo==undefined){
  localBlindCopyToEmail=[""].concat(localBlindCopyToEmail)
 }
else if(EditFormDetails.BlindCopyTo!=undefined){
for(var i=0;i < EditFormDetails.BlindCopyTo.length; i++){
// localBlindCopyToEmail.push(EditFormDetails.BlindCopyTo[i].EMail);
await this.getuserEmail(EditFormDetails.BlindCopyTo[i].ID).then(async(usr) => {
  localBlindCopyToEmail.push(usr.Email)
   bccarr = localBlindCopyToEmail.filter((val, id, array) => array.indexOf(val) == id);
  localBlindCopyToEmail=[...bccarr];  
  });
localBlindCopyToID.push(EditFormDetails.BlindCopyTo[i].ID);
localBlindCopyToUser.push(EditFormDetails.BlindCopyTo[i].Title);
bccarr = localBlindCopyToUser.filter((val, id, array) => array.indexOf(val) == id);
localBlindCopyToUser=[...bccarr];
}}
localFromEmail=[];
localFromID=[];
localFromUser=[];
let farr=[];
if(EditFormDetails.From==undefined){
  localFromEmail=[""].concat(localFromEmail)
 }
else if(EditFormDetails.From!=undefined){
// localFromEmail.push(EditFormDetails.From.EMail);
await this.getuserEmail(EditFormDetails.From.ID).then(async(usr) => {
  localFromEmail.push(usr.Email)
   farr = localFromEmail.filter((val, id, array) => array.indexOf(val) == id);
  localFromEmail=[...farr];  
  });
localFromID.push(EditFormDetails.From.ID);
localFromUser.push(EditFormDetails.From.Title);
farr = localFromUser.filter((val, id, array) => array.indexOf(val) == id);
localFromUser=[...farr];
}
let parsedBody= domparser.parseFromString(EditFormDetails.Body,'text/html');
parsedBody.querySelectorAll('[class*=se-component]').
forEach((ext) => {ext.removeAttribute('class');});let serializeBody= s.serializeToString(parsedBody);
delAttachList=[...EditFormDetails.AttachmentFiles];
this.setState({ 
FormAttachmentNames:EditFormDetails.AttachmentFiles,
// oldAttachments:EditFormDetails.AttachmentFiles,

GAPAgreeNum:EditFormDetails.GAPAgreeNum,

FromText:EditFormDetails.FromText,
BlindCopyToText:EditFormDetails.BlindCopyToText,
CopyToText:EditFormDetails.CopyToText,
SendToText:EditFormDetails.SendToText,
VSCAdj:EditFormDetails.VSCAdj,
InsuredLastName:EditFormDetails.InsuredLastName,
InsuredFirstName:EditFormDetails.InsuredFirstName,
InsuredStreetAddress:EditFormDetails.InsuredStreetAddress,
InsuredCity:EditFormDetails.InsuredCity,
InsuredState:EditFormDetails.InsuredState,
InsZip:EditFormDetails.InsZip,
NotesType:EditFormDetails.NotesType,
mrk_delete:EditFormDetails.mrk_delete,
SendToDefaultItems:localSendToEmail,
SendToUserItems:localSendToUser,
SendTo:localSendToID,
CopyToDefaultItems:localCopyToEmail,
CopyToUserItems:localCopyToUser,
CopyTo:localCopyToID,
BlindCopyToDefaultItems:localBlindCopyToEmail,
BlindCopyToUserItems:localBlindCopyToUser,
BlindCopyTo:localBlindCopyToID,
FromDefaultItems:localFromEmail,
FromUserItems:localFromUser,
From:localFromID,
Date:EditFormDetails.Date != null? new Date(EditFormDetails.Date):null,
Title:EditFormDetails.Title,
Body: _.unescape(serializeBody),

});
}
}


static get mrk_deleteChoice(){  
  const mrk_deleteOptions: IChoiceGroupOption[] = [  
      { key: "Yes", text: "Yes" },  
      { key: "No", text: "No" },
  ];  
  return mrk_deleteOptions;  
}   
public assignmrk_deleteStore= () => {
try {
let mrk_deleteChoice= [];

if(GapClaimsLettersStore.getmrk_deleteChoiceStoreValue() != undefined){
  if(GapClaimsLettersStore.getmrk_deleteChoiceStoreValue().length!=0)
GapClaimsLettersStore.getmrk_deleteChoiceStoreValue().map((item) => {
mrk_deleteChoice.push([{key:item,text:item,id:'mrk_delete'},]);
});
this.setState({mrk_deleteChoiceArr: mrk_deleteChoice});
}


} catch (e) {
console.log('assignmrk_deleteStore: ' + e);
}
}

// Call action save Result method
public assignInsertResultStore = () => {
try {
if (GapClaimsLettersStore.getInserResultStoreValue() != undefined) {
window.location.href = url;
}
} catch (e) {
console.log('assignInsertResultStore: ' + e);
}
}
public Dialog_close=()=>{
  this.setState({hideDialog:true});
}
public Dialog_close2=()=>{
  this.setState({hideDialog2:true});
}
//Assigntocalim
public Dialog_save=(actionCall)=>{
  actionclicked=actionCall;
  try{
    // if(actionclicked=='Save' && this.state.GAPAgreeNumA!="" && this.state.InsuredFirstNameA!=""
    //  && this.state.InsuredLastNameA!=""){
      if(actionclicked=='Save'){
    if(uniqueId!=0){
      isAssignToClaim=false;
      GapClaimsLettersAction.closeDialog(uniqueId,this.state.GAPAgreeNumA,this.state.InsuredFirstNameA,
        this.state.InsuredLastNameA);
        this.setState({hideDialog:true,hideDialog2:false});
        this.txtfile();
        //  this.getDatafromApi();
        
      openDailog2 = true;
     
     
    }
  }
  // else if(actionclicked!='Save'){
  //   alert("Please enter mandatory fields")
    
  // }
  else{
    this.setState({hideDialog2:true})
  }
  }
  
  catch (e) {
      console.log('Dialog_save ' + e);
    }
}

public _close=()=>{
  this.setState({hideDialog:true,hideDialog2:true}); 
  // this.txtfile();
  //this.txtattachfile();

}
//convert to word doc

// Call action save method
public insertForm = () => {
 try {
if (uniqueId == 0) {
GapClaimsLettersAction.saveForm(absoluteUrl,this.state.GAPAgreeNum,this.state.NotesType,this.state.VSCAdj,
  this.state.InsuredLastName,this.state.InsuredFirstName,this.state.InsuredStreetAddress,
  this.state.InsuredCity,this.state.InsuredState,this.state.InsZip,this.state.mrk_delete,
  this.state.SendTo,this.state.CopyTo,this.state.BlindCopyTo,this.state.From,this.state.Date,
  this.state.Title,this.state.Body,uploadedRichTextFiles,this.state.FormAttachment)
 
}
else
{
GapClaimsLettersAction.updateForm(uniqueId,this.state.NotesType,
  this.state.GAPAgreeNum,this.state.VSCAdj,this.state.InsuredLastName,
  this.state.InsuredFirstName,this.state.InsuredStreetAddress,this.state.InsuredCity,
  this.state.InsuredState,this.state.InsZip,this.state.mrk_delete,this.state.SendTo,
  this.state.CopyTo,this.state.BlindCopyTo,this.state.From,this.state.Date,this.state.Title,
  this.state.Body,uploadedRichTextFiles,this.state.FormAttachment,deleteFiles)
  }
  }
  catch (e) {
  console.log('insertForm: ' + e);
  }
  }
//get Assigndetails
private inputFormChange1=(e)=>{
  try {
 switch (e.target.name) {

case 'GAPAgreeNumA':
{
this.setState({GAPAgreeNumA :e.target.value});
break;
}
case 'InsuredLastNameA':
{
this.setState({InsuredLastNameA :e.target.value});
break;
}
case 'InsuredFirstNameA':
{
this.setState({InsuredFirstNameA :e.target.value});
break;
}
}
}
catch (e) {
console.log('inputFormChange1: ' + e);
}
} 
// Get Input Details
private inputFormChange = (inputValue) => {
 try {
 switch (inputValue.target.name) {

case 'GAPAgreeNum':
{
this.setState({GAPAgreeNum :inputValue.target.value});
break;
}
case 'NotesType':
{
this.setState({NotesType :inputValue.target.value});
break;
}
case 'VSCAdj':
{
this.setState({VSCAdj :inputValue.target.value});
break;
}
case 'InsuredLastName':
{
this.setState({InsuredLastName :inputValue.target.value});
break;
}
case 'InsuredFirstName':
{
this.setState({InsuredFirstName :inputValue.target.value});
break;
}
case 'InsuredStreetAddress':
{
this.setState({InsuredStreetAddress :inputValue.target.value});
break;
}
case 'InsuredCity':
{
this.setState({InsuredCity :inputValue.target.value});
break;
}
case 'InsuredState':
{
this.setState({InsuredState :inputValue.target.value});
break;
}
case 'InsZip':
{
this.setState({InsZip :inputValue.target.value});
break;
}
case 'SendTo':
{
this.setState({SendTo :inputValue.target.value});
break;
}
case 'CopyTo':
{
this.setState({CopyTo :inputValue.target.value});
break;
}
case 'BlindCopyTo':
{
this.setState({BlindCopyTo :inputValue.target.value});
break;
}
case 'From':
{
this.setState({From :inputValue.target.value});
break;
}
case 'Date':
{
this.setState({Date :inputValue.target.value});
break;
}
case 'Title':
{
this.setState({Title :inputValue.target.value});
break;
}
case 'Body':
{
this.setState({Body :inputValue.target.value});
break;
}
 }
  }
  catch (e) {
  console.log('inputFormChange: ' + e);
  }
  }

// Get Input RichText Details
private handleRichTextChange = (fieldName, content) => {
 try {
 switch (fieldName) {

case 'Body':
this.setState({ Body: content });
break;
 }
  }
  catch (e) {
  console.log('handleRichTextChange: ' + e);
  }
  }

/****RichTextMy */

/***k */

private handleImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {
  if (imageInfo != null) {
  let files = uploadedRichTextFiles;
  let dataURI = imageInfo.src;
   let fileName = imageInfo.name;
  if (dataURI.split(',')[0].indexOf('base64') >= 0) {
  var arr = dataURI.split(','),
  mime = arr[0].match(/:(.*?);/)[1],
  bstr = atob(arr[1]),
  n = bstr.length,
  u8arr = new Uint8Array(n);
  while (n--) {
  u8arr[n] = bstr.charCodeAt(n);
  }
  const file = new File([u8arr], fileName, { type: mime });
  let fExists = files.some((f) => f['name'] === file['name']);
  if (!fExists) {
  files.push(file);
   }
  uploadedRichTextFiles = files;
  }
  }
  }
  

handleAttachmentChange = (chTarget) => {
 
  
  debugger;
  try{
    let { FormAttachment, FormAttachmentNames } = this.state;
   
   let fileInfos = [];

  let target = chTarget.target;
  var d = new Date;
var ampm = d.getHours() >= 12 ? ' PM ' : ' AM ';
let dformat = [d.getMonth()+1,
d.getDate(),
d.getFullYear()].join('-')+' '+
[d.getHours(),
d.getMinutes(),
d.getSeconds()].join(' ')+ampm;


  if (FormAttachment.length !== 0 || target.files.length !== 0) {
   
   let filecount=(FormAttachmentNames.length+1);
    let fileName = [];
    let tempfile = [];
    let tempFName = [];
    
    FormAttachment.forEach((aFiles) => {
      if (aFiles.name === target.files.name) {
        console.log("file already exisist with same name");
      }
    });
    tempfile = this.state.FormAttachment;
    tempFName =  this.state.FormAttachmentNames;
    
    //console.log("handle file change", tempfile, tempFName);
  
  

    for (let fileItem of target.files) {
      
      let  attachmentfile_name:any="CLAIM}U}" +this.state.GAPAgreeNumA + "}U}GAP10}I}" +dformat+"-" +((filecount)+"000")+"-"+"ATTACHMENT"+((filecount)+"000")+"."
  
      tempFName.push({ FileName: fileItem.name });
      tempfile.push({ name: attachmentfile_name +fileItem.name, content: fileItem });
      // console.log("handle file change", tempfile, tempFName);
      this.setState({
        FormAttachment: tempfile,
        FormAttachmentNames: tempFName,
      });
    }
   
  }


} catch (e) {
  console.log("handleAttachmentChange: " + e);
}

}

addDeleteFiles =async(fileName) => {
  try {
    let tempAttachFileName = this.state.FormAttachmentNames;
    //console.log("tempAttachFileName", tempAttachFileName);

    var index = tempAttachFileName.map((p) => p.FileName).indexOf(fileName);
    if (
      uniqueId != 0 &&
      deleteFiles != undefined &&
      deleteFiles.length != 0
    ) {
      var indexCheck =  deleteFiles.map(
        (p) => p.FileName
      ).indexOf(fileName);
      indexCheck != -1 &&
      deleteFiles[indexCheck].ServerRelativePath !=
        undefined
        ? deleteFiles.push(fileName)
        : null;
      tempAttachFileName.splice(index, 1);
      //console.log("tempAttachFileName", tempAttachFileName);
      await this.setState({ FormAttachmentNames: tempAttachFileName });
    }
    if (uniqueId != 0) {
      var indexCheck = deleteFiles.map(
        (p) => p.FileName
      ).indexOf(fileName);
      indexCheck === -1 ? deleteFiles.push(fileName) : null;
      let filtered = tempAttachFileName.filter(
        (file) => file.FileName !== fileName
      );
      //console.log("filtered", filtered);
    
      await this.setState({
        FormAttachmentNames: filtered,
        
      });
    }
  } catch (e) {
    console.log("addDeleteFiles " + e);
  }
}

// Get DropDownDetails
private inputDropDownDetailsChange = (inputValue) => {
 try {
 switch (inputValue.id) {

 }
  }
  catch (e) {
  console.log('inputDropDownDetailsChange: ' + e);
  }
  }


private _getSendToPeoplePickerItems = (items: any[]) => {
let peoplePickArr = [];
for (let item in items) {
peoplePickArr.push(items[item].id);
}this.setState({ SendTo: peoplePickArr });
}
private _getCopyToPeoplePickerItems = (items: any[]) => {
let peoplePickArr = [];
for (let item in items) {
peoplePickArr.push(items[item].id);
}this.setState({ CopyTo: peoplePickArr });
}
private _getBlindCopyToPeoplePickerItems = (items: any[]) => {
let peoplePickArr = [];
for (let item in items) {
peoplePickArr.push(items[item].id);
}this.setState({ BlindCopyTo: peoplePickArr });
}
private _getFromPeoplePickerItems = (items: any[]) => {
let peoplePickArr = [];
for (let item in items) {
peoplePickArr.push(items[item].id);
}this.setState({ From: peoplePickArr });
};

private _getDateDatePickerItems = (items) => {
this.setState({ Date: items });
}


private mrk_deleteRadioBtnChange = (items) => {
items.target.innerText!=''?this.setState({ mrk_delete: items.target.innerText }):null;
}

PrintScreen = () => {
try {
window.print();

} catch (e) {
console.log('PrintScreen: ' + e);
}
}

/***********8Cover Lettters */
public txtfile=()=>{
  var d = new Date;
var ampm = d.getHours() >= 12 ? ' PM ' : ' AM ';
let dformat = [d.getMonth()+1,
d.getDate(),
d.getFullYear()].join('-')+' '+
[d.getHours(),
d.getMinutes(),
d.getSeconds()].join(':')+ampm;
 
const txt=document.createElement('a');
// const htmlToFormattedText = require("html-to-formatted-text");
const htmlToFormattedText = require("html2plaintext");



let domparser = new DOMParser();
let s = new XMLSerializer();
let parsedBody= domparser.parseFromString(this.state.Body,'text/html');
parsedBody.querySelectorAll('[class*=se-component]').
forEach((ext) => {ext.removeAttribute('class');});
let serializeBody= s.serializeToString(parsedBody);

const functionn =(htmlToFormattedText)=> {
  return htmlToFormattedText(serializeBody);
  // return htmlToFormattedText(serializeBody.replace(regex,''));
};
const SendtoVal=()=>{
  
if (this.state.SendToDefaultItems.includes(null) == true || this.state.SendToDefaultItems.includes(undefined) == true || this.state.SendToDefaultItems.includes("") == true||this.state.SendToDefaultItems.length ==0){
let splisendtoval = split(this.state.SendToText,",");
return splisendtoval[0];
}
else{
 
   return localSendToEmail[0];
}
}
const CopyToVal=()=>{
  if (this.state.CopyToDefaultItems.includes(null) == true || this.state.CopyToDefaultItems.includes(undefined) == true || this.state.CopyToDefaultItems.includes("") == true){
    let splicopyval = split(this.state.CopyToText,", ");
return splicopyval[0];
    }
    else{
     
       return localCopyToEmail.slice(0,1);
    }
}

const FromVal=()=>{
  if (this.state.FromDefaultItems.includes(null) == true || this.state.FromDefaultItems.includes(undefined) == true || this.state.FromDefaultItems.includes("") == true){
    let splifromval = split(this.state.FromText,",");
return splifromval[0];
    }
    else{
     
       return localFromEmail;
    }
}
const search='}';
const replace="";
const searchdate=":";
const replacedate=""; 
var searchsub = /[!@#$%^&*()_+\-=\[\];':"\\|,.<>\/?]+/;
const SubjectVal=()=>{
  if (this.state.Title=="" || this.state.Title == null || _.isEmpty(this.state.Title)== true){
    return this.state.Title;
  }
  else{
     return (this.state.Title.split(search).join(replace)).slice(0,91)
  }
}
const FileSubjectVal=()=>{
  if (SubjectVal()=="" || SubjectVal() == null || _.isEmpty(SubjectVal())== true){
    return SubjectVal()
  }
  else{
       if (searchsub.test(this.state.Title)){
         return SubjectVal().split(searchsub).join(replacedate)
       }
      
  }
}

const file=new Blob([("Sender: " +FromVal() +"\n"),("Date: " +dformat +"\n"),
("Send To: "+ SendtoVal()+"\n"),("Copy To: "+ CopyToVal()+"\n"),("Subject: "+SubjectVal() +"\n")
,("DocumentID: " +uniqueId +"\n"),("Content:" +functionn(htmlToFormattedText)+"\n"),("Attachments:   "+this.state.FormAttachmentNames.map((item,index)=>item.FileName) )
  ],{
  type:"text/html;charset=UTF-8"
  // item.FileName
 
});
// this.props.SendToDefaultItems.map((team, index) =>
//<span>{team}{index!=this.props.SendToDefaultI tems.length-1?',':null}</span>):null}</Label></div>
// functionname(htmlToFormattedText)
// "CLAIM}U}12345678}U}GAP10}I}12-31-2021 052900-AM-001-FW: CLM#:C004556367 INS CHK for RHOADS.TXT"dformat.split(searchdate).join(replacedate)
 var filename="CLAIM}U}" +this.state.GAPAgreeNumA + "_}U}GAP10}I}" 
 + dformat.split(searchdate).join(replacedate) + "-001-" +FileSubjectVal() + ".TXT";
// saveAs(file,filename);

txt.href=URL.createObjectURL(file);
txt.download=filename;
document.body.appendChild(txt);
txt.click();

var reader = new FileReader();
reader.readAsDataURL(file); 
reader.onloadend = function() {
  var base64data = reader.result;                
  console.log(base64data);
}



let txtFileSP = [];
var tempfilee= new File([file],filename)
txtFileSP.push({
  name:filename,
  content:tempfilee,

})

this.setState({FormAttachment:txtFileSP})


}


public  getDatafromApi(): Promise<any> { 

  const requestHeaders:Headers=new Headers();
    requestHeaders.append('Client ID', '0oa196vp85ef6DzRm0h8');
  requestHeaders.append('Ocp-Apim-Subscription-Key','cec1c33eb72e4f09848849408b10585a');
  // requestHeaders.append('Client Secret','lD87mobgguWkd2-5HdTBQk2w1I6G11_GTWYm-2O2');
  requestHeaders.append('Content-Type','application/json');
  const httpClientOptionsForGlobal: IHttpClientOptions = { 
    headers:requestHeaders,
    
    method: "GET" 
     
  }
  return this.props.myhttpclient
  .get(  
    ' https://azureapi-dev.zurichna.com/purefi/api/claim/v2/UUG/claims/C004627457/documents',
      
    HttpClient.configurations.v1,httpClientOptionsForGlobal
  )  
  .then((response: HttpClientResponse) => {  
    return response.json();  
  })  
  .then(jsonResponse => {  
    console.log(jsonResponse);  
    return jsonResponse;  
  }) as Promise<any>;  
}   
 
/***working */
   
/*****POST REquest */
private postdata():Promise<any>{
  const posturl="https://zna-api-dev.zurichna.com/purefi/api/claim/v2/{tpa}/claims/{claimNumber}/document/{direction}/{identifier}"
  const body:string=JSON.stringify({
    value :'name1'
  })
  const requestHeaders: Headers = new Headers();  
  requestHeaders.append('Content-type', 'application/json');
  requestHeaders.append('Cache-Control', 'no-cache');
  requestHeaders.append('Authorization', 'Bearer <TOKEN>');  
  //For Basic authentication  
  requestHeaders.append('Authorization', 'Basic <CREDENTIALS>'); 
  const httpClientOptions: IHttpClientOptions = {  
    body: body,  
    headers: requestHeaders  
  }; 
  return this.context.myhttpclient.post(
    posturl,HttpClient.configurations.v1,httpClientOptions)
    .then((response:Response):Promise<HttpClientResponse>=>{
      console.log("Post Request recieved");
      return response.json();
    });
}
 
/***************** */
//Render Method //
public render(): React.ReactElement<IGapClaimsLettersProps> {
return (
 <div className='container'> 

 <div className='border p-3' style={{backgroundColor:this.props.bannerBackground}}>

 <div className='row'>
 <div className='col-md-6'><h3>{this.props.description}</h3></div>
 <div className='col-md-6 text-right'>
   <img src={this.props.logo} alt='Logo' width='50' height='50' /></div>
 </div>
 </div>
 {isViewMode == true && isEditMode == false? 
 <div>
 <div className='buttonCls text-right'> 
 <PrimaryButton className='' text='Exit'  allowDisabledFocus />
 <PrimaryButton className='ml-1' text='Edit' onClick={this.EditClickBtn} allowDisabledFocus />
 <PrimaryButton className='ml-1' text='Print' onClick={this.PrintScreen} allowDisabledFocus />
 </div><div style={{backgroundColor:this.props.bodyBackground}}><ViewGapClaimsLetters {...this.state}/></div></div>: 
 <div>
 <div className='buttonCls mt-2 text-right'> 
 <PrimaryButton className='' text='Exit' allowDisabledFocus />
 <PrimaryButton className='ml-1' text='Save and Exit' onClick={this.insertForm} allowDisabledFocus />
 {isEditMode == true ?
  <><PrimaryButton className='ml-1' text='View' onClick={this.ViewClickBtn} allowDisabledFocus />

  <PrimaryButton className='assign'  text="Assign To Claim" onClick={this.open_dialog} allowDisabledFocus></PrimaryButton>
  </>: null}
 
 </div>

 


<div className='border p-3 mt-2'>
<div className='row'>
<div className='col-md-6'>
 <TextField className='w-100' label='GAP Agreement #' value={this.state.GAPAgreeNum} readOnly name='GAPAgreeNum' onChange={this.inputFormChange} />
</div>
<div className='col-md-6'>
 <TextField className='w-100' label='Gap Adjuster'  value={this.state.VSCAdj} name='VSCAdj' onChange={this.inputFormChange} />
</div>
</div>
<div className='row'>
<div className='col-md-6'>
 <TextField className='w-100' label='Claimant Last Name' readOnly value={this.state.InsuredLastName} name='InsuredLastName' onChange={this.inputFormChange} />
</div>
<div className='col-md-6'>
 <TextField className='w-100' label='First Name' readOnly value={this.state.InsuredFirstName} name='InsuredFirstName' onChange={this.inputFormChange} />
</div>
</div>
<div className='row'>
<div className='col-md-6'>
 <TextField className='w-100' label='Claimant Address' readOnly value={this.state.InsuredStreetAddress} name='InsuredStreetAddress' onChange={this.inputFormChange} />
</div>
<div className='col-md-6'>
 <TextField className='w-100' label='Claimant City' readOnly value={this.state.InsuredCity} name='InsuredCity' onChange={this.inputFormChange} />
</div>
</div>
<div className='row'>
<div className='col-md-6'>
 <TextField className='w-100' label='Claimant State' readOnly value={this.state.InsuredState} name='InsuredState' onChange={this.inputFormChange} />
</div>
<div className='col-md-6'>
 <TextField className='w-100' label='Claimant Zip' readOnly value={this.state.InsZip} name='InsZip' onChange={this.inputFormChange} />
</div>
</div>
<div className='row'>
<div className='col-md-6'><Label>Mark Delete</Label></div>
<div className='w-50 inlineflex'><ChoiceGroup 
 selectedKey={this.state.mrk_delete} 
 options={this.state.mrk_deleteChoiceArr} onClick={this.mrk_deleteRadioBtnChange} />
</div>
</div>
</div>
<div className='border p-3 mt-2'>

{this.state.SendToDefaultItems.includes(null) == true || this.state.SendToDefaultItems.includes(undefined) == true || this.state.SendToDefaultItems.includes("") == true ||((this.state.SendToText!=null || this.state.SendToText!=undefined || this.state.SendToText!="") && this.state.SendToDefaultItems.includes("") != true) ? 
  
  <div className='row'>
  <div className='col-md-6'><Label>To:</Label></div>
  <div className='w-50'><Label>{this.state.SendToText}</Label></div>

  </div>:
    <div className='row'>
<div className='col-md-6'><Label>To:</Label></div>
  <div className='w-50'><Label>
  {this.state.SendToDefaultItems.length > 0 ? this.state.SendToDefaultItems.map((team, index) =>
<span>{team}{index!=this.state.SendToDefaultItems.length-1?' , ':null}</span>):null}</Label>

    {/* <Label>{this.state.SendToDefaultItems}</Label> */}
{/* <div className='w-25'>
<PeoplePicker context ={ this.props.context} titleText = 'To'
personSelectionLimit ={ 3} showtooltip ={ true} required ={ true} disabled ={ false} ensureUser ={ true}
 onChange ={ this._getSendToPeoplePickerItems}
showHiddenInUI ={ false}
 defaultSelectedUsers ={ this.state.SendToDefaultItems}
  principalTypes ={[PrincipalType.User]} resolveDelay ={ 1000}/></div> */}
</div>
</div>
}


<div>

{this.state.CopyToDefaultItems.includes(null) == true || this.state.CopyToDefaultItems.includes(undefined) == true || this.state.CopyToDefaultItems.includes("") == true ||((this.state.CopyToText!=null || this.state.CopyToText!=undefined || this.state.CopyToText!="") && this.state.CopyToDefaultItems.includes("") != true)? 
  <div className='row'>
  
  <div className='col-md-6'><Label>Copy To:</Label></div>
  <div className='w-50'><Label>{this.state.CopyToText}</Label></div>

  </div>
  
  :
    <div className='row'>
<div className='col-md-6'><Label>Copy To:</Label></div>
{/* <div className='w-50'><Label>{this.state.CopyToDefaultItems}</Label></div> */}
<div className='w-50'><Label>
  {this.state.CopyToDefaultItems.length > 0? this.state.CopyToDefaultItems.map((team, index) =>
<span>{team}{index!=this.state.CopyToDefaultItems.length-1?' , ':null}</span>):null}</Label></div>

{/* <div className='w-25'><PeoplePicker context ={ this.props.context} titleText = 'Copy To'
personSelectionLimit ={ 3} showtooltip ={ true} required ={ true} disabled ={true} ensureUser ={ true} onChange ={ this._getCopyToPeoplePickerItems}
showHiddenInUI ={ false} defaultSelectedUsers ={ this.state.CopyToDefaultItems}  principalTypes ={[PrincipalType.User]} resolveDelay ={ 1000}/></div> */}
</div>}
</div>

<div>

  {this.state.BlindCopyToDefaultItems.includes(null) == true || this.state.BlindCopyToDefaultItems.includes(undefined) == true || this.state.BlindCopyToDefaultItems.includes("")==true ||((this.state.BlindCopyToText!=null || this.state.BlindCopyToText!=undefined || this.state.BlindCopyToText!="") && this.state.BlindCopyToDefaultItems.includes("") != true)?
  <div className='row'>
  <div className='col-md-6'><Label>Blind Copy To:</Label></div>
    <div className='w-50'><Label>{this.state.BlindCopyToText}</Label></div>
    
  
  </div>
  :
  <div className='row'>
<div className='col-md-6'><Label>Blind Copy To</Label></div>
<div className='w-50'><Label>{this.state.BlindCopyToDefaultItems.length > 0 ? this.state.BlindCopyToDefaultItems.map((team, index) =>
<span>{team}{index!=this.state.BlindCopyToDefaultItems.length-1?' , ':null}</span>):null}</Label></div>
{/* <div className='w-25'><PeoplePicker context ={ this.props.context} titleText = 'Blind Copy To'
personSelectionLimit ={ 3} showtooltip ={ true} required ={ true} disabled ={ false} ensureUser ={ true} onChange ={ this._getBlindCopyToPeoplePickerItems}
showHiddenInUI ={ false} defaultSelectedUsers ={ this.state.BlindCopyToDefaultItems} principalTypes ={[PrincipalType.User]} resolveDelay ={ 1000}/></div> */}

</div>}

</div>
  {/* {this.state.FromDefaultItems.includes(null)==true? */}
  {this.state.FromDefaultItems.includes(null) == true || this.state.FromDefaultItems.includes(undefined) == true || this.state.FromDefaultItems.includes("")==true? 
  
<div className='row'>

<div className='col-md-6'><Label>From:</Label></div>
<div className='w-50'><Label>{this.state.FromText}</Label></div></div>:
  <div className='row'>
<div className='col-md-6'><Label>From:</Label></div>
  <div className='w-50'><Label>{this.state.FromDefaultItems}</Label></div>
{/* <div className='w-25'><PeoplePicker context ={ this.props.context} titleText = 'From'
personSelectionLimit ={1} showtooltip ={ true} required ={ true} disabled ={ false} ensureUser ={ true} onChange ={ this._getFromPeoplePickerItems}
showHiddenInUI ={ false} defaultSelectedUsers ={ this.state.FromDefaultItems} principalTypes ={[PrincipalType.User]} resolveDelay ={ 1000}/></div> */}
</div>
}

  
<div className='row'>
<div className='col-md-6'><Label>Date</Label></div>
<div className='w-50'>
<Label>{this.state.Date != undefined && this.state.Date != '' && this.state.Date != null ? moment(this.state.Date).format('L hh:mm A') : null}</Label>
  {/* <DateTimePicker showLabels={false}
formatDate={onFormatDate}
dateConvention={DateConvention.Date}
 disabled={true}
value={this.state.Date} onChange={this._getDateDatePickerItems} /> */}

</div>
</div>
<div className='row'>
<div className='col-md-6'><Label>Subject</Label></div>
 <div className='w-50'><Label>{this.state.Title}</Label></div>
 {/* <TextField className='w-50' readOnly  value={this.state.Subject} name='Subject' onChange={this.inputFormChange} /> */}
</div>
</div>
<div className='border p-3 mt-2'>
<div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold w-25'>Message</Label>

{/* <SunEditor enableToolbar={true} lang='en' placeholder='Please type here...' 
setContents={this.state.Body} autoFocus={true} setOptions={{mode: 'classic', minHeight: '170px', buttonList: [
['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
['table', 'link', 'image'],],}}
onChange={this.handleRichTextChange.bind(this,'Body')}
onImageUpload={this.handleImageUpload}/> */}
<SunEditor enableToolbar={false}  lang='en' placeholder='Please type here...' 
setContents={this.state.Body} autoFocus={true} disable={true} setOptions={{mode:"classic",minHeight: '170px', buttonList: [
['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
['table', 'link', 'image'],],}}
onChange={this.handleRichTextChange.bind(this,'Body')} 
onImageUpload={this.handleImageUpload}/>
</div>
</div>
</div>

<div className='border p-3 mt-2'>
<div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold'> Attachments </Label>
<input className='ReactFieldEditor - Attachments - UploadInput'
 type='file' name='attachmentFiles' title='Attach Files' 
 aria-required='false' aria-label='Attach Files'  multiple onChange={this.handleAttachmentChange.bind(this)} />
<div>
 <div className="row">
                  <div className="col-md-12">

                    {this.state.FormAttachmentNames !== undefined &&
                    this.state.FormAttachmentNames !== null
                      ? 
                      this.state.FormAttachmentNames.map((item) => (
                     
                        <span>
                          <Link
                            key={item.FileName}
                            onClick={() =>
                              window.open(
                                item.ServerRelativePath.DecodedUrl,
                                "_blank"
                              )
                            }
                          >
                            {item.FileName}
                          
                          </Link>
                          {uniqueId == 0 ? null : (
                            <IconButton
                              className="mt-1"
                               iconProps={{ iconName: "Download" }}
                              title="Download"
                              ariaLabel="Download"
                              onClick={() =>
                                (window.location.href =
                                  this.props.context.pageContext.web
                                    .absoluteUrl +
                                  "/_layouts/download.aspx?sourceurl=" +
                                  item.ServerRelativePath.DecodedUrl)
                              }
                            />
                          )}

                          {/* <IconButton
                            className="mt-1"
                            iconProps={{ iconName: "Delete" }}
                            title="Delete"
                            ariaLabel="Delete"
                            onClick={() => this.addDeleteFiles(item.FileName)}
                          /> */}
                        </span>
                      
                      
                      
                      ))
                      // this.state.FormAttachmentNames.map((item) => (
                        
                      //     <span>
                      //       <Link
                      //         key={item.FileName}
                      //         onClick={() =>
                      //           window.open(
                      //             item.ServerRelativePath.DecodedUrl,
                      //             "_blank"
                      //           )
                      //         }
                      //       >
                      //         {item.FileName}
                      //       </Link>
                      //       {uniqueId == 0 ? null : (
                      //         <IconButton
                      //           className="mt-1"
                      //           iconProps={{ iconName: "Download" }}
                      //           title="Download"
                      //           ariaLabel="Download"
                      //           onClick={() =>
                      //             (window.location.href =
                      //               this.props.context.pageContext.web
                      //                 .absoluteUrl +
                      //               "/_layouts/download.aspx?sourceurl=" +
                      //               item.ServerRelativePath.DecodedUrl)
                      //           }
                      //         />
                      //       )}

                      //       <IconButton
                      //         className="mt-1"
                      //         iconProps={{ iconName: "Delete" }}
                      //         title="Delete"
                      //         ariaLabel="Delete"
                      //         onClick={() => this.addDeleteFiles(item.FileName)}
                      //       />
                      //     </span>
                        
                        
                        
                        // ))
                      : null}
                  </div>
                </div>

</div>
<Dropdown  

          label="Type"

          placeholder="Select an option"

          selectedKey={this.state.NotesType}

          options={this.state.PaymentTypeOptions}

          onChange={this.onPaymentTypeChange}/>
</div>
{isAssignToClaim==true?
  <Dialog  
          hidden={this.state.hideDialog}  

          onDismiss={this.Dialog_close}  

          dialogContentProps={{  

            type: DialogType.close,  

            title:<div className='border p-3' style={{backgroundColor:this.props.bannerBackground}}>

            <div className='row'>
            <div className='col-md-12'><Label><h6>SCS Claims Correspondence</h6></Label></div>
            
            </div>
            </div> 
            // subText:  

            //   'Are you sure you want to Save?', 


          }}  
          modalProps={{  

            isBlocking: false,  

            styles: { main: { maxWidth: 9000 } },  

          }} >

<div className='row'>
            <div className='col-md-9'>
 <TextField className='w-100' label='Claim Number' 
 value={this.state.GAPAgreeNumA} name='GAPAgreeNumA'  onChange={this.inputFormChange1} />
</div>
<div className='col-md-9'>
 <TextField className='w-100' label='Claimant Last Name' value={this.state.InsuredLastNameA} name='InsuredLastNameA' onChange={this.inputFormChange1} />
</div>
<div className='col-md-9'>
 <TextField className='w-100' label='First Name' value={this.state.InsuredFirstNameA}  name='InsuredFirstNameA' onChange={this.inputFormChange1} />
</div>
</div>
            <DialogFooter>  

<PrimaryButton onClick={this.Dialog_save.bind(this,"Save")} text="Save and Exit" />  

</DialogFooter>
</Dialog> 
          
  :null}
  {openDailog2 == true ?  <Dialog
  hidden={this.state.hideDialog2}  

  onDismiss={this.Dialog_close2}  

  dialogContentProps={{  

    type: DialogType.close,  

    title: ' ',
    subText:"This document content has been saved to shared folder."
  }} 
  modalProps={{  

    isBlocking: false,  

    styles: { main: { maxWidth: 450 } },  

  }}  

>  

  <DialogFooter>  

    <PrimaryButton onClick={this._close} text="Ok" />  

  </DialogFooter>  

</Dialog>:null}
 

  

</div>
</div>
 </div>}
 </div>
 
);

// {asigntoclaim ==true or false ? <Dailog></Dailog> : null}
// {isAssignToClaim==true?
  // <Dialog  
  //         hidden={this.state.hideDialog}  

  //         onDismiss={this.Dialog_save}  

  //         dialogContentProps={{  

  //           type: DialogType.close,  

  //           title: 'Delete?',  

  //           subText:  

  //             'Are you sure you want to Save?',  

  //         }}  
  //         modalProps={{  

  //           isBlocking: false,  

  //           styles: { main: { maxWidth: 450 } },  

  //         }} />  
          
  // :null}
  // <DialogFooter>  

  //           <PrimaryButton onClick={this.Dialog_save} text="Delete" />  

  //         </DialogFooter>

}}