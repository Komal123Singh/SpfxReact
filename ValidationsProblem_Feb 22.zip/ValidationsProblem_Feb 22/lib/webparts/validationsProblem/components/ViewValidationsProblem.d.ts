import * as React from 'react';
import { IValidationsProblemStates } from './IValidationsProblemStates';
export default class ViewValidationsProblem extends React.Component<IValidationsProblemStates> {
    private showReadOnlyAttachment;
    render(): JSX.Element;
}
//# sourceMappingURL=ViewValidationsProblem.d.ts.map