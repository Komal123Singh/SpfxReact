import { Dispatcher } from 'simplr-flux';
import { sp } from '@pnp/sp';
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/fields';
import '@pnp/sp/attachments';
import { SPHttpClient} from '@microsoft/sp-http';

//Get Docconfig List details
const getDocDetails = () => {
    debugger;
    sp.web.lists.getByTitle("DocConfig").items.get().then(res =>{
        console.log(res);
        Dispatcher.dispatch({ type: 'getDocTypeType', response: res});
    }).catch(error => {
      //  console.log('getDocTypeType', +error)
    })
}
export {getDocDetails}  

//Get Admin List Details
const getAdminlistDetails = async () => {
    debugger;
    await sp.web.lists.getByTitle("Admin").items.get().then(res =>{
        console.log(res);
        Dispatcher.dispatch({ type: 'getAdminvalues', response: res});
    }).catch(error => {
        console.log('getAdminvalues', +error)
    })
}
export {getAdminlistDetails}  

const getProblemlistDetails = async () => {
    debugger;
    await sp.web.lists.getByTitle("Problem").items.getAll().then(res =>{
        console.log(res);
        Dispatcher.dispatch({ type: 'getProbelmvalues', response: res});
    }).catch(error => {
        console.log('getProblemlistDetails', +error)
    })
}
export {getProblemlistDetails}  

// Get the edit click details
const getEditFormDetails = (Id) => {
    debugger;
sp.web.lists.getByTitle('Problem').items.getById(Id).select('*','AttachmentFiles',
'ActivePlayers/ID','ActivePlayers/EMail','ActivePlayers/Title',
'ApprovedBy/ID','ApprovedBy/EMail','ApprovedBy/Title',
'AssignedTo/ID','AssignedTo/EMail','AssignedTo/Title',
'ProjectManagers/ID','ProjectManagers/EMail','ProjectManagers/Title',
'SendTo/ID','SendTo/EMail','SendTo/Title',).expand('AttachmentFiles','ActivePlayers','ApprovedBy','AssignedTo','ProjectManagers','SendTo',).get().then(res => {
debugger;
console.log("Success");
    Dispatcher.dispatch({ type: 'getEditFormDetailsType', response:res});
}).catch(error => {
console.log('getEditFormDetails ' + error);
});
  }
export {getEditFormDetails};

// Get Input Details
const saveForm = (createdby, createdon, ActivePlayers,ApplicationArea,ApprovedBy,ApprovedDt,AssignedTo,AssignedDt,Comments,CreateDt,CreateTime,DateResolved,docnumber,DocType,EditHistoryFields,EnvType,EstCompDt,IONum,Keywords,PhaseDetect,PhaseIntro,Priority,Probdesc,ProjectArea,ProjectManagers,Proposedres,ReportedBy,ReptArea,ReptDt,ReptMgr,Resolution,RootCause,SendTo,Severity,Status,Suggest,TestCase,Title,Vendors,WONum,Attachments,)=> {
debugger;
sp.web.lists.getByTitle('Problem').items.add({
 'ProblemCreatedBy':createdby,
 'CreateTime':createdon,
 'ActivePlayersId': ActivePlayers.length > 0 ? ActivePlayers[0] : null,
 'ApplicationArea': ApplicationArea,
 'ApprovedById': ApprovedBy.length > 0 ? ApprovedBy[0] : null,
 'ApprovedDt':ApprovedDt,
 'AssignedToId': AssignedTo.length > 0 ? AssignedTo[0] : null,
 'AssignedDt':AssignedDt,
 'Comments': Comments,
 //'CreateDt': CreateDt,
 //'CreateTime': CreateTime,
 'DateResolved': DateResolved,
'DocNumber': docnumber,
 'DocType': DocType,
 //'EditHistoryFields': EditHistoryFields,
  'EnvType': EnvType,
 'EstCompDt': EstCompDt,
 //'IONum': IONum,
 'Keywords': Keywords,
 //'PhaseDetect': PhaseDetect,
   //'PhaseIntro': PhaseIntro,
 'Priority': Priority,
 'Probdesc': Probdesc,
 'ProjectArea': ProjectArea,
 'ProjectManagersId': ProjectManagers.length > 0 ? ProjectManagers[0] : null,
 'Proposedres': Proposedres,
 'ReportedById': ReportedBy.length>0? ReportedBy[0]:null,
 //'ReptArea': ReptArea,
 'ReptDt': ReptDt,
 //'ReptMgr': ReptMgr,
 'Resolution': Resolution,
 'RootCause': RootCause,
'SendToId': SendTo.length > 0 ? SendTo[0] : null,
 'Severity': Severity,
 'Status': Status,
 'Suggest': Suggest,
 'TestCase': TestCase,
 'Title': Title,
 'Vendors': Vendors,
 'WONum': WONum,
 
}).then(res => {

    if (res.data != undefined) {
        debugger;
        if(Attachments!=""){
            res.item.attachmentFiles.addMultiple(Attachments).then(result => {
            
                if (result != undefined) {
                    Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
                    }
            });}
        else{
           Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
        }
        
       
    
         
    }}).catch(error => {
console.log('saveForm ' + error);
});
};
export {saveForm};

// Update Existing Item
const updateForm = (toDelNames,Attachments,uniqueId,ActivePlayers,ApplicationArea,ApprovedBy,AssignedTo,Comments,CreateDt,CreateTime,DateResolved,DocNumber,DocType,EditHistoryFields,EnvType,EstCompDt,IONum,Keywords,PhaseDetect,PhaseIntro,Priority,Probdesc,ProjectArea,ProjectManagers,Proposedres,ReportedBy,ReptArea,ReptDt,ReptMgr,Resolution,RootCause,SendTo,Severity,Status,Suggest,TestCase,Title,Vendors,WONum,)=> {
sp.web.lists.getByTitle('Problem').items.getById(uniqueId).update({

'ActivePlayersId': ActivePlayers.length > 0 ? ActivePlayers[0] : null,
'ApplicationArea': ApplicationArea,
'ApprovedById': ApprovedBy.length > 0 ? ApprovedBy[0] : null,
'AssignedToId': AssignedTo.length > 0 ? AssignedTo[0] : null,
'Comments': Comments,
//'CreateDt': CreateDt,
//'CreateTime': CreateTime,
'DateResolved': DateResolved,
'DocNumber': DocNumber,
'DocType': DocType,
//'EditHistoryFields': EditHistoryFields,
'EnvType': EnvType,
'EstCompDt': EstCompDt,
//'IONum': IONum,
'Keywords': Keywords,
//'PhaseDetect': PhaseDetect,
//'PhaseIntro': PhaseIntro,
'Priority': Priority,
'Probdesc': Probdesc,
'ProjectArea': ProjectArea,
'ProjectManagersId': ProjectManagers.length > 0 ? ProjectManagers[0] : null,
'Proposedres': Proposedres,
'ReportedById': ReportedBy.length>0? ReportedBy[0]:null,
//'ReptArea': ReptArea,
'ReptDt': ReptDt,
//'ReptMgr': ReptMgr,
'Resolution': Resolution,
 'RootCause': RootCause,
'SendToId': SendTo.length > 0 ? SendTo[0] : null,
'Severity': Severity,
'Status': Status,
'Suggest': Suggest,
'TestCase': TestCase,
'Title':Title,
'Vendors': Vendors,
 'WONum': WONum,
}).then(res => {
    if (res.data != undefined) {
        debugger;
        if(toDelNames!=""){
            res.item.attachmentFiles.deleteMultiple(...toDelNames).then(resp => {
                debugger;
            if(Attachments!=""){
                res.item.attachmentFiles.addMultiple(Attachments).then(result => {
                    Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId});
                    
                })}
            else{
                Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
            }

         })}
         else if(Attachments!=""){
             debugger;
            res.item.attachmentFiles.addMultiple(Attachments).then(result => {
                Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
                
            })}
         else{
            Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
         }
        // if(Attachments!=""){
        }}).catch(error => {
console.log('updateForm ' + error);
});
  };
export {updateForm};














