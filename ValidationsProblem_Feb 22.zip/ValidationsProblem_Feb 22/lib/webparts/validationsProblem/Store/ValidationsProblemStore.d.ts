import { EventEmitter } from 'events';
declare class ValidationsProblemStore extends EventEmitter {
    constructor();
    storeChange(action: any): void;
    getEditClickStoreValue(): any[];
    getInserResultStoreValue(): any;
    getDocConfigDetails(): any[];
    getAdminDetails(): any[];
    getProblemDetails(): any[];
}
declare let objValidationsProblemStore: ValidationsProblemStore;
export default objValidationsProblemStore;
//# sourceMappingURL=ValidationsProblemStore.d.ts.map