declare interface IValidationsProblemWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  LogoUrlFieldLabel:string;
  ExitUrlFieldLabel: string;
}

declare module 'ValidationsProblemWebPartStrings' {
  const strings: IValidationsProblemWebPartStrings;
  export = strings;
}
