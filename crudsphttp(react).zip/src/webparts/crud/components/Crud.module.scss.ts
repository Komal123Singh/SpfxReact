/* tslint:disable */
require("./Crud.module.css");
const styles = {
  crud: 'crud_c20b0176',
  container: 'container_c20b0176',
  row: 'row_c20b0176',
  column: 'column_c20b0176',
  'ms-Grid': 'ms-Grid_c20b0176',
  title: 'title_c20b0176',
  subTitle: 'subTitle_c20b0176',
  description: 'description_c20b0176',
  button: 'button_c20b0176',
  label: 'label_c20b0176'
};

export default styles;
/* tslint:enable */