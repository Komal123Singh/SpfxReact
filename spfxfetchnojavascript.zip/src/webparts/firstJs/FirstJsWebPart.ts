import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';

import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';


import FirstJs from './components/FirstJs';
import { IFirstJsProps } from './components/IFirstJsProps';
import styles from './firstwebpart.module.scss';
import * as strings from 'FirstJsWebPartStrings';

export interface IFirstJsWebPartProps {
  description: string;
  
 
}

export default class FirstJsWebPart extends BaseClientSideWebPart<IFirstJsWebPartProps> {


  public Showdata=()=>{
 
     var xhttp=new XMLHttpRequest();
     var html=this.domElement;
     xhttp.onreadystatechange=function()
       {
        if(this.readyState==4 && this.status==200)
        {
          var result=JSON.parse( this.responseText);
          console.log(result.value);
           
           html.innerHTML=`<table border="2" cols="4" class="${styles.tbl}">
           <tr>
           <td>UserRole</td>
           <td>Reason For Request</td>
           <td>Location</td>
           <td>Employee Name</td>
           <td>Employee Email</td>
           <td>User ID</td>
           <td>System Name</td>
           <td>System Number</td>
           
           </tr>`
    
          result.value.forEach(item=>{
          
             html.innerHTML+=`<table border="2" cols="4" class="${styles.tbl}">
            
            <tr>     
                 <td>${item.UserRole}</td>
                 <td>${item.ReasonForRequest}</td>
                 <td>${item.Title}</td>
                 <td>${item.EmployeeName}</td>
                 <td>${item.User_x0020_ID}</td>
                 <td>${item.SystemName}</td>
                 <td>${item.SystemNumber}</td>
                 </tr>
                 `;
           });
           html.innerHTML += '</table>';
        }
      }
       xhttp.open("GET","/sites/teams/_api/web/lists/getbytitle('Spfxlist')/items",true);
       xhttp.setRequestHeader("Accept","application/json");
       xhttp.send();
     
   
  }
public Update=()=>{
  alert("clicked");
}
    public BindAllMethods=()=>{
this.domElement.querySelector('#btn').addEventListener('click',this.Showdata);
this.domElement.querySelector('#btnupdate').addEventListener('click',this.Update);
// this.domElement.querySelector('#Re').appendChild();
 };

  public render(): void {
        this.domElement.innerHTML+=`<div class="${styles.dvParent}">
       <div class="${styles.dvChild}">
       <div class="${styles.dvsubChild}">
      
        <button id ="btn" class="${styles.btn}">Showdata</button>
        </div>
    
        <div class="${styles.dvsubChild}">
        <button id ="btnupdate" class="${styles.btn}">Update</button>
        </div>
        </div>
        </div>
        </div>`;
        
        this.BindAllMethods();
  }


  //   const element: React.ReactElement<IFirstJsProps> = React.createElement(
  //     FirstJs,
  //     {
  //       description: this.properties.description
  //     }
  //   );

  //   ReactDom.render(element, this.domElement);
  // }

  // protected onDispose(): void {
  //   ReactDom.unmountComponentAtNode(this.domElement);
  //  }
  
  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
