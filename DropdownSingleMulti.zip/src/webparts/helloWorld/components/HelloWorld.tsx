import * as React from 'react';
import styles from './HelloWorld.module.scss';
import { IHelloWorldProps } from './IHelloWorldProps';
import { escape } from '@microsoft/sp-lodash-subset';

import {Operation} from '../Crud/pnpOperation';
import "@pnp/sp/lists";
import "@pnp/sp/items";
import { Web } from "@pnp/sp/presets/all";
import { Guid } from '@microsoft/sp-core-library';
import {Checkbox, Label, Dropdown,PrimaryButton, ChoiceGroup,IDropdownOption} from '@fluentui/react';

var arr = [];
export interface IHelloWorldState
{
  singleValueDropdown:string;
  multiValueDropdown:any;
}

export default class HelloWorld extends React.Component<IHelloWorldProps, IHelloWorldState,{}> {
  constructor(props)
  {
    super(props);
    this.state={
      singleValueDropdown:"",
      multiValueDropdown:[]
    };
    
  }
  
  public onDropdownChange = (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): void => {
    this.setState({ singleValueDropdown: item.key as string});
  }

  public onDropdownMultiChange = async (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): Promise<void> => {
    if (item.selected) {
      await arr.push(item.key as string);
    }
    else {
      await arr.indexOf(item.key) !== -1 && arr.splice(arr.indexOf(item.key), 1);
    }
    await this.setState({ multiValueDropdown: arr });
  }
  public  async Save(e) {
    let web = Web(this.props.context);
    await web.lists.getByTitle("Spfxlist").items.add({
      Title: Guid.newGuid().toString(),
      SingleValueDropdown: this.state.singleValueDropdown,
      MultiValueDropdown: { results: this.state.multiValueDropdown }

    }).then(i => {
      console.log(i);
    });
    alert("Submitted Successfully");
  }
  
  ///////////////////////////////////////////////////////////////////////////////
  
   /////////////////////////////////////////////////////////////////////////////////
  public render(): React.ReactElement<IHelloWorldProps> {
    
    return (
      <div className={ styles.helloWorld }>
        <div>
     
      <Dropdown
          placeholder="Single Select Dropdown..."
          selectedKey={this.state.singleValueDropdown}
          label="Single Select Dropdown"
          options={this.props.singleValueOptions}
          onChange={this.onDropdownChange}
        />
        </div>
        <div>
          
        <Dropdown
          placeholder="Multi Select Dropdown..."
          defaultSelectedKeys={this.state.multiValueDropdown}
          label="Multi Select Dropdown"
          multiSelect
          options={this.props.multiValueOptions}
          onChange={this.onDropdownMultiChange}
        />
        </div>
        <PrimaryButton onClick={e => this.Save(e)}>Submit</PrimaryButton>
      </div>
    );
  }
}
