import {EventEmitter} from 'events';
import { Dispatcher } from 'simplr-flux';


let ListChoicesStoreResp= [];
let AdminDetailsStoreResp=[];
let DefSubCatgDetailsStoreResp=[];
let DefScopeDetailsStoreResp=[];
let ListMakeDetailsStoreResp=[];
let UserGroupDetailsStoreResp=[];
let AccountNumberDetailsStoreResp=[];
let UserInfoDetailsStoreResp=[];
let sendEmailResp=[];
let ExceptionLogStoreResp=[];

let EditFormDetails = [];
let savedResult;

class ExceptionsStore extends EventEmitter {

constructor() {
super();
}

storeChange(action){
switch(action.action.type){
case 'getEditFormDetailsType':
{
EditFormDetails = action.action.response;
this.emit('getEditFormDetailschange');
break;
}
case 'insertResultType':
{
debugger;
savedResult = action.action.response;
this.emit('insertResultchange');
break;
}

case 'getListChoicesChoiceType':
{
ListChoicesStoreResp=action.action.response;
this.emit('ListChoiceschange');
break;
}
case 'getAdminDetailsType':
{
AdminDetailsStoreResp=action.action.response;
this.emit('AdminDetailsChange');
break;
}
case 'getDefSubCatgDetailsType':
{
DefSubCatgDetailsStoreResp=action.action.response;
this.emit('DefSubCatgDetailsChange');
break;
}
case 'getDefScopeDetailsType':
{
DefScopeDetailsStoreResp=action.action.response;
this.emit('DefScopeDetailsChange');
break;
}
case 'getListMakeDetailsType':
{
ListMakeDetailsStoreResp=action.action.response;
this.emit('ListMakeDetailsChange');
break;
}
case 'getUserGroupDetailsType':
{
UserGroupDetailsStoreResp=action.action.response;
this.emit('UserGroupDetailsChange');
break;
}
case 'getAccountNumberDetailsType':
{
AccountNumberDetailsStoreResp=action.action.response;
this.emit('AccountNumberDetailsChange');
break;
}
case 'getUserInfoDetailsType':
{
   UserInfoDetailsStoreResp=action.action.response;
this.emit('UserInfoDetailsChange');
break;
}
case 'sendEmailType':
{
   sendEmailResp=action.action.response;
this.emit('sendEmailChange');
break;
}
case 'insertExceptionType':
{
   ExceptionLogStoreResp=action.action.response;
this.emit('insertExceptionChange');
break;
}
}
}
getEditClickStoreValue(){
return EditFormDetails;
}
getInserResultStoreValue(){
return savedResult;
}


getListChoicesStoreValue() {
return ListChoicesStoreResp;
}

getAdminDetailsStoreValue() {
    return AdminDetailsStoreResp;
    }
 getDefSubCatgDetailsStoreValue() {
    return DefSubCatgDetailsStoreResp;
 }
 getDefScopeDetailsStoreValue() {
   return DefScopeDetailsStoreResp;
}
getListMakeDetailsStoreValue() {
   return ListMakeDetailsStoreResp;
}
getUserGroupDetailsStoreValue() {
   return UserGroupDetailsStoreResp;
}
getAccountNumberDetailsStoreValue() {
   return AccountNumberDetailsStoreResp;
}
getUserInfoDetailStoreValue() {
   return UserInfoDetailsStoreResp;
}
sendEmailStoreValue() {
   return sendEmailResp;
}
getExceptionLogStoreValue() {
   return ExceptionLogStoreResp;
}
}

let objExceptionsStore = new ExceptionsStore();

Dispatcher.register(objExceptionsStore.storeChange.bind(objExceptionsStore));

export default objExceptionsStore;