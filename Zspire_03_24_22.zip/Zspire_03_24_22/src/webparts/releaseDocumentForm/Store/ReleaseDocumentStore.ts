import { EventEmitter } from 'events';
import { Dispatcher } from 'simplr-flux';
let EditFormDetails = [];
let savedResult;
let DropdownDetails = [];
class ReleaseDocumentStore extends EventEmitter {

    constructor() {
        super();
    }
    storeChange(action) {
        switch (action.action.type) {
            case 'getEditFormDetailsType':
                {
                    EditFormDetails = action.action.response;
                    this.emit('getEditFormDetailschange');
                    break;
                }
            case 'insertResultType':
                {
                    savedResult = action.action.response;
                    this.emit('insertResultchange');
                    break;
                }
                case 'getDropdownDetailsType':
                {
                    DropdownDetails = action.action.response;
                    this.emit('DropdownDetailschange');
                    break;
                }
        }
    }
    getEditClickStoreValue() {
        return EditFormDetails;
    }
    getInserResultStoreValue() {
        return savedResult;
    } 
    getDropdownDetailsStoreValue() {
        return DropdownDetails;
   }
}

let objReleaseDocumentStore = new ReleaseDocumentStore();

Dispatcher.register(objReleaseDocumentStore.storeChange.bind(objReleaseDocumentStore));

export default objReleaseDocumentStore;

