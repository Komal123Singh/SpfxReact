import * as React from 'react';
import { MyState } from './Exceptions';
export default class ViewExceptions extends React.Component<MyState> {
    componentDidMount(): void;
    render(): JSX.Element;
}
//# sourceMappingURL=ViewExceptions.d.ts.map