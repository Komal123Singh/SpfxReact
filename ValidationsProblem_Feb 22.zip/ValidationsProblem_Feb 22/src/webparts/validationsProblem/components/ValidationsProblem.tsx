import * as React from 'react';
import { useEffect } from 'react';
import { IValidationsProblemProps } from './IValidationsProblemProps';
import { IValidationsProblemStates } from './IValidationsProblemStates';
import './ValidationsProblem.css';
import * as ValidationsProblemAction from '../Action/ValidationsProblemAction';
import ValidationsProblemStore from '../Store/ValidationsProblemStore';
import { PeoplePicker, PrincipalType } from '@pnp/spfx-controls-react/lib/PeoplePicker';
import { DateTimePicker, DateConvention, TimeConvention } from '@pnp/spfx-controls-react/lib/dateTimePicker';
import { TextField, Dropdown, Checkbox, Label, Link, ThemeProvider, createTheme, PrimaryButton, Toggle, ChoiceGroup, IconButton, IIconProps, ShimmerElementsDefaultHeights, DefaultButton } from '@fluentui/react';
import { ComboBox, IComboBox, IComboBoxOption, IComboBoxStyles, SelectableOptionMenuItemType, IButtonStyles, } from '@fluentui/react';
import { Stack } from 'office-ui-fabric-react/lib/Stack';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { SecurityTrimmedControl, PermissionLevel, } from '@pnp/spfx-controls-react/lib/SecurityTrimmedControl';
import { SPPermission } from '@microsoft/sp-page-context';
import ViewValidationsProblem from './ViewValidationsProblem';
import { Separator } from '@fluentui/react/lib/Separator';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { DropdownMenuItemType, IDropdownStyles, IDropdownOption, Icon } from '@fluentui/react';
//import './ValidationsProblemCss.css';
import moment from 'moment';
import { sp } from "@pnp/sp/presets/all";
import { Dialog, DialogType, DialogFooter } from '@fluentui/react/lib/Dialog';
import { RichText } from "@pnp/spfx-controls-react/lib/RichText";
import "@pnp/sp/webs";
import "@pnp/sp/site-users/web";
import { IStyleSet, ILabelStyles, Pivot, PivotItem } from '@fluentui/react';
import { DatePicker, defaultDatePickerStrings } from '@fluentui/react';
import SunEditor from 'suneditor-react';
import 'suneditor/dist/css/suneditor.min.css';
import strings from 'ValidationsProblemWebPartStrings';

const labelStyles: Partial<IStyleSet<ILabelStyles>> = {

  root: { marginTop: 10 },

};


// Global Variable
let absoluteUrl;
let relativeURL;
let uploadedProbdescRichTextFiles = [];
let uploadedProposedresRichTextFiles = [];
let uploadedResolutionRichTextFiles=[];
let uploadedSuggestRichTextFiles=[];
let uploadedCommentsRichTextFiles=[];

let deleteFiles = [];
let keywordsarr=[];
let envtypearr=[];
let vendorarr=[];
let rootcausearr=[];
let arr=[];
let delAttachList;
let isAdmin=false;
let isReader=false;
let isEditor=false;
let sendUpdate=false;

let user;
let updateHistory = ["DocNumber", "DocType", "Title", "TestCase", "Status", "Priority", "ProjectArea", "Severity", "Keywords", "EnvType", "ApplicationArea", "ActivePlayers", "ReportedBy", "ReptDt", "ProjectManagers", "AssignedTo", "AssignedDt", "ApprovedBy", "ApprovedDt", "DateResolved", "SendTo"];
let updateHistoryValue = '';
let HistoryStore = '';
let actionBtnClicked = '';
let uniqueId=0;

let localActivePlayersEmail=[];
let localActivePlayersID=[];
let localActivePlayersUser=[];
let localApprovedByEmail=[];
let localApprovedByID=[];
let localApprovedByUser=[];
let localAssignedToEmail=[];
let localAssignedToID=[];
let localAssignedToUser=[];
let localProjectManagersEmail=[];
let localProjectManagersID=[];
let localProjectManagersUser=[];
let localReportedByEmail=[];
let localReportedByID=[];
let localReportedByUser=[];
let localSendToEmail=[];
let localSendToID=[];
let localSendToUser=[];
let isEditMode=false;
let isViewMode=false;
let ActivePlayersHistory = [];
let ReportedByHistory = [];
let ProjectManagersHistory = [];
let AssignedToHistory = [];
let ApprovedByHistory = [];
let SendToHistory = [];
let EditFormDetails;
let CurrentloggedinUserID = [];
let CurrentloggedinUserName = [];
let createtimearray=[];

let DocConfiglistvalues;  //For DocConfig form values
let Adminlistvalues; // For Admin form values
let Problemlistvalues; //For Problem list Values
const stackTokens = { childrenGap: 3 };
const addIcon: IIconProps = { iconName: 'Add' };
const subIcon: IIconProps = { iconName: 'CalculatorMultiply' };
var XMLserialize = new XMLSerializer();
const stylesSep = {root: [{selectors: {  '::before': 
{ background: '#23366f',height: '7px' },}}]};

const dropdownStyles: Partial<IDropdownStyles> = {
  dropdownItems: { maxHeight: '130px' },
};

const myTheme = createTheme({
  palette: {
    themePrimary: '#23366f',
    themeLighterAlt: '#f3f4f9',
    themeLighter: '#cfd5e8',
    themeLight: '#a9b4d4',
    themeTertiary: '#6476a9',
    themeSecondary: '#344781',
    themeDarkAlt: '#203165',
    themeDark: '#1b2a55',
    themeDarker: '#141f3f',
    neutralLighterAlt: '#faf9f8',
    neutralLighter: '#f3f2f1',
    neutralLight: '#edebe9',
    neutralQuaternaryAlt: '#e1dfdd',
    neutralQuaternary: '#d0d0d0',
    neutralTertiaryAlt: '#c8c6c4',
    neutralTertiary: '#a19f9d',
    neutralSecondary: '#605e5c',
    neutralPrimaryAlt: '#3b3a39',
    neutralPrimary: '#323130',
    neutralDark: '#201f1e',
    black: '#000000',
    white: '#ffffff',
  }
});

const onFormatDate = (date?: Date): string => {
  return !date ? '' : date.getDate() + '/' + (date.getMonth() + 1) + '/' + (date.getFullYear() % 100);
};

const dialogContentProps = {
   type: DialogType.largeHeader,
   title: 'Confirmation',
   subText: 'Are you sure want to save?',
 };
 const dialogSavedProps = {
  type: DialogType.normal,
  title: 'SUCCESSFUL',
  closeButtonAriaLabel: 'Close',
  // subText: "",
};
 const iconStyle = {
   root: {
     color: '#107c10',
     fontSize: '50px',
   }
 };
const dialogModelContentProps = {
   type: DialogType.normal,
   title: <div className="text-center"><div><Icon styles={iconStyle} iconName="SkypeCircleCheck"></Icon></div><div>Success</div></div>,
   closeButtonAriaLabel: 'Close',
   subText: '',
 };

//Business Objects Starts //
export interface MyState 
{

}
//Business Objects End //

export default class ValidationsProblem extends React.Component<IValidationsProblemProps, IValidationsProblemStates> {
constructor(prop) {
super(prop);
this.state = {
         DocTypeChoice: [],
         PriorityChoice: [],
         SeverityChoice: [],
         JurisdictionChoice: [],
         ProjectAreaChoice: [],
         EnvironmentTypeChoice: [],
         VendorChoice: [],
         RootCauseChoice: [],
         ResponseData: [],
         createdby: null,
         createdon: null,
         FormNoteID: '',
         Date: null,
         UpdateKeywords: [],
         UpdateEnvType: [],
         UpdateRootCause: [],
         UpdateVendors: [],
         isModalClose: true,
         ishide: false,
         ProjectAreaLabel: '',
         docnumber: null,
         TitleValidations: '',
         DocTypeValidations: '',
         SeverityValidations: '',
         KeywordsValidations: '',
         ProjectAreaValidations: '',
         EnvTypeValidations: '',
         TestCaseValidations: '',
         EstCompDateValidations: '',
         isModaldialogClose: true,
           isvalidRecord: false,
           isSavedHidden:true,
FormAttachment: [],
FormAttachmentNames: [],
oldAttachments: '',
Attachments: '',
FormID: '',
ActivePlayers: [],
ActivePlayersDefaultItems: [],
ActivePlayersUserItems: [],
ApplicationArea: '',
ApprovedBy: [],
ApprovedDt: null,
ApprovedByDefaultItems: [],
ApprovedByUserItems: [],
AssignedTo: [],
AssignedDt: null,
AssignedToDefaultItems: [],
AssignedToUserItems: [],
Comments: '',
CreateDt: null,
CreateTime: '',
DateResolved: null,
AbsoluteUrl: '',
DocNumber: null,
DocType: 'Validations',
EditHistoryFields: '',
EnvType: '',
EmailIdList: [],
EstCompDt: null,
IONum: '',
Keywords: '',
PhaseDetect: '',
PhaseIntro: '',
Priority: '',
Probdesc: '',
ProjectArea: '',
ProjectManagers: [],
ProjectManagersDefaultItems: [],
ProjectManagersUserItems: [],
Proposedres: '',
ReportedBy: [],
ReportedByDefaultItems: [],
ReportedByUserItems: [],
ReptArea: '',
ReptDt: new Date(),
ReptMgr: '',
Resolution: '',
RootCause: '',
SendTo: [],
SendToDefaultItems: [],
SendToUserItems: [],
Severity: '',
Status: 'Open',
Suggest: '',
TestCase: null,
Title: '',
Vendors: '',
WONum: null,

};
absoluteUrl = this.props.context.pageContext.site.absoluteUrl;
relativeURL = this.props.context.pageContext.site.serverRelativeUrl;
SPComponentLoader.loadCss('https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
SPComponentLoader.loadCss('https://cdn.jsdelivr.net/npm/suneditor@latest/dist/css/suneditor.min.css');
SPComponentLoader.loadScript('https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js');
SPComponentLoader.loadScript('https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js');
SPComponentLoader.loadScript('https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js');
}

  componentDidMount() {
     
  try {
    const url = window.location.href;
const urlObject = new URL(url);
uniqueId = urlObject.searchParams.get('itemID')==''||urlObject.searchParams.get('itemID')==null?0:parseInt(urlObject.searchParams.get('itemID'));

    this.getDocTypeDetails();
     this.getAdminListValues();
     this.CurrentloggedinUser();
     this.getProblemListValues();
     this.getLoggedUsersGroup();
     this.getFormDefaultDetails();
     this.setState({
      AbsoluteUrl:this.props.context.pageContext.web.absoluteUrl
     });
if(uniqueId!=0)
{
  isEditMode = false;
  isViewMode = true;
  this.getEditFormDetailsComp();
  this.showResponse();
}
// else {
// this.getFormDefaultDetails();
// }
  }
  catch (e) {
  console.log('componentDidMount: ' + e);
  }
  }

  getLoggedUsersGroup = async () => {

    try {
      debugger;
      let LoggedUsersGroup = await sp.web.currentUser.groups();
      //currentUserDetails = await sp.web.currentUser();
      LoggedUsersGroup.map((groupItem) => {
        if (groupItem.Title == "USU_APPS_Validations_Admins") {
          isAdmin = true;
        } if (groupItem.Title == "USU_APPS_Validations_Editors") {
          isEditor = true;
        } if (groupItem.Title == "USU_APPS_Validations_Readers") {
          isReader = true;
        }
      });
    } catch (e) {
      console.log('getLoggedUsersGroup' + e);
    }
  }

getFormDefaultDetails = () => {
 try {
    debugger;
ValidationsProblemStore.on('insertResultchange', this.assignInsertResultStore);

} catch (e) {
console.log('getFormDefaultDetails' + e);
  }
  }

getEditFormDetailsComp = () => {
 try {
ValidationsProblemAction.getEditFormDetails(uniqueId);
ValidationsProblemStore.on('getEditFormDetailschange', this.assignEditFormDetailsStore);
} catch (e) {
console.log('EditClickBtn' + e);
  }
  }

public EditClickBtn = () => {
 try {
 isEditMode = true;
isViewMode = false;
this.getEditFormDetailsComp();
} catch (e) {
console.log('EditClickBtn' + e);
  }
  }

public ViewClickBtn = () => {
 try {
 isEditMode = false;
isViewMode = true;
this.getEditFormDetailsComp();
} catch (e) {
console.log('ViewClickBtn' + e);
  }
  }

  getDocTypeDetails = () => {
   try {
      ValidationsProblemStore.on('getDocTypechange',this.getDocTypeStore);
      ValidationsProblemAction.getDocDetails();
   }   
  catch (e) {
     //   console.log('getDocTypeDetails' + e);
      }  
}

 public getDocTypeStore =()=>{
     DocConfiglistvalues=ValidationsProblemStore.getDocConfigDetails();
     let DocTypeDropDown=[];
     DocConfiglistvalues.map((item)=>{
        DocTypeDropDown.push({ key: item.DocType, text: item.DocType, id: 'DocType'});
     });
   this.setState({
    DocTypeChoice: DocTypeDropDown.sort((a, b) => (a.key > b.key) ? 1 : -1)
   });
    console.log(this.state.DocTypeChoice);
}

public getProblemListValues = () => {
  try {
    ValidationsProblemStore.on('Problemlist', this.getProblemListValuesStore);
    ValidationsProblemAction.getProblemlistDetails();
  }
  catch (e) {
       console.log('getProblemListValues' + e);
     }
}

public getProblemListValuesStore=()=>{
  Problemlistvalues= ValidationsProblemStore.getProblemDetails();
  const lngt = Problemlistvalues.length;
  console.log(lngt);

  this.setState({ docnumber: lngt+1});
  console.log(this.state.docnumber);
}

public getAdminListValues = () => { 
  try {
     ValidationsProblemStore.on('Adminlist',this.getAdminListValuesStore);
     ValidationsProblemAction.getAdminlistDetails();
  }   
 catch (e) {
       console.log('getAdminListValues' + e);
     }  
}

public getAdminListValuesStore = () => {
  Adminlistvalues= ValidationsProblemStore.getAdminDetails();


  //Getting Priority Values from AdminList
  let PriorityDropDown=[];
  let VarPriority;
  let splitPriorityarr=[];
  VarPriority=Adminlistvalues[0].Priority;
  splitPriorityarr=VarPriority!=undefined?VarPriority.split(/[\n,;]+/):[];
  splitPriorityarr.map((item)=>{
     PriorityDropDown.push({ key: item, text: item});     
  });
  this.setState({
                 PriorityChoice:PriorityDropDown
                });
  console.log(this.state.PriorityChoice);

  //Getting Severity Values from AdminList
  let SeverityDropDown=[];
  let VarSeverity;
  let splitSeverityarr=[];
  VarSeverity=Adminlistvalues[0].Severity;
  splitSeverityarr=VarSeverity!=undefined?VarSeverity.split(/[\n,;]+/):[];
  splitSeverityarr.map((item)=>{
     SeverityDropDown.push({ key: item, text: item});
  });
  this.setState({
               SeverityChoice:SeverityDropDown
                 });
  console.log(this.state.SeverityChoice);

  //Getting Jurisdiction Values from AdminList
  let JurisdictionDropDown=[];
  let VarJurisdiction;
  let splitJurisdictionarr=[];
  VarJurisdiction=Adminlistvalues[0].Jurisdiction;
  splitJurisdictionarr=VarJurisdiction!=undefined?VarJurisdiction.split(/[\n,;]+/):[];
  splitJurisdictionarr.map((item)=>{
     JurisdictionDropDown.push({ key: item, text: item});
  });
  this.setState({
                JurisdictionChoice:JurisdictionDropDown
                });
  console.log(this.state.JurisdictionChoice);
  
  //Getting ProjectArea Values from AdminList
  let ProjectAreaDropDown=[];
  let VarProjectArea;
  let splitProjectAreaarr=[];
  VarProjectArea=Adminlistvalues[0].ProjectArea;
  splitProjectAreaarr=VarProjectArea!=undefined?VarProjectArea.split(/[\n,;]+/):[];
  splitProjectAreaarr.map((item)=>{
   ProjectAreaDropDown.push({ key: item, text: item});    
  });
  this.setState({
                ProjectAreaChoice:ProjectAreaDropDown
              });
  console.log(this.state.ProjectAreaChoice);

  //Getting EnvType Values from AdminList
  let EnvironmentTypeDropDown=[];
  let VarEnvironmentType;
  let splitEnvironmentTypearr=[];
  VarEnvironmentType=Adminlistvalues[0].EnvironmentType;
  splitEnvironmentTypearr=VarEnvironmentType!=undefined?VarEnvironmentType.split(/[\n,;]+/):[];
  splitEnvironmentTypearr.map((item)=>{
  EnvironmentTypeDropDown.push({ key: item, text: item});
  });
  this.setState({
                 EnvironmentTypeChoice:EnvironmentTypeDropDown
               });
  console.log(this.state.EnvironmentTypeChoice);
 
  //Getting Vendor Values from AdminList
  let VendorDropDown=[];
  let VarVendor;
  let splitVendorarr=[];
  VarVendor=Adminlistvalues[0].Vendors;
  splitVendorarr=VarVendor!=undefined?VarVendor.split(/[\n,;]+/):[];
  splitVendorarr.map((item)=>{
   VendorDropDown.push({ key: item, text: item});
  });
  this.setState({
             VendorChoice:VendorDropDown
             });
  console.log(this.state.VendorChoice);

  //Getting RootCause Values from AdminList
  let RootCauseDropDown=[];
  let VarRootCause;
  let splitRootCausearr=[];
  VarRootCause=Adminlistvalues[0].RootCauses;
  splitRootCausearr=VarRootCause!=undefined?VarRootCause.split(/[\n,;]+/):[];
  splitRootCausearr.map((item)=>{
   RootCauseDropDown.push({ key: item, text: item});
  });
  this.setState({
                 RootCauseChoice:RootCauseDropDown
                 });
 console.log(this.state.RootCauseChoice);
}

public CurrentloggedinUser = () => {
  debugger;
    user=this.props.context.pageContext.user.displayName;
   
   var dateTime = moment().format('L h:mm A');
   createtimearray=dateTime.split(/ (.*)/);
   const username = this.props.context.pageContext.user.email;
    sp.web.ensureUser(username).then((res)=>{
     debugger;
     let result = res;
     //let arrReptby=[];
     CurrentloggedinUserID.push(res.data.Id);
     CurrentloggedinUserName.push(res.data.Title);
     if(uniqueId==0)
      {       
    this.setState({
      createdby:user,
      createdon:dateTime,
      CreateTime:dateTime,
      ReportedBy: CurrentloggedinUserID,
      ReportedByDefaultItems: [username],
     // ApprovedBy: arrReptby,
     // ApprovedByDefaultItems: [username],
    });
  }
   });
 }
 CheckFormValidation=(actionClick)=>{
  debugger;
  try{
    
    actionBtnClicked = actionClick;
    let vartitlevalidation =((this.state.DocType == 'Validations' || this.state.DocType == 'Issues' || this.state.DocType == 'Instructions' || this.state.DocType == 'Discussion Item') && this.state.Title == '' )?this.setState({TitleValidations:'Please Enter Title'}):'';
   let vardoctypevalidation = (this.state.DocType == '')?this.setState({DocTypeValidations: 'Please Select DocType Value'}):'';
   let varseverityvalidation = (this.state.DocType == 'Validations' && this.state.Severity =='')?this.setState({ SeverityValidations: 'Please Select Risk Level Value'}):'';
  //  let varkeywordsvalidation = (this.state.DocType == 'Validations' &&  this.state.Keywords=='')?this.setState({KeywordsValidations: 'Please Select Jurisdiction Value'}):(this.state.DocType == 'Discussion Item' &&  this.state.Keywords=='')?this.setState({KeywordsValidations: 'Please Select Category Value'}):'';
   let varprojectareavalidation = ((this.state.DocType == 'Instructions' || this.state.DocType == 'Validations') && this.state.ProjectArea =='')?this.setState({ProjectAreaValidations: 'Please Select CPL Action Value'}):'';
   let varprojectareavalidation1 = (this.state.DocType =='Discussion Item'  && this.state.ProjectArea =='')?this.setState({ProjectAreaValidations: 'Please Select Product Line Value'}):'';
   let varenvtypevalidation = (this.state.DocType =='Validations'  && this.state.EnvType =='')?this.setState({EnvTypeValidations:'Please Select BU(s) Affected Value'}):'';
  let vartestcasevalidation = (this.state.DocType =='Validations' && (this.state.TestCase =='' || this.state.TestCase==null || this.state.TestCase==undefined))?this.setState({TestCaseValidations:'Please Provide Ready Date Value'}):'';
  let varestcompdtvalidation = (this.state.DocType =='Validations' && (this.state.EstCompDt =='' || this.state.EstCompDt==null || this.state.EstCompDt==undefined))?this.setState({EstCompDateValidations:'Please Provide Estimated Completion Date Value'}):'';
   
  if(vartitlevalidation!='' || vardoctypevalidation!= '' || varseverityvalidation!='' || varprojectareavalidation!=''|| varprojectareavalidation1!=''|| varenvtypevalidation!=''|| vartestcasevalidation!='' || varestcompdtvalidation!=''){
       this.setState({isvalidRecord:false});
    }
    else{
      this.modalPopupOpen(actionBtnClicked);
      this.setState({isvalidRecord:true});
    }  
  }
  catch (e) {
    console.log('checkFormValidationChange: ' + e);
  } 
  }

modalPopupOpen = (actionCall) => {

  try {
    debugger;
    actionBtnClicked = actionCall;
    if (actionBtnClicked == 'close') {
      dialogContentProps.title = 'Close Confirmation';
      dialogContentProps.subText = 'Are you sure you want to close this Form?';
    } else if (actionBtnClicked == 'saveClose') {
      dialogContentProps.title = 'Save Confirmation';
      dialogContentProps.subText = 'Do you want to save this details?';
    } else if (actionBtnClicked == 'sendupdate') {
      dialogContentProps.title = 'Send Update';
      dialogContentProps.subText = 'Do you want to send an Email Update?';
    } else if (actionBtnClicked == 'statusreopen'){
      dialogContentProps.title = 'Status Open Confirmation';
      dialogContentProps.subText = 'Do you want to open the Status?';
    }else if (actionBtnClicked == 'statusclose'){
      dialogContentProps.title = 'Status Close Confirmation';
      dialogContentProps.subText = 'Do you want to close the Status?';
    }


    this.setState({ isModalClose: false });
  } catch (e) {
    console.log('modalPopup: ' + e);
  }
}


modalPopupOpenView = (actionCall) => {

  try {
    debugger;
    actionBtnClicked = actionCall;
    if (actionBtnClicked == 'close') {
      dialogContentProps.title = 'Close Confirmation';
      dialogContentProps.subText = 'Are you sure you want to close the form?';
    }

    this.setState({ isModalClose: false });
  } catch (e) {
    console.log('modalPopup: ' + e);
  }
}

modalPopupClose = () => {
  try {
    debugger;
    this.setState({ isModalClose: true });
  } catch (e) {
    console.log('modalPopup: ' + e);
  }
}

modalSubmitClick = () => {
  try {
       debugger;
    if (actionBtnClicked == 'close') {
      this.CloseForm();
    } else if (actionBtnClicked == 'saveClose') {
         if(uniqueId == 0){
          this.insertForm();
          this.setState({ isModalClose: true });
         }else{
            ApprovedByHistory = localApprovedByUser;
            this.checkUpdateHistory();
         }   
    }else if (actionBtnClicked == 'sendupdate') {
      // alert('Update Send');
      sendUpdate=true;
     this.checkUpdateHistory();
      this.setState({ isModalClose: true });
   }else if (actionBtnClicked == 'statusreopen') {
     this.SendReopenEmail();
     
     this.setState({ isModalClose: true });
   }else if (actionBtnClicked == 'statusclose') {
     this.SendClosedEmail();
     this.setState({ isModalClose: true });
   }

  } catch (e) {
    console.log('modalSubmitClick: ' + e);
  }
}

CloseForm = () => {
  try {
    debugger;
   // exiturl = this.props.exiturl;
   this.setState({ isSavedHidden: true});
    window.location.href = this.props.exiturl;
  } catch (e) {
    console.log('CloseForm: ' + e);
  }
}

// Single Select DropDown Values Save in SP Starts

public onDocTypeDropdownChange = (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): void => {
   this.setState({ DocType: item.key as string });
  if(item.key == "Discussion Item"){
    this.setState({Status: "Discussion"});
  }
   else{
     this.setState({Status:"Open"});
   }
   this.setState({DocTypeValidations:''});
 }
 public onPriorityDropDownChange = (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): void => { 
    this.setState({ Priority: item.key as string }); 
    console.log(this.state.Priority);
 }
 public onSeverityDropDownChange = (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): void => { 
  this.setState({ Severity: item.key as string }); 
   console.log(this.state.Severity);
   this.setState({SeverityValidations:''});
}
public onProjectAreaDropDownChange = (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): void => { 
   this.setState({ ProjectArea: item.key as string }); 
   console.log(this.state.ProjectArea);
   this.setState({ProjectAreaValidations:''});
}

// Single Select DropDown Values Save in SP Ends

//Multi Select DropDown Values Save in SP Starts
public onKeywordsDropdownChange = async (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): Promise<void> => {
 debugger;
//  {this.state.UpdateKeywords!=''?this.setState({KeywordsValidations:''}):''}
  keywordsarr=this.state.UpdateKeywords;
   if (item.selected) {
      keywordsarr=[...keywordsarr, item.key as string];
     //keywordsarr.push(item.key as string);
   }
   else {
      // keywordsarr.indexOf(item.key) !== -1 && keywordsarr.splice(keywordsarr.indexOf(item.key), 1);
       keywordsarr=keywordsarr.filter(keyitem=>keyitem!==item.key);  
   }
   let text = keywordsarr.join(',');
   this.setState({ Keywords: text, UpdateKeywords:keywordsarr});
   console.log(this.state.Keywords);
  //  this.setState({KeywordsValidations:''});
 }

 public onEnvTypeDropdownChange = async (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): Promise<void> => {   
  debugger;
  envtypearr=this.state.UpdateEnvType;
    if (item.selected) {
       envtypearr=[...envtypearr, item.key as string];
       //envtypearr.push(item.key as string);
    }
    else {
      // envtypearr.indexOf(item.key) !== -1 && envtypearr.splice(envtypearr.indexOf(item.key), 1);
      envtypearr=envtypearr.filter(keyitem=>keyitem!==item.key);   
   }
    let text = envtypearr.join(',');
    this.setState({ EnvType: text , UpdateEnvType:envtypearr});
    console.log(this.state.EnvType);
    this.setState({EnvTypeValidations:''});
  }

public onVendorDropdownChange = async (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): Promise<void> => {
     vendorarr=this.state.UpdateVendors;
    if (item.selected) {
      vendorarr=[...vendorarr, item.key as string];
       //vendorarr.push(item.key as string);
    }
    else {
       //vendorarr.indexOf(item.key) !== -1 && vendorarr.splice(vendorarr.indexOf(item.key), 1);
       vendorarr=vendorarr.filter(keyitem=>keyitem!==item.key); 
      }
    let text = vendorarr.join(',');
    this.setState({ Vendors: text, UpdateVendors: vendorarr });
    console.log(this.state.Vendors);
  }

  public onRootCauseDropdownChange = async (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): Promise<void> => {
        rootcausearr=this.state.UpdateRootCause;
    if (item.selected) {
      rootcausearr=[...rootcausearr, item.key as string];
       //rootcausearr.push(item.key as string);
    }
    else {
      // rootcausearr.indexOf(item.key) !== -1 && rootcausearr.splice(rootcausearr.indexOf(item.key), 1);
      rootcausearr=rootcausearr.filter(keyitem=>keyitem!==item.key);  
   }
    let text = rootcausearr.join(',');
    this.setState({ RootCause: text, UpdateRootCause: rootcausearr });
    console.log(this.state.RootCause);
  }
 
  

public assignEditFormDetailsStore = () => {
EditFormDetails = ValidationsProblemStore.getEditClickStoreValue();
let domparser = new DOMParser();
let s = new XMLSerializer();
if (EditFormDetails.length != 0)
{

localActivePlayersEmail=[];
localActivePlayersID=[];
localActivePlayersUser=[];
if(EditFormDetails.ActivePlayers!=undefined){
localActivePlayersEmail.push(EditFormDetails.ActivePlayers.EMail);
localActivePlayersID.push(EditFormDetails.ActivePlayers.ID);
localActivePlayersUser.push(EditFormDetails.ActivePlayers.Title);
}
localApprovedByEmail=[];
localApprovedByID=[];
localApprovedByUser=[];
if(EditFormDetails.ApprovedBy!=undefined){
localApprovedByEmail.push(EditFormDetails.ApprovedBy.EMail);
localApprovedByID.push(EditFormDetails.ApprovedBy.ID);
localApprovedByUser.push(EditFormDetails.ApprovedBy.Title);
}

localAssignedToEmail=[];
localAssignedToID=[];
localAssignedToUser=[];
if(EditFormDetails.AssignedTo!=undefined){
localAssignedToEmail.push(EditFormDetails.AssignedTo.EMail);
localAssignedToID.push(EditFormDetails.AssignedTo.ID);
localAssignedToUser.push(EditFormDetails.AssignedTo.Title);
}
localProjectManagersEmail=[];
localProjectManagersID=[];
localProjectManagersUser=[];
if(EditFormDetails.ProjectManagers!=undefined){
localProjectManagersEmail.push(EditFormDetails.ProjectManagers.EMail);
localProjectManagersID.push(EditFormDetails.ProjectManagers.ID);
localProjectManagersUser.push(EditFormDetails.ProjectManagers.Title);
}
localReportedByEmail=[];
localReportedByID=[];
localReportedByUser=[];
if(EditFormDetails.ReportedBy!=undefined){
localReportedByEmail.push(EditFormDetails.ReportedBy.EMail);
localReportedByID.push(EditFormDetails.ReportedBy.ID);
localReportedByUser.push(EditFormDetails.ReportedBy.Title);
}
localSendToEmail=[];
localSendToID=[];
localSendToUser=[];
if(EditFormDetails.SendTo!=undefined){
localSendToEmail.push(EditFormDetails.SendTo.EMail);
localSendToID.push(EditFormDetails.SendTo.ID);
localSendToUser.push(EditFormDetails.SendTo.Title);
}
 let localKeywords=[];
 let Varkeywords;
 if(EditFormDetails.Keywords!=undefined){
   Varkeywords=EditFormDetails.Keywords;
   localKeywords=Varkeywords!=undefined?Varkeywords.split(/[\n,;]+/):[];
   console.log(localKeywords);
 }

 let localEnvType=[];
 let VarEnvType;
 if(EditFormDetails.EnvType!=undefined){
   VarEnvType=EditFormDetails.EnvType;
   localEnvType=VarEnvType!=undefined?VarEnvType.split(/[\n,;]+/):[];
   console.log(localEnvType);
 }

 let localVendors=[];
 let VarVendors;
 if(EditFormDetails.Vendors!=undefined){
   VarVendors=EditFormDetails.Vendors;
   localVendors=VarVendors!=undefined?VarVendors.split(/[\n,;]+/):[];
   console.log(localVendors);
 }

 let localRootCause=[];
 let VarRootCause;
 if(EditFormDetails.RootCause!=undefined){
   VarRootCause=EditFormDetails.RootCause;
   localRootCause=VarRootCause!=undefined?VarRootCause.split(/[\n,;]+/):[];
   console.log(localRootCause);
 }
  
let TempWorkFlowHistoryArr=EditFormDetails.WorkFlowHistory!=null && EditFormDetails.WorkFlowHistory!=''?EditFormDetails.WorkFlowHistory.split('\n'):[];
let TempWorkFlowJoin=TempWorkFlowHistoryArr.join('</br>');
debugger;
delAttachList=[...EditFormDetails.AttachmentFiles];
this.setState({ 
  createdby:EditFormDetails.ProblemCreatedBy,
  createdon:EditFormDetails.CreateDt,
  FormID:EditFormDetails.ID,
  FormNoteID:EditFormDetails.NoteID,
  oldAttachments:EditFormDetails.AttachmentFiles,
  ActivePlayersDefaultItems:localActivePlayersEmail,
  ActivePlayersUserItems:localActivePlayersUser,
  ActivePlayers:localActivePlayersID,
  ApplicationArea:EditFormDetails.ApplicationArea,
  ApprovedByDefaultItems:localApprovedByEmail,
  ApprovedByUserItems:localApprovedByUser,
  ApprovedBy:localApprovedByID,
ApprovedDt:EditFormDetails.ApprovedDt != null? new Date(EditFormDetails.ApprovedDt):null,
AssignedToDefaultItems:localAssignedToEmail,
AssignedToUserItems:localAssignedToUser,
AssignedTo:localAssignedToID,
AssignedDt:EditFormDetails.AssignedDt != null? new Date(EditFormDetails.AssignedDt):null,
Comments:EditFormDetails.Comments,
CreateDt:EditFormDetails.CreateDt != null? new Date(EditFormDetails.CreateDt):null,
CreateTime:EditFormDetails.CreateTime,
DateResolved:EditFormDetails.DateResolved != null? new Date(EditFormDetails.DateResolved):null,
DocNumber:EditFormDetails.DocNumber,
DocType:EditFormDetails.DocType,
EditHistoryFields:TempWorkFlowJoin,
EnvType:EditFormDetails.EnvType,
UpdateEnvType:localEnvType,
EstCompDt:EditFormDetails.EstCompDt != null? new Date(EditFormDetails.EstCompDt):null,
IONum:EditFormDetails.IONum,
Keywords:EditFormDetails.Keywords,
UpdateKeywords:localKeywords,
PhaseDetect:EditFormDetails.PhaseDetect,
PhaseIntro:EditFormDetails.PhaseIntro,
Priority:EditFormDetails.Priority,
Probdesc:EditFormDetails.Probdesc,
ProjectArea:EditFormDetails.ProjectArea,
ProjectManagersDefaultItems:localProjectManagersEmail,
ProjectManagersUserItems:localProjectManagersUser,
ProjectManagers:localProjectManagersID,
Proposedres:EditFormDetails.Proposedres,

ReportedByDefaultItems:localReportedByEmail,
ReportedByUserItems:localReportedByUser,
ReportedBy:localReportedByID,
ReptArea:EditFormDetails.ReptArea,
ReptDt:EditFormDetails.ReptDt != null? new Date(EditFormDetails.ReptDt):null,
ReptMgr:EditFormDetails.ReptMgr,
Resolution:EditFormDetails.Resolution,
RootCause:EditFormDetails.RootCause,
UpdateRootCause:localRootCause,
SendToDefaultItems:localSendToEmail,
SendToUserItems:localSendToUser,
SendTo:localSendToID,
EmailIdList:localSendToEmail,
Severity:EditFormDetails.Severity,
Status:EditFormDetails.Status,
Suggest:EditFormDetails.Suggest,
TestCase:EditFormDetails.TestCase != null? new Date(EditFormDetails.TestCase):null,
Title:EditFormDetails.Title,
Vendors:EditFormDetails.Vendors,
 UpdateVendors:localVendors,
WONum:EditFormDetails.WONum != null? new Date(EditFormDetails.WONum):null,
});
}
}



// Call action save Result method
public assignInsertResultStore = () => {
try {
  debugger;
if (ValidationsProblemStore.getInserResultStoreValue() != undefined) {
    debugger;
    const id=ValidationsProblemStore.getInserResultStoreValue();
    if(this.state.SendTo.length!=0 && uniqueId==0){

     debugger;
      this.SendEmail(id);
    }else if(this.state.SendTo.length!=0 && sendUpdate==true){
      debugger;
      this.SendEmail(id);
     }else{
      this.setState({ isSavedHidden: false});

     }

}
} catch (e) {
console.log('assignInsertResultStore: ' + e);
}
}
// Call action save method

public insertForm = () => {
  debugger;
 try {
   this.setState({ isModalClose: false });
if (uniqueId == 0) {
   debugger;
   var dateTimestamp = moment().format();
  var Rand= Math.random();
  var tempstamp=dateTimestamp+Rand;
  var stamp=tempstamp.replace('-','').replace(':','').replace('.','').replace('-','').replace(':','').replace('-','').replace(':','');

  console.log(stamp);
   updateHistoryValue = '<br/>' + moment().format('L h:mm A ') + ': Document Created by ' + this.props.context.pageContext.user.displayName + '<br/>' ; 
ValidationsProblemAction.saveForm(stamp,uploadedCommentsRichTextFiles,uploadedSuggestRichTextFiles,uploadedResolutionRichTextFiles,uploadedProposedresRichTextFiles,uploadedProbdescRichTextFiles,this.state.createdby,this.state.createdon,this.state.ActivePlayers,this.state.ApplicationArea,this.state.ApprovedBy,this.state.ApprovedDt,this.state.AssignedTo,this.state.AssignedDt,this.state.Comments,this.state.CreateDt,this.state.CreateTime,this.state.DateResolved,this.state.docnumber,this.state.DocType,updateHistoryValue,this.state.EditHistoryFields,this.state.EnvType,this.state.EstCompDt,this.state.IONum,this.state.Keywords,this.state.PhaseDetect,this.state.PhaseIntro,this.state.Priority,this.state.Probdesc,this.state.ProjectArea,this.state.ProjectManagers,this.state.Proposedres,this.state.ReportedBy,this.state.ReptArea,this.state.ReptDt,this.state.ReptMgr,this.state.Resolution,this.state.RootCause,this.state.SendTo,this.state.Severity,this.state.Status,this.state.Suggest,this.state.TestCase,this.state.Title,this.state.Vendors,this.state.WONum,this.state.Attachments,); 

}
else
{
   debugger;
   let toDelNames=[];
   if(this.state.oldAttachments.length!=delAttachList.length){
      const tokeep=[...this.state.oldAttachments];
      const final=[...delAttachList];
      for(var i=0;i<tokeep.length;i++){
        debugger;
        for(var j=0;j<delAttachList.length;j++){
          if(tokeep[i]==delAttachList[j]){
            debugger;
            final.splice(j, 1); 
            console.log('match');
          }
        }
        
      }
      
      final.map((item)=>{
        toDelNames.push(item.FileName);
      });
      console.log(toDelNames);
   }
ValidationsProblemAction.updateForm(uploadedCommentsRichTextFiles,uploadedSuggestRichTextFiles,uploadedResolutionRichTextFiles,uploadedProposedresRichTextFiles,uploadedProbdescRichTextFiles,toDelNames,this.state.Attachments,uniqueId,this.state.ActivePlayers,this.state.ApplicationArea,this.state.ApprovedBy,this.state.ApprovedDt,this.state.AssignedTo,this.state.AssignedDt,this.state.Comments,this.state.CreateDt,this.state.CreateTime,this.state.DateResolved,this.state.DocNumber,this.state.DocType, updateHistoryValue,this.state.EditHistoryFields,this.state.EnvType,this.state.EstCompDt,this.state.IONum,this.state.Keywords,this.state.PhaseDetect,this.state.PhaseIntro,this.state.Priority,this.state.Probdesc,this.state.ProjectArea,this.state.ProjectManagers,this.state.Proposedres,this.state.ReportedBy,this.state.ReptArea,this.state.ReptDt,this.state.ReptMgr,this.state.Resolution,this.state.RootCause,this.state.SendTo,this.state.Severity,this.state.Status,this.state.Suggest,this.state.TestCase,this.state.Title,this.state.Vendors,this.state.WONum,);   
}
  }
  catch (e) {
  console.log('insertForm: ' + e);
  }
  }

  checkUpdateHistory = () => {
      
    if (EditFormDetails.length != 0) {
       
      updateHistoryValue =  '<br/>' + moment().format('L h:mm A ') + ': Document changed by ' + this.props.context.pageContext.user.displayName ; 
      let isRun = false;
      updateHistory.map((fieldName, index) => {
        let fieldValue = EditFormDetails[fieldName];       
        debugger;
        this.formUpdateHistory(fieldName, fieldValue, index);
      });
      
    }
  }

  formUpdateHistory = (fieldName, fieldValue, index) => {
    
    try {
      switch (fieldName) {
        case 'DocNumber':
          {
            updateHistoryValue = this.state.DocNumber != fieldValue ? updateHistoryValue + '<br/>' + '...............[DocNumber] from "' + ((fieldValue == '' || fieldValue == undefined || fieldValue == null) ? '' : fieldValue) + '" to "' + this.state.DocNumber + '"' : updateHistoryValue;
            break;
          }
        case 'DocType':
          {
            updateHistoryValue = this.state.DocType != fieldValue ? updateHistoryValue + '<br/>' + '...............[DocType] from "' + (fieldValue == '' || fieldValue == undefined || fieldValue == null ? '' : fieldValue) + '" to "' + this.state.DocType + '"' : updateHistoryValue;
            break;
          }
        case 'Title':
          {
            updateHistoryValue = this.state.Title != fieldValue ? updateHistoryValue + '<br/>' + '...............[Title] from "' + (fieldValue == '' || fieldValue == undefined || fieldValue == null ? '' : fieldValue )+ '" to "' + this.state.Title + '"' : updateHistoryValue;

            break;
          }
        case 'TestCase':
          {
            updateHistoryValue = moment(this.state.TestCase).format('L') != moment(fieldValue).format('L') ? updateHistoryValue + '<br/>' + '...............[TestCase] from "' + (fieldValue == null || moment(fieldValue).format('L') == undefined || moment(fieldValue).format('L') == '' ? '' : moment(fieldValue).format('L')) + '" to "' + (this.state.TestCase != null? moment(this.state.TestCase).format('L'):'') + '"' : updateHistoryValue;
            break;
          }
        case 'Status':
          {
            updateHistoryValue = this.state.Status != fieldValue ? updateHistoryValue + '<br/>' + '...............[Status] from "' + (fieldValue == '' || fieldValue == undefined || fieldValue == null ? '' : fieldValue) + '" to "' + this.state.Status + '"' : updateHistoryValue;
            break;
          }
        case 'Priority':
          {
            updateHistoryValue = this.state.Priority != fieldValue ? updateHistoryValue + '<br/>' + '...............[Priority] from "' + (fieldValue == '' || fieldValue == undefined || fieldValue == null ? '' : fieldValue) + '" to "' + this.state.Priority + '"' : updateHistoryValue;
            break;
          }
        case 'ProjectArea':
          {
            updateHistoryValue = this.state.ProjectArea != fieldValue ? updateHistoryValue + '<br/>' + '...............[ProjectArea] from "' + (fieldValue == '' || fieldValue == undefined || fieldValue == null ? '' : fieldValue) + '" to "' + this.state.ProjectArea + '"' : updateHistoryValue;
            break;
          }
        case 'Severity':
          {
            updateHistoryValue = this.state.Severity != fieldValue ? updateHistoryValue + '<br/>' + '...............[Severity] from "' + (fieldValue == '' || fieldValue == undefined || fieldValue == null ? '' : fieldValue) + '" to "' + this.state.Severity + '"' : updateHistoryValue;
            break;
          }
        case 'Keywords':
          {
            updateHistoryValue = this.state.Keywords != fieldValue ? updateHistoryValue + '<br/>' + '...............[Keywords] from "' + (fieldValue == '' || fieldValue == undefined || fieldValue == null ? '' : fieldValue) + '" to "' + this.state.Keywords + '"' : updateHistoryValue;
            break;
          }
        case 'EnvType':
          {
            updateHistoryValue = this.state.EnvType != fieldValue ? updateHistoryValue + '<br/>' + '...............[EnvType] from "' + (fieldValue == '' || fieldValue == undefined || fieldValue == null ? '' : fieldValue) + '" to "' + this.state.EnvType + '"' : updateHistoryValue;
            break;
          }
        case 'ApplicationArea':
          {
            updateHistoryValue = this.state.ApplicationArea != fieldValue ? updateHistoryValue + '<br/>' + '...............[ApplicationArea] from "' + (fieldValue == '' || fieldValue == undefined || fieldValue == null ? '' : fieldValue) + '" to "' + this.state.ApplicationArea + '"' : updateHistoryValue;
            break;
          }
        case 'ActivePlayers':
          {
            if(ActivePlayersHistory.length>0){
            updateHistoryValue = ActivePlayersHistory[0] != localActivePlayersUser[0] ? updateHistoryValue + '<br/>' + '...............[ActivePlayers] from "' + (localActivePlayersUser[0] == '' || localActivePlayersUser[0] == undefined || localActivePlayersUser[0] == null ? '' : localActivePlayersUser[0]) + '" to "' + ActivePlayersHistory[0] + '"' : updateHistoryValue;
            }
            break;
            
          }
        case 'ReportedBy':
          {
            if(ReportedByHistory.length>0){
            updateHistoryValue = ReportedByHistory[0] != localReportedByUser[0] ? updateHistoryValue + '<br/>' + '...............[ReportedBy] from "' + (localReportedByUser[0] == '' || localReportedByUser[0] == undefined || localReportedByUser[0] == null ? '' : localReportedByUser[0]) + '" to "' + ReportedByHistory[0] + '"' : updateHistoryValue;
             }
            break;
          }
        case 'ReptDt':
          {
            updateHistoryValue = moment(this.state.ReptDt).format('L') != moment(fieldValue).format('L') ? updateHistoryValue + '<br/>' + '...............[ReptDt] from "' + (fieldValue == null || moment(fieldValue).format('L') == undefined || moment(fieldValue).format('L') == '' ? '' : moment(fieldValue).format('L')) + '" to "' +(this.state.ReptDt != null? moment(this.state.ReptDt).format('L'):'') + '"' : updateHistoryValue;
            break;
          }
        case 'ProjectManagers':
          {
            if(ProjectManagersHistory.length>0){
            updateHistoryValue = ProjectManagersHistory[0] != localProjectManagersUser[0] ? updateHistoryValue + '<br/>' + '...............[ProjectManagers] from "' + (localProjectManagersUser[0] == '' || localProjectManagersUser[0] == undefined || localProjectManagersUser[0] == null ? '' : localProjectManagersUser[0]) + '" to "' + ProjectManagersHistory[0] + '"' : updateHistoryValue;
             }
             break;
          }
        case 'AssignedTo':
          {
            if(AssignedToHistory.length>0){
            updateHistoryValue = AssignedToHistory[0] != localAssignedToUser[0] ? updateHistoryValue + '<br/>' + '...............[AssignedTo] from "' + (localAssignedToUser[0] == '' || localAssignedToUser[0] == undefined || localAssignedToUser[0] == null ? '' : localAssignedToUser[0]) + '" to "' + AssignedToHistory[0] + '"' : updateHistoryValue;
            }
            break;
          }
        case 'AssignedDt':
          {
            updateHistoryValue = moment(this.state.AssignedDt).format('L') != moment(fieldValue).format('L') ? updateHistoryValue + '<br/>' + '...............[AssignedDt] from "' + (fieldValue == null || moment(fieldValue).format('L') == undefined || moment(fieldValue).format('L') == '' ? '' : moment(fieldValue).format('L')) + '" to "' +(this.state.AssignedDt !=null? moment(this.state.AssignedDt).format('L'):'') + '"' : updateHistoryValue;
            break;
          }
        case 'EstCompDt':
          {
            updateHistoryValue = moment(this.state.EstCompDt).format('L') != moment(fieldValue).format('L') ? updateHistoryValue + '<br/>' + '...............[EstCompDt] from "' + (fieldValue == null || moment(fieldValue).format('L') == undefined || moment(fieldValue).format('L') == '' ? '' : moment(fieldValue).format('L')) + '" to "' +(this.state.EstCompDt != null ? moment(this.state.EstCompDt).format('L'):'') + '"' : updateHistoryValue;
            break;
          }
        case 'ApprovedBy':
          {
          updateHistoryValue = ApprovedByHistory[0] != localApprovedByUser[0] ? updateHistoryValue + '<br/>' + '...............[ApprovedBy] from "' + (localApprovedByUser[0] == '' || localApprovedByUser[0] == undefined || localApprovedByUser[0] == null ? '' : localApprovedByUser[0]) + '" to "' +  (ApprovedByHistory[0] == '' || ApprovedByHistory[0] == undefined || ApprovedByHistory[0] == null ? '' : ApprovedByHistory[0])+ '"' : updateHistoryValue;
             break;
          }
        case 'ApprovedDt':
          {
            updateHistoryValue = moment(this.state.ApprovedDt).format('L') != moment(fieldValue).format('L') ? updateHistoryValue + '<br/>' + '...............[ApprovedDt] from "' + (( fieldValue == null || moment(fieldValue).format('L') == undefined || moment(fieldValue).format('L') == '') ? '' : moment(fieldValue).format('L')) + '" to "' + (this.state.ApprovedDt != null? moment(this.state.ApprovedDt).format('L'):'') + '"' : updateHistoryValue;
            break;
          }
        case 'DateResolved':
          {
            updateHistoryValue = moment(this.state.DateResolved).format('L') != moment(fieldValue).format('L') ? updateHistoryValue + '<br/>' + '...............[DateResolved] from "' + (fieldValue == null || moment(fieldValue).format('L') == undefined || moment(fieldValue).format('L') == '' ? '' : moment(fieldValue).format('L')) + '" to "' + (this.state.DateResolved != null ?moment(this.state.DateResolved).format('L'):'') + '"' : updateHistoryValue;
            break;
          }
        case 'SendTo':
          {
            if(SendToHistory.length>0){
            updateHistoryValue = SendToHistory[0] != localSendToUser[0] ? updateHistoryValue + '<br/>' + '...............[SendTo] from "' + (localSendToUser[0] == '' || localSendToUser[0] == undefined || localSendToUser[0] == null ? '' : localSendToUser[0]) + '" to "' + SendToHistory[0] + '"' : updateHistoryValue  ;
            }
            break;
          }
      }

      if (updateHistory.length == index + 1) {
        debugger;
        updateHistoryValue=updateHistoryValue + this.state.EditHistoryFields;
        this.insertForm();
        this.setState({ isModalClose: true });
      }
    }
    catch (e) {
      console.log(e);
    }
  }
// Get Input Details
private inputFormChange = (inputValue) => {
 try {
    debugger;
 switch (inputValue.target.name) {
    

case 'ActivePlayers':
{
this.setState({ActivePlayers :inputValue.target.value});
break;
}
case 'ApplicationArea':
{
this.setState({ApplicationArea :inputValue.target.value});
break;
}
case 'ApprovedBy':
{
this.setState({ApprovedBy :inputValue.target.value});
break;
}
case 'AssignedTo':
{
this.setState({AssignedTo :inputValue.target.value});
break;
}
case 'Comments':
{
this.setState({Comments :inputValue.target.value});
break;
}
case 'CreateDt':
{
this.setState({CreateDt :inputValue.target.value});
break;
}
case 'CreateTime':
{
this.setState({CreateTime :inputValue.target.value});
break;
}
case 'DateResolved':
{
this.setState({DateResolved :inputValue.target.value});
break;
}
case 'DocNumber':
{
this.setState({DocNumber :inputValue.target.value});
break;
}
case 'DocType':
{
 this.setState({DocType :inputValue.target.value});
break;
}
case 'EditHistoryFields':
{
this.setState({EditHistoryFields :inputValue.target.value});
break;
}
case 'EnvType':
{
this.setState({EnvType :inputValue.target.value});
break;
}
case 'EstCompDt':
{
this.setState({EstCompDt :inputValue.target.value});
break;
}
case 'IONum':
{
this.setState({IONum :inputValue.target.value});
break;
}
case 'Keywords':
{
this.setState({Keywords :inputValue.target.value});
break;
}
case 'PhaseDetect':
{
this.setState({PhaseDetect :inputValue.target.value});
break;
}
case 'PhaseIntro':
{
this.setState({PhaseIntro :inputValue.target.value});
break;
}
case 'Priority':
{
this.setState({Priority :inputValue.target.value});
break;
}
case 'Probdesc':
{
this.setState({Probdesc :inputValue.target.value});
break;
}
case 'ProjectArea':
{
this.setState({ProjectArea :inputValue.target.value});
break;
}
case 'ProjectManagers':
{
this.setState({ProjectManagers :inputValue.target.value});
break;
}
case 'Proposedres':
{
this.setState({Proposedres :inputValue.target.value});
break;
}
case 'ReportedBy':
{
this.setState({ReportedBy :inputValue.target.value});
break;
}
case 'ReptArea':
{
this.setState({ReptArea :inputValue.target.value});
break;
}
case 'ReptDt':
{
this.setState({ReptDt :inputValue.target.value});
break;
}
case 'ReptMgr':
{
this.setState({ReptMgr :inputValue.target.value});
break;
}
case 'Resolution':
{
this.setState({Resolution :inputValue.target.value});
break;
}
case 'RootCause':
{
this.setState({RootCause :inputValue.target.value});
break;
}
case 'SendTo':
{
this.setState({SendTo :inputValue.target.value});
break;
}
case 'Severity':
{
this.setState({Severity :inputValue.target.value});
break;
}
case 'Status':
{
this.setState({Status :inputValue.target.value});
break;
}
case 'Suggest':
{
this.setState({Suggest :inputValue.target.value});
break;
}
case 'TestCase':
{
this.setState({TestCase :inputValue.target.value});
break;
}
case 'Title':
{
this.setState({Title :inputValue.target.value});
this.setState({TitleValidations:''});
break;
}
case 'Vendors':
{
this.setState({Vendors :inputValue.target.value});
break;
}
case 'WONum':
{
this.setState({WONum :inputValue.target.value});
break;
}
 }
  }
  catch (e) {
  console.log('inputFormChange: ' + e);
  }
  }



// Get Input RichText Details
// private handleRichTextChange = (fieldName, content) => {
//  try {
//  switch (fieldName) {

//  }
//   }
//   catch (e) {
//   console.log('handleRichTextChange: ' + e);
//   }
//   }







// Get DropDownDetails
private inputDropDownDetailsChange = (inputValue) => {
 try {
 switch (inputValue.id) {

 }
  }
  catch (e) {
  console.log('inputDropDownDetailsChange: ' + e);
  }
  }


private _getActivePlayersPeoplePickerItems = (items: any[]) => {
let peoplePickArr = [];
for (let item in items) {
peoplePickArr.push(items[item].id);
ActivePlayersHistory.push(items[item].text);
} this.setState({ ActivePlayers: peoplePickArr });
}
private _getApprovedByPeoplePickerItems = (items: any[]) => {
let peoplePickArr = [];
for (let item in items) {
peoplePickArr.push(items[item].id);
ApprovedByHistory.push(items[item].text);
} this.setState({ ApprovedBy: peoplePickArr });
}
private _getAssignedToPeoplePickerItems = (items: any[]) => {
let peoplePickArr = [];
for (let item in items) {
peoplePickArr.push(items[item].id);
AssignedToHistory.push(items[item].text);
} this.setState({ AssignedTo: peoplePickArr, AssignedDt: new Date() });
  if(this.state.AssignedTo ==[]){
    this.setState({ AssignedDt: null});
  }
}
private _getProjectManagersPeoplePickerItems = (items: any[]) => {
let peoplePickArr = [];
for (let item in items) {
peoplePickArr.push(items[item].id);
ProjectManagersHistory.push(items[item].text);
} this.setState({ ProjectManagers: peoplePickArr });
}
private _getReportedByPeoplePickerItems = (items: any[]) => {
let peoplePickArr = [];
for (let item in items) {
peoplePickArr.push(items[item].id);
ReportedByHistory.push(items[item].text);
} this.setState({ ReportedBy: peoplePickArr });
}

private _getSendToPeoplePickerItems = (items: any[]) => {
   let sendMailToArr = [];
   let emailListArr = [];
   for (let item in items) {
   debugger;
   sendMailToArr.push(items[item].id);
   emailListArr.push(items[item].secondaryText);
   SendToHistory.push(items[item].text); 
  }
   this.setState({ SendTo: sendMailToArr });
   this.setState({ EmailIdList: emailListArr });
   // console.log(emailList);
   }


private _getCreateDtDatePickerItems = (items) => {
this.setState({ CreateDt: items });
}
private _getDateResolvedDatePickerItems = (items) => {
this.setState({ DateResolved: items });
}
private _getEstCompDtDatePickerItems = (items) => {
this.setState({ EstCompDt: items });
this.setState({ EstCompDateValidations: '' });
}
private _getReptDtDatePickerItems = (items) => {
this.setState({ ReptDt: items });
}
private _getTestCaseDatePickerItems = (items) => {
this.setState({ TestCase: items });
this.setState({ TestCaseValidations: '' });
}
private _getWONumDatePickerItems = (items) => {
this.setState({ WONum: items });
}
private _getAssignedDtDatePickerItems = (items) => {
  this.setState({ AssignedDt: items });
}
private _getApprovedDtDatePickerItems = (items) => {
  this.setState({ ApprovedDt: items });
}
private onProbdescChange = (newText: string) => {
   this.setState({ Probdesc: newText });
   return newText;
 }
 private onProposedresChange = (newText: string) => {
   this.setState({ Proposedres: newText });
   return newText;
 }
 private onResolutionChange = (newText: string) => {
   this.setState({ Resolution: newText });
   return newText;
 }
 private onSuggestChange = (newText: string) => {
   this.setState({ Suggest: newText });
   return newText;
 }
 private onCommentsChange = (newText: string) => {
   this.setState({ Comments: newText });
   return newText;
 }

 public Attachment = (event) => {
   debugger;
   let fileInfos = [];
   
   for (var index=0; index<event.target.files.length;index++){
     fileInfos.push({
       name: event.target.files[index].name,
       content: event.target.files[index]
   });
   }
   
   this.setState({ Attachments:fileInfos});
   console.log(this.state.Attachments);
 }

 private handleDelete=(e)=>{
   debugger;
   const list1=[...this.state.oldAttachments];
   for(var i=0;i<list1.length;i++){
     if(list1[i].FileName==e.target.parentElement.id){
       list1.splice(i, 1); 
     }
   }
   console.log(list1);
   
   this.setState({
     oldAttachments:list1
   });
   
 }
 private selectedFiles=()=>{
  if(this.state.Attachments!=''&& this.state.Attachments.length>1){
  let file=this.state.Attachments;

  return file.map((item)=>{
     return(
     <div id={item.name}><span>{item.name}</span></div>
   );
 });

 }

}
 private showAttachment=() =>{
  //  debugger;
   try{
     if(this.state.oldAttachments.length!=0){
       console.log(this.state.oldAttachments);
       let AttachmentList=this.state.oldAttachments;
       // let AttachmentListArray=[];
       let filtereditem = AttachmentList.filter(attachmentitems =>!(attachmentitems.FileName.match(/=/g)));
       let filtereditem2 = filtereditem.filter(attachmentitems2 =>!(attachmentitems2.FileName.match(/.(jpg|jpeg|png|gif)$/i)));
       return filtereditem2.map((item)=>{
         let downloadUrl = this.props.context.pageContext.web.absoluteUrl + "/_layouts/download.aspx?sourceurl=" + item.ServerRelativeUrl;  
         return(
           <div id={item.FileName}><span><a href={downloadUrl}>{item.FileName}</a></span><Icon iconName="Delete" className='btn btn-light' onClick={(e)=>this.handleDelete(e)}/></div>
         );
       }) ;   
   }
  } catch (e){
     console.log('bindAttachment: ' + e);
   }
 }

PrintScreen = () => {
try {
window.print();
} catch (e) {
console.log('PrintScreen: ' + e);
}
}

SendClosedEmail=async ()=>{
   //from, external
   try {
    isViewMode = false;
    isEditMode= true;

      this.setState({        
         ApprovedBy: CurrentloggedinUserID,
         ApprovedByUserItems: [this.props.context.pageContext.user.displayName],
         ApprovedDt: new Date(),
         Status:"Closed",
      });
      ApprovedByHistory = CurrentloggedinUserName;
      if(this.state.DateResolved == null){
            this.setState({ DateResolved:new Date()});
         }
    
      
      console.log(this.state.EmailIdList);
      const docUrl="https://zurichinsurancenam.sharepoint.com/sites/VALIDATIONS/SitePages/ProblemForm.aspx?itemID="+uniqueId;
      let addressString: string = await sp.utility.getCurrentUserEmailAddresses();
      const emailProps= {
         To: this.state.EmailIdList,
         From:addressString,
         CC: [],
         BCC: [],
        // Subject:  "Update for " + this.state.DocType+ " # " + this.state.DocNumber+ " - " + this.state.Title,
        Subject:   this.state.DocType+ " Has Been Closed for " + this.state.ProjectArea + " Document ID: "  + this.state.docnumber+ " - " + this.state.Title, 
        Body: "Click the link to open the document - <b><a href='"+docUrl+"'>Document</a></b>",
         AdditionalHeaders: {
             "content-type": "text/html"
         }
     };
     if(this.state.EmailIdList.length!=0){
      await sp.utility.sendEmail(emailProps).then((res)=>{
        if(res!=undefined){
          this.checkUpdateHistory();
        }
      });
     } else {
       this.checkUpdateHistory();
     }
    
     console.log("Email Sent!");
      } catch (e) {
      console.log(e);
      }
  
}
SendReopenEmail=async ()=>{
   //from, external
   try {
    isViewMode = false;
    isEditMode= true;
      this.setState({
        ApprovedBy: [],
        ApprovedDt: null,
         Status:"Open"
      });
      console.log(this.state.EmailIdList);
      const docUrl="https://zurichinsurancenam.sharepoint.com/sites/VALIDATIONS/SitePages/ProblemForm.aspx?itemID="+uniqueId;
      let addressString: string = await sp.utility.getCurrentUserEmailAddresses();
      const emailProps= {
         To: this.state.EmailIdList,
         From:addressString,
         CC: [],
         BCC: [],
         //Subject:  "Update for " + this.state.DocType+ " # " + this.state.DocNumber+ " - " + this.state.Title,
         Subject:   this.state.DocType+ " Has Been Reopened for " + this.state.ProjectArea + " Document ID: "  + this.state.docnumber+ " - " + this.state.Title,
         Body: "Click the link to open the document -<b><a href='"+docUrl+"'>Document</a></b>",
         AdditionalHeaders: {
             "content-type": "text/html"
         }
     };
     
    //  await sp.utility.sendEmail(emailProps).then((res)=>{
    //   if(res!=undefined){
    //     this.checkUpdateHistory();
    //   }
    // });
    if(this.state.EmailIdList.length!=0){
      await sp.utility.sendEmail(emailProps).then((res)=>{
        if(res!=undefined){
          this.checkUpdateHistory();
        }
      });
     } else {
       this.checkUpdateHistory();
     }
     console.log("Email Sent!");
      } catch (e) {
      console.log(e);
      }
  
}

SendEmail = async (id) => {
  debugger;
   //from, external
   try {
      if(uniqueId==0){
        // const receipent=this.state.EmailIdList
        console.log(this.state.EmailIdList);
        const docUrl="https://zurichinsurancenam.sharepoint.com/sites/VALIDATIONS/SitePages/ProblemForm.aspx?itemID="+id;
        let addressString: string = await sp.utility.getCurrentUserEmailAddresses();
        const emailProps= {
           To: this.state.EmailIdList,
           From:addressString,
           CC: [],
           BCC: [],
           Subject:  " New " + this.state.DocType+ " for " + this.state.ProjectArea + " Document ID: "  + this.state.docnumber+ " - " + this.state.Title,
           Body: "Click the link to open the document -<b><a href='"+docUrl+"'>Document</a></b>",
           AdditionalHeaders: {
               "content-type": "text/html"
           }
       };
       
      const Email = await sp.utility.sendEmail(emailProps).then((res)=>{
        if(res!=undefined){
          this.setState({ isSavedHidden: false});
        }
      });
      }else{
        // const receipent=this.state.SendTo
        // console.log(this.state.EmailIdList);
        const docUrl="https://zurichinsurancenam.sharepoint.com/sites/VALIDATIONS/SitePages/ProblemForm.aspx?itemID="+uniqueId;
        let addressString: string = await sp.utility.getCurrentUserEmailAddresses();
        debugger;
        const emailProps= {
          
           To: this.state.SendToDefaultItems,
           From:addressString,
           CC: [],
           BCC: [],
           Subject:  "Update for " + this.state.DocType+ " # " + this.state.DocNumber+ " - " + this.state.Title,
           Body: "Click the link to open the document -<b><a href='"+docUrl+"'>Document</a></b>",
           AdditionalHeaders: {
               "content-type": "text/html"
           }
       };
       
      const Email = await sp.utility.sendEmail(emailProps).then((res)=>{
        if(res!=undefined){
          this.setState({ isSavedHidden: false});
        }
      });

      }
      
      
     
     console.log("Email Sent!");
      } catch (e) {
      console.log(e);
      }
}

createNewResponse=()=>{
  window.location.assign('https://zurichinsurancenam.sharepoint.com/sites/VALIDATIONS/SitePages/ResponseForm.aspx?itemID='+this.state.FormID);
}

showResponse=async()=>{

  // let stamp=new Date();
  // var dateTime = moment().format('L h:mm');
  

    
    await sp.web.lists.getByTitle("Response").items.getAll().then(res => {
      debugger;
      // console.log(res);
      let matcharray=[];
      
      res.map((item)=>{
        // const dig=(item.ParentUNID).localeCompare(this.state.FormNoteID);
        // if(dig==0){
          if(item.ParentUNID==this.state.FormNoteID){
            debugger;
            matcharray.push({'Date':item.Date,'ParentUNID':item.ParentUNID,'SharePointID':item.ID, 'ResTitle':item.Title});
        }
      });
      
      
      console.log(matcharray);
      this.dataFormResponse(matcharray);
    }).catch(error => {
      console.log(error);
    });
  
}
dataFormResponse=(matcharray)=>{
  if(matcharray.length!=0){
    this.setState({
      ResponseData:matcharray
    });
  }
}
showResponseList=()=>{
  
  return this.state.ResponseData.map((item)=>{
    return (
      <div className='row border'>
        <div className='col-md-2'>   
        
        <a href={'https://zurichinsurancenam.sharepoint.com/sites/VALIDATIONS/SitePages/ResponseForm.aspx?resID='+item.SharePointID+'&itemID='+uniqueId}><Icon iconName="EditSolid12" className='btn btn-light'/></a>     
        </div>   
        <div className='col-md-2'>        
        {moment(item.Date).format('L')}
        </div>
        <div className='col-md-2'>        
        {item.ResTitle}
         </div>   
      </div>
    );
  });

}


handleRichTextChange = (fieldName, content) => {
  debugger;
  try {
    switch (fieldName) {
       
      case 'Probdesc':
        this.setState({ Probdesc: content });
        break;
      case 'Proposedres':
          this.setState({ Proposedres: content });
          break;
      case 'Resolution':
          this.setState({ Resolution: content });
          break;
      case 'Suggest':
          this.setState({ Suggest: content });
          break;
      case 'Comments':
          this.setState({ Comments: content });
          break;
          
    }
  }
  catch (e) {
    console.log('handleRichTextChange: ' + e);
  }
}

handleCommentsImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {
  debugger;
  if (imageInfo != null) {
    let files = uploadedCommentsRichTextFiles;
    let dataURI = imageInfo.src;
    let fileName = imageInfo.name;
    if (dataURI.split(',')[0].indexOf('base64') >= 0) {
      var arr = dataURI.split(','),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]),
        n = bstr.length,
        u8arr = new Uint8Array(n);
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
      }
      const file = new File([u8arr], fileName, { type: mime });
      let fExists = files.some((f) => f['name'] === file['name']);
      if (!fExists) {
        files.push(file);
      }
      uploadedCommentsRichTextFiles = files;
    }
  }
}

handleSuggestImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {
  debugger;
  if (imageInfo != null) {
    let files = uploadedSuggestRichTextFiles;
    let dataURI = imageInfo.src;
    let fileName = imageInfo.name;
    if (dataURI.split(',')[0].indexOf('base64') >= 0) {
      var arr = dataURI.split(','),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]),
        n = bstr.length,
        u8arr = new Uint8Array(n);
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
      }
      const file = new File([u8arr], fileName, { type: mime });
      let fExists = files.some((f) => f['name'] === file['name']);
      if (!fExists) {
        files.push(file);
      }
      uploadedSuggestRichTextFiles = files;
    }
  }
}
handleResolutionImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {
  debugger;
  if (imageInfo != null) {
    let files = uploadedResolutionRichTextFiles;
    let dataURI = imageInfo.src;
    let fileName = imageInfo.name;
    if (dataURI.split(',')[0].indexOf('base64') >= 0) {
      var arr = dataURI.split(','),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]),
        n = bstr.length,
        u8arr = new Uint8Array(n);
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
      }
      const file = new File([u8arr], fileName, { type: mime });
      let fExists = files.some((f) => f['name'] === file['name']);
      if (!fExists) {
        files.push(file);
      }
      uploadedResolutionRichTextFiles = files;
    }
  }
}

handleProposedresImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {
  debugger;
  if (imageInfo != null) {
    let files = uploadedProposedresRichTextFiles;
    let dataURI = imageInfo.src;
    let fileName = imageInfo.name;
    if (dataURI.split(',')[0].indexOf('base64') >= 0) {
      var arr = dataURI.split(','),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]),
        n = bstr.length,
        u8arr = new Uint8Array(n);
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
      }
      const file = new File([u8arr], fileName, { type: mime });
      let fExists = files.some((f) => f['name'] === file['name']);
      if (!fExists) {
        files.push(file);
      }
      uploadedProposedresRichTextFiles = files;
    }
  }
}

handleProbdescImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {
  debugger;
  if (imageInfo != null) {
    let files = uploadedProbdescRichTextFiles;
    let dataURI = imageInfo.src;
    let fileName = imageInfo.name;
    if (dataURI.split(',')[0].indexOf('base64') >= 0) {
      var arr = dataURI.split(','),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]),
        n = bstr.length,
        u8arr = new Uint8Array(n);
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
      }
      const file = new File([u8arr], fileName, { type: mime });
      let fExists = files.some((f) => f['name'] === file['name']);
      if (!fExists) {
        files.push(file);
      }
      uploadedProbdescRichTextFiles = files;
    }
  }
}


//Render Method //
public render(): React.ReactElement<IValidationsProblemProps> {
   
return (
  <ThemeProvider theme={myTheme}>
        <div className='container'>
          <div className='border p-3' style={{ backgroundColor: '#23366f' }}>
            <div className='row'>
              <div className='col-md-6'><h3 className="text-light ">{this.props.description} - {this.state.DocType} </h3></div>
              <div className='col-md-6 text-right'><img src={this.props.logourl} alt='Logo' width='50' height='50' /></div>
            </div>
            
          </div>
        

 
 {/* <PrimaryButton className='ml-1' text='Email' onClick={this.SendEmail} allowDisabledFocus/> */}
 
 {/* {isViewMode == true ?  */}
 <div>
 <div className='buttonCls container mt-2'>
<div className='row'>
 {isEditMode == true || uniqueId == 0? null:<PrimaryButton className='ml-1' text='Exit'  onClick={this.modalPopupOpen.bind(this, 'close')} allowDisabledFocus />}

 {isEditMode == true || uniqueId == 0?null:
    
      (isAdmin|| isEditor || user == this.state.createdby)?<PrimaryButton className='ml-1' text='Edit' onClick={this.EditClickBtn} allowDisabledFocus />:null
      }

 
 {isAdmin && isViewMode == true?
 <PrimaryButton className='ml-1' text='Response' onClick={this.createNewResponse} allowDisabledFocus/>
 :null}
 
 </div>
 </div>
 </div>

 
 {isViewMode == true && isEditMode == false? 
 <div>

 <Separator styles={stylesSep}></Separator>
 <Pivot aria-label="Problem">
<PivotItem
  headerText="Problem"

  headerButtonProps={{
    'data-order': 1,
    'data-title': 'Problem',
  }}
>
  <Label styles={labelStyles} >
  <ViewValidationsProblem {...this.state}/>
  </Label>

</PivotItem>

<PivotItem headerText="Response List">

  <Label styles={labelStyles}><div className='table table-hover'>
   <div className='row '>
    <th className='col-md-2'>
    Action
    </th>
    <th className='col-md-2'>
    Created on
    </th>
    <th className='col-md-2'>
    Response Title
    </th>
   </div>
     {this.showResponseList()}
      </div></Label>
    </PivotItem>
        {this.state.DocType == 'Discussion Item'?null :
           <PivotItem
                  headerText="History"
                  headerButtonProps={{
                    'data-order': 1,
                    'data-title': 'Problem',
                  }}>
                  <Label styles={labelStyles} >
                    <div dangerouslySetInnerHTML={{ __html: this.state.EditHistoryFields }} />
                  </Label>
                </PivotItem>
          }  
</Pivot>
 </div>: 
 <div>
 <div className='buttonCls mt-1'> 
 <PrimaryButton className='' text='Exit'  onClick={this.modalPopupOpen.bind(this, 'close')} allowDisabledFocus />
 {/* {isEditMode == true  ? <PrimaryButton className='ml-1' text='View' onClick={this.ViewClickBtn} allowDisabledFocus />: null} */}
 <PrimaryButton className='ml-1' text='Save & Exit' onClick={this.CheckFormValidation.bind(this, 'saveClose')}  allowDisabledFocus />

 {(this.state.Status== 'Closed' && isEditMode == true )?
   ((this.state.ApprovedBy == null || this.state.DocType== "Discussion Item" || uniqueId == 0 || isEditor == false))?null: <PrimaryButton className='ml-1' text='Reopen' onClick={this.modalPopupOpen.bind(this, 'statusreopen')} allowDisabledFocus/>
 :null}
 
 

 {/* { this.state.ApprovedBy == null || this.state.DocType == "Discussion Item" || isEditor ==false || isAdmin ==false ? null : <PrimaryButton className='ml-1' text='Reopen' onClick={this.modalPopupOpen.bind(this, 'statusreopen')} allowDisabledFocus/>} */}

{(this.state.Status== 'Open' && isEditMode == true )?
 ((this.state.ApprovedBy! == null || this.state.DocType== "Discussion Item" || uniqueId == 0 || isEditor == false || isAdmin == false))?null: <PrimaryButton className='ml-1' text='Closed' onClick={this.modalPopupOpen.bind(this, 'statusclose')} allowDisabledFocus/>
 :null}
 
 {(this.state.SendTo == '' || uniqueId == 0) ? null:<PrimaryButton className='ml-1' text='Send Update' onClick={this.modalPopupOpen.bind(this, 'sendupdate')} allowDisabledFocus/>}
 </div>

<div className='border p-3 mt-2'>
<div className='row'>
<div className='col-md-12'>
<div className='w-100'>Created by {this.state.createdby} on {createtimearray[0]} at {createtimearray[1]+createtimearray[2]}</div>
 
</div>
</div>
<div className='row'>
<div className='col-md-6'>
 <Dropdown  
   label='Document Type' 
   placeholder="Select an option" 
   errorMessage={this.state.DocTypeValidations}
   selectedKey={this.state.DocType} 
   options={this.state.DocTypeChoice}   
   onChange={this.onDocTypeDropdownChange} />
</div>
{(this.state.ishide)?
<div className='col-md-6'>
 <TextField className='w-100' label='IO#' value={this.state.IONum} name='IONum' onChange={this.inputFormChange} />
</div>
:null}

</div>
<div className='row'>
<div className='col-md-6'>
 <TextField className='w-100' label='Title' placeholder='Enter Title' value={this.state.Title} name='Title' errorMessage={this.state.TitleValidations} onChange={this.inputFormChange} />
</div>
<div className='col-md-6'>
 <TextField className='w-100' disabled label='Document ID' value={this.state.DocNumber} name='DocNumber' onChange={this.inputFormChange} />
</div>
</div>
<div className='row'>
{(this.state.ishide)?
<div className='col-md-6'>
 <TextField className='w-100' label='Reporting Area' value={this.state.ReptArea} name='ReptArea' onChange={this.inputFormChange} />
</div>
:null}
{(this.state.ishide)?
<div className='col-md-6'>
 <TextField className='w-100' label='Reporting Manager' value={this.state.ReptMgr} name='ReptMgr' onChange={this.inputFormChange} />
</div>
:null}
</div>
<div className='row'>
<div className='col-md-6'>
<TextField className='w-100' label='Status' readOnly  value ={this.state.Status}  name='Status' onChange={this.inputFormChange} />
</div>
{(this.state.DocType == 'Validations' || this.state.DocType == 'Issues')?
     <div className='col-md-6'>       
          <Dropdown  
          label={(this.state.DocType == 'Validations')?"Result Ranking":"Priority"}
          placeholder="Select an option" 
          selectedKey={this.state.Priority} 
          options={this.state.PriorityChoice} 
          onChange={this.onPriorityDropDownChange}/>
</div>
:null}
</div>
<div className='row'>
{(this.state.DocType == 'Validations' || this.state.DocType == 'Issues')?
    <div className='col-md-6'>
      {/* {(this.state.DocType == 'Validations')?} 
           */}
            <Dropdown  
            label={(this.state.DocType == 'Validations')?"Risk Level":"Severity"}
            placeholder="Select an option" 
            errorMessage={this.state.SeverityValidations}
            selectedKey={this.state.Severity} 
            options={this.state.SeverityChoice} 
            onChange={this.onSeverityDropDownChange}/>
     </div>
:null}
{(this.state.DocType == 'Validations' || this.state.DocType == 'Issues' || this.state.DocType == 'Discussion Item')?
<div className='col-md-6'>
       <Dropdown  
        placeholder="Select options"
         selectedKeys={this.state.UpdateKeywords}
        //defaultSelectedKeys={this.state.UpdateKeywords}
        // errorMessage={this.state.KeywordsValidations}
        styles={dropdownStyles}
        label={(this.state.DocType =='Issues' || this.state.DocType =='Discussion Item')?"Category":"Jurisdiction"}
        multiSelect
        options={this.state.JurisdictionChoice}
        onChange={this.onKeywordsDropdownChange }/>
</div>
:null}
</div>
<div className='row'>
<div className='col-md-6'>
       <Dropdown  
          label={(this.state.DocType =='Discussion Item')?"Product Line":(this.state.DocType =='Issues')?"Project Area":"CPL Action"}
          placeholder="Select an option" 
          selectedKey={this.state.ProjectArea} 
          errorMessage={this.state.ProjectAreaValidations}
          options={this.state.ProjectAreaChoice} 
          onChange={this.onProjectAreaDropDownChange}/>
</div>
{this.state.DocType == 'Issues'?
<div className='col-md-6'>
 <TextField className='w-100' label='ApplicationArea' value={this.state.ApplicationArea} name='ApplicationArea' onChange={this.inputFormChange} />
</div>
:null}
</div>
<div className='row'>
{(this.state.DocType == 'Validations' || this.state.DocType == 'Issues')?
<div className='col-md-6'>
      <Dropdown  
       placeholder="Select options"
       selectedKeys={this.state.UpdateEnvType} //defaultSelectedKeys={this.state.UpdateEnvType}
       label={(this.state.DocType == 'Validations')?"BU(s) Affected":"Environment Type"}
       errorMessage={this.state.EnvTypeValidations}
       multiSelect
      options={this.state.EnvironmentTypeChoice}
      onChange={this.onEnvTypeDropdownChange }
      />    
</div>
:null}
{(this.state.DocType == 'Validations' || this.state.DocType == 'Issues')?
<div className='col-md-6'>
<div className='w-100'>
      <DatePicker
        label={(this.state.DocType == 'Validations')?"Ready date":"Test Case #"}
        placeholder="Select a date..."
        ariaLabel="Select a date"
        value={this.state.TestCase}
        formatDate={onFormatDate}
        textField={{errorMessage:this.state.TestCaseValidations}}  
        onSelectDate={this._getTestCaseDatePickerItems}/> 
    </div>
</div>
:null}
</div>
<div className='row'>
{(this.state.DocType == 'Issues')?
<div className='col-md-6'>
 <div className='w-100'><PeoplePicker context ={ this.props.context} titleText = 'Participants'
personSelectionLimit ={1} showtooltip ={ true}  disabled ={ false} ensureUser ={ true} onChange ={ this._getActivePlayersPeoplePickerItems}
showHiddenInUI ={ false} defaultSelectedUsers ={ this.state.ActivePlayersDefaultItems} principalTypes ={[PrincipalType.User]} resolveDelay ={ 1000}/></div>
</div> 
:null}
{(this.state.DocType == 'Issues')?
<div className='col-md-6'>
<div className='w-100'><PeoplePicker context ={ this.props.context} titleText = 'ProjectManagers'
personSelectionLimit ={1} showtooltip ={ true}  disabled ={ false} ensureUser ={ true} onChange ={ this._getProjectManagersPeoplePickerItems}
showHiddenInUI ={ false} defaultSelectedUsers ={ this.state.ProjectManagersDefaultItems} principalTypes ={[PrincipalType.User]} resolveDelay ={ 1000}/></div>
</div>
:null}
</div>
<div className='row'>
{(this.state.DocType == 'Validations' || this.state.DocType == 'Issues')?
<div className='col-md-6'>
 {/* <TextField className='w-100' label='ReportedBy' value={this.state.createdby} name='ReportedBy' onChange={this.inputFormChange} /> */}
<div className='w-100'><PeoplePicker context ={ this.props.context} titleText = {this.state.DocType == 'Validations'?'Record Created By':'Reported By'}
personSelectionLimit ={1} showtooltip ={ true}  disabled ={ false} ensureUser ={ true} onChange ={ this._getReportedByPeoplePickerItems}
showHiddenInUI ={ false} defaultSelectedUsers ={ this.state.ReportedByDefaultItems} principalTypes ={[PrincipalType.User]} resolveDelay ={ 1000}/></div>
</div>
:null}
{(this.state.DocType == 'Validations' || this.state.DocType == 'Issues')?
<div className='col-md-6'>
     <div className='w-100'>  
       <DatePicker
        label={(this.state.DocType == 'Validations')?"Date Created":"Date Reported"}
        placeholder="Select a date..."
        ariaLabel="Select a date"
        value={this.state.ReptDt}
        formatDate={onFormatDate}
        onSelectDate={this._getReptDtDatePickerItems}/>
    </div>
    {/* <TextField className='w-100' label={(this.state.DocType == 'Validations')?"Date Created":"Date Reported"} value={moment(this.state.ReptDt).format('L')}  onChange={this.inputFormChange} /> */}
</div>
:null}
</div>
<div className='row'>
{(this.state.ishide)?
<div className='col-md-6'>
 <TextField className='w-100' label='PhaseDetect' value={this.state.PhaseDetect} name='PhaseDetect' onChange={this.inputFormChange} />
</div>
:null}
{(this.state.ishide)?
<div className='col-md-6'>
 <TextField className='w-100' label='PhaseIntro' value={this.state.PhaseIntro} name='PhaseIntro' onChange={this.inputFormChange} />
</div>
:null}
</div>
<div className='row'>
{(this.state.DocType == 'Validations')?
<div className='col-md-6'>
 
      <Dropdown  
         placeholder="Select options"
         selectedKeys={this.state.UpdateVendors} //defaultSelectedKeys={this.state.UpdateVendors}
         label='LOB(s) Affected'   //label="Vendor"
         multiSelect
        options={this.state.VendorChoice}
        onChange={this.onVendorDropdownChange}
        />
</div>
:null}
{(this.state.DocType == 'Validations')?
<div className='col-md-6'>    
       <div className='w-100'>
               <DatePicker
                 label='Val Completion Date'
                 placeholder="Select a date..."
                 ariaLabel="Select a date"
                 value={this.state.WONum}     
                 formatDate={onFormatDate}
               onSelectDate={this._getWONumDatePickerItems}/> 
            </div>
</div>
:null}
</div>
<div className='row'>
   {(this.state.DocType == 'Validations')?
    <div className='col-md-6'>
        <Dropdown  
         placeholder="Select options"
         selectedKeys={this.state.UpdateRootCause} //defaultSelectedKeys={this.state.UpdateRootCause} 
         label="Ins. Categories"  //label="RootCause"
         multiSelect
        options={this.state.RootCauseChoice}
        onChange={this.onRootCauseDropdownChange}
        />
     </div>
    :null}
</div>
<div className='row'>
{(this.state.DocType == 'Issues')?
<div className='col-md-6'>
<div className='w-100'><PeoplePicker context ={ this.props.context} titleText = 'Assigned To'
personSelectionLimit ={1} showtooltip ={ true}  disabled ={ false} ensureUser ={ true} onChange ={ this._getAssignedToPeoplePickerItems}
showHiddenInUI ={ false} defaultSelectedUsers ={ this.state.AssignedToDefaultItems} principalTypes ={[PrincipalType.User]} resolveDelay ={ 1000}/></div>
</div>
:null}
{(this.state.DocType == 'Issues')?
<div className='col-md-6'>
<div className='w-100'>
      {/* <DatePicker
        label="Date Assigned"
        placeholder="Select a date..."
        ariaLabel="Select a date"
        value={this.state.AssignedDt}
        formatDate={onFormatDate}
        onSelectDate={this._getAssignedDtDatePickerItems}/> */}

        <Label>Date Assigned</Label>
           {this.state.AssignedTo != ''?
             <TextField className='w-100' value={moment(this.state.AssignedDt).format('L')}  onChange={this.inputFormChange} />
         :null}
    </div>
</div>
:null}

</div>




<div className='row'>
{(this.state.DocType == 'Validations' || this.state.DocType == 'Issues')?
  <div className='col-md-6'>
     <div className='w-100'>
          <DatePicker
           label={(this.state.DocType == 'Validations')?"Estimated Completion Date":"Est Comp Date"}
           placeholder="Select a date..."
           ariaLabel="Select a date"
           value={this.state.EstCompDt} 
           formatDate={onFormatDate}
           textField={{errorMessage:this.state.EstCompDateValidations}}  
           onSelectDate={this._getEstCompDtDatePickerItems}/>        
    </div>
   </div>
:null}
{(this.state.DocType == 'Validations' || this.state.DocType == 'Issues')?
<div className='col-md-6'>
     <div className='w-100'>
        <DatePicker
           label={(this.state.DocType == 'Validations')?"Re-Val/Final Completion Date":"Date Resolved"}
           placeholder="Select a date..."
           ariaLabel="Select a date"
           value={this.state.DateResolved}
           formatDate={onFormatDate}    
           onSelectDate={this._getDateResolvedDatePickerItems}/>  
      </div>
</div>
:null}
</div>
{(this.state.DocType == 'Validations' || this.state.DocType == 'Issues')?
<div className='row'>
{this.state.Status == 'Closed'?
<div className='col-md-6'>
<div className='w-100'>
  {/* <PeoplePicker context ={ this.props.context} titleText = 'Closed By'
personSelectionLimit ={1} showtooltip ={ true}  disabled ={ false} ensureUser ={ true} onChange ={ this._getApprovedByPeoplePickerItems}
showHiddenInUI ={ false} defaultSelectedUsers ={ this.state.ApprovedByDefaultItems} principalTypes ={[PrincipalType.User]} resolveDelay ={ 1000}/> */}


<Label> Closed By </Label>
{this.state.ApprovedByUserItems.length > 0 ? this.state.ApprovedByUserItems.map((team, index) =>
<span>{team}</span>
):null}
 
</div> 
</div>
:null}
{this.state.Status == 'Closed'?
<div className='col-md-6'>
<div className='w-100'>
      {/* <DatePicker
        label="Closed Date"
        placeholder="Select a date..."
        ariaLabel="Select a date"
        value={this.state.ApprovedDt}
        formatDate={onFormatDate}
        onSelectDate={this._getApprovedDtDatePickerItems}/> */}
{/* <TextField className='w-100' label='Closed Date' value={moment(this.state.ApprovedDt).format('L')}  onChange={this.inputFormChange} /> */}

<Label> Closed Date </Label>
{this.state.ApprovedDt!=undefined&&this.state.ApprovedDt!=''&&this.state.ApprovedDt!=null?moment(this.state.ApprovedDt.toUTCString()).format('L'):null}
    </div>
</div>
:null}
</div>
:null}
<div className='row'>
 <div className='col-md-6'>
 <div className='w-100'><PeoplePicker context ={ this.props.context} titleText = 'Send Email Notifications To'
 showtooltip ={ true} required ={ false} disabled ={ false} ensureUser ={ true} onChange ={ this._getSendToPeoplePickerItems}
 personSelectionLimit ={100} showHiddenInUI ={ false} defaultSelectedUsers ={ this.state.SendToDefaultItems} principalTypes ={[PrincipalType.User]} resolveDelay ={ 1000}/></div>
 </div>
 </div>
<div className='row'>
 <div className='col-md-12'>
   <label className='font-weight-bold'>Description:</label>
   <SunEditor enableToolbar={true} placeholder='Please type here...' setContents={this.state.Probdesc} showToolbar={true} setOptions={{
                      minHeight: '270px', mode: 'classic', buttonList: [
                        ['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
                        ['table', 'link', 'image'],],
                    }} onChange={this.handleRichTextChange.bind(this, 'Probdesc')} onImageUpload={this.handleProbdescImageUpload} />
 
 {/* <RichText className='border' isEditMode={true} value={this.state.Probdesc} onChange={this.onProbdescChange} /> */}
 </div>
 </div>
 <div className='row'>
 {(this.state.DocType == 'Validations' || this.state.DocType == 'Issues')?
 <div className='col-md-12'>
   {this.state.DocType == 'Validations'? <label className='font-weight-bold'>Validation Results & Recommendations:</label>: <label className='font-weight-bold'>Proposed Resolution</label>}
   <SunEditor enableToolbar={true} placeholder='Please type here...' setContents={this.state.Proposedres} showToolbar={true} setOptions={{
                      minHeight: '170px', mode: 'classic', buttonList: [
                        ['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
                        ['table', 'link', 'image'],],
                    }} onChange={this.handleRichTextChange.bind(this, 'Proposedres')} onImageUpload={this.handleProposedresImageUpload} />
 
 {/* <RichText className='border' isEditMode={true} value={this.state.Proposedres} onChange={this.onProposedresChange} /> */}
 </div>
 :null}
 </div>
 <div className='row'>
 {(this.state.DocType == 'Validations' || this.state.DocType == 'Issues')?
 <div className='col-md-12'>
    {this.state.DocType == 'Validations'? <label className='font-weight-bold'>Re-Validation Results & Recommendations</label>: <label className='font-weight-bold'>Final Resolution</label>}
   <SunEditor enableToolbar={true} placeholder='Please type here...' setContents={this.state.Resolution} showToolbar={true} setOptions={{
                      minHeight: '170px', mode: 'classic', buttonList: [
                        ['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
                        ['table', 'link', 'image'],],
                    }} onChange={this.handleRichTextChange.bind(this, 'Resolution')} onImageUpload={this.handleResolutionImageUpload} />
 
 {/* <RichText className='border' isEditMode={true} value={this.state.Resolution} onChange={this.onResolutionChange} /> */}
 </div>
 :null}
 </div>
 <div className='row'>
 {this.state.DocType == 'Validations'?
 <div className='col-md-12'>
     <label className='font-weight-bold'>Follow Up Activities</label>
   <SunEditor enableToolbar={true} placeholder='Please type here...' setContents={this.state.Suggest} showToolbar={true} setOptions={{
                      minHeight: '170px', mode: 'classic', buttonList: [
                        ['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
                        ['table', 'link', 'image'],],
                    }} onChange={this.handleRichTextChange.bind(this, 'Suggest')} onImageUpload={this.handleSuggestImageUpload} />
 
 {/* <RichText className='border' isEditMode={true} value={this.state.Suggest Comments} onChange={this.onSuggestChange} /> */}
 </div>
:null}
 </div>
 <div className='row'>
 <div className='col-md-12'>
   <label className='font-weight-bold'>Comments</label>
   <SunEditor enableToolbar={true} placeholder='Please type here...' setContents={this.state.Comments} showToolbar={true} setOptions={{
                      minHeight: '170px', mode: 'classic', buttonList: [
                        ['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
                        ['table', 'link', 'image'],],
                    }} onChange={this.handleRichTextChange.bind(this, 'Comments')} onImageUpload={this.handleCommentsImageUpload} />
 
 {/* <RichText className='border' isEditMode={true} value={this.state.Comments} onChange={this.onCommentsChange} /> */}
 </div>
 </div>
 <div className='row'>
 <div className='col-md-12'>
   <label className='font-weight-bold'>Attachments</label>
  <input className='ReactFieldEditor-Attachments-UploadInput mt-2' type="file" multiple title='Attach Files' aria-required='false' aria-label='Attach Files' onChange={this.Attachment}/>
  {this.selectedFiles()}
 {this.showAttachment()}
 </div>
 </div>
 <Dialog minWidth={'380px'} hidden={this.state.isModaldialogClose} dialogContentProps={dialogModelContentProps}>
            <DialogFooter>
              <PrimaryButton style={{ textAlign: 'center' }} onClick={this.CloseForm} text="OK" />
            </DialogFooter>
          </Dialog>
</div>
 </div>
 }<Dialog minWidth={'460px'} maxWidth={'520px'} hidden={this.state.isModalClose} onDismiss={this.modalPopupClose} dialogContentProps={dialogContentProps}>
 <DialogFooter>
   <DefaultButton onClick={this.modalPopupClose} text="No" />
   <PrimaryButton onClick={this.modalSubmitClick} text="Yes" />
 </DialogFooter>
</Dialog>
<Dialog   hidden={this.state.isSavedHidden} dialogContentProps={dialogSavedProps}>
        <div className="text-center">
        <Icon iconName="CompletedSolid" className="btn-lg text-success"/>
        <br></br>
          Data Saved Succesfully!
       </div>
        <DialogFooter>
          <PrimaryButton onClick={this.CloseForm} text="OK" />
        </DialogFooter>
     </Dialog>

 </div>
 </ThemeProvider>
);
}}