import * as React from 'react';
import { MyState } from './UserGuideForm';
export default class ViewUserGuide extends React.Component<MyState> {
    bindAttachmentFileNames(): any;
    render(): JSX.Element;
}
//# sourceMappingURL=ViewUserGuide.d.ts.map