import * as React from 'react';
import { MyState } from './NewsArticleForm';
export default class ViewNewsArticle extends React.Component<MyState> {
    bindAttachmentFileNames(): any;
    render(): JSX.Element;
}
//# sourceMappingURL=ViewNewsArticle.d.ts.map