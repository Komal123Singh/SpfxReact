import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IUserGuideFormWebPartProps {
    description: string;
    logo: string;
    exitLocation: string;
}
export default class UserGuideFormWebPart extends BaseClientSideWebPart<IUserGuideFormWebPartProps> {
    onInit(): Promise<void>;
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=UserGuideFormWebPart.d.ts.map