import * as React from 'react';
import "@pnp/polyfill-ie11";
import { INewFormsProps } from './INewFormsProps';
import { escape } from '@microsoft/sp-lodash-subset';
import {PrimaryButton,createTheme,ThemeProvider} from '@fluentui/react';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { sp } from '@pnp/sp';
import "@pnp/sp/webs"; 
import "@pnp/sp/site-users/web";
import './NewFormsCSS.css';

let ReleaseDocLocation;
let NewsArcticleLocation;
let FaqLocation;
let SystemAlertLocation;
let absoluteUrl;
let exitLocation;
let uniqueId=0;
const myTheme = createTheme({
  palette: {
    themePrimary: '#23366f',
    themeLighterAlt: '#f3f4f9',
    themeLighter: '#cfd5e8',
    themeLight: '#a9b4d4',
    themeTertiary: '#6476a9',
    themeSecondary: '#344781',
    themeDarkAlt: '#203165',
    themeDark: '#1b2a55',
    themeDarker: '#141f3f',
    neutralLighterAlt: '#faf9f8',
    neutralLighter: '#f3f2f1',
    neutralLight: '#edebe9',
    neutralQuaternaryAlt: '#e1dfdd',
    neutralQuaternary: '#d0d0d0',
    neutralTertiaryAlt: '#c8c6c4',
    neutralTertiary: '#a19f9d',
    neutralSecondary: '#605e5c',
    neutralPrimaryAlt: '#3b3a39',
    neutralPrimary: '#323130',
    neutralDark: '#201f1e',
    black: '#000000',
    white: '#ffffff',
  }
});

export interface MyState {
  webpartContxt: WebPartContext;
  isEditor:boolean;
}
export default class NewForms extends React.Component<INewFormsProps,MyState > {
  constructor(prop) {
    super(prop);
    this.state = {
      webpartContxt: this.props.context,
      isEditor:false,
    };
    absoluteUrl= this.props.context.pageContext.site.absoluteUrl;
SPComponentLoader.loadCss(absoluteUrl+'/SiteAssets/StyleSheet/bootstrap.min.css');
SPComponentLoader.loadCss(absoluteUrl+'/SiteAssets/StyleSheet/suneditor.min.css');
SPComponentLoader.loadScript(absoluteUrl+'/SiteAssets/JS/jquery.min.js');
SPComponentLoader.loadScript(absoluteUrl+'/SiteAssets/JS/popper.min.js');
SPComponentLoader.loadScript(absoluteUrl+'/SiteAssets/JS/bootstrap.min.js');
  }
  componentDidMount() {
    try {

      const url = window.location.href;
      const urlObject = new URL(url);
      uniqueId = urlObject.searchParams.get('itemID') == '' || urlObject.searchParams.get('itemID') == null ? 0 : parseInt(urlObject.searchParams.get('itemID'));
      this.getLoggedUsersGroup();
    }
    catch (e) {
  
      console.log('componentDidMount: ' + e);
    } 
  }
  
  public NewsReleaseform = () => {
   
    try {
     
      NewsArcticleLocation=this.props.NewsArcticleLocation;
      window.open(NewsArcticleLocation);
  
    } catch (e) {
  
      console.log('Exitform: ' + e);
    } 
  }
  public Faqform = () => {
 
    try {
      FaqLocation=this.props.FaqLocation;
     window.open(FaqLocation);
  
    } catch (e) {
  
      console.log('Exitform: ' + e);
    } 
  }
  public  Releasedocumentform = () => {
  
    try {
      ReleaseDocLocation=this.props.ReleaseDocLocation;
      window.open(ReleaseDocLocation);
  
    } catch (e) {
  
      console.log('Exitform: ' + e);
    } 
  }
  
  public   Systemalertform = () => {
  
    try {
      SystemAlertLocation=this.props.SystemAlertLocation;
      window.open(SystemAlertLocation);
  
    } catch (e) {
  
      console.log('Exitform: ' + e);
    } 
  }
  
  getLoggedUsersGroup = async () => {
    try { 
    let LoggedUsersGroup = await sp.web.currentUser.groups();
    let permissionupdated=false;
    LoggedUsersGroup.map((groupItem) => {
     if(permissionupdated==false) {
      if (groupItem.Title == "USZ_ZSPIREHomePage_Access_Admins"||groupItem.Title == "USZ_ZSPIREHomePage_Admins"||groupItem.Title == "USZ_ZSPIREHomePage_Editors"
    ||groupItem.Title == "Z-SPIRE Homepage & User guide Owners"||groupItem.Title == "Z-SPIRE Homepage & User guide Members")
     {
      permissionupdated=true;
      this.setState({isEditor:true});
    } 
     }
    
    }) 
    
    } catch (e) {
    console.log('getLoggedUsersGroup' + e);
    }
    }
  public render(): React.ReactElement<INewFormsProps> {
    return (
      <ThemeProvider theme={myTheme}>
      {this.state.isEditor==true?<div className='buttonCls mt-0'>
     
      
<PrimaryButton className='ml-1 ' text='New Release Document' onClick={this.Releasedocumentform}> </PrimaryButton>
<PrimaryButton className='ml-3 ' text='New System Alert' onClick={this.Systemalertform}> </PrimaryButton>
<PrimaryButton className='ml-3' text='New News Article' onClick={this.NewsReleaseform}> </PrimaryButton>
<PrimaryButton className='ml-3 ' text='New FAQ Document' onClick={this.Faqform}> </PrimaryButton></div>:null}

     
      </ThemeProvider>

    );
  }
}
