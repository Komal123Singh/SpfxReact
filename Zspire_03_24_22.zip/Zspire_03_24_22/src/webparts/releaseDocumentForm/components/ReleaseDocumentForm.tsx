import * as React from 'react';
import { IReleaseDocumentFormProps } from './IReleaseDocumentFormProps';
import "@pnp/sp/webs";
import "@pnp/sp/site-users/web";
import { sp } from "@pnp/sp";
import * as _ from '@microsoft/sp-lodash-subset';
import './ReleaseDocumentCss.css';
import ReleaseDocumentStore from '../Store/ReleaseDocumentStore';
import * as ReleaseDocumentAction from '../Action/ReleaseDocumentAction';
import * as moment from 'moment';
import ViewReleaseDocument from './ViewReleaseDocument';
import { ThemeProvider, createTheme,ProgressIndicator, ChoiceGroup, TextField, Label, PrimaryButton, DefaultButton, Dropdown, IDropdownStyles, IDropdownOption, Text, Link, Icon, IconButton, DialogType, Dialog, DialogFooter } from '@fluentui/react';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { DateTimePicker, DateConvention } from '@pnp/spfx-controls-react/lib/dateTimePicker';
import { RichText } from '@pnp/spfx-controls-react/lib/RichText'
import { remove } from 'lodash';
import { Pivot, PivotItem, } from '@fluentui/react';
import { IAttachmentFileInfo } from "@pnp/sp/attachments";
import SunEditor from 'suneditor-react';
import 'suneditor/dist/css/suneditor.min.css';
import * as ReactDom from 'react-dom';



let uniqueId = 0;
let isEditMode = false;
let isViewMode = false;
let EditFormDetails;
let exitLocation;
let documentStatusValidation = '';
let dateValidation = '';
let titleValidation = '';
let bodyValidation = '';
let releaseValidation = '';
let categoryValidation = '';
let actionBtnClicked = '';
let Dropdownarr;
let absoluteUrl;
let uploadedRichTextFiles = [];
let loadSpinner=false;


const dropdownStyles: Partial<IDropdownStyles> = {
  dropdownItems: { maxHeight: '250px' },
  dropdownItemsWrapper: { maxHeight: '250px' }
};

const myTheme = createTheme({
  palette: {
    themePrimary: '#23366f',
    themeLighterAlt: '#f3f4f9',
    themeLighter: '#cfd5e8',
    themeLight: '#a9b4d4',
    themeTertiary: '#6476a9',
    themeSecondary: '#344781',
    themeDarkAlt: '#203165',
    themeDark: '#1b2a55',
    themeDarker: '#141f3f',
    neutralLighterAlt: '#faf9f8',
    neutralLighter: '#f3f2f1',
    neutralLight: '#edebe9',
    neutralQuaternaryAlt: '#e1dfdd',
    neutralQuaternary: '#d0d0d0',
    neutralTertiaryAlt: '#c8c6c4',
    neutralTertiary: '#a19f9d',
    neutralSecondary: '#605e5c',
    neutralPrimaryAlt: '#3b3a39',
    neutralPrimary: '#323130',
    neutralDark: '#201f1e',
    black: '#000000',
    white: '#ffffff',
  }
});

const iconStyle = {
  root: {
    color: '#107c10',
    fontSize: '50px',
  }
};

let dialogContentProps = {
  type: DialogType.normal,
  title: 'Confirmation',
  closeButtonAriaLabel: 'Close',
  subText: '',
};

let dialogModelContentProps = {
  type: DialogType.normal,
  title: <div className="text-center"><div><Icon styles={iconStyle} iconName="SkypeCircleCheck"></Icon></div><div>Success</div></div>,
  closeButtonAriaLabel: 'Close',
  subText: '',
};

export interface MyState {
  webpartContxt: WebPartContext;
  DocStatus: string;
  DocStatusChoiceArr: any;
  CreationDate: any;
  DocAuthor: any;
  Release: string;
  Releasearr: any;
  Category: string;
  Categoryarr: any;
  ArticleTitle: string;
  Richtextbody: string;
  Attachments: any;
  EditAttachments: any;
  delAttach: any;
  Comments: string;
  DocType: string;
  Year: any;
  Created: any;
  isvalidRecord: boolean;
  isModalClose: boolean;
  isModaldialogClose: boolean;
  LNCreated: any;
  LNCreatedBy: any;
  LNModified: any;
  LNModifiedBy: any;
  EhEditor: any;
  EhRev: any;
  EhDate: any;
  isEditor:any;
  buttoncheck:any;

}

export default class ReleaseDocumentForm extends React.Component<IReleaseDocumentFormProps, MyState> {
  constructor(prop) {
    super(prop);
    this.state = {
      webpartContxt: this.props.context,
      DocStatus: 'In-Progress',
      DocStatusChoiceArr: [{ key: 'In-Progress', text: 'In-Progress' }, { key: 'Publish', text: 'Publish' }],
      CreationDate:  new Date(),
      DocAuthor: this.props.context.pageContext.user.displayName,
      Release: '',
      Releasearr: [],
      Category: '',
      Categoryarr: [],
      ArticleTitle: '',
      Richtextbody: '',
      Attachments: [],
      EditAttachments: [],
      delAttach: [],
      Comments: '',
      DocType: 'Release Documentation',
      Year: null,
      Created: null,
      isvalidRecord: false,
      isModalClose: true,
      isModaldialogClose: true,
      LNCreated: null,
      LNCreatedBy: null,
      LNModified: null,
      LNModifiedBy: null,
      EhEditor: null,
      EhRev: null,
      EhDate: null,
      isEditor:false,
      buttoncheck:'',


    }
    absoluteUrl = this.props.context.pageContext.site.absoluteUrl;
    SPComponentLoader.loadCss(absoluteUrl + '/SiteAssets/StyleSheet/bootstrap.min.css');
    SPComponentLoader.loadCss(absoluteUrl + '/SiteAssets/StyleSheet/suneditor.min.css');
    SPComponentLoader.loadCss('https://cdn.jsdelivr.net/npm/suneditor@latest/dist/css/suneditor.min.css');
    SPComponentLoader.loadScript(absoluteUrl + '/SiteAssets/JS/jquery.min.js');
    SPComponentLoader.loadScript(absoluteUrl + '/SiteAssets/JS/popper.min.js');
    SPComponentLoader.loadScript(absoluteUrl + '/SiteAssets/JS/bootstrap.min.js');

  }

  componentDidMount() {
    try {

      const url = window.location.href;
      const urlObject = new URL(url);
      uniqueId = urlObject.searchParams.get('itemID') == '' || urlObject.searchParams.get('itemID') == null ? 0 : parseInt(urlObject.searchParams.get('itemID'));

      // Call default form details
      this.getFormDefaultDetails();
      this.getLoggedUsersGroup();

      if (uniqueId != 0) {
        isViewMode = true;
        isEditMode = false;
        this.getEditFormDetailsComp();
      }
      else {
        isViewMode = false;
        isEditMode = true;
      }
    }
    catch (e) {
      console.log('componentDidMount: ' + e);
    }
  }

  getFormDefaultDetails = () => {
    try {

      ReleaseDocumentAction.getDropdownDetails();
      ReleaseDocumentStore.on('insertResultchange', this.assignInsertResultStore);
      ReleaseDocumentStore.on('DropdownDetailschange', this.CreateDropdownDetails)
    } catch (e) {
      console.log('getFormDefaultDetails' + e);
    }
  }

  getEditFormDetailsComp = () => {
    try {

      ReleaseDocumentAction.getEditFormDetails(uniqueId);
      ReleaseDocumentStore.on('getEditFormDetailschange', this.assignEditFormDetailsStore);
    } catch (e) {
      console.log('getEditFormDetailsComp' + e);
    }
  }

  public EditClickBtn = () => {
    try {
      isEditMode = true;
      isViewMode = false;
      this.getEditFormDetailsComp();
    } catch (e) {
      console.log('EditClickBtn' + e);
    }
  }

  public ViewClickBtn = () => {
    try {
      isEditMode = false;
      isViewMode = true;
      this.getEditFormDetailsComp();
    } catch (e) {
      console.log('ViewClickBtn' + e);
    }
  }


  public assignInsertResultStore = () => {
    try {
      if (ReleaseDocumentStore.getInserResultStoreValue() != undefined) {
        let test = ReleaseDocumentStore.getInserResultStoreValue();
        if (actionBtnClicked == "saveClose") {
          dialogModelContentProps.subText = 'This Form has been submitted sucessfully. Click Ok to exit';
          loadSpinner=false;
          this.setState({ isModaldialogClose: false });
        }

      }
    } catch (e) {
      console.log('assignInsertResultStore: ' + e);
    }
  }

  public assignEditFormDetailsStore = () => {
debugger;
    EditFormDetails = ReleaseDocumentStore.getEditClickStoreValue();
    if (EditFormDetails != undefined) {
      debugger;
      let domparser = new DOMParser();
      let s = new XMLSerializer();
      let parsedAttachments0 = domparser.parseFromString(EditFormDetails.Body, 'text/html');
      parsedAttachments0.querySelectorAll('[class*=se-component]').forEach((ext) => { ext.removeAttribute('class'); }); let serializeAttachments0 = s.serializeToString(parsedAttachments0);
      this.setState({
        DocStatus: EditFormDetails.DocStatus,
        CreationDate: EditFormDetails.CreationDate != null ? new Date(EditFormDetails.CreationDate) : null,
        DocAuthor: EditFormDetails.DocAuthor,
        ArticleTitle: EditFormDetails.Title0,
        Richtextbody: serializeAttachments0 != '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>null</body></html>' ? _.unescape(serializeAttachments0) : '',
        EditAttachments: EditFormDetails.AttachmentFiles,
        Release: EditFormDetails.Release,
        Category: EditFormDetails.Category,
        Comments: EditFormDetails.Comments,
        Created:EditFormDetails.Created,
        LNCreated: EditFormDetails.LNCreated != null ? new Date(EditFormDetails.LNCreated) : null,
        LNModified: EditFormDetails.LNModified != null ? new Date(EditFormDetails.LNModified) : null,
        LNCreatedBy: EditFormDetails.LNCreatedBy,
        LNModifiedBy: EditFormDetails.LNModifiedBy,
        EhDate: EditFormDetails.EhDate,
        EhEditor: EditFormDetails.EhEditor,
        EhRev: EditFormDetails.EhRev,

      });


    }
  }

  public insertForm = () => {

    try {
      debugger;
      loadSpinner=true;
      this.setState({ isModalClose: true,buttoncheck:'disabledbutton' });
      let username = this.props.context.pageContext.user.displayName;
      let date = moment(new Date()).format("MM/DD/YYYY LTS");
      let year = moment(new Date()).format("YYYY");
      let editor = this.props.context.pageContext.user.displayName;
      let ehDate = moment(new Date()).format("MM/DD/YYYY LTS");
      let Ehrev = '0';
      let count = parseInt(this.state.EhRev);
      let neweditor = this.props.context.pageContext.user.displayName + "\n" + this.state.EhEditor;
      let rev = count + 1;
      let newrev = rev.toString() + "\n" + this.state.EhRev;
      let newdate = moment(new Date()).format("MM/DD/YYYY LTS") + "\n" + this.state.EhDate;
      //let release= (this.state.Release || []).join(', ');
      // let category= (this.state.Category || []).join(', ');
      if (uniqueId == 0) {

        ReleaseDocumentAction.saveForm(this.state.DocStatus, this.state.CreationDate, this.state.DocAuthor, this.state.Release, this.state.Category, this.state.ArticleTitle, this.state.Richtextbody, this.state.Attachments, this.state.Comments, this.state.DocType, this.state.Created, date, username, date, username, year, Ehrev, editor, ehDate, uploadedRichTextFiles)
      }
      else {
        ReleaseDocumentAction.updateForm(uniqueId, this.state.DocStatus, this.state.CreationDate, this.state.DocAuthor, this.state.Release, this.state.Category, this.state.ArticleTitle, this.state.Richtextbody, this.state.Comments, this.state.Attachments, this.state.EditAttachments, this.state.delAttach, date, username, newrev, neweditor, newdate,uploadedRichTextFiles)
      }
    }
    catch (e) {
      console.log('insertForm: ' + e);
    }
  }

  private inputFormChange = (inputValue) => {

    try {

      //let test=inputValue;
      switch (inputValue.target.name) {

        case 'ArticleTitle':
          {
            this.setState({ ArticleTitle: inputValue.target.value });
            break;
          }
        case 'CreationDate':
          {
            this.setState({ CreationDate: inputValue.target.value });
            break;
          }
        case 'DocAuthor':
          {
            this.setState({ DocAuthor: inputValue.target.value });
            break;
          }
        case 'Comments':
          {
            this.setState({ Comments: inputValue.target.value });
            break;
          }
      }
    }
    catch (e) {
      console.log('inputFormChange: ' + e);
    }
  }

  private InProgressRadioBtnChange = (ev: React.FormEvent<HTMLInputElement>, option: any) => {
    this.setState({ DocStatus: option.key });
  }

  private _getDateDatePickerItems = (items) => {
    this.setState({ CreationDate: items });
  }

  // private _onTextChange = (newText:string) => { 
  //   this.setState({ Body: newText });
  //   return newText;
  // }
  // Get Input RichText Details
  handleRichTextChange = (fieldName, content) => {

    try {
      switch (fieldName) {

        case 'Body':
          this.setState({ Richtextbody: content });
          break;
      }
    }
    catch (e) {
      console.log('handleRichTextChange: ' + e);
    }
  }
  handleImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {
   
    if (imageInfo != null) {
      let files = uploadedRichTextFiles;
      let dataURI = imageInfo.src;
      let fileName = imageInfo.name;
      if (dataURI.split(',')[0].indexOf('base64') >= 0) {
        var arr = dataURI.split(','),
          mime = arr[0].match(/:(.*?);/)[1],
          bstr = atob(arr[1]),
          n = bstr.length,
          u8arr = new Uint8Array(n);
        while (n--) {
          u8arr[n] = bstr.charCodeAt(n);
        }
        const file = new File([u8arr], fileName, { type: mime });
        let fExists = files.some((f) => f['name'] === file['name']);
        if (!fExists) {
          files.push(file);
        }
        uploadedRichTextFiles = files;
      }
    }
  }


  private attach = (newattach) => {
    debugger;
    //this.setState({ Attachments:newattach.target.files});
    try{
    let fileInfos = [];
   
    for (var i = 0; i < newattach.target.files.length; i++) {
      debugger;
      
      fileInfos.push({
        name: newattach.target.files[i].name,
        content: newattach.target.files[i]
      });
    }
    this.setState({ Attachments: fileInfos });
    
  }
  catch(e){
       console.log('bindAttachment: ' + e);

  }
  }
  private showattach= ()=>{
    try{
      debugger;
      let showitem=this.state.Attachments;
      return showitem.map((item, idx) => {
      
        return(
              <div><span><a href=''>{showitem[idx].name}</a>
              </span>
              </div>
        )
    })
    }
    catch(e){
      console.log('showattach: ' + e);

 }
  }

  // private bindAttachment= ()  =>{
  // debugger;
  // let test=[];
  // //test=this.state.EditAttachments;
  //   try{
  //       //  console.log(this.state.EditAttachments);
  //     if(this.state.EditAttachments.length!=0){

  //       let downloadUrl = this.props.context.pageContext.web.absoluteUrl + "/_layouts/download.aspx?sourceurl=" + this.state.EditAttachments[0].ServerRelativeUrl;  
  //     return(
  //      <span> <a href={downloadUrl}>{this.state.EditAttachments[0].FileName}</a>
  //       <IconButton className='mt-1' iconProps={{ iconName: 'Delete' }} title='Delete' ariaLabel='Delete' onClick={this.deleteAttachment} />
  //      </span> 
  //     )

  //   }
  //  } catch (e){
  //     console.log('bindAttachment: ' + e);
  //   }
  // }

  private bindAttachmentFileNames() {
    debugger;
    try {
    
      let editattchments=this.state.EditAttachments;
     
        // let fileExtension = fileName.split('.').pop();
        let filtereditem = editattchments.filter(attachmentitems =>!attachmentitems.FileName.match(/.(jpg|jpeg|png|gif)$/i))
     return filtereditem.map((item, idx) => {  
        let downloadUrl = this.props.context.pageContext.web.absoluteUrl + "/_layouts/download.aspx?sourceurl=" + filtereditem[idx].ServerRelativeUrl;
        return (
          <div><span><a data-interception="off" target='_blank' href={filtereditem[idx].ServerRelativePath.DecodedUrl}>{filtereditem[idx].FileName}</a>
            <IconButton className='mt-1' iconProps={{ iconName: 'Delete' }} title='Delete' ariaLabel='Delete' onClick={this.deleteAttachment.bind(this, filtereditem[idx].FileName)} />
          </span></div>
        )

      });
      
    }
    catch (e) {
      console.log('bindAttachmentFileNames ' + e);
    }
  }
  private deleteAttachment = (DeleteFileName) => {
    debugger;
    try {
      //remove(this.state.EditAttachments);
      let tempEditAttachment = this.state.EditAttachments;
      let tempDeleteAttachment = this.state.delAttach;
      let result;

      // let index=tempEditAttachment.indexOf(DeleteFileName);
      var index = tempEditAttachment.findIndex(function (DeleteItem) {
        return DeleteItem.FileName == DeleteFileName

      });
      tempEditAttachment.splice(index, 1);
      this.setState({ EditAttachments: tempEditAttachment });

      tempDeleteAttachment.push(DeleteFileName);

      this.setState({ delAttach: tempDeleteAttachment })


      console.log(this.state.delAttach);

    }
    catch (e) {
      console.log('deleteAttachment: ' + e);
    }
  }

  private CreateDropdownDetails = () => {

    try {
      let result;
      let categoriesdetails;
      let Releasedetails;
      let splitcategorydetails = [];
      let splitreleasedetails = [];
      Dropdownarr = ReleaseDocumentStore.getDropdownDetailsStoreValue();
      let categorieslistchoice = [];
      let releaselistchoice = [];
      if (Dropdownarr.length != 0)
        categoriesdetails = Dropdownarr[3].SubCategory;
      Releasedetails = Dropdownarr[1].SubCategory;
      splitcategorydetails = categoriesdetails != undefined ? categoriesdetails.split(/[\n,;]+/) : [];
      if (splitcategorydetails.length != 0) {
        splitcategorydetails.map((categoriesitems) => {
          categorieslistchoice.push({ key: categoriesitems, text: categoriesitems, id: 'Category' });
        });
      }
      splitreleasedetails = Releasedetails != undefined ? Releasedetails.split(/[\n,;]+/) : [];
      if (splitreleasedetails.length != 0) {
        splitreleasedetails.map((responseitems) => {
          releaselistchoice.push({ key: responseitems, text: responseitems, id: 'Release' });
        });
      }

      this.setState({ Categoryarr: categorieslistchoice });
      this.setState({ Releasearr: releaselistchoice });
    }
    catch (e) {
      console.log('CreateDropdownDetails: ' + e);
    }
  }

  public onDropdownChange = (item: IDropdownOption): void => {
    try {
      this.setState({ Release: item.key as string });
    }
    catch (e) {
      console.log('onDropdownChange: ' + e);
    }
  }

  public onCategoryChange = (item: IDropdownOption): void => {
    try {
      this.setState({ Category: item.key as string });
    }
    catch (e) {
      console.log('onCategoryChange: ' + e);
    }
  }

  private tabledetails = () => {


    try {
      let splitEheditor = this.state.EhEditor != undefined ? this.state.EhEditor.split('\n') : [];
      let splitEhrev = this.state.EhRev != undefined ? this.state.EhRev.split('\n') : [];
      let splitEhdate = this.state.EhDate != undefined ? this.state.EhDate.split('\n') : [];

      return (
        <table className="table table-bordered border-spacing:2px text-center">
          <thead>
            <tr>
              <th scope="col">Rev.</th>
              <th scope="col">Editor</th>
              <th scope="col">Edit Date</th>
            </tr>
          </thead>
          <tbody>

            {splitEhrev.filter((item, index) => index < 10).map((items, index) => {

              return (
                <tr>
                  <td className='text-center'>{items}</td>
                  <td className='text-center'>{splitEheditor[index]}</td>
                  <td className='text-center'>{splitEhdate[index]}</td>
                </tr>
                //)}}}}
              )
            })}
          </tbody>
        </table>
      )
    } catch (e) {
      console.log('tabledetails: ' + e);
    }
  }

  checkFormValidation = (actionClick) => {

    try {
      documentStatusValidation = '';
      dateValidation = '';
      titleValidation = '';
      bodyValidation = '';
      releaseValidation = '';
      categoryValidation = '';
      // Assign action value
      actionBtnClicked = actionClick;

      // Validation Check
      documentStatusValidation = this.state.DocStatus == '' ? 'Please enter the document status' : '';
      releaseValidation = this.state.Release == '' ? 'Please select release' : '';
      categoryValidation = this.state.Category == '' ? 'Please select category' : '';
      titleValidation = this.state.ArticleTitle == '' ? 'Please enter the title' : '';
      if (documentStatusValidation != '' || dateValidation != '' || releaseValidation != '' || categoryValidation != '' || titleValidation != '') {
        this.setState({ isvalidRecord: false });
      } else {
        this.modalPopupOpen(actionBtnClicked);
        this.setState({ isvalidRecord: true });
      }
    }
    catch (e) {
      console.log('checkFormValidationChange: ' + e);
    }
  }

  modalPopupOpen = (actionCall) => {

    try {
      actionBtnClicked = actionCall;
      if (actionBtnClicked == 'close') {
        dialogContentProps.title = 'Close Confirmation';
        dialogContentProps.subText = 'Are you sure you want to close this Form?';
      } else if (actionBtnClicked == 'saveClose') {
        dialogContentProps.title = 'Save Confirmation';
        dialogContentProps.subText = 'Do you want to save this details?';
      }

      this.setState({ isModalClose: false });
    } catch (e) {
      console.log('modalPopup: ' + e);
    }
  }

  modalPopupOpenView = (actionCall) => {

    try {
      actionBtnClicked = actionCall;
      if (actionBtnClicked == 'close') {
        dialogContentProps.title = 'Close Confirmation';
        dialogContentProps.subText = 'Are you sure you want to close the form?';
      }

      this.setState({ isModalClose: false });
    } catch (e) {
      console.log('modalPopup: ' + e);
    }
  }

  modalPopupClose = () => {
    try {
      this.setState({ isModalClose: true });
    } catch (e) {
      console.log('modalPopup: ' + e);
    }
  }


  modalSubmitClick = () => {
    try {

      if (actionBtnClicked == 'close') {
        this.CloseForm();
      } else if (actionBtnClicked == 'saveClose') {
        //actionBtnClicked = this.state.ProcessStatus == 'Complete' ? 'Complete' : actionBtnClicked;
        this.insertForm();
      }
    } catch (e) {
      console.log('modalSubmitClick: ' + e);
    }
  }

  getLoggedUsersGroup = async () => {
    try { 
    let LoggedUsersGroup = await sp.web.currentUser.groups();
    let permissionupdated=false;
    LoggedUsersGroup.map((groupItem) => {
     if(permissionupdated==false) {
      if (groupItem.Title == "USZ_ZSPIREHomePage_Access_Admins"||groupItem.Title == "USZ_ZSPIREHomePage_Admins"||groupItem.Title == "USZ_ZSPIREHomePage_Editors"
    ||groupItem.Title == "Z-SPIRE Homepage & User guide Owners"||groupItem.Title == "Z-SPIRE Homepage & User guide Members")
     {
      permissionupdated=true;
      this.setState({isEditor:true});
    } 
     }
    
    }) 
    
    } catch (e) {
    console.log('getLoggedUsersGroup' + e);
    }
    }
  CloseForm = () => {

    try {
      window.open('','_parent','');
      window.close();

    } catch (e) {

      console.log('CloseForm: ' + e);
    }
  }
  Exit = () => {

    try {
      window.open('','_parent','');
      window.close();

    } catch (e) {

      console.log('CloseForm: ' + e);
    }
  }

  public render(): React.ReactElement<IReleaseDocumentFormProps> {
 
    return (
      <ThemeProvider theme={myTheme}>
        <div className={this.state.buttoncheck+' container'}>
          <div className='border p-3' style={{ backgroundColor: '#23366f' }}>
            <div className='row'>
              <div className='col-md-6'><h3 className="text-light ">{this.props.description}</h3></div>
              <div className='col-md-6 text-right'><img src={this.props.logo} alt='Logo' width='50' height='50' /></div>
            </div>
          </div>

          {isViewMode == true && isEditMode == false ?
            <div>
              <div className='buttonCls mt-0'>
                <DefaultButton className='mt-2 md-2' text='Close' onClick={this.modalPopupOpenView.bind(this, 'close')} allowDisabledFocus />
                {this.state.isEditor==true?<PrimaryButton className='ml-1 ' text='Edit' onClick={this.EditClickBtn} allowDisabledFocus />:null}
                <div className='mt-1'>
                  <Pivot aria-label="Basic Pivot Example">
                    <PivotItem className='mt-3' headerText="Release Documentation">
                      <div style={{ backgroundColor: '' }}><ViewReleaseDocument {...this.state} /></div>
                    </PivotItem>
                    <PivotItem className='mt-3' headerText="Edit History">
                      <div>{this.tabledetails()}</div>
                    </PivotItem>
                  </Pivot>
                </div>
              </div>
            </div> :
            <div>
              <div className='buttonCls mt-2'>
                <DefaultButton className='' text='Close' onClick={this.modalPopupOpen.bind(this, 'close')} allowDisabledFocus />
                <PrimaryButton className='ml-1' text='Save & Close' onClick={this.checkFormValidation.bind(this, 'saveClose')} allowDisabledFocus />
              </div>
              {loadSpinner==true?<ProgressIndicator label="Submitting Details" />:null}
              <div className='row p-6 mt-2'>
                <div className='col-md-6'><p>Created on {(this.state.Created != null) ? (moment(this.state.Created).format('MM/DD/YYYY')) : moment().format('MM/DD/YYYY')}</p></div>
                <div className='col-md-6 text-right style required'><b className='control'></b> Signifies a Required Field </div>
              </div>

              <div className='border p-3 mt-1'>
                <div className='row mt-2 '>
                  <div className='col-md-3 form-group required'><b className='control-label'>Document Status:</b></div>
                  <div className='col-md-9'>
                    <ChoiceGroup className='w-100 inlineflex' selectedKey={this.state.DocStatus} options={this.state.DocStatusChoiceArr} onChange={this.InProgressRadioBtnChange} />
                  </div>
                </div>
                <div className='row mt-2'>
                  <div className='col-md-3 form-group required'><b className='control-label'>Date:</b></div>
                  <div className='col-md-4'>
                    <DateTimePicker dateConvention={DateConvention.Date} showLabels={false} formatDate={(date: Date) => date.toLocaleDateString('en-US',{month:"2-digit", day:"2-digit", year:"numeric"})} value={this.state.CreationDate} onChange={this._getDateDatePickerItems} />
                  </div>
                </div>
                <div className='row mt-2'>
                  <div className='col-md-3 form-group required'><b className='control-label'>Author:</b></div>
                  <div className='col-md-4'>
                    <Label className='w-4 normal'> {this.state.DocAuthor}</Label>
                  </div>
                </div>
                <div className='row mt-2'>
                  <div className='col-md-3 form-group required'><b className='control-label'>Release:</b></div>
                  <div className='col-md-4'>
                    <Dropdown styles={dropdownStyles} placeholder={'Select Release'} errorMessage={releaseValidation} defaultSelectedKey={this.state.Release} options={this.state.Releasearr} onChanged={this.onDropdownChange} />
                  </div>
                </div>
                <div className='row mt-2'>
                  <div className='col-md-3 form-group required'><b className='control-label'> Category:</b></div>
                  <div className='col-md-4'>
                    <Dropdown styles={dropdownStyles} placeholder={'Select Category'} errorMessage={categoryValidation} defaultSelectedKey={this.state.Category} options={this.state.Categoryarr} onChanged={this.onCategoryChange} />

                  </div>
                </div>
                <div className='row mt-2'>
                  <div className='col-md-3 form-group required'><b className='control-label'>Title:</b></div>
                  <div className='col-md-6'>
                    <TextField className='w-4' value={this.state.ArticleTitle} name='ArticleTitle' placeholder={'Enter the Title'} errorMessage={titleValidation} onChange={this.inputFormChange} />
                  </div>
                </div>
                <div className='row mt-2'>
                  <div className='col-md-3 form-group required'><b> Body:</b></div>
                  <div className='col-md-9'>
                    <div className='border p-3 mt-2'>
                      {/* <RichText isEditMode={true} value={this.state.Body} placeholder={'Enter the Body'} onChange={this._onTextChange} /> */}
                      <SunEditor enableToolbar={true} placeholder='Please type here...' setContents={this.state.Richtextbody} showToolbar={true} setOptions={{
                        minHeight: '170px', mode: 'classic', buttonList: [
                          ['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
                          ['table', 'link', 'image'],],
                      }} onChange={this.handleRichTextChange.bind(this, 'Body')} onImageUpload={this.handleImageUpload} />
                    </div>
                  </div>
                </div>
                <div className='row mt-2'>
                  <div className='col-md-3'><b>Attachment:</b></div>
                  <div className='col-md-8'>
                    <input className='ReactFieldEditor-Attachments-UploadInput mt-2' type='file' name='attachmentFiles' title='Attach Files' aria-required='false' aria-label='Attach Files' multiple onChange={this.attach} />
                    <div> {this.showattach()}</div>
                    <div>{this.bindAttachmentFileNames()}
                    </div>
                  </div>
                </div>
                <div className='row mt-2'>
                  <div className='col-md-3 '><b > Comments:</b></div>
                  <div className='col-md-6'>
                    <TextField className='w-100' multiline value={this.state.Comments} name='Comments'maxLength={250} placeholder={'Enter the Comments'} onChange={this.inputFormChange} />
                  </div>
                </div>
              </div>
            </div>}
          <Dialog minWidth={'460px'} maxWidth={'520px'} hidden={this.state.isModalClose} onDismiss={this.modalPopupClose} dialogContentProps={dialogContentProps}>
            <DialogFooter>
              <DefaultButton onClick={this.modalPopupClose} text="No" />
              <PrimaryButton onClick={this.modalSubmitClick} text="Yes" />
            </DialogFooter>
          </Dialog>
          <Dialog minWidth={'380px'} hidden={this.state.isModaldialogClose} dialogContentProps={dialogModelContentProps}>
            <DialogFooter>
              <PrimaryButton style={{ textAlign: 'center' }} onClick={this.Exit} text="OK" />
            </DialogFooter>
          </Dialog>
        </div>
      </ThemeProvider>
    );
  }
}
