declare interface ISystemAlertFormWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SystemAlertFormWebPartStrings' {
  const strings: ISystemAlertFormWebPartStrings;
  export = strings;
}
