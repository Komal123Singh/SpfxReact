/* tslint:disable */
require("./ReleaseDocumentForm.module.css");
const styles = {
  releaseDocumentForm: 'releaseDocumentForm_7a6eae57',
  container: 'container_7a6eae57',
  row: 'row_7a6eae57',
  column: 'column_7a6eae57',
  'ms-Grid': 'ms-Grid_7a6eae57',
  title: 'title_7a6eae57',
  subTitle: 'subTitle_7a6eae57',
  description: 'description_7a6eae57',
  button: 'button_7a6eae57',
  label: 'label_7a6eae57'
};

export default styles;
/* tslint:enable */