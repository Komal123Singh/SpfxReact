import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface IValidationsProblemProps {
  description: string;
  context: WebPartContext;
  
  logourl: string;
  exiturl: string;
}
