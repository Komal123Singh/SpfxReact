import * as React from 'react';
import "@pnp/polyfill-ie11";
import { INewFormsProps } from './INewFormsProps';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import "@pnp/sp/webs";
import "@pnp/sp/site-users/web";
import './NewFormsCSS.css';
export interface MyState {
    webpartContxt: WebPartContext;
    isEditor: boolean;
}
export default class NewForms extends React.Component<INewFormsProps, MyState> {
    constructor(prop: any);
    componentDidMount(): void;
    NewsReleaseform: () => void;
    Faqform: () => void;
    Releasedocumentform: () => void;
    Systemalertform: () => void;
    getLoggedUsersGroup: () => Promise<void>;
    render(): React.ReactElement<INewFormsProps>;
}
//# sourceMappingURL=NewForms.d.ts.map