/* tslint:disable */
require("./GapClaimsLetters.module.css");
const styles = {
  gapClaimsLetters: 'gapClaimsLetters_f2ed7385',
  teams: 'teams_f2ed7385',
  welcome: 'welcome_f2ed7385',
  welcomeImage: 'welcomeImage_f2ed7385',
  links: 'links_f2ed7385'
};

export default styles;
/* tslint:enable */