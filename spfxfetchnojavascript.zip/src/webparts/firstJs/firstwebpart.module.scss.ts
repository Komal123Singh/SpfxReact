/* tslint:disable */
require("./firstwebpart.module.css");
const styles = {
  dvParent: 'dvParent_86c12122',
  dvChild: 'dvChild_86c12122',
  dvsubChild: 'dvsubChild_86c12122',
  up: 'up_86c12122',
  btn: 'btn_86c12122',
  tbl: 'tbl_86c12122',
  trow: 'trow_86c12122'
};

export default styles;
/* tslint:enable */