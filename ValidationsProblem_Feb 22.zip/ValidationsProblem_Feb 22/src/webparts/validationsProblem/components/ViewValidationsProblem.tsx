import * as React from 'react';
import { IValidationsProblemStates } from './IValidationsProblemStates';
//import {div} from '@fluentui/react';
import moment from 'moment';
export default class ViewValidationsProblem extends React.Component<IValidationsProblemStates> {
  private showReadOnlyAttachment=()=>{
    try{
      
  
      if(this.props.oldAttachments.length!=0){
        console.log(this.props.oldAttachments);
        let AttachmentList=this.props.oldAttachments;
        // let AttachmentListArray=[];
        let filtereditem = AttachmentList.filter(attachmentitems =>!(attachmentitems.FileName.match(/=/g)));
        let filtereditem2 = filtereditem.filter(attachmentitems2 =>!(attachmentitems2.FileName.match(/.(jpg|jpeg|png|gif)$/i)));
        return filtereditem2.map((item)=>{
        
          let downloadUrl = this.props.AbsoluteUrl + "/_layouts/download.aspx?sourceurl=" + item.ServerRelativeUrl;  
          return(
            <div id={item.FileName}><span><a href={downloadUrl}>{item.FileName}</a></span></div>
          
          )
        })
        
    
    }
  
   } catch (e){
  
      console.log('bindAttachment: ' + e);
  
    }
  

  }

render() {
return (
<div>

 <div className='row mt-1' >


<div className='col-md-12'>

<div className=' w-100'> <b>Created by</b> {this.props.createdby} <b>on</b> {moment(this.props.CreateTime).format('L [at] h:mm A')}</div>

 

</div>

</div>
<div className='border p-3 mt-1'>
 <div className='row mt-1' >

<div className='col-md-3'>
 <div className='font-weight-bold w-100'> Document Type</div>
</div>
<div className='col-md-3'>
 {this.props.DocType}
</div>
{(this.props.ishide)?
<div>
<div className='col-md-3'>
 <div className='font-weight-bold w-100'> IO#</div>
</div>
<div className='col-md-3'>
 {this.props.IONum}
</div>
</div>
:null}

</div>
 <div className='row mt-1' >

<div className='col-md-3'>
 <div className='font-weight-bold w-100'> Title</div>
</div>
<div className='col-md-3'>
 {this.props.Title}
</div>
<div className='col-md-3'>
 <div className='font-weight-bold w-100'> Document ID</div>
</div>
<div className='col-md-3'>
 {this.props.DocNumber}
</div>

</div>
{(this.props.ishide)?
 <div className='row mt-1' >

<div className='col-md-3'>
 <div className='font-weight-bold w-100'> Reporting Area</div>
</div>
<div className='col-md-3'>
 {this.props.ReptArea}
</div>
<div className='col-md-3'>
 <div className='font-weight-bold w-100'> Reporting Manager</div>
</div>
<div className='col-md-3'>
 {this.props.ReptMgr}
</div>
</div>
:null}
 <div className='row mt-1' >

<div className='col-md-3'>
 <div className='font-weight-bold w-100'> Status</div>
</div>
<div className='col-md-3'>
 {this.props.Status}
</div>
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
<div className='col-md-3'>
  {this.props.DocType == 'Validations'?<div className='font-weight-bold w-100'>Result Ranking</div>:<div className='font-weight-bold w-100'> Priority</div>}
</div>
:null}
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
<div className='col-md-3'>
 {this.props.Priority}
</div>
:null}


</div>
 <div className='row mt-1' >

{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
<div className='col-md-3'>
{this.props.DocType == 'Validations'?<div className='font-weight-bold w-100'>Risk Level</div>:<div className='font-weight-bold w-100'>Severity</div>}
 </div>
:null}
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
<div className='col-md-3'>
 {this.props.Severity}
</div>
:null}
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues' || this.props.DocType == 'Discussion Item')?
<div className='col-md-3'>
  {(this.props.DocType == 'Issues' || this.props.DocType == "Discussion Item")?<div className='font-weight-bold w-100'>Category</div>:<div className='font-weight-bold w-100'>Jurisdiction</div>}
</div>
:null}
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues' || this.props.DocType == 'Discussion Item')?
<div className='col-md-3'>
{this.props.UpdateKeywords.map((item,index)=>{
return (<>

 {item}{index!=this.props.UpdateKeywords.length-1?',':null} </>

)
})}

</div>
:null}
</div>
 <div className='row mt-1' >

<div className='col-md-3'>
  {this.props.DocType == 'Discussion Item'?<div className='font-weight-bold w-100'>Product Line</div>:this.props.DocType == 'Issues'?<div className='font-weight-bold w-100'>Project Area</div>:<div className='font-weight-bold w-100'>CPL Action</div>}
 
</div>
<div className='col-md-3'>
 {this.props.ProjectArea}
</div>
{this.props.DocType == 'Issues'?
<div className='col-md-3'>
 <div className='font-weight-bold w-100'> ApplicationArea</div>
</div>
:null}
{this.props.DocType == 'Issues'?
<div className='col-md-3'>
 {this.props.ApplicationArea}
</div>
:null}
</div>

{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
 <div className='row mt-1' >

<div className='col-md-3'>
  {this.props.DocType == 'Validations'?<div className='font-weight-bold w-100'>BU(s) Affected</div>:<div className='font-weight-bold w-100'>Environment Type</div>}
 </div>
<div className='col-md-3'>

{this.props.UpdateEnvType.map((item,index)=>{
return (<>{item}{index!=this.props.UpdateEnvType.length-1?',':null} </>)
})}

</div>
<div className='col-md-3'>
{this.props.DocType == 'Validations'?<div className='font-weight-bold w-100'>Ready date</div>:<div className='font-weight-bold w-100'>Test Case #</div>}
</div>
<div className='col-md-3'>
{this.props.TestCase!=undefined&&this.props.TestCase!=''&&this.props.TestCase!=null?moment(this.props.TestCase.toUTCString()).format('L'):null}
</div>
</div>
:null}
{(this.props.DocType == 'Issues')?
 <div className='row mt-1' >

<div className='col-md-3'>
<div className='font-weight-bold w-100'>Participants</div>
</div>
<div className='col-md-3'>
{this.props.ActivePlayersUserItems.length > 0 ? this.props.ActivePlayersUserItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
<div className='col-md-3'>
<div className='font-weight-bold w-100'>ProjectManagers</div>

</div>
<div className='col-md-3'>
{this.props.ProjectManagersUserItems.length > 0 ? this.props.ProjectManagersUserItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
</div>
:null}
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
 <div className='row mt-1' >

<div className='col-md-3'>
  {this.props.DocType == 'Validations'?<div className='font-weight-bold w-100'>Record Created By</div>:<div className='font-weight-bold w-100'>Reported By</div>}
 
</div>
<div className='col-md-3'>
{this.props.ReportedByUserItems.length > 0 ? this.props.ReportedByUserItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
<div className='col-md-3'>
{this.props.DocType == 'Validations'?<div className='font-weight-bold w-100'>Date Created</div>:<div className='font-weight-bold w-100'>Date Reported</div>}

</div>
<div className='col-md-3'>
{this.props.ReptDt!=undefined&&this.props.ReptDt!=''&&this.props.ReptDt!=null?moment(this.props.ReptDt.toUTCString()).format('L'):null}
</div>
</div>
:null}

{(this.props.ishide)?
 <div className='row mt-1' >

<div className='col-md-3'>
 <div className='font-weight-bold w-100'> PhaseDetect</div>
</div>
<div className='col-md-3'>
{this.props.PhaseDetect}
</div>
<div className='col-md-3'>
 <div className='font-weight-bold w-100'> PhaseIntro </div><span></span>
</div>
<div className='col-md-3'>
{this.props.PhaseIntro}
</div>
</div>
:null}
{(this.props.DocType == 'Validations')?
 <div className='row mt-1' >

<div className='col-md-3'>
 <div className='font-weight-bold w-100'> LOB(s) Affected</div>
</div>
<div className='col-md-3'>

{this.props.UpdateVendors.map((item,index)=>{
return (<> {item}{index!=this.props.UpdateVendors.length-1?',':null}</>)
})}

</div>
<div className='col-md-3'>
<div className='font-weight-bold w-100'>Val Completion Date</div>
</div>
<div className='col-md-3'>
{this.props.WONum!=undefined&&this.props.WONum!=''&&this.props.WONum!=null?moment(this.props.WONum.toUTCString()).format('L'):null}
</div>
</div>
:null}

{(this.props.DocType == 'Validations')?
 <div className='row mt-1' >

<div className='col-md-3'>
 <div className='font-weight-bold w-100'> Ins. Categories</div>
</div>
<div className='col-md-3'>
{this.props.UpdateRootCause.map((item,index)=>{
return (<> {item}{index!=this.props.UpdateRootCause.length-1?',':null}</>)
})}
</div>
</div>
:null}
{(this.props.DocType == 'Issues')?
 <div className='row mt-1' >

<div className='col-md-3'>
<div className='font-weight-bold w-100'> Assigned To </div>

</div>
<div className='col-md-3'>
{this.props.AssignedToUserItems.length > 0 ? this.props.AssignedToUserItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
<div className='col-md-3'>
<div className='font-weight-bold w-100'> Date Assigned </div>

</div>
{this.props.AssignedTo != ''?
<div className='col-md-3'>
{this.props.AssignedDt!=undefined&&this.props.AssignedDt!=''&&this.props.AssignedDt!=null?moment(this.props.AssignedDt.toUTCString()).format('L'):null}
</div>
:null}
</div>
:null}
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
 <div className='row mt-1' >

<div className='col-md-3'>
  {this.props.DocType == 'Validations'?<div className='font-weight-bold w-100'>Estimated Completion Date</div>:<div className='font-weight-bold w-100'>Est Comp Date</div>}
</div>
<div className='col-md-3'>
{this.props.EstCompDt!=undefined&&this.props.EstCompDt!=''&&this.props.EstCompDt!=null?moment(this.props.EstCompDt.toUTCString()).format('L'):null}
</div>
<div className='col-md-3'>
{this.props.DocType == 'Validations'?<div className='font-weight-bold w-100'>Re-Val/Final Completion Date</div>:<div className='font-weight-bold w-100'>Date Resolved</div>}

</div>
<div className='col-md-3'>
{this.props.DateResolved!=undefined&&this.props.DateResolved!=''&&this.props.DateResolved!=null?moment(this.props.DateResolved.toUTCString()).format('L'):null}
</div>
</div>
:null}
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
 <div className='row mt-1' >

{this.props.Status == 'Closed'?
<div className='col-md-3'>
<div className='font-weight-bold w-100'> Closed By </div>
</div>
:null}
{this.props.Status == 'Closed'?
<div className='col-md-3'>
{this.props.ApprovedByUserItems.length > 0 ? this.props.ApprovedByUserItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
:null}
{this.props.Status == 'Closed'?
<div className='col-md-3'>
<div className='font-weight-bold w-100'> Closed Date </div>
</div>
:null}
{this.props.Status == 'Closed'?
<div className='col-md-3'>
{this.props.ApprovedDt!=undefined&&this.props.ApprovedDt!=''&&this.props.ApprovedDt!=null?moment(this.props.ApprovedDt.toUTCString()).format('L'):null}
</div>
:null}
</div>
:null}
 <div className='row mt-1' >

<div className='col-md-3'>
<div className='font-weight-bold w-100'> Send Email Notifications To </div>

</div>
<div className='col-md-3'>

{this.props.SendToUserItems}
</div>
</div>

 <div className='row mt-1' >

<div className='col-md-12'>
<div className='font-weight-bold w-100'>Description</div>
<div dangerouslySetInnerHTML={{__html:this.props.Probdesc}} />
  {/* <RichText className='border' isEditMode={false} value={this.props.Probdesc} /> */}
</div>
</div>
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
 <div className='row mt-1' >

<div className='col-md-12'>
{this.props.DocType == 'Validations'? <div className='font-weight-bold'>Validation Results & Recommendations:</div>: <div className='font-weight-bold'>Proposed Resolution</div>}
<div dangerouslySetInnerHTML={{__html:this.props.Proposedres}} />
</div>
</div>
:null}
{(this.props.DocType == 'Validations' || this.props.DocType == 'Issues')?
 <div className='row mt-1' >

<div className='col-md-12'>
{this.props.DocType == 'Validations'? <div className='font-weight-bold'>Re-Validation Results & Recommendations</div>: <div className='font-weight-bold'>Final Resolution</div>}
<div dangerouslySetInnerHTML={{__html:this.props.Resolution}} />
</div>
</div>
:null}
{this.props.DocType == 'Validations'?
 <div className='row mt-1' >

<div className='col-md-12'>
<div className='font-weight-bold w-100'>Follow Up Activities</div>
<div dangerouslySetInnerHTML={{__html:this.props.Suggest}} />
</div>
</div>
:null}
 <div className='row mt-1' >

<div className='col-md-12'>
<div className='font-weight-bold w-100'> Comments </div>
<div dangerouslySetInnerHTML={{__html:this.props.Comments}} />

</div>
</div>
 <div className='row mt-1' >

<div className='col-md-12'>
<div className='font-weight-bold w-100'> Attachments </div>
{this.showReadOnlyAttachment()}
</div>
</div>

</div>




</div>
)
}
}