import * as React from 'react';
import {Label,Link,IconButton} from '@fluentui/react';
import { SecurityTrimmedControl, PermissionLevel, } from '@pnp/spfx-controls-react/lib/SecurityTrimmedControl';
import { SPPermission } from '@microsoft/sp-page-context';
import { IGapClaimsLettersStates } from './IGapClaimsLettersStates'; 
import * as  moment from "moment";
let deleteFiles = [];

export default class ViewGapClaimsLetters extends React.Component<IGapClaimsLettersStates,{}> {

bindAttachmentFileNames() {
try {
   var d = new Date;
var ampm = d.getHours() >= 12 ? ' PM ' : ' AM ';
let dformat = [d.getMonth()+1,
d.getDate(),
d.getFullYear()].join('-')+' '+
[d.getHours(),
d.getMinutes(),
d.getSeconds()].join(' ')+ampm;
return this.props.FormAttachmentNames.map((item) => {
  let filecount=1;
  let  attachmentfile_name:any="CLAIM}U}" +this.props.GAPAgreeNumA + "}U}GAP10}I}" +dformat+"-" +((filecount+1)+"000")+"-"+"ATTACHMENT"+(filecount+"000")+"."

 if (item.FileName.indexOf(attachmentfile_name) != -1) {
 let fileName = item.FileName.replace(attachmentfile_name, '');
return (
<div><span><Link target='_blank' href={item.ServerRelativePath.DecodedUrl}>{attachmentfile_name+fileName}</Link><IconButton className='mt-1' iconProps={{ iconName: 'CalculatorMultiply' }} title='Delete' ariaLabel='Delete' onClick={this.addDeleteFiles.bind(this,attachmentfile_name+ fileName)} /></span></div>
)
}});
}
catch (e) {
console.log('bindAttachmentFileNames ' + e);
}
}

addDeleteFiles = (fileName) => {
try {
let tempAttachFileName = this.props.FormAttachmentNames;
var index = tempAttachFileName.map(p => p.FileName).indexOf('FormAtach_' + fileName);
tempAttachFileName.splice(index, 1);
deleteFiles.push('FormAtach_' + fileName);
this.setState({ FormAttachmentNames: tempAttachFileName });
}
catch (e) {
console.log('addDeleteFiles ' + e);
}
}
render() {
return (
<div>


<div className='border p-3 mt-1'>
<div className='row'>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> GAP Agreement #</Label><span>{this.props.GAPAgreeNum}</span>
</div>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Gap Adjuster</Label><span>{this.props.VSCAdj}</span>
</div>
</div>
<div className='row'>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Claimant Last Name</Label><span>{this.props.InsuredLastName}</span>
</div>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> First Name</Label><span>{this.props.InsuredFirstName}</span>
</div>
</div>
<div className='row'>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Claimant Address</Label><span>{this.props.InsuredStreetAddress}</span>
</div>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Claimant City</Label><span>{this.props.InsuredCity}</span>
</div>
</div>
<div className='row'>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Claimant State</Label><span>{this.props.InsuredState}</span>
</div>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Claimant Zip</Label><span>{this.props.InsZip}</span>
</div>
</div>
<div className='row'>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Mark Delete</Label><span>{this.props.mrk_delete}</span>
</div>
</div>
</div>

<div className='border p-3 mt-1'>
<div>

{this.props.SendToDefaultItems.includes(null) == true || this.props.SendToDefaultItems.includes(undefined) == true || this.props.SendToDefaultItems.includes("")==true?
<div className='row'>
<div className='col-md-6'><Label>To</Label></div>
  <div className='w-50'><Label>{this.props.SendToText}</Label></div>

</div>
:
<div className='row'>
<div className='col-md-6'><Label>To</Label></div>
<div className='w-50'><Label>{this.props.SendToDefaultItems.length > 0 ?
 this.props.SendToDefaultItems.map((team, index) =>
<span>{team}{index!=this.props.SendToDefaultItems.length-1?',':null}</span>):null}</Label></div>

</div>}

</div>








{/* <div className='row'>
<div className='col-md-6'><Label className='font-weight-bold w-25'> To </Label></div>
<div className='w-50'>

{this.props.SendToUserItems.length > 0 ? this.props.SendToUserItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
</div> */}
<div>

{this.props.CopyToDefaultItems.includes(null) == true || this.props.CopyToDefaultItems.includes(undefined) == true || this.props.CopyToDefaultItems.includes("")==true?
<div className='row'>
<div className='col-md-6'><Label>Copy To:</Label></div>
  <div className='w-50'>{this.props.CopyToText}</div>
</div>
:
<div className='row'>
<div className='col-md-6'><Label> Copy To:</Label></div>
<div className='w-50'><Label>{this.props.CopyToDefaultItems.length > 0 ? this.props.CopyToDefaultItems.map((team, index) =>
<span>{team}{index!=this.props.CopyToDefaultItems.length-1?',':null}</span>):null}</Label></div>

</div>}

</div>
{/* <div className='row'>
<div className='col-md-6'><Label className='font-weight-bold w-25'> Copy To </Label></div>
<div className='w-50'>
{this.props.CopyToUserItems.length > 0 ? this.props.CopyToUserItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
</div> */}



<div>

{this.props.BlindCopyToDefaultItems.includes(null) == true || this.props.BlindCopyToDefaultItems.includes(undefined) == true || this.props.BlindCopyToDefaultItems.includes("")==true?
<div className='row'>
<div className='col-md-6'><Label>Blind Copy To:</Label></div>
  <div className='w-50'><Label>{this.props.BlindCopyToText}</Label></div>

</div>
:
<div className='row'>
<div className='col-md-6'><Label>Blind Copy To:</Label></div>
<div className='w-50'><Label>{this.props.BlindCopyToDefaultItems.length > 0 ? this.props.BlindCopyToDefaultItems.map((team, index) =>
<span>{team}{index!=this.props.BlindCopyToDefaultItems.length-1?',':null}</span>):null}</Label></div>

</div>}

</div>
{/* <div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold w-25'> Blind Copy To </Label>
{this.props.BlindCopyToUserItems.length > 0 ? this.props.BlindCopyToUserItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
</div> */}

<div>

{this.props.FromDefaultItems.includes(null) == true || this.props.FromDefaultItems.includes(undefined) == true || this.props.FromDefaultItems.includes("")==true?
<div className='row'>
<div className='col-md-6'><Label>From:</Label></div>
  <div className='w-50'>{this.props.FromText}</div>
</div>
:
<div className='row'>
<div className='col-md-6'><Label>From:</Label></div>
<div className='w-50'><Label>{this.props.FromDefaultItems.length > 0 ? this.props.FromDefaultItems.map((team, index) =>
<span>{team}{index!=this.props.FromDefaultItems.length-1?' , ':null}</span>):null}</Label></div>

</div>}

</div>
{/* <div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold w-25'> From </Label>
{this.props.FromUserItems.length > 0 ? this.props.FromUserItems.map((team, index) =>
<span>{team}</span>
):null}

</div>
</div> */}
<div className='row'>
<div className='col-md-6'><Label className='font-weight w-25'> Date</Label></div>
   {/* <Label className='font-weight-bold w-25'> Date</Label><span>{this.props.Date!=undefined&&this.props.Date!=''&&this.props.Date!=null?this.props.Date.toUTCString():null}</span> */}
<div className='w-50'><Label><span>{this.props.Date!=undefined&&this.props.Date!=''&&this.props.Date!=null?moment(this.props.Date).format('L hh:mm A'):null}</span>
</Label>

</div>
</div>
<div className='row'>
<div className='col-md-6'> <Label className='font-weight w-25'> Subject </Label></div>
<div className='w-50'><span>{this.props.Subject}</span></div>
</div>
</div>

<div className='border p-3 mt-1'>
<div className='row'>
<div className='col-md-12'>
 <Label className='font-weight-bold w-25'>Message</Label><span><div dangerouslySetInnerHTML={{ __html: this.props.Body }}></div></span>
</div>
</div>
</div>

<div className='border p-3 mt-2'>
<div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold'> Attachments </Label>
<div>
{/* {this.bindAttachmentFileNames()} */}
<div className="row">
                  <div className="col-md-12">
                    {this.props.FormAttachmentNames !== undefined &&
                    this.props.FormAttachmentNames !== null
                      ? this.props.FormAttachmentNames.map((item) => (
                          <span>
                            <Link
                              key={item.FileName}
                              onClick={() =>
                                window.open(
                                  item.ServerRelativePath.DecodedUrl,
                                  "_blank"
                                )
                              }
                            >
                              {item.FileName}
                            </Link>
                            {/* {uniqueId == 0 ? null : (
                              <IconButton
                                className="mt-1"
                                iconProps={{ iconName: "Download" }}
                                title="Download"
                                ariaLabel="Download"
                                onClick={() =>
                                  (window.location.href =
                                    this.props.context.pageContext.web
                                      .absoluteUrl +
                                    "/_layouts/download.aspx?sourceurl=" +
                                    item.ServerRelativePath.DecodedUrl)
                                }
                              />
                            )} */}

                            <IconButton
                              className="mt-1"
                              iconProps={{ iconName: "Delete" }}
                              title="Delete"
                              ariaLabel="Delete"
                              onClick={() => this.addDeleteFiles(item.FileName)}
                            />
                          </span>
                        ))
                      : null}
                  </div>
                </div>

</div>
</div>
</div>
</div>
<div className='border p-3 mt-1'>
<div className='row'>
<div className='col-md-6'> <Label className='font-weight w-25'>Type:</Label></div>
<div className='w-50'><span>{this.props.NotesType}</span></div>
</div>
</div>
</div>

)
}
}